
jQuery(document).ready(function($) {
    // Image upload functionality
    $(".upload-image-button").click(function(e) {
        e.preventDefault();
        
        var targetInput = $(this).data("target");
        var image = wp.media({
            title: "Upload Image",
            multiple: false
        }).open().on("select", function() {
            var uploaded_image = image.state().get("selection").first();
            var image_url = uploaded_image.toJSON().url;
            
            // Update input field
            $("#" + targetInput).val(image_url);
            
            // Update preview
            $("#" + targetInput + "_preview").show().find("img").attr("src", image_url);
        });
    });
    
    // Remove image functionality
    $(".remove-image, .remove-image-button").click(function() {
        var targetInput = $(this).data("target");
        $("#" + targetInput).val("");
        $("#" + targetInput + "_preview").hide();
    });
    
    // Category selection
    $(".category-checkbox").change(function() {
        updateCategoryDisplay();
    });
    
    function updateCategoryDisplay() {
        var selectedCategories = [];
        $(".category-checkbox:checked").each(function() {
            selectedCategories.push($(this).val());
        });
        
        $("#selected_categories").val(selectedCategories.join(","));
    }
    
    // Initialize on page load
    updateCategoryDisplay();
});
        