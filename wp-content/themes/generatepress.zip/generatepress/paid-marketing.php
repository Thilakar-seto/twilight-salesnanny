<?php
   /*
   Template Name: Paid Marketing
   */
?>
<html>
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
<body>    
      <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/earned-media.non-critical.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
      <noscript>
            <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/earned-media.non-critical.css" />
      </noscript>
    <div>
        <style>
            .channel-card img,.illustration-column img,.process-diagram img{max-width:100%;height:auto}.hero-wrapper{background-color:#fdf3f3;width:100%}.hero-section{padding:80px 20px;min-height:600px;display:flex;align-items:center;margin-top:80px;width:100%;box-sizing:border-box}.hero-container{display:flex;align-items:center;justify-content:space-between;gap:12rem;width:100%;max-width:1250px;margin:0 auto}.hero-content{max-width:600px;flex:1}.hero-title{font-size:54px;line-height:1.2;margin-bottom:24px;color:#1a1a1a}.hero-title span{background:linear-gradient(120deg,gold 0,gold 100%);background-repeat:no-repeat;background-size:100% .4em;background-position:0 88%}.hero-description{font-size:1.25rem;line-height:1.6;color:#4a4a4a;margin-bottom:32px}.hero-cta{display:inline-block;cursor:pointer;background-color:#c82333;color:#fff;padding:.875rem 1.5rem;text-decoration:none;border-radius:4px;font-weight:600;transition:background-color .3s;box-shadow:rgba(0,0,0,.02) 0 1px 3px 0,rgba(27,31,35,.15) 0 0 0 1px}.channel-card,.process-diagram{border-radius:8px;padding:40px}.hero-image{flex:1;max-width:500px;aspect-ratio:1;position:relative;display:flex;align-items:center;justify-content:center}.hero-image img{width:100%;height:100%;object-fit:contain;position:relative}.channels-section,.features-section,.quotes-section,.sales-process-section{padding:80px 20px;width:100%;box-sizing:border-box}.channels-header,.feature-item{margin-bottom:60px}.channels-title{font-size:48px;font-weight:700;margin-bottom:20px;color:#1a1a1a}.channels-description{font-size:19px;line-height:1.6;color:#000;max-width:600px}.channels-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:30px;width:100%;max-width:1250px;margin:0 auto}.quotes-content,.sales-process-content{gap:60px;box-sizing:border-box;display:flex;width:100%}.channel-card{background:#f8f9fa;display:flex;flex-direction:column;align-items:center;text-align:center;padding:20px;box-sizing:border-box}.channel-card h3{font-size:28px;font-weight:600;margin:20px 0 10px;color:#1a1a1a}.channel-card p{font-size:17px;line-height:1.5;color:#4a4a4a;margin-bottom:20px}.channel-card img{border-radius:4px;max-height:95px;width:auto;object-fit:contain}.channels-header,.quotes-header,.sales-process-header{width:100%;max-width:1250px;margin:0 auto 60px;box-sizing:border-box}.sales-process-title{font-size:48px;line-height:1.2;font-weight:600;color:#1a1a1a;margin-bottom:24px}.quotes-description,.sales-process-description{font-size:1.125rem;line-height:1.6;color:#4a4a4a}.sales-process-content{background-color:#fdf3f3;align-items:flex-start;padding:40px;max-width:1250px;margin:0 auto}.features-column,.features-list{flex:1;max-width:400px}.feature-item:last-child,.quote-feature:last-child{margin-bottom:0}.feature-title{font-size:1.75rem;font-weight:600;color:#1a1a1a;margin-bottom:16px}.feature-description{font-size:1.125rem;line-height:1.5;color:#4a4a4a;margin-bottom:16px}.process-diagram{flex:1.5;min-height:600px;display:flex;align-items:center;justify-content:center}.quotes-title{font-size:3rem;line-height:1.2;font-weight:600;color:#1a1a1a;margin-bottom:24px}.quotes-content{align-items:center;background-color:#e8f5f0;border-radius:12px;padding:60px;position:relative;overflow:hidden;max-width:1250px;margin:0 auto}.features-column{position:relative;z-index:2}.quote-feature{margin-bottom:40px}.quote-feature-title{font-size:1.75rem;font-weight:600;color:#1a1a1a;margin-bottom:12px}.quote-feature-description{font-size:1rem;line-height:1.5;color:#4a4a4a;margin-bottom:16px}.feature-name,.features-title{font-weight:600;color:#1a1a1a}.illustration-column{flex:1;display:flex;justify-content:center;align-items:center;position:relative;z-index:1}.features-title{font-size:28px;line-height:1.2;text-align:center;margin-bottom:60px}.features-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:24px;width:100%;max-width:1200px;margin:0 auto}.feature-card{background:0 0;padding:32px 24px;border-radius:8px;text-align:center;transition:transform .3s;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;aspect-ratio:1}.feature-card:first-child{background-color:#ffe4e1}.feature-icon{width:48px;height:48px;margin-bottom:16px}.feature-name{font-size:1.25rem;margin:0}@media (max-width:968px){.hero-container{flex-direction:column;text-align:center;gap:2rem}.hero-content{order:1}.hero-section{min-height:400px;padding:60px 10px 40px}.hero-image{order:2;aspect-ratio:1/1;min-height:220px;max-width:320px;width:100%;margin:0 auto;height:auto;display:flex;align-items:center;justify-content:center}.hero-image img{width:100%;height:auto;max-height:320px;object-fit:contain;display:block}.hero-title{font-size:2rem}.hero-content{max-width:100%}}@media (max-width:1024px){.channels-header,.quotes-header,.sales-process-header{padding:0 20px}.quotes-content,.sales-process-content{padding:40px 20px;flex-direction:column}.features-column,.features-list{max-width:100%}.process-diagram{width:100%}.quotes-content{flex-direction:column}.illustration-column{margin-top:40px}.features-grid{grid-template-columns:repeat(3,1fr);gap:20px}}@media (max-width:768px){.channels-grid{grid-template-columns:1fr}.channels-title{font-size:2rem}.channel-card{height:auto;min-height:350px}.channel-card h3{font-size:24px}.channel-card p{font-size:16px}.channel-card img{max-height:150px}.quotes-title,.sales-process-title{font-size:2.5rem}.feature-title,.quote-feature-title{font-size:1.5rem}.process-diagram{padding:20px;min-height:400px}.features-grid{grid-template-columns:repeat(2,1fr);gap:16px}.features-title{font-size:2rem;margin-bottom:40px}}@media (max-width:480px){.channels-section,.features-section,.hero-section,.quotes-section,.sales-process-section{padding:50px 20px!important}.channels-title,.features-title,.hero-title,.quotes-title,.sales-process-title{font-size:24px}.hero-description,.quotes-description,.sales-process-description{font-size:18px}.hero-container{flex-direction:column;text-align:center;gap:2rem}.channel-card{height:auto;min-height:400px}.channel-card img{width:100%;height:auto}.features-grid{grid-template-columns:1fr;max-width:280px;margin:0 auto}.feature-card{padding:24px}.hero-section{min-height:320px;padding:40px 5px 30px}.hero-image{min-height:160px;max-width:200px}.hero-title{font-size:1.5rem}}
        </style>
        <?php salesnanny_nav_header(); ?>
        <div class="hero-wrapper">
            <section class="hero-section">
                <div class="hero-container">
                    <div class="hero-content">
                        <h1 class="hero-title">
                        <span>Accelerate Your Marketing Success</span> with Our Paid Marketing Solutions
                        </h1>
                        <p class="hero-description">
                            We help you reach your target audience quickly and effectively with paid advertising on Google, social media, and other platforms. Get your message seen by the right people.
                        </p>
                        <a class="calendly-trigger hero-cta">Schedule a Call</a>
                    </div>
                    <div class="hero-image">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/paid-media/paid-header.png" alt="Rocket illustration representing accelerated marketing growth" fetchpriority="high" width="458" height="458">
                    </div>
                </div>
            </section>
        </div>
        <section class="channels-section">
            <div class="channels-header">
                <h2 class="channels-title">Your Gateway to Paid Advertising Success</h2>
                <p class="channels-description">We ensure your message is seen by the right people at the right time. Take your business to the next level with our Paid Marketing solutions.</p>
            </div>
            
            <div class="channels-grid">
                <!-- CRM Mobile Card -->
                <div class="channel-card">
                    <h3>Paid Search</h3>
                    <p>Show your ads on search engines when people look for what you offer. We help you reach customers who are actively searching for your products or services.</p>
                    <!-- <a href="#" class="watch-video-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                            <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                        </svg>
                        Watch a video
                    </a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/paid-media/paid-search.png" alt="Search engine optimization icon representing paid search advertising" loading="lazy" width="95" height="95">
                </div>

                <!-- Email Card -->
                <div class="channel-card">
                    <h3>Paid Social</h3>
                    <p>Show your ads on social media sites to reach more people. We help you find the right audience for your ads and get them interested in your brand.</p>
                    <!-- <a href="#" class="watch-video-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                            <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                        </svg>
                        Watch a video
                    </a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/paid-media/paid-social.png" alt="Social media marketing icon representing paid social advertising" loading="lazy" width="95" height="95">
                </div>

                <!-- Telephony Card -->
                <div class="channel-card">
                    <h3>Paid Marketing Strategy</h3>
                    <p>Plan your paid ads to get the best results. We help you decide where to spend money and how to reach your goals with paid advertising.</p>
                    <!-- <a href="#" class="learn-more-link">Learn more</a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/paid-media/paid-marketing.png" alt="Marketing strategy icon representing paid marketing planning" loading="lazy" width="95" height="95">
                </div>

                <!-- Social Media Card -->
                <div class="channel-card">
                    <h3>Marketplace Optimization</h3>
                    <p>Make your products easier to find on online stores. We help your products show up higher so more customers will see and buy them.</p>
                    <!-- <a href="#" class="watch-video-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                            <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                        </svg>
                        Watch a video
                    </a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/paid-media/market-place.png" alt="Online marketplace icon representing marketplace optimization" loading="lazy" width="95" height="95">
                </div>
            </div>
        </section>
        <section class="sales-process-section">
            <div class="sales-process-header">
                <h2 class="sales-process-title">Your Partner for Paid Marketing Success</h2>
                <p class="sales-process-description">We don't just run ads. We build strategic campaigns with a deep understanding of your business and your customers. Our focus is on driving measurable results and maximizing your ROI.</p>
            </div>
            <div class="sales-process-content">
                <div class="features-list">
                    <div class="feature-item">
                        <h3 class="feature-title">Data-Driven Targeting</h3>
                        <p class="feature-description">We use advanced analytics to identify your ideal customers and reach them with highly targeted ads. This ensures that your budget is spent efficiently and effectively.</p>
                        <!-- <a href="#" class="feature-link">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                                <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                            </svg>
                            Watch a video
                        </a> -->
                    </div>
                    <div class="feature-item">
                        <h3 class="feature-title">Transparent Reporting</h3>
                        <p class="feature-description">We provide detailed reports that show you exactly how your campaigns are performing. You'll have full visibility into your ad spend and ROI.</p>
                        <!-- <a href="#" class="learn-more">Learn more</a> -->
                    </div>
                    <div class="feature-item">
                        <h3 class="feature-title">Expert Campaign Management</h3>
                        <p class="feature-description">Our team of Paid Marketing experts has a proven track record of success. We stay up-to-date with the latest trends and technologies to ensure that your campaigns are always optimized.</p>
                        <!-- <a href="#" class="feature-link">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                                <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                            </svg>
                            Watch a video
                        </a> -->
                    </div>
                </div>
                <div class="process-diagram">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/paid-media/paid-proven.png" alt="Visual representation of our proven paid marketing process" loading="lazy" width="670" height="670">
                </div>
            </div>
        </section>
        <section class="features-section">
            <h2 class="features-title">See What Else You Can Do with Salesnanny</h2>
            <div class="features-grid">
                <a href="<?php echo SN_HTTP_URL; ?>organic-marketing/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/organic-marketing-tab.png" alt="Icon representing organic marketing services" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Organic Marketing</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>website-development/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/web-development-tab.png" alt="Icon representing website development services" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Website Development</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>branding/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/branding-tab.png" alt="Icon representing branding services" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Branding</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>inside-sales/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/inside-sales-tab.png" alt="Icon representing inside sales services" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Inside Sales</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>creative/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/creative-tab.png" alt="Icon representing creative services" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Creative</h3>
                    </div>
                </a>
            </div>
        </section>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>
