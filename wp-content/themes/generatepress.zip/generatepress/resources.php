<?php
/*
Template Name: Resources
*/
?>
<html>
<body>
    <div>
        <?php salesnanny_nav_header(); ?>
        <style>
            .resource-hero {
                background-color: #FFD440;
                padding: 80px 20px;
                text-align: center;
                width: 100%;
                margin-top: 80px;
            }

            .resource-hero__title {
                font-size: clamp(2.5rem, 5vw, 4rem);
                color: #000;
                margin-bottom: 24px;
                font-weight: bold;
            }

            .resource-hero__description {
                font-size: clamp(1rem, 2vw, 1.25rem);
                color: #000;
                max-width: 800px;
                margin: 0 auto;
                line-height: 1.5;
            }
        </style>
        <section class="resource-hero">
            <h1 class="resource-hero__title">Salesnanny Resource Page</h1>
            <p class="resource-hero__description">Find help materials like how-to guides, webinars, and courses on all the services available in Zoho One.</p>
        </section>

        <nav class="resource-nav" id="resourceNav">
            <ul class="resource-nav__list">
                <li class="resource-nav__item">
                    <a href="javascript:void(0)" data-tab="product-help" class="resource-nav__link resource-nav__link--active">
                        <span class="resource-nav__text">Product Help</span>
                    </a>
                </li>
                <li class="resource-nav__item">
                    <a href="javascript:void(0)" data-tab="app-resources" class="resource-nav__link">
                        <span class="resource-nav__text">App Resources</span>
                    </a>
                </li>
                <li class="resource-nav__item">
                    <a href="javascript:void(0)" data-tab="events" class="resource-nav__link">Events</a>
                </li>
                <li class="resource-nav__item">
                    <a href="javascript:void(0)" data-tab="webinar" class="resource-nav__link">Webinar</a>
                </li>
                <li class="resource-nav__item">
                    <a href="javascript:void(0)" data-tab="training" class="resource-nav__link">Training</a>
                </li>
                <li class="resource-nav__item">
                    <a href="javascript:void(0)" data-tab="blog" class="resource-nav__link">Blog</a>
                </li>
            </ul>
        </nav>
        <style>
            .resource-nav {
                width: 100%;
                background: linear-gradient(to right, #f8f9fa, #ffffff);
                border-bottom: 2px solid #f0f0f0;
                box-shadow: 0 2px 15px rgba(0,0,0,0.03);
                margin-bottom: 40px;
                padding: 0 20px;
                position: relative;
                z-index: 1000;
            }

            .resource-nav--sticky {
                position: fixed;
                top: 80px;
                left: 0;
                right: 0;
                margin-bottom: 0;
            }

            /* @keyframes slideDown {
                from {
                    transform: translateY(-100%);
                }
                to {
                    transform: translateY(0);
                }
            } */

            .resource-nav__list {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0;
                list-style: none;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 8px;
            }

            .resource-nav__item {
                margin: 0;
                padding: 0;
            }

            .resource-nav__link {
                display: block;
                padding: 16px 24px;
                color: #555;
                text-decoration: none;
                font-size: 1.1rem;
                font-weight: 500;
                position: relative;
                transition: all 0.3s ease;
                border-radius: 30px;
                margin: 8px 4px;
            }

            .resource-nav__text {
                position: relative;
                z-index: 1;
            }

            .resource-nav__link:hover {
                color: #000;
                background-color: rgba(255, 212, 64, 0.1);
                transform: translateY(-1px);
            }

            .resource-nav__link--active {
                color: #000;
                font-weight: 600;
                background-color: rgba(255, 212, 64, 0.15);
            }

            .resource-nav__link--active::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%);
                width: 30px;
                height: 3px;
                background-color: #FFD440;
                border-radius: 3px;
                transition: width 0.3s ease;
            }

            .resource-nav__link--active:hover::after {
                width: 40px;
            }

            /* Responsive styles */
            @media (max-width: 768px) {
                .resource-nav__list {
                    gap: 5px;
                }

                .resource-nav__link {
                    padding: 12px 20px;
                    font-size: 1rem;
                }
            }

            @media (max-width: 480px) {
                .resource-nav__list {
                    flex-direction: column;
                    align-items: center;
                    padding: 10px 0;
                }

                .resource-nav__link {
                    padding: 12px 24px;
                    width: 200px;
                    text-align: center;
                }
            }
        </style>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const nav = document.getElementById('resourceNav');
                const header = document.querySelector('header'); // Get the header element
                const headerHeight = 80; // Set this to match your header height

                function handleSticky() {
                    if (window.pageYOffset >= headerHeight) {
                        nav.classList.add('resource-nav--sticky');
                        // Adjust the top position to be right below the header
                        nav.style.top = headerHeight + 'px';
                        document.body.style.paddingTop = nav.offsetHeight + 'px';
                    } else {
                        nav.classList.remove('resource-nav--sticky');
                        nav.style.top = '';
                        document.body.style.paddingTop = 0;
                    }
                }

                window.addEventListener('scroll', handleSticky);
            });
        </script>
        
        <div class="content-wrapper">
            <!-- Dynamic side navigation that changes based on active tab -->
            <nav class="side-nav" id="dynamicSideNav">
                <!-- Product Help side nav -->
                <ul class="side-nav__list" data-tab="product-help">
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="getting-started" class="side-nav__link side-nav__link--active">
                            <span class="side-nav__icon">🚀</span>
                            Getting Started
                        </a>
                    </li>
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="admin-guides" class="side-nav__link">
                            <span class="side-nav__icon">⚙️</span>
                            Admin Guides
                        </a>
                    </li>
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="user-guides" class="side-nav__link">
                            <span class="side-nav__icon">📚</span>
                            User Guides
                        </a>
                    </li>
                </ul>

                <!-- App Resources side nav -->
                <ul class="side-nav__list" data-tab="app-resources" style="display: none;">
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="sales-apps" class="side-nav__link side-nav__link--active">
                            <span class="side-nav__icon">💼</span>
                            Sales 
                        </a>
                    </li>
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="marketing-apps" class="side-nav__link">
                            <span class="side-nav__icon">📢</span>
                            Marketing Apps
                        </a>
                    </li>
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="support-apps" class="side-nav__link">
                            <span class="side-nav__icon">🎯</span>
                            Support Apps
                        </a>
                    </li>
                </ul>

                <!-- Events side nav -->
                <ul class="side-nav__list" data-tab="events" style="display: none;">
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="upcoming-events" class="side-nav__link side-nav__link--active">
                            <span class="side-nav__icon">📅</span>
                            Upcoming Events
                        </a>
                    </li>
                    <li class="side-nav__item">
                        <a href="javascript:void(0)" data-section="past-events" class="side-nav__link">
                            <span class="side-nav__icon">📍</span>
                            Past Events
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="content-sections">
                <section id="product-help" class="content-section">
                    <div class="product-help__grid">
                        <div class="product-help__card">
                            <div class="product-help__icon">
                                <img src="/path-to-rocket-icon.svg" alt="Getting started icon">
                            </div>
                            <h3 class="product-help__title">Getting started</h3>
                            <p class="product-help__description">Everything you need to know to complete the basic implementation of Zoho One for your business.</p>
                            <a href="#" class="product-help__link">LEARN MORE</a>
                        </div>

                        <div class="product-help__card">
                            <div class="product-help__icon">
                                <img src="/path-to-admin-icon.svg" alt="Admin Guides icon">
                            </div>
                            <h3 class="product-help__title">Admin Guides</h3>
                            <p class="product-help__description">The Zoho One Admin Panel enables you to get set up quickly and manage Zoho apps across your organization from one central location.</p>
                            <a href="#" class="product-help__link">LEARN MORE</a>
                        </div>

                        <div class="product-help__card">
                            <div class="product-help__icon">
                                <img src="/path-to-user-icon.svg" alt="User guides icon">
                            </div>
                            <h3 class="product-help__title">User guides</h3>
                            <p class="product-help__description">Helpful information for users to request access to apps and make the most of Zoho One features such as dashboards and widgets.</p>
                            <a href="#" class="product-help__link">LEARN MORE</a>
                        </div>
                    </div>
                </section>

                <section id="app-resources" class="content-section">
                    <h2>Additional Resources</h2>
                    <!-- Add additional resources content -->
                </section>

                <section id="events" class="content-section">
                    <h2>Events</h2>
                    <!-- Add events content -->
                </section>

                <section id="webinar" class="content-section">
                    <h2>Webinar</h2>
                    <!-- Add webinar content -->
                </section>

                <section id="training" class="content-section">
                    <h2>Training</h2>
                    <!-- Add training content -->
                </section>

                <section id="blog" class="content-section">
                    <h2>Blog</h2>
                    <!-- Add blog content -->
                </section>

                <section id="sales-apps" class="content-section">
                    <h2 class="section-title">Explore more on sales</h2>
                    <p class="section-description">Make your best sales by empowering employees with a 360-degree customer view.</p>
                    
                    <div class="sales-apps__grid">
                        <div class="sales-app__card">
                            <div class="sales-app__icon">
                                <img src="/path-to-salesiq-icon.svg" alt="SalesIQ icon">
                            </div>
                            <div class="sales-app__content">
                                <h3 class="sales-app__title">SalesIQ</h3>
                                <p class="sales-app__description">Live-chat app to engage and convert website visitors.</p>
                            </div>
                        </div>

                        <div class="sales-app__card">
                            <div class="sales-app__icon">
                                <img src="/path-to-crm-icon.svg" alt="CRM icon">
                            </div>
                            <div class="sales-app__content">
                                <h3 class="sales-app__title">CRM</h3>
                                <p class="sales-app__description">Convert leads and close sales deals faster.</p>
                            </div>
                        </div>

                        <div class="sales-app__card">
                            <div class="sales-app__icon">
                                <img src="/path-to-forms-icon.svg" alt="Forms icon">
                            </div>
                            <div class="sales-app__content">
                                <h3 class="sales-app__title">Forms</h3>
                                <p class="sales-app__description">Build online forms for every business need.</p>
                            </div>
                        </div>

                        <div class="sales-app__card">
                            <div class="sales-app__icon">
                                <img src="/path-to-bookings-icon.svg" alt="Bookings icon">
                            </div>
                            <div class="sales-app__content">
                                <h3 class="sales-app__title">Bookings</h3>
                                <p class="sales-app__description">Appointment scheduling app for consultations with customers.</p>
                            </div>
                        </div>

                        <div class="sales-app__card">
                            <div class="sales-app__icon">
                                <img src="/path-to-bigin-icon.svg" alt="Bigin icon">
                            </div>
                            <div class="sales-app__content">
                                <h3 class="sales-app__title">Bigin</h3>
                                <p class="sales-app__description">Pipeline management solution for customer-facing teams.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <style>
            .content-wrapper {
                display: flex;
                gap: 40px;
                max-width: 1200px;
                margin: 0 auto;
                padding: 40px 20px;
            }

            .side-nav {
                width: 260px;
                flex-shrink: 0;
                position: sticky;
                top: 120px; /* Adjust based on header + nav height */
                height: fit-content;
            }

            .side-nav__list {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .side-nav__item {
                margin-bottom: 8px;
            }

            .side-nav__link {
                display: flex;
                align-items: center;
                padding: 12px 16px;
                color: #555;
                text-decoration: none;
                border-radius: 8px;
                transition: all 0.3s ease;
                font-weight: 500;
            }

            .side-nav__link:hover {
                background-color: rgba(255, 212, 64, 0.1);
                color: #000;
            }

            .side-nav__link--active {
                background-color: rgba(255, 212, 64, 0.15);
                color: #000;
                font-weight: 600;
            }

            .side-nav__icon {
                margin-right: 12px;
                font-size: 1.2rem;
            }

            .content-sections {
                flex-grow: 1;
                min-width: 0; /* Prevents flex item from overflowing */
            }

            .content-section {
                display: none;
                animation: fadeIn 0.3s ease-in-out;
            }

            .content-section.active {
                display: block;
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            /* Responsive styles */
            @media (max-width: 992px) {
                .content-wrapper {
                    gap: 30px;
                }

                .side-nav {
                    width: 220px;
                }
            }

            @media (max-width: 768px) {
                .content-wrapper {
                    flex-direction: column;
                }

                .side-nav {
                    width: 100%;
                    position: relative;
                    top: 0;
                    margin-bottom: 30px;
                }

                .side-nav__list {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                }

                .side-nav__item {
                    margin-bottom: 0;
                    flex: 1 1 calc(50% - 5px);
                }

                .side-nav__link {
                    text-align: center;
                    justify-content: center;
                }
            }

            @media (max-width: 480px) {
                .side-nav__item {
                    flex: 1 1 100%;
                }
            }

            /* Add these styles for product help cards */
            .product-help__grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 30px;
                padding: 20px 0;
            }

            .product-help__card {
                background: #fff;
                border-radius: 12px;
                padding: 30px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .product-help__card:hover {
                transform: translateY(-5px);
                box-shadow: 0 6px 25px rgba(0, 0, 0, 0.12);
            }

            .product-help__icon {
                width: 60px;
                height: 60px;
                margin-bottom: 20px;
            }

            .product-help__icon img {
                width: 100%;
                height: 100%;
                object-fit: contain;
            }

            .product-help__title {
                font-size: 1.5rem;
                color: #000;
                margin-bottom: 15px;
                font-weight: 600;
            }

            .product-help__description {
                color: #555;
                line-height: 1.6;
                margin-bottom: 20px;
            }

            .product-help__link {
                display: inline-block;
                color: #000;
                font-weight: 600;
                text-decoration: none;
                padding: 8px 0;
                position: relative;
            }

            .product-help__link::after {
                content: '';
                position: absolute;
                bottom: 0;
                left: 0;
                width: 0;
                height: 2px;
                background-color: #FFD440;
                transition: width 0.3s ease;
            }

            .product-help__link:hover::after {
                width: 100%;
            }

            @media (max-width: 768px) {
                .product-help__grid {
                    grid-template-columns: 1fr;
                    gap: 20px;
                }
            }

            .section-title {
                font-size: 2.5rem;
                color: #000;
                margin-bottom: 16px;
                font-weight: bold;
            }

            .section-description {
                font-size: 1.1rem;
                color: #555;
                margin-bottom: 40px;
                max-width: 800px;
            }

            .sales-apps__grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 24px;
                margin-top: 32px;
            }

            .sales-app__card {
                display: flex;
                align-items: flex-start;
                padding: 24px;
                background: #fff;
                border-radius: 12px;
                box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .sales-app__card:hover {
                transform: translateY(-4px);
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.12);
            }

            .sales-app__icon {
                width: 48px;
                height: 48px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 20px;
                flex-shrink: 0;
                background-color: #f5f5f5;
            }

            .sales-app__icon img {
                width: 24px;
                height: 24px;
                object-fit: contain;
            }

            .sales-app__content {
                flex-grow: 1;
            }

            .sales-app__title {
                font-size: 1.25rem;
                color: #000;
                margin-bottom: 8px;
                font-weight: 600;
            }

            .sales-app__description {
                color: #555;
                line-height: 1.5;
                font-size: 0.95rem;
            }

            /* Responsive styles */
            @media (max-width: 768px) {
                .sales-apps__grid {
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 16px;
                }

                .sales-app__card {
                    padding: 20px;
                }
            }

            @media (max-width: 480px) {
                .sales-app__card {
                    flex-direction: row;
                    align-items: center;
                }

                .sales-app__icon {
                    width: 40px;
                    height: 40px;
                    margin-right: 16px;
                }

                .sales-app__icon img {
                    width: 20px;
                    height: 20px;
                }

                .sales-app__title {
                    font-size: 1.1rem;
                    margin-bottom: 4px;
                }

                .sales-app__description {
                    font-size: 0.9rem;
                }
            }
        </style>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const mainNavLinks = document.querySelectorAll('.resource-nav__link');
                const sideNavLists = document.querySelectorAll('.side-nav__list');
                const sideNavLinks = document.querySelectorAll('.side-nav__link');
                const contentSections = document.querySelectorAll('.content-section');

                // Function to update side navigation and content sections
                function updateSideNav(tabId) {
                    // Hide all side nav lists
                    sideNavLists.forEach(list => {
                        list.style.display = 'none';
                    });

                    // Show the relevant side nav list
                    const relevantList = document.querySelector(`.side-nav__list[data-tab="${tabId}"]`);
                    if (relevantList) {
                        relevantList.style.display = 'block';
                    }

                    // Update active state of main nav links
                    mainNavLinks.forEach(link => {
                        link.classList.remove('resource-nav__link--active');
                        if (link.getAttribute('data-tab') === tabId) {
                            link.classList.add('resource-nav__link--active');
                        }
                    });

                    // Show/hide relevant content sections
                    contentSections.forEach(section => {
                        if (section.id === tabId) {
                            section.style.display = 'block';
                        } else {
                            section.style.display = 'none';
                        }
                    });
                }

                // Function to update active side nav link
                function updateActiveSideNavLink(clickedLink) {
                    // Find all side nav links within the same list
                    const sideNavList = clickedLink.closest('.side-nav__list');
                    const sideNavLinksInList = sideNavList.querySelectorAll('.side-nav__link');
                    
                    // Remove active class from all links in the list
                    sideNavLinksInList.forEach(link => {
                        link.classList.remove('side-nav__link--active');
                    });
                    
                    // Add active class to clicked link
                    clickedLink.classList.add('side-nav__link--active');
                }

                // Handle main navigation clicks
                mainNavLinks.forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        const tabId = link.getAttribute('data-tab');
                        updateSideNav(tabId);
                    });
                });

                // Handle side navigation clicks
                sideNavLinks.forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        updateActiveSideNavLink(link);
                        // Here you can add logic to show/hide content sections based on data-section
                    });
                });

                // Show initial content (Product Help)
                updateSideNav('product-help');
            });
        </script>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>