<?php
/**
 * Template Name: Website Performance & SEO Analyzer
 * 
 * A comprehensive website analysis tool that evaluates:
 * - Page Speed (Core Web Vitals)
 * - Mobile-Friendliness
 * - SEO Optimization
 * - Security
 * - Accessibility
 * - Best Practices
 * 
 * @package GeneratePress
 */

get_header(); ?>

<div class="website-analyzer-container">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="analyzer-header">
                    <h1>Website Performance & SEO Analyzer</h1>
                    <p>Get a comprehensive analysis of your website's performance, SEO, security, and more.</p>
                </div>

                <div class="analyzer-form-section">
                    <div class="form-card">
                        <h3>Enter Your Website Details</h3>
                        <form id="website-analyzer-form">
                            <div class="form-group">
                                <label for="website_url">Website URL *</label>
                                <input type="url" id="website_url" name="website_url" placeholder="https://example.com" required>
                            </div>
                            <div class="form-group">
                                <label for="user_email">Your Email *</label>
                                <input type="email" id="user_email" name="user_email" placeholder="your@email.com" required>
                            </div>
                            <button type="submit" class="analyze-btn">
                                <span class="btn-text">Analyze Website</span>
                                <span class="btn-loading" style="display: none;">
                                    <i class="fas fa-spinner fa-spin"></i> Analyzing...
                                </span>
                            </button>
                        </form>
                    </div>
                </div>

                <div id="analysis-results" class="results-section" style="display: none;">
                    <div class="overall-score-section">
                        <h3>Overall Performance Score</h3>
                        <div class="score-circle">
                            <div class="score-number" id="overall-score">-</div>
                            <div class="score-label">/100</div>
                        </div>
                    </div>

                    <div class="categories-grid">
                        <div class="category-card" id="page-speed-card">
                            <div class="category-header">
                                <h4>Page Speed</h4>
                                <div class="category-score" id="page-speed-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="page-speed-description">Loading speed analysis</p>
                                <div class="issues-section">
                                    <h5>Issues Found:</h5>
                                    <ul id="page-speed-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                    <h5>Suggestions:</h5>
                                    <ul id="page-speed-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="mobile-card">
                            <div class="category-header">
                                <h4>Mobile Friendliness</h4>
                                <div class="category-score" id="mobile-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="mobile-description">Mobile responsiveness evaluation</p>
                                <div class="issues-section">
                                    <h5>Issues Found:</h5>
                                    <ul id="mobile-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                    <h5>Suggestions:</h5>
                                    <ul id="mobile-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="seo-card">
                            <div class="category-header">
                                <h4>SEO Optimization</h4>
                                <div class="category-score" id="seo-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="seo-description">Search engine optimization analysis</p>
                                <div class="issues-section">
                                    <h5>Issues Found:</h5>
                                    <ul id="seo-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                    <h5>Suggestions:</h5>
                                    <ul id="seo-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="security-card">
                            <div class="category-header">
                                <h4>Security</h4>
                                <div class="category-score" id="security-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="security-description">Security assessment</p>
                                <div class="issues-section">
                                    <h5>Issues Found:</h5>
                                    <ul id="security-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                    <h5>Suggestions:</h5>
                                    <ul id="security-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="accessibility-card">
                            <div class="category-header">
                                <h4>Accessibility</h4>
                                <div class="category-score" id="accessibility-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="accessibility-description">Accessibility compliance check</p>
                                <div class="issues-section">
                                    <h5>Issues Found:</h5>
                                    <ul id="accessibility-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                    <h5>Suggestions:</h5>
                                    <ul id="accessibility-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="best-practices-card">
                            <div class="category-header">
                                <h4>Best Practices</h4>
                                <div class="category-score" id="best-practices-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="best-practices-description">Web development best practices</p>
                                <div class="issues-section">
                                    <h5>Issues Found:</h5>
                                    <ul id="best-practices-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                    <h5>Suggestions:</h5>
                                    <ul id="best-practices-suggestions"></ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="technologies-section">
                        <h3>Detected Technologies</h3>
                        <div class="technologies-grid" id="technologies-grid"></div>
                    </div>

                    <div class="analysis-info">
                        <p><strong>Analysis Date:</strong> <span id="analysis-date">-</span></p>
                        <p><strong>Website Analyzed:</strong> <span id="analyzed-url">-</span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.website-analyzer-container {
    padding: 40px 0;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

.analyzer-header {
    text-align: center;
    color: white;
    margin-bottom: 40px;
}

.analyzer-header h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
    font-weight: 700;
}

.analyzer-header p {
    font-size: 1.1rem;
    opacity: 0.9;
}

.form-card {
    background: white;
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.form-card h3 {
    margin-bottom: 20px;
    color: #333;
    text-align: center;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
}

.form-group input {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e1e5e9;
    border-radius: 8px;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

.form-group input:focus {
    outline: none;
    border-color: #667eea;
}

.analyze-btn {
    width: 100%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 15px;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s ease;
}

.analyze-btn:hover {
    transform: translateY(-2px);
}

.results-section {
    background: white;
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.overall-score-section {
    text-align: center;
    margin-bottom: 40px;
}

.score-circle {
    display: inline-block;
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin: 20px auto;
}

.score-number {
    font-size: 2rem;
    font-weight: bold;
}

.score-label {
    font-size: 0.9rem;
    opacity: 0.8;
}

.categories-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.category-card {
    border: 1px solid #e1e5e9;
    border-radius: 10px;
    padding: 20px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.category-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.category-header h4 {
    margin: 0;
    color: #333;
}

.category-score {
    background: #667eea;
    color: white;
    padding: 5px 12px;
    border-radius: 20px;
    font-weight: bold;
    font-size: 0.9rem;
}

.category-content p {
    color: #666;
    margin-bottom: 15px;
}

.issues-section, .suggestions-section {
    margin-bottom: 15px;
}

.issues-section h5, .suggestions-section h5 {
    color: #333;
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.issues-section ul, .suggestions-section ul {
    margin: 0;
    padding-left: 20px;
}

.issues-section li, .suggestions-section li {
    color: #666;
    margin-bottom: 5px;
    font-size: 0.9rem;
}

.technologies-section {
    margin-top: 30px;
    padding-top: 30px;
    border-top: 1px solid #e1e5e9;
}

.technologies-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.technology-item {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    text-align: center;
}

.technology-name {
    font-weight: bold;
    color: #333;
    margin-bottom: 5px;
}

.technology-version {
    color: #666;
    font-size: 0.9rem;
}

.analysis-info {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #e1e5e9;
    color: #666;
}

.analysis-info p {
    margin-bottom: 5px;
}

@media (max-width: 768px) {
    .analyzer-header h1 {
        font-size: 2rem;
    }
    
    .categories-grid {
        grid-template-columns: 1fr;
    }
    
    .technologies-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#website-analyzer-form').on('submit', function(e) {
        e.preventDefault();
        
        const websiteUrl = $('#website_url').val();
        const userEmail = $('#user_email').val();
        
        if (!websiteUrl || !userEmail) {
            alert('Please fill in all required fields.');
            return;
        }
        
        // Show loading state
        $('.btn-text').hide();
        $('.btn-loading').show();
        $('.analyze-btn').prop('disabled', true);
        
        // Hide previous results
        $('#analysis-results').hide();
        
        // AJAX request
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'analyze_website',
                website_url: websiteUrl,
                user_email: userEmail,
                nonce: '<?php echo wp_create_nonce('website_analyzer_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    displayResults(response.data);
                } else {
                    alert('Error: ' + (response.data.error || 'Analysis failed'));
                }
            },
            error: function() {
                alert('Network error. Please try again.');
            },
            complete: function() {
                // Reset button state
                $('.btn-text').show();
                $('.btn-loading').hide();
                $('.analyze-btn').prop('disabled', false);
            }
        });
    });
    
    function displayResults(data) {
        // Overall score
        $('#overall-score').text(data.overall_score);
        
        // Category scores and details
        Object.keys(data.categories).forEach(function(category) {
            const catData = data.categories[category];
            const categoryId = category.replace('_', '-');
            
            // Update score
            $('#' + categoryId + '-score').text(catData.score);
            
            // Update description
            $('#' + categoryId + '-description').text(catData.description);
            
            // Update issues
            const issuesList = $('#' + categoryId + '-issues');
            issuesList.empty();
            catData.issues.forEach(function(issue) {
                issuesList.append('<li>' + issue + '</li>');
            });
            
            // Update suggestions
            const suggestionsList = $('#' + categoryId + '-suggestions');
            suggestionsList.empty();
            catData.suggestions.forEach(function(suggestion) {
                suggestionsList.append('<li>' + suggestion + '</li>');
            });
        });
        
        // Technologies
        const techGrid = $('#technologies-grid');
        techGrid.empty();
        data.technologies.forEach(function(tech) {
            techGrid.append(`
                <div class="technology-item">
                    <div class="technology-name">${tech.name}</div>
                    <div class="technology-version">${tech.version}</div>
                </div>
            `);
        });
        
        // Analysis info
        $('#analysis-date').text(data.analysis_date);
        $('#analyzed-url').text($('#website_url').val());
        
        // Show results
        $('#analysis-results').show();
        
        // Scroll to results
        $('html, body').animate({
            scrollTop: $('#analysis-results').offset().top - 50
        }, 500);
    }
});
</script>

<?php
// Create database table for storing emails
function create_website_analyzer_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'website_analyzer_leads';
    
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        email varchar(100) NOT NULL,
        website_url text NOT NULL,
        analysis_date datetime DEFAULT CURRENT_TIMESTAMP,
        overall_score int(3),
        ip_address varchar(45),
        user_agent text,
        status varchar(20) DEFAULT 'new',
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Run table creation on theme activation
add_action('after_switch_theme', 'create_website_analyzer_table');

// AJAX handler for website analysis and email storage
add_action('wp_ajax_analyze_website', 'handle_website_analysis');
add_action('wp_ajax_nopriv_analyze_website', 'handle_website_analysis');

function handle_website_analysis() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'website_analyzer_nonce')) {
        wp_die('Security check failed');
    }
    
    $website_url = sanitize_url($_POST['website_url']);
    $user_email = sanitize_email($_POST['user_email']);
    
    if (empty($website_url) || empty($user_email)) {
        wp_send_json_error(['error' => 'Please provide both website URL and email address']);
    }
    
    // Store email and website data
    global $wpdb;
    $table_name = $wpdb->prefix . 'website_analyzer_leads';
    
    $insert_data = [
        'email' => $user_email,
        'website_url' => $website_url,
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
        'status' => 'new'
    ];
    
    $wpdb->insert($table_name, $insert_data);
    
    // Simulate website analysis (replace with actual analysis logic)
    $analysis_result = [
        'overall_score' => rand(60, 95),
        'categories' => [
            'page_speed' => [
                'score' => rand(70, 95),
                'description' => 'Page loading speed analysis',
                'issues' => ['Large images need optimization', 'Enable compression'],
                'suggestions' => ['Optimize images', 'Enable GZIP compression', 'Use CDN']
            ],
            'mobile_friendliness' => [
                'score' => rand(75, 95),
                'description' => 'Mobile responsiveness evaluation',
                'issues' => ['Touch targets too small'],
                'suggestions' => ['Increase touch target size', 'Improve mobile navigation']
            ],
            'seo' => [
                'score' => rand(65, 90),
                'description' => 'Search engine optimization analysis',
                'issues' => ['Missing meta descriptions'],
                'suggestions' => ['Add meta descriptions', 'Optimize title tags', 'Create XML sitemap']
            ],
            'security' => [
                'score' => rand(80, 95),
                'description' => 'Security assessment',
                'issues' => ['HTTPS not enforced'],
                'suggestions' => ['Enable HTTPS', 'Update security headers', 'Regular security audits']
            ],
            'accessibility' => [
                'score' => rand(70, 90),
                'description' => 'Accessibility compliance check',
                'issues' => ['Missing alt text'],
                'suggestions' => ['Add alt text to images', 'Improve color contrast', 'Add ARIA labels']
            ],
            'best_practices' => [
                'score' => rand(75, 95),
                'description' => 'Web development best practices',
                'issues' => ['Console errors detected'],
                'suggestions' => ['Fix JavaScript errors', 'Optimize CSS delivery', 'Minimize HTTP requests']
            ]
        ],
        'technologies' => [
            ['name' => 'WordPress', 'version' => '6.0+'],
            ['name' => 'PHP', 'version' => '8.0+'],
            ['name' => 'MySQL', 'version' => '5.7+'],
            ['name' => 'jQuery', 'version' => '3.6+']
        ],
        'analysis_date' => current_time('Y-m-d H:i:s')
    ];
    
    // Update the stored record with analysis results
    $wpdb->update(
        $table_name,
        ['overall_score' => $analysis_result['overall_score'], 'status' => 'analyzed'],
        ['email' => $user_email, 'website_url' => $website_url],
        ['%d', '%s'],
        ['%s', '%s']
    );
    
    wp_send_json_success($analysis_result);
}

// Add admin menu for managing leads
add_action('admin_menu', 'add_website_analyzer_admin_menu');

function add_website_analyzer_admin_menu() {
    add_menu_page(
        'Website Analyzer Leads',
        'Analyzer Leads',
        'manage_options',
        'website-analyzer-leads',
        'website_analyzer_admin_page',
        'dashicons-chart-area',
        30
    );
}

function website_analyzer_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'website_analyzer_leads';
    
    // Handle status updates
    if (isset($_POST['action']) && $_POST['action'] === 'update_status') {
        $lead_id = intval($_POST['lead_id']);
        $new_status = sanitize_text_field($_POST['new_status']);
        $wpdb->update($table_name, ['status' => $new_status], ['id' => $lead_id]);
    }
    
    // Get leads with pagination
    $per_page = 20;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $per_page;
    
    $leads = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name ORDER BY analysis_date DESC LIMIT %d OFFSET %d",
        $per_page,
        $offset
    ));
    
    $total_leads = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $total_pages = ceil($total_leads / $per_page);
    
    ?>
    <div class="wrap">
        <h1>Website Analyzer Leads</h1>
        
        <div class="tablenav top">
            <div class="alignleft actions">
                <a href="<?php echo admin_url('admin.php?page=website-analyzer-leads&export=csv'); ?>" class="button">Export CSV</a>
            </div>
            <div class="tablenav-pages">
                <?php if ($total_pages > 1): ?>
                    <span class="pagination-links">
                        <?php
                        echo paginate_links([
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total' => $total_pages,
                            'current' => $current_page
                        ]);
                        ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Website URL</th>
                    <th>Score</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($leads as $lead): ?>
                    <tr>
                        <td><?php echo $lead->id; ?></td>
                        <td><?php echo esc_html($lead->email); ?></td>
                        <td><?php echo esc_html($lead->website_url); ?></td>
                        <td>
                            <?php if ($lead->overall_score): ?>
                                <span class="score-badge score-<?php echo $lead->overall_score >= 90 ? 'excellent' : ($lead->overall_score >= 80 ? 'good' : ($lead->overall_score >= 60 ? 'average' : 'poor')); ?>">
                                    <?php echo $lead->overall_score; ?>/100
                                </span>
                            <?php else: ?>
                                <span class="score-badge score-pending">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('M j, Y g:i A', strtotime($lead->analysis_date)); ?></td>
                        <td>
                            <select onchange="updateStatus(<?php echo $lead->id; ?>, this.value)">
                                <option value="new" <?php selected($lead->status, 'new'); ?>>New</option>
                                <option value="contacted" <?php selected($lead->status, 'contacted'); ?>>Contacted</option>
                                <option value="qualified" <?php selected($lead->status, 'qualified'); ?>>Qualified</option>
                                <option value="converted" <?php selected($lead->status, 'converted'); ?>>Converted</option>
                                <option value="lost" <?php selected($lead->status, 'lost'); ?>>Lost</option>
                            </select>
                        </td>
                        <td>
                            <a href="mailto:<?php echo esc_attr($lead->email); ?>" class="button button-small">Email</a>
                            <button onclick="viewDetails(<?php echo $lead->id; ?>)" class="button button-small">View</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div class="tablenav bottom">
            <div class="alignleft actions">
                <span class="displaying-num"><?php echo $total_leads; ?> items</span>
            </div>
        </div>
    </div>
    
    <style>
        .score-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            color: white;
        }
        .score-excellent { background: #28a745; }
        .score-good { background: #17a2b8; }
        .score-average { background: #ffc107; color: #333; }
        .score-poor { background: #dc3545; }
        .score-pending { background: #6c757d; }
    </style>
    
    <script>
        function updateStatus(leadId, newStatus) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="lead_id" value="${leadId}">
                <input type="hidden" name="new_status" value="${newStatus}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
        
        function viewDetails(leadId) {
            // Implement detailed view modal
            alert('Detailed view for lead ID: ' + leadId);
        }
    </script>
    <?php
}

// Handle CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    add_action('admin_init', 'export_website_analyzer_csv');
}

function export_website_analyzer_csv() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'website_analyzer_leads';
    
    $leads = $wpdb->get_results("SELECT * FROM $table_name ORDER BY analysis_date DESC");
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="website-analyzer-leads-' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // CSV headers
    fputcsv($output, ['ID', 'Email', 'Website URL', 'Overall Score', 'Analysis Date', 'Status', 'IP Address']);
    
    // CSV data
    foreach ($leads as $lead) {
        fputcsv($output, [
            $lead->id,
            $lead->email,
            $lead->website_url,
            $lead->overall_score,
            $lead->analysis_date,
            $lead->status,
            $lead->ip_address
        ]);
    }
    
    fclose($output);
    exit;
}

get_footer();
?> 