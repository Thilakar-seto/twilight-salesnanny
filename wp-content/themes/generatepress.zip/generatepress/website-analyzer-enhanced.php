<?php
/**
 * Template Name: Enhanced Website Performance & SEO Analyzer
 * 
 * A comprehensive website analysis tool that evaluates:
 * - Page Speed (Mobile & Desktop)
 * - Core Web Vitals
 * - SEO Optimization
 * - Mobile-Friendliness
 * - Security
 * - Accessibility
 * - Best Practices
 * - PDF Report Generation with Email Collection
 * 
 * @package GeneratePress
 */

// Enqueue jQuery and FontAwesome
function enqueue_analyzer_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
}
add_action('wp_enqueue_scripts', 'enqueue_analyzer_scripts');

// Ensure jQuery is loaded in header for this page
add_action('wp_head', function() {
    if (is_page_template('website-analyzer-enhanced.php')) {
        wp_print_scripts('jquery');
    }
});

get_header(); ?>
<div class="enhanced-website-analyzer-container">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="analyzer-header">
                    <h1>Website Performance & SEO Analyzer</h1>
                    <p>Get a comprehensive analysis of your website's performance, SEO, security, and more. Receive detailed PDF reports via email.</p>
                </div>

                <div class="analyzer-form-section">
                    <div class="form-card">
                        <h3>Enter Your Website URL</h3>
                        <form id="enhanced-website-analyzer-form">
                            <div class="form-group">
                                <label for="website_url">Website URL *</label>
                                <input type="url" id="website_url" name="website_url" placeholder="https://example.com" required>
                            </div>
                            <button type="submit" class="analyze-btn">
                                <span class="btn-text">Analyze Website</span>
                                <span class="btn-loading" style="display: none;">
                                    <i class="fas fa-spinner fa-spin"></i> Analyzing...
                                </span>
                            </button>
                        </form>
                    </div>
                </div>

                <div id="enhanced-analysis-results" class="results-section" style="display: none;">
                    <!-- Overall Performance Summary -->
                    <div class="overall-score-section">
                        <h3>Overall Performance Summary</h3>
                        <div class="score-circle">
                            <div class="score-number" id="overall-score">-</div>
                            <div class="score-label">/100</div>
                        </div>
                        <div class="score-breakdown">
                            <div class="score-item">
                                <span class="score-label">Mobile:</span>
                                <span class="score-value" id="mobile-overall-score">-</span>
                            </div>
                            <div class="score-item">
                                <span class="score-label">Desktop:</span>
                                <span class="score-value" id="desktop-overall-score">-</span>
                            </div>
                        </div>
                        <div class="performance-status">
                            <span class="status-badge" id="status-badge">Analyzing...</span>
                            <p class="status-description" id="status-description">Performance analysis in progress</p>
                        </div>
                    </div>

                    <!-- Key Metrics Dashboard -->
                    <div class="key-metrics-dashboard">
                        <h3>Key Performance Metrics</h3>
                        <div class="metrics-grid">
                            <div class="metric-card">
                                <div class="metric-icon">
                                    <i class="fa-solid fa-tachometer-alt"></i>
                                    </div>
                                <div class="metric-content">
                                    <h4>Page Speed</h4>
                                    <div class="metric-value" id="page-speed-metric">-</div>
                                    <div class="metric-description">Average load time</div>
                                    </div>
                                    </div>
                            <div class="metric-card">
                                <div class="metric-icon">
                                    <i class="fa-solid fa-mobile-screen"></i>
                                    </div>
                                <div class="metric-content">
                                    <h4>Mobile Score</h4>
                                    <div class="metric-value" id="mobile-score-metric">-</div>
                                    <div class="metric-description">Mobile performance</div>
                                </div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-icon">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                    </div>
                                <div class="metric-content">
                                    <h4>SEO Score</h4>
                                    <div class="metric-value" id="seo-score-metric">-</div>
                                    <div class="metric-description">Search optimization</div>
                                    </div>
                                    </div>
                            <div class="metric-card">
                                <div class="metric-icon">
                                    <i class="fa-solid fa-shield-halved"></i>
                                    </div>
                                <div class="metric-content">
                                    <h4>Security Score</h4>
                                    <div class="metric-value" id="security-score-metric">-</div>
                                    <div class="metric-description">Security assessment</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Core Web Vitals Section -->
                    <div class="core-web-vitals-section">
                        <h3>Core Web Vitals Analysis</h3>
                        <div class="vitals-comparison">
                            <div class="vitals-card mobile-vitals">
                                <h4><i class="fa-solid fa-mobile-screen"></i> Mobile Core Web Vitals</h4>
                                <div class="vitals-metrics">
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">First Contentful Paint (FCP)</span>
                                            <span class="vital-status" id="mobile-fcp-status">-</span>
                                        </div>
                                        <div class="vital-value" id="mobile-fcp">-</div>
                                        <div class="vital-description">Time to first contentful paint</div>
                                    </div>
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">Largest Contentful Paint (LCP)</span>
                                            <span class="vital-status" id="mobile-lcp-status">-</span>
                                        </div>
                                        <div class="vital-value" id="mobile-lcp">-</div>
                                        <div class="vital-description">Time to largest contentful paint</div>
                                    </div>
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">Cumulative Layout Shift (CLS)</span>
                                            <span class="vital-status" id="mobile-cls-status">-</span>
                                        </div>
                                        <div class="vital-value" id="mobile-cls">-</div>
                                        <div class="vital-description">Visual stability measure</div>
                                    </div>
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">First Input Delay (FID)</span>
                                            <span class="vital-status" id="mobile-fid-status">-</span>
                                        </div>
                                        <div class="vital-value" id="mobile-fid">-</div>
                                        <div class="vital-description">Interactivity measure</div>
                                    </div>
                                </div>
                            </div>
                            <div class="vitals-card desktop-vitals">
                                <h4><i class="fa-solid fa-desktop"></i> Desktop Core Web Vitals</h4>
                                <div class="vitals-metrics">
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">First Contentful Paint (FCP)</span>
                                            <span class="vital-status" id="desktop-fcp-status">-</span>
                                        </div>
                                        <div class="vital-value" id="desktop-fcp">-</div>
                                        <div class="vital-description">Time to first contentful paint</div>
                                    </div>
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">Largest Contentful Paint (LCP)</span>
                                            <span class="vital-status" id="desktop-lcp-status">-</span>
                                        </div>
                                        <div class="vital-value" id="desktop-lcp">-</div>
                                        <div class="vital-description">Time to largest contentful paint</div>
                                    </div>
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">Cumulative Layout Shift (CLS)</span>
                                            <span class="vital-status" id="desktop-cls-status">-</span>
                                        </div>
                                        <div class="vital-value" id="desktop-cls">-</div>
                                        <div class="vital-description">Visual stability measure</div>
                                    </div>
                                    <div class="vital-metric">
                                        <div class="vital-header">
                                            <span class="vital-label">First Input Delay (FID)</span>
                                            <span class="vital-status" id="desktop-fid-status">-</span>
                                        </div>
                                        <div class="vital-value" id="desktop-fid">-</div>
                                        <div class="vital-description">Interactivity measure</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Detailed Analysis Categories -->
                    <div class="analysis-categories-section">
                        <h3>Detailed Analysis Categories</h3>
                    <div class="categories-grid">
                        <div class="category-card" id="seo-card">
                            <div class="category-header">
                                    <h4><i class="fa-solid fa-magnifying-glass"></i> SEO Optimization</h4>
                                <div class="category-score" id="seo-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="seo-description">Search engine optimization analysis</p>
                                    <div class="category-stats">
                                        <div class="stat-item">
                                            <span class="stat-label">Issues Found:</span>
                                            <span class="stat-value" id="seo-issues-count">-</span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Suggestions:</span>
                                            <span class="stat-value" id="seo-suggestions-count">-</span>
                                        </div>
                                    </div>
                                <div class="issues-section">
                                        <h5>Critical Issues:</h5>
                                    <ul id="seo-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                        <h5>Improvement Suggestions:</h5>
                                    <ul id="seo-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="mobile-card">
                            <div class="category-header">
                                    <h4><i class="fa-solid fa-mobile-screen"></i> Mobile Friendliness</h4>
                                <div class="category-score" id="mobile-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="mobile-description">Mobile responsiveness evaluation</p>
                                    <div class="category-stats">
                                        <div class="stat-item">
                                            <span class="stat-label">Issues Found:</span>
                                            <span class="stat-value" id="mobile-issues-count">-</span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Suggestions:</span>
                                            <span class="stat-value" id="mobile-suggestions-count">-</span>
                                        </div>
                                    </div>
                                <div class="issues-section">
                                        <h5>Critical Issues:</h5>
                                    <ul id="mobile-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                        <h5>Improvement Suggestions:</h5>
                                    <ul id="mobile-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="security-card">
                            <div class="category-header">
                                    <h4><i class="fa-solid fa-shield-halved"></i> Security Assessment</h4>
                                <div class="category-score" id="security-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="security-description">Security assessment</p>
                                    <div class="category-stats">
                                        <div class="stat-item">
                                            <span class="stat-label">Issues Found:</span>
                                            <span class="stat-value" id="security-issues-count">-</span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Suggestions:</span>
                                            <span class="stat-value" id="security-suggestions-count">-</span>
                                        </div>
                                    </div>
                                <div class="issues-section">
                                        <h5>Security Issues:</h5>
                                    <ul id="security-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                        <h5>Security Recommendations:</h5>
                                    <ul id="security-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="accessibility-card">
                            <div class="category-header">
                                    <h4><i class="fa-solid fa-universal-access"></i> Accessibility</h4>
                                <div class="category-score" id="accessibility-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="accessibility-description">Accessibility compliance check</p>
                                    <div class="category-stats">
                                        <div class="stat-item">
                                            <span class="stat-label">Issues Found:</span>
                                            <span class="stat-value" id="accessibility-issues-count">-</span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Suggestions:</span>
                                            <span class="stat-value" id="accessibility-suggestions-count">-</span>
                                        </div>
                                    </div>
                                <div class="issues-section">
                                        <h5>Accessibility Issues:</h5>
                                    <ul id="accessibility-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                        <h5>Accessibility Improvements:</h5>
                                    <ul id="accessibility-suggestions"></ul>
                                </div>
                            </div>
                        </div>

                        <div class="category-card" id="best-practices-card">
                            <div class="category-header">
                                    <h4><i class="fa-solid fa-circle-check"></i> Best Practices</h4>
                                <div class="category-score" id="best-practices-score">-</div>
                            </div>
                            <div class="category-content">
                                <p id="best-practices-description">Web development best practices</p>
                                    <div class="category-stats">
                                        <div class="stat-item">
                                            <span class="stat-label">Issues Found:</span>
                                            <span class="stat-value" id="best-practices-issues-count">-</span>
                                        </div>
                                        <div class="stat-item">
                                            <span class="stat-label">Suggestions:</span>
                                            <span class="stat-value" id="best-practices-suggestions-count">-</span>
                                        </div>
                                    </div>
                                <div class="issues-section">
                                        <h5>Best Practice Issues:</h5>
                                    <ul id="best-practices-issues"></ul>
                                </div>
                                <div class="suggestions-section">
                                        <h5>Best Practice Recommendations:</h5>
                                    <ul id="best-practices-suggestions"></ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Technologies & Stack Analysis -->
                    <div class="technologies-section">
                        <h3>Detected Technologies & Stack</h3>
                        <div class="tech-analysis">
                            <div class="tech-categories">
                                <div class="tech-category">
                                    <h4><i class="fa-solid fa-code"></i> Frontend Technologies</h4>
                                    <div class="tech-tags" id="frontend-tech"></div>
                                </div>
                                <div class="tech-category">
                                    <h4><i class="fa-solid fa-server"></i> Backend Technologies</h4>
                                    <div class="tech-tags" id="backend-tech"></div>
                                </div>
                                <div class="tech-category">
                                    <h4><i class="fa-solid fa-database"></i> Database & CMS</h4>
                                    <div class="tech-tags" id="database-tech"></div>
                                </div>
                                <div class="tech-category">
                                    <h4><i class="fa-solid fa-wrench"></i> Tools & Services</h4>
                                    <div class="tech-tags" id="tools-tech"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Performance Recommendations -->
                    <div class="recommendations-section">
                        <h3>Performance Recommendations</h3>
                        <div class="recommendations-grid">
                            <div class="recommendation-card high-priority">
                                <div class="priority-badge">High Priority</div>
                                <h4>Critical Issues</h4>
                                <ul id="critical-recommendations"></ul>
                            </div>
                            <div class="recommendation-card medium-priority">
                                <div class="priority-badge">Medium Priority</div>
                                <h4>Important Improvements</h4>
                                <ul id="medium-recommendations"></ul>
                            </div>
                            <div class="recommendation-card low-priority">
                                <div class="priority-badge">Low Priority</div>
                                <h4>Optimization Opportunities</h4>
                                <ul id="low-recommendations"></ul>
                            </div>
                        </div>
                    </div>

                    <!-- PDF Report Section -->
                    <div class="pdf-download-section">
                        <div class="pdf-card">
                            <h3><i class="fa-solid fa-file-pdf"></i> Download Comprehensive PDF Report</h3>
                            <p>Get a detailed PDF report with complete analysis, actionable recommendations, and performance insights. Your email will be stored for admin purposes only.</p>
                            <div class="pdf-features">
                                <div class="feature-item">
                                    <i class="fa-solid fa-chart-line"></i>
                                    <span>Detailed Performance Metrics</span>
                                </div>
                                <div class="feature-item">
                                    <i class="fa-solid fa-list-check"></i>
                                    <span>Actionable Recommendations</span>
                                </div>
                                <div class="feature-item">
                                    <i class="fa-solid fa-chart-bar"></i>
                                    <span>Visual Charts & Graphs</span>
                                </div>
                                <div class="feature-item">
                                    <i class="fa-solid fa-clock"></i>
                                    <span>Historical Comparison</span>
                                </div>
                            </div>
                            <div class="pdf-email-form" id="pdf-email-form" style="display: none;">
                                <div class="form-group">
                                    <label for="pdf_email">Your Email Address *</label>
                                    <input type="email" id="pdf_email" name="pdf_email" placeholder="your@email.com" required>
                                    <small class="form-text" style="color: rgba(255,255,255,0.8);">Your email will be stored for admin purposes only</small>
                                </div>
                                <button id="download-pdf-btn" class="pdf-download-btn">
                                    <i class="fa-solid fa-download"></i> Download PDF Report
                                </button>
                            </div>
                            <button id="show-email-form-btn" class="pdf-download-btn">
                                <i class="fa-solid fa-file-pdf"></i> Get PDF Report
                            </button>
                            <div id="pdf-status" class="pdf-status" style="display: none;">
                                <p><i class="fa-solid fa-spinner fa-spin"></i> Generating PDF report...</p>
                            </div>
                        </div>
                    </div>

                    <!-- Analysis Summary -->
                    <div class="analysis-summary">
                        <h3>Analysis Summary</h3>
                        <div class="summary-grid">
                            <div class="summary-item">
                                <div class="summary-icon">
                                    <i class="fa-solid fa-calendar-days"></i>
                    </div>
                                <div class="summary-content">
                                    <h4>Analysis Date</h4>
                                    <p id="analysis-date">-</p>
                </div>
            </div>
                            <div class="summary-item">
                                <div class="summary-icon">
                                    <i class="fa-solid fa-globe"></i>
                                </div>
                                <div class="summary-content">
                                    <h4>Website Analyzed</h4>
                                    <p id="analyzed-url">-</p>
                                </div>
                            </div>
                            <div class="summary-item">
                                <div class="summary-icon">
                                    <i class="fa-solid fa-clock"></i>
                                </div>
                                <div class="summary-content">
                                    <h4>Analysis Duration</h4>
                                    <p id="analysis-duration">-</p>
                                </div>
                            </div>
                            <div class="summary-item">
                                <div class="summary-icon">
                                    <i class="fa-solid fa-list-check"></i>
                                </div>
                                <div class="summary-content">
                                    <h4>Total Issues Found</h4>
                                    <p id="total-issues">-</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Professional Website Analyzer Styling */
.enhanced-website-analyzer-container {
    padding: 40px 0;
    margin: 80px auto 0px;
    background: linear-gradient(135deg, #1F2253 0%, #2a2d6a 25%, #3a1f3a 50%, #c22034 75%, #a81b2b 100%);
    min-height: 100vh;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    position: relative;
    overflow-x: hidden;
}

.enhanced-website-analyzer-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 80%, rgba(194, 32, 52, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(31, 34, 83, 0.1) 0%, transparent 50%);
    pointer-events: none;
}

.analyzer-header {
    text-align: center;
    color: white;
    margin-bottom: 50px;
    position: relative;
    z-index: 2;
}

.analyzer-header h1 {
    font-size: 3rem;
    margin-bottom: 20px;
    font-weight: 700;
    color: white;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.analyzer-header p {
    font-size: 1.2rem;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
    line-height: 1.6;
    color: #e0e6ed;
}

.analyzer-form-section {
    margin-bottom: 50px;
    position: relative;
    z-index: 2;
}

.form-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 16px;
    padding: 40px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    max-width: 600px;
    margin: 0 auto;
    position: relative;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.form-card h3 {
    text-align: center;
    color: #1F2253;
    margin-bottom: 30px;
    font-size: 1.8rem;
    font-weight: 700;
}

.form-group {
    margin-bottom: 25px;
    position: relative;
}

.form-group label {
    display: block;
    margin-bottom: 10px;
    font-weight: 600;
    color: #1F2253;
    font-size: 0.95rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.form-group input {
    width: 100%;
    padding: 16px 20px;
    background: white;
    border: 2px solid #e1e5e9;
    border-radius: 12px;
    font-size: 16px;
    color: #333;
    transition: all 0.3s ease;
}

.form-group input::placeholder {
    color: #999;
}

.form-group input:focus {
    outline: none;
    border-color: #c22034;
    box-shadow: 0 0 0 4px rgba(194, 32, 52, 0.1);
}

.analyze-btn {
    width: 100%;
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    color: white;
    border: none;
    padding: 18px;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    text-transform: uppercase;
    letter-spacing: 1px;
    box-shadow: 0 8px 25px rgba(31, 34, 83, 0.3);
}

.analyze-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 30px rgba(31, 34, 83, 0.4);
}

.analyze-btn:active {
    transform: translateY(-1px);
}

.btn-loading {
    display: none;
}

.results-section {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 16px;
    padding: 40px;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
    margin-top: 40px;
    position: relative;
    z-index: 2;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.overall-score-section {
    text-align: center;
    margin-bottom: 50px;
    padding: 40px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 16px;
    border: 1px solid #e9ecef;
    position: relative;
}

.score-circle {
    width: 180px;
    height: 180px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin: 0 auto 30px;
    color: white;
    box-shadow: 0 15px 30px rgba(31, 34, 83, 0.3);
    position: relative;
    z-index: 2;
}

.score-number {
    font-size: 3rem;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.score-label {
    font-size: 1.1rem;
    opacity: 0.9;
    font-weight: 500;
}

.score-breakdown {
    display: flex;
    justify-content: center;
    gap: 40px;
    margin-top: 30px;
    position: relative;
    z-index: 2;
}

.score-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px 25px;
    background: white;
    border-radius: 12px;
    border: 1px solid #e9ecef;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.score-value {
    font-weight: 700;
    color: #1F2253;
    font-size: 1.2rem;
}

.speed-testing-section {
    margin-bottom: 50px;
}

.speed-testing-section h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
    font-size: 2rem;
    font-weight: 700;
}

.speed-comparison {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.speed-card {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 30px;
    border-left: 4px solid #1F2253;
    transition: all 0.3s ease;
    position: relative;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.speed-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

.speed-card h4 {
    color: #1F2253;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.3rem;
    font-weight: 600;
}

.speed-metrics {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.metric {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #e9ecef;
    transition: all 0.3s ease;
}

.metric:hover {
    background: rgba(31, 34, 83, 0.05);
    border-radius: 8px;
    padding-left: 10px;
    padding-right: 10px;
}

.metric:last-child {
    border-bottom: none;
}

.metric-label {
    font-weight: 500;
    color: #555;
    font-size: 0.95rem;
}

.metric-value {
    font-weight: 700;
    color: #1F2253;
    font-size: 1.1rem;
}

.categories-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(380px, 1fr));
    gap: 30px;
    margin-bottom: 50px;
}

.category-card {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    position: relative;
    border: 1px solid #e9ecef;
}

.category-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}

.category-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding-bottom: 20px;
    border-bottom: 2px solid #f8f9fa;
}

.category-header h4 {
    margin: 0;
    color: #1F2253;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.2rem;
    font-weight: 600;
}

.category-score {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    font-size: 1.3rem;
    color: white;
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
}

.category-score.excellent { 
    background: linear-gradient(135deg, #28a745, #20c997);
}
.category-score.good { 
    background: linear-gradient(135deg, #17a2b8, #6f42c1);
}
.category-score.average { 
    background: linear-gradient(135deg, #ffc107, #fd7e14);
}
.category-score.poor { 
    background: linear-gradient(135deg, #dc3545, #e83e8c);
}

.category-content p {
    color: #666;
    margin-bottom: 25px;
    line-height: 1.6;
}

.issues-section, .suggestions-section {
    margin-bottom: 25px;
}

.issues-section h5, .suggestions-section h5 {
    color: #1F2253;
    margin-bottom: 15px;
    font-size: 1rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.issues-section ul, .suggestions-section ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.issues-section li, .suggestions-section li {
    padding: 12px 0;
    border-bottom: 1px solid #f8f9fa;
    color: #555;
    font-size: 0.95rem;
    line-height: 1.5;
    transition: all 0.3s ease;
}

.issues-section li:hover, .suggestions-section li:hover {
    background: rgba(31, 34, 83, 0.05);
    border-radius: 8px;
    padding-left: 10px;
    margin-left: -10px;
}

.issues-section li:before {
    content: "⚠️ ";
    margin-right: 10px;
    font-size: 1.1rem;
}

.suggestions-section li:before {
    content: "💡 ";
    margin-right: 10px;
    font-size: 1.1rem;
}

.technologies-section {
    margin-bottom: 50px;
}

.technologies-section h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
    font-size: 2rem;
    font-weight: 700;
}

.technologies-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    justify-content: center;
}

.technology-tag {
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    color: white;
    padding: 12px 20px;
    border-radius: 25px;
    font-size: 0.95rem;
    font-weight: 600;
    box-shadow: 0 6px 15px rgba(31, 34, 83, 0.3);
    transition: all 0.3s ease;
}

.technology-tag:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(31, 34, 83, 0.4);
}

.pdf-download-section {
    margin-bottom: 50px;
}

.pdf-card {
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    color: white;
    border-radius: 20px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 20px 40px rgba(31, 34, 83, 0.3);
    position: relative;
}

.pdf-card h3 {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
    font-size: 1.8rem;
    font-weight: 700;
    position: relative;
    z-index: 2;
}

.pdf-card p {
    margin-bottom: 30px;
    opacity: 0.9;
    line-height: 1.6;
    position: relative;
    z-index: 2;
}

.pdf-email-form {
    margin: 25px 0;
    text-align: left;
    position: relative;
    z-index: 2;
}

.pdf-email-form .form-group {
    margin-bottom: 25px;
}

.pdf-email-form label {
    color: white;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-size: 0.9rem;
}

.pdf-email-form input {
    background: rgba(255, 255, 255, 0.9);
    border: 2px solid rgba(255, 255, 255, 0.2);
    color: #333;
}

.pdf-email-form input:focus {
    border-color: white;
    box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.2);
}

.pdf-download-btn {
    background: white;
    color: #1F2253;
    border: none;
    padding: 18px 35px;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 0 auto;
    text-transform: uppercase;
    letter-spacing: 1px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
}

.pdf-download-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 25px rgba(0, 0, 0, 0.3);
}

.pdf-status {
    margin-top: 25px;
    padding: 20px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.analysis-info {
    background: #f8f9fa;
    border-radius: 16px;
    padding: 25px;
    text-align: center;
    border: 1px solid #e9ecef;
}

.analysis-info p {
    margin: 8px 0;
    color: #666;
    font-weight: 500;
}

/* Responsive Design */
@media (max-width: 768px) {
    .enhanced-website-analyzer-container {
        padding: 20px 0;
        margin: 60px auto;
    }
    
    .analyzer-header h1 {
        font-size: 2.5rem;
    }
    
    .speed-comparison {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .categories-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .score-breakdown {
        flex-direction: column;
        gap: 20px;
    }
    
    .form-card, .results-section {
        padding: 25px;
        margin: 0 15px;
    }
    
    .score-circle {
        width: 150px;
        height: 150px;
    }
    
    .score-number {
        font-size: 2.5rem;
    }
}

/* Scrollbar Styling */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
    background: linear-gradient(135deg, #1F2253, #c22034);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(135deg, #2a2d6a, #a81b2b);
}

/* Selection Styling */
::selection {
    background: rgba(194, 32, 52, 0.3);
    color: white;
}

/* Focus Styles */
*:focus {
    outline: 2px solid #c22034;
    outline-offset: 2px;
}

/* Smooth Scrolling */
html {
    scroll-behavior: smooth;
}

/* Key Metrics Dashboard */
.key-metrics-dashboard {
    margin-bottom: 50px;
}

.key-metrics-dashboard h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
        font-size: 2rem;
    font-weight: 700;
}

.metrics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
}

.metric-card {
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    border: 1px solid #e9ecef;
    transition: all 0.3s ease;
    text-align: center;
}

.metric-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

.metric-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    color: white;
    font-size: 1.5rem;
}

.metric-content h4 {
    color: #1F2253;
    margin-bottom: 15px;
    font-size: 1.2rem;
    font-weight: 600;
}

.metric-content .metric-value {
    font-size: 2rem;
    font-weight: 800;
    color: #1F2253;
    margin-bottom: 10px;
}

.metric-content .metric-description {
    color: #666;
    font-size: 0.9rem;
}

/* Performance Status */
.performance-status {
    margin-top: 30px;
    text-align: center;
}

.status-badge {
    display: inline-block;
    padding: 8px 20px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 10px;
}

.status-badge.excellent {
    background: #28a745;
    color: white;
}

.status-badge.good {
    background: #17a2b8;
    color: white;
}

.status-badge.average {
    background: #ffc107;
    color: #333;
}

.status-badge.poor {
    background: #dc3545;
    color: white;
}

.status-description {
    color: #666;
    font-size: 1rem;
    margin: 0;
}

/* Core Web Vitals Section */
.core-web-vitals-section {
    margin-bottom: 50px;
}

.core-web-vitals-section h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
    font-size: 2rem;
    font-weight: 700;
}

.vitals-comparison {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.vitals-card {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    border: 1px solid #e9ecef;
}

.vitals-card h4 {
    color: #1F2253;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 1.3rem;
    font-weight: 600;
    padding-bottom: 15px;
    border-bottom: 2px solid #f8f9fa;
}

.vitals-metrics {
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.vital-metric {
    padding: 20px;
    background: #f8f9fa;
    border-radius: 12px;
    border-left: 4px solid #1F2253;
}

.vital-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.vital-label {
    font-weight: 600;
    color: #1F2253;
    font-size: 0.95rem;
}

.vital-status {
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
}

.vital-status.good {
    background: #d4edda;
    color: #155724;
}

.vital-status.needs-improvement {
    background: #fff3cd;
    color: #856404;
}

.vital-status.poor {
    background: #f8d7da;
    color: #721c24;
}

.vital-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1F2253;
    margin-bottom: 8px;
}

.vital-description {
    color: #666;
    font-size: 0.9rem;
    line-height: 1.4;
}

/* Analysis Categories Section */
.analysis-categories-section {
    margin-bottom: 50px;
}

.analysis-categories-section h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
    font-size: 2rem;
    font-weight: 700;
}

.category-stats {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 8px;
}

.stat-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

.stat-label {
    font-size: 0.8rem;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 5px;
}

.stat-value {
    font-size: 1.2rem;
    font-weight: 700;
    color: #1F2253;
}

/* Technologies Section */
.tech-analysis {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    border: 1px solid #e9ecef;
}

.tech-categories {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
}

.tech-category h4 {
    color: #1F2253;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 1.1rem;
    font-weight: 600;
    padding-bottom: 10px;
    border-bottom: 2px solid #f8f9fa;
}

.tech-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.tech-tag {
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    color: white;
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 500;
    box-shadow: 0 4px 12px rgba(31, 34, 83, 0.2);
    transition: all 0.3s ease;
}

.tech-tag:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(31, 34, 83, 0.3);
}

/* Recommendations Section */
.recommendations-section {
    margin-bottom: 50px;
}

.recommendations-section h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
    font-size: 2rem;
    font-weight: 700;
}

.recommendations-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 25px;
}

.recommendation-card {
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    border: 1px solid #e9ecef;
    position: relative;
    transition: all 0.3s ease;
}

.recommendation-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

.priority-badge {
    position: absolute;
    top: -10px;
    right: 20px;
    padding: 6px 15px;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.high-priority .priority-badge {
    background: #dc3545;
    color: white;
}

.medium-priority .priority-badge {
    background: #ffc107;
    color: #333;
}

.low-priority .priority-badge {
    background: #28a745;
    color: white;
}

.recommendation-card h4 {
    color: #1F2253;
    margin-bottom: 20px;
    font-size: 1.2rem;
    font-weight: 600;
    padding-top: 10px;
}

.recommendation-card ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.recommendation-card li {
    padding: 12px 0;
    border-bottom: 1px solid #f8f9fa;
    color: #555;
    font-size: 0.95rem;
    line-height: 1.5;
    transition: all 0.3s ease;
}

.recommendation-card li:hover {
    background: rgba(31, 34, 83, 0.05);
    border-radius: 8px;
    padding-left: 10px;
    margin-left: -10px;
}

.recommendation-card li:before {
    content: "→ ";
    color: #c22034;
    font-weight: bold;
    margin-right: 8px;
}

/* PDF Features */
.pdf-features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.feature-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 15px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.feature-item i {
    font-size: 1.2rem;
    color: rgba(255, 255, 255, 0.8);
}

.feature-item span {
    color: white;
    font-weight: 500;
}

/* Analysis Summary */
.analysis-summary {
    margin-bottom: 50px;
}

.analysis-summary h3 {
    text-align: center;
    margin-bottom: 40px;
    color: #1F2253;
    font-size: 2rem;
    font-weight: 700;
}

.summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
}

.summary-item {
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    border: 1px solid #e9ecef;
    display: flex;
    align-items: center;
    gap: 20px;
    transition: all 0.3s ease;
}

.summary-item:hover {
    transform: translateY(-3px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

.summary-icon {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1F2253 0%, #c22034 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    flex-shrink: 0;
}

.summary-content h4 {
    color: #1F2253;
    margin-bottom: 8px;
    font-size: 1rem;
    font-weight: 600;
}

.summary-content p {
    color: #666;
    margin: 0;
    font-size: 0.95rem;
}

/* Responsive Design Updates */
@media (max-width: 768px) {
    .vitals-comparison {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .metrics-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
    }
    
    .tech-categories {
        grid-template-columns: 1fr;
        gap: 25px;
    }
    
    .recommendations-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .summary-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .pdf-features {
        grid-template-columns: 1fr;
        gap: 15px;
    }
    
    .category-stats {
        flex-direction: column;
        gap: 15px;
    }
}

/* FontAwesome Icon Fixes */
.fa-solid, .fas, .fa {
    font-family: "Font Awesome 6 Free", "Font Awesome 6 Pro", "Font Awesome 5 Free", "Font Awesome 5 Pro", "FontAwesome" !important;
    font-weight: 900 !important;
    font-style: normal !important;
    font-variant: normal !important;
    text-rendering: auto !important;
    -webkit-font-smoothing: antialiased !important;
    -moz-osx-font-smoothing: grayscale !important;
}

/* Icon fallback styles */
.metric-icon i,
.vitals-card h4 i,
.category-header h4 i,
.tech-category h4 i,
.pdf-card h3 i,
.feature-item i,
.summary-icon i,
.pdf-download-btn i {
    display: inline-block !important;
    width: auto !important;
    height: auto !important;
    line-height: 1 !important;
}

/* Specific icon fixes */
.fa-tachometer-alt::before { content: "\f3fd"; }
.fa-mobile-screen::before { content: "\f3ce"; }
.fa-magnifying-glass::before { content: "\f002"; }
.fa-shield-halved::before { content: "\f3ed"; }
.fa-desktop::before { content: "\f108"; }
.fa-universal-access::before { content: "\f29a"; }
.fa-circle-check::before { content: "\f058"; }
.fa-code::before { content: "\f121"; }
.fa-server::before { content: "\f233"; }
.fa-database::before { content: "\f1c0"; }
.fa-wrench::before { content: "\f0ad"; }
.fa-file-pdf::before { content: "\f1c1"; }
.fa-chart-line::before { content: "\f201"; }
.fa-list-check::before { content: "\e1d7"; }
.fa-chart-bar::before { content: "\f080"; }
.fa-clock::before { content: "\f017"; }
.fa-download::before { content: "\f019"; }
.fa-spinner::before { content: "\f110"; }
.fa-calendar-days::before { content: "\f073"; }
.fa-globe::before { content: "\f0ac"; }

/* Ensure icons are visible */
i[class*="fa-"] {
    opacity: 1 !important;
    visibility: visible !important;
}

/* Icon sizing */
.metric-icon i {
    font-size: 1.5rem !important;
}

.vitals-card h4 i,
.category-header h4 i,
.tech-category h4 i {
    font-size: 1.2rem !important;
}

.pdf-card h3 i {
    font-size: 1.5rem !important;
}

.feature-item i {
    font-size: 1.2rem !important;
}

.summary-icon i {
    font-size: 1.2rem !important;
}

.pdf-download-btn i {
    font-size: 1rem !important;
}
</style>

<script>
// Wait for jQuery to be available and DOM ready
function waitForJQuery(callback) {
    if (typeof jQuery !== 'undefined') {
        jQuery(document).ready(function($) {
            callback($);
        });
    } else {
        setTimeout(function() {
            waitForJQuery(callback);
        }, 100);
    }
}

waitForJQuery(function($) {
    $('#enhanced-website-analyzer-form').on('submit', function(e) {
        e.preventDefault();
        
        const url = $('#website_url').val();
        
        if (!url) {
            console.error('Please enter a website URL.');
            return;
        }
        
        // Show loading state - use specific selectors for this button only
        const $analyzeBtn = $('.analyze-btn');
        $analyzeBtn.find('.btn-text').hide();
        $analyzeBtn.find('.btn-loading').show();
        $analyzeBtn.prop('disabled', true);
        
        // Perform analysis
        analyzeWebsite(url);
    });
    
    $('#show-email-form-btn').on('click', function() {
        $('#show-email-form-btn').hide();
        $('#pdf-email-form').show();
    });
    
    $('#download-pdf-btn').on('click', function() {
        const email = $('#pdf_email').val();
        if (!email) {
            console.error('Please enter your email address to download the PDF report.');
            return;
        }
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            console.error('Please enter a valid email address.');
            return;
        }
        
        downloadPDFReport(email);
    });
    
    function analyzeWebsite(url) {
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'enhanced_website_analysis',
                url: url,
                nonce: '<?php echo wp_create_nonce('enhanced_analysis_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    displayResults(response.data);
                    $('#enhanced-analysis-results').show();
                } else {
                    console.error('Analysis failed: ' + response.data);
                    // Show sample data for demonstration
                    displaySampleResults(url);
                    $('#enhanced-analysis-results').show();
                }
            },
            error: function() {
                console.error('An error occurred during analysis. Please try again.');
                // Show sample data for demonstration
                displaySampleResults(url);
                $('#enhanced-analysis-results').show();
            },
            complete: function() {
                // Reset loading state - use specific selectors for this button only
                const $analyzeBtn = $('.analyze-btn');
                $analyzeBtn.find('.btn-text').show();
                $analyzeBtn.find('.btn-loading').hide();
                $analyzeBtn.prop('disabled', false);
            }
        });
    }
    
    function displaySampleResults(url) {
        // Sample data for demonstration
        const sampleData = {
            url: url,
            overall_score: 78,
            mobile_score: 72,
            desktop_score: 85,
            seo_score: 82,
            mobile_friendliness_score: 75,
            security_score: 88,
            accessibility_score: 70,
            best_practices_score: 80,
            mobile_metrics: {
                fcp: 2.1,
                lcp: 3.2,
                cls: 0.08,
                fid: 85
            },
            desktop_metrics: {
                fcp: 1.8,
                lcp: 2.5,
                cls: 0.05,
                fid: 65
            },
            seo_issues: [
                'Missing meta descriptions on key pages',
                'Image alt tags not optimized',
                'Internal linking structure needs improvement'
            ],
            seo_suggestions: [
                'Add unique meta descriptions to all pages',
                'Optimize image alt tags with relevant keywords',
                'Implement a better internal linking strategy'
            ],
            mobile_issues: [
                'Touch targets too small on mobile',
                'Text too small to read on mobile devices',
                'Horizontal scrolling on mobile view'
            ],
            mobile_suggestions: [
                'Increase touch target sizes to at least 44px',
                'Use larger font sizes for mobile readability',
                'Implement responsive design to prevent horizontal scrolling'
            ],
            security_issues: [
                'HTTPS not properly configured',
                'Missing security headers'
            ],
            security_suggestions: [
                'Implement proper HTTPS configuration',
                'Add security headers (HSTS, CSP, etc.)',
                'Regular security audits recommended'
            ],
            accessibility_issues: [
                'Missing alt text on images',
                'Poor color contrast ratios',
                'Keyboard navigation not fully functional'
            ],
            accessibility_suggestions: [
                'Add descriptive alt text to all images',
                'Improve color contrast ratios to meet WCAG guidelines',
                'Ensure all interactive elements are keyboard accessible'
            ],
            best_practices_issues: [
                'Unoptimized images',
                'Missing favicon',
                'No custom 404 page'
            ],
            best_practices_suggestions: [
                'Compress and optimize all images',
                'Add a favicon to improve brand recognition',
                'Create a custom 404 error page'
            ],
            technologies: [
                'WordPress',
                'PHP',
                'MySQL',
                'jQuery',
                'Bootstrap',
                'Google Analytics',
                'Cloudflare',
                'SSL Certificate'
            ]
        };
        
        displayResults(sampleData);
    }
    
    function displayResults(data) {
        // Overall scores
        $('#overall-score').text(data.overall_score);
        $('#mobile-overall-score').text(data.mobile_score);
        $('#desktop-overall-score').text(data.desktop_score);
        
        // Performance status
        updatePerformanceStatus(data.overall_score);
        
        // Key metrics dashboard
        $('#page-speed-metric').text(data.overall_score + '/100');
        $('#mobile-score-metric').text(data.mobile_score + '/100');
        $('#seo-score-metric').text(data.seo_score + '/100');
        $('#security-score-metric').text(data.security_score + '/100');
        
        // Core Web Vitals with status
        updateCoreWebVitals('mobile', data.mobile_metrics);
        updateCoreWebVitals('desktop', data.desktop_metrics);
        
        // Category scores with statistics
        updateCategoryScore('seo', data.seo_score, data.seo_issues, data.seo_suggestions);
        updateCategoryScore('mobile', data.mobile_friendliness_score, data.mobile_issues, data.mobile_suggestions);
        updateCategoryScore('security', data.security_score, data.security_issues, data.security_suggestions);
        updateCategoryScore('accessibility', data.accessibility_score, data.accessibility_issues, data.accessibility_suggestions);
        updateCategoryScore('best-practices', data.best_practices_score, data.best_practices_issues, data.best_practices_suggestions);
        
        // Technologies
        displayTechnologies(data.technologies);
        
        // Recommendations
        displayRecommendations(data);
        
        // Analysis info
        $('#analysis-date').text(new Date().toLocaleDateString());
        $('#analyzed-url').text(data.url);
        $('#analysis-duration').text('~30 seconds');
        $('#total-issues').text(calculateTotalIssues(data));
    }
    
    function updatePerformanceStatus(score) {
        const statusBadge = $('#status-badge');
        const statusDescription = $('#status-description');
        
        statusBadge.removeClass('excellent good average poor');
        
        if (score >= 90) {
            statusBadge.addClass('excellent').text('Excellent');
            statusDescription.text('Your website is performing exceptionally well!');
        } else if (score >= 70) {
            statusBadge.addClass('good').text('Good');
            statusDescription.text('Your website is performing well with room for improvement.');
        } else if (score >= 50) {
            statusBadge.addClass('average').text('Average');
            statusDescription.text('Your website needs some optimization to improve performance.');
        } else {
            statusBadge.addClass('poor').text('Poor');
            statusDescription.text('Your website requires significant optimization.');
        }
    }
    
    function updateCoreWebVitals(device, metrics) {
        // FCP
        $(`#${device}-fcp`).text(metrics.fcp + 's');
        updateVitalStatus(`${device}-fcp-status`, metrics.fcp, 'fcp');
        
        // LCP
        $(`#${device}-lcp`).text(metrics.lcp + 's');
        updateVitalStatus(`${device}-lcp-status`, metrics.lcp, 'lcp');
        
        // CLS
        $(`#${device}-cls`).text(metrics.cls);
        updateVitalStatus(`${device}-cls-status`, metrics.cls, 'cls');
        
        // FID
        $(`#${device}-fid`).text(metrics.fid + 'ms');
        updateVitalStatus(`${device}-fid-status`, metrics.fid, 'fid');
    }
    
    function updateVitalStatus(elementId, value, metric) {
        const element = $(`#${elementId}`);
        element.removeClass('good needs-improvement poor');
        
        let status, className;
        
        switch(metric) {
            case 'fcp':
                if (value <= 1.8) { status = 'Good'; className = 'good'; }
                else if (value <= 3.0) { status = 'Needs Improvement'; className = 'needs-improvement'; }
                else { status = 'Poor'; className = 'poor'; }
                break;
            case 'lcp':
                if (value <= 2.5) { status = 'Good'; className = 'good'; }
                else if (value <= 4.0) { status = 'Needs Improvement'; className = 'needs-improvement'; }
                else { status = 'Poor'; className = 'poor'; }
                break;
            case 'cls':
                if (value <= 0.1) { status = 'Good'; className = 'good'; }
                else if (value <= 0.25) { status = 'Needs Improvement'; className = 'needs-improvement'; }
                else { status = 'Poor'; className = 'poor'; }
                break;
            case 'fid':
                if (value <= 100) { status = 'Good'; className = 'good'; }
                else if (value <= 300) { status = 'Needs Improvement'; className = 'needs-improvement'; }
                else { status = 'Poor'; className = 'poor'; }
                break;
        }
        
        element.addClass(className).text(status);
    }
    
    function updateCategoryScore(category, score, issues, suggestions) {
        const scoreElement = $('#' + category + '-score');
        const issuesList = $('#' + category + '-issues');
        const suggestionsList = $('#' + category + '-suggestions');
        const issuesCount = $('#' + category + '-issues-count');
        const suggestionsCount = $('#' + category + '-suggestions-count');
        
        scoreElement.text(score);
        scoreElement.removeClass('excellent good average poor');
        
        if (score >= 90) scoreElement.addClass('excellent');
        else if (score >= 70) scoreElement.addClass('good');
        else if (score >= 50) scoreElement.addClass('average');
        else scoreElement.addClass('poor');
        
        // Update counts
        issuesCount.text(issues.length);
        suggestionsCount.text(suggestions.length);
        
        // Clear and populate lists
        issuesList.empty();
        issues.forEach(function(issue) {
            issuesList.append('<li>' + issue + '</li>');
        });
        
        suggestionsList.empty();
        suggestions.forEach(function(suggestion) {
            suggestionsList.append('<li>' + suggestion + '</li>');
        });
    }
    
    function displayTechnologies(technologies) {
        // Categorize technologies
        const frontend = ['HTML5', 'CSS3', 'JavaScript', 'React', 'Vue.js', 'Angular', 'Bootstrap', 'jQuery'];
        const backend = ['PHP', 'Node.js', 'Python', 'Java', 'Ruby', 'ASP.NET', 'WordPress'];
        const database = ['MySQL', 'PostgreSQL', 'MongoDB', 'SQLite', 'Redis'];
        const tools = ['Google Analytics', 'Google Tag Manager', 'Cloudflare', 'AWS', 'CDN', 'SSL'];
        
        const categorized = {
            frontend: technologies.filter(tech => frontend.some(f => tech.toLowerCase().includes(f.toLowerCase()))),
            backend: technologies.filter(tech => backend.some(b => tech.toLowerCase().includes(b.toLowerCase()))),
            database: technologies.filter(tech => database.some(d => tech.toLowerCase().includes(d.toLowerCase()))),
            tools: technologies.filter(tech => tools.some(t => tech.toLowerCase().includes(t.toLowerCase())))
        };
        
        // Display categorized technologies
        displayTechCategory('frontend-tech', categorized.frontend);
        displayTechCategory('backend-tech', categorized.backend);
        displayTechCategory('database-tech', categorized.database);
        displayTechCategory('tools-tech', categorized.tools);
        
        // Fallback: if no categorization, show all in frontend
        if (categorized.frontend.length === 0 && categorized.backend.length === 0 && 
            categorized.database.length === 0 && categorized.tools.length === 0) {
            displayTechCategory('frontend-tech', technologies);
        }
    }
    
    function displayTechCategory(elementId, techs) {
        const container = $('#' + elementId);
        container.empty();
        
        if (techs.length === 0) {
            container.append('<span class="tech-tag">No technologies detected</span>');
            return;
        }
        
        techs.forEach(function(tech) {
            container.append('<span class="tech-tag">' + tech + '</span>');
        });
    }
    
    function displayRecommendations(data) {
        // Collect all issues and suggestions
        const allIssues = [
            ...(data.seo_issues || []),
            ...(data.mobile_issues || []),
            ...(data.security_issues || []),
            ...(data.accessibility_issues || []),
            ...(data.best_practices_issues || [])
        ];
        
        const allSuggestions = [
            ...(data.seo_suggestions || []),
            ...(data.mobile_suggestions || []),
            ...(data.security_suggestions || []),
            ...(data.accessibility_suggestions || []),
            ...(data.best_practices_suggestions || [])
        ];
        
        // Categorize recommendations by priority
        const critical = allIssues.slice(0, 3); // First 3 issues as critical
        const important = allSuggestions.slice(0, 4); // First 4 suggestions as important
        const optimization = allSuggestions.slice(4, 7); // Next 3 as optimization opportunities
        
        // Display recommendations
        displayRecommendationList('critical-recommendations', critical);
        displayRecommendationList('medium-recommendations', important);
        displayRecommendationList('low-recommendations', optimization);
    }
    
    function displayRecommendationList(elementId, recommendations) {
        const container = $('#' + elementId);
        container.empty();
        
        if (recommendations.length === 0) {
            container.append('<li>No recommendations available</li>');
            return;
        }
        
        recommendations.forEach(function(recommendation) {
            container.append('<li>' + recommendation + '</li>');
        });
    }
    
    function calculateTotalIssues(data) {
        return (
            (data.seo_issues ? data.seo_issues.length : 0) +
            (data.mobile_issues ? data.mobile_issues.length : 0) +
            (data.security_issues ? data.security_issues.length : 0) +
            (data.accessibility_issues ? data.accessibility_issues.length : 0) +
            (data.best_practices_issues ? data.best_practices_issues.length : 0)
        );
    }
    
    function downloadPDFReport(email) {
        const url = $('#website_url').val();
        
        $('#pdf-status').show();
        $('#download-pdf-btn').prop('disabled', true);
        
        console.log('Starting PDF generation for URL:', url, 'Email:', email);
        
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'generate_enhanced_pdf_report',
                url: url,
                email: email,
                nonce: '<?php echo wp_create_nonce('pdf_generation_nonce'); ?>'
            },
            success: function(response) {
                console.log('PDF generation response:', response);
                
                if (response.success) {
                    console.log('PDF generated successfully:', response.data);
                    
                    // Create download link and trigger download
                    const downloadLink = document.createElement('a');
                    downloadLink.href = response.data.download_url;
                    downloadLink.download = response.data.filename;
                    downloadLink.style.display = 'none';
                    document.body.appendChild(downloadLink);
                    downloadLink.click();
                    document.body.removeChild(downloadLink);
                    
                    // Reset form
                    $('#pdf-email-form').hide();
                    $('#show-email-form-btn').show();
                    $('#pdf_email').val('');
                    
                    // Show success message
                    alert('PDF report generated successfully! Your download should start automatically.');
                } else {
                    console.error('PDF generation failed:', response.data);
                    alert('PDF generation failed: ' + (response.data || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error details:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText,
                    statusCode: xhr.status
                });
                
                let errorMessage = 'An error occurred while generating the PDF report.';
                
                // Try to get more specific error information
                if (xhr.responseText) {
                    try {
                        const errorResponse = JSON.parse(xhr.responseText);
                        if (errorResponse.data) {
                            errorMessage = errorResponse.data;
                        }
                    } catch (e) {
                        // If we can't parse JSON, use the raw response
                        if (xhr.responseText.length < 200) {
                            errorMessage = 'Server error: ' + xhr.responseText;
                        }
                    }
                }
                
                alert(errorMessage);
            },
            complete: function() {
                $('#pdf-status').hide();
                $('#download-pdf-btn').prop('disabled', false);
            }
        });
    }
});
</script>

<?php get_footer(); ?> 