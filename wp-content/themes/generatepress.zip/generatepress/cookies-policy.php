<?php
/*
Template Name: Cookies Policy
*/
?>
<html>
<?php get_custom_head(); ?>
<body>
    <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
    <noscript>
        <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css"/>
    </noscript>
    <div>
        <style>
            body{margin:0;padding:0;font-family:"Lexend Deca",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif!important;color:#333;line-height:1.6;background-color:#f8f9fa;overflow-x:hidden}.terms-container{width:100%;margin:80px auto 0;padding:0}.terms-header{position:relative;background:linear-gradient(135deg,#c22034,#1e2154);padding:6rem 2rem;text-align:center;margin-bottom:0;box-shadow:0 10px 25px rgba(0,0,0,.15);display:flex;flex-direction:column;justify-content:center;align-items:center;min-height:350px;overflow:hidden}.terms-header::before{content:'';position:absolute;top:0;left:0;width:100%;height:100%;background-image:url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");opacity:.6}.terms-header h1{color:#fff;margin-bottom:1.5rem;font-size:3.5rem;font-weight:700;text-shadow:0 2px 4px rgba(0,0,0,.2);position:relative}.terms-header p{color:#fff;font-size:1.2rem;max-width:700px;margin:0 auto;opacity:.9;position:relative;line-height:1.6}.terms-content-wrapper{position:relative;margin-top:-50px;padding:0 20px;max-width:1200px;margin-left:auto;margin-right:auto}.terms-content{background-color:#fff;padding:3rem;border-radius:12px;margin:0 auto 4rem;box-shadow:0 15px 35px rgba(0,0,0,.1);position:relative;border-top:5px solid #c22034}.terms-content h2{color:#1e2154;font-size:1.8rem;font-weight:700;margin:2.5rem 0 1.5rem;padding-bottom:.5rem;border-bottom:2px solid rgba(194,32,52,.2)}.terms-content h2:first-child{margin-top:0}.terms-content p{color:#444;font-size:1.05rem;line-height:1.8;margin:1.5rem 0}.terms-content ol,.terms-content ul{margin:1.5rem 0 1.5rem 1rem;padding-left:1.5rem}.terms-content ol{list-style-type:decimal;counter-reset:item}.terms-content ol li{margin:1rem 0;color:#444;line-height:1.7}.terms-cta{text-align:center;margin:3rem 0 2rem;padding:2rem;background:rgba(194,32,52,.05);border-radius:8px;border-left:3px solid #c22034}.back-to-top,.terms-cta-button{background:#c22034;text-decoration:none;transition:.3s}.terms-cta p{font-size:1.1rem;margin-bottom:1.5rem}.terms-cta-button{display:inline-block;padding:.8rem 2rem;color:#fff;font-weight:600;border-radius:50px}.last-updated{display:block;text-align:right;margin-top:2rem;font-size:.9rem;color:#777;font-style:italic}.back-to-top{position:fixed;bottom:100px;right:30px;width:50px;height:50px;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;z-index:99;box-shadow:0 4px 10px rgba(0,0,0,.15)}
        </style>
        <?php salesnanny_nav_header(); ?>
            <div class="terms-container">
                <div class="terms-header">
                    <h1>Cookies Policy</h1>
                    <p>Please read these terms and conditions carefully before using our services. By accessing and using our website, you agree to be bound by these terms.</p>
                </div>
                <div class="terms-content-wrapper">
                    <div class="terms-content">
                       <p>This is the Cookies Policy for SalesNanny, accessible from https://SalesNanny.com/</p>
                       <h2>What Are Cookies</h2>
                       <p>+ As is common practice with almost all professional websites this site uses cookies, which are tiny files that are downloaded to your computer, to improve your experience.</p>
                       <p>+ This page describes what information they gather, how we use it, and why we sometimes need to store these cookies. We will also share how you can prevent these cookies from being stored however this may downgrade or ‘break’ certain elements of the site’s functionality.</p>
                       
                       <h2>How We Use Cookies</h2>
                       <p>+ We use cookies for a variety of reasons detailed below. Unfortunately in most cases there are no industry standard options for disabling cookies without completely disabling the functionality and features they add to this site. It is recommended that you leave on all cookies if you are not sure whether you need them or not in case they are used to provide a service that you use.</p>
                       
                       <h2>Disabling Cookies</h2>
                       <p>+ You can prevent the setting of cookies by adjusting the settings on your browser (see your browser Help for how to do this). Be aware that disabling cookies will affect the functionality of this and many other websites that you visit. Disabling cookies will usually result in also disabling certain functionality and features of the this site. Therefore it is recommended that you do not disable cookies.</p>

                       <h2>The Cookies We Set</h2>
                       <p>+ We use cookies for a variety of reasons detailed below. Unfortunately in most cases there are no industry standard options for disabling cookies without completely disabling the functionality and features they add to this site. It is recommended that you leave on all cookies if you are not sure whether you need them or not in case they are used to provide a service that you use.</p>
                       
                       <h2>Login related cookies</h2>
                       <p>+ We use cookies when you are logged in so that we can remember this fact. This prevents you from having to log in every single time you visit a new page. These cookies are typically removed or cleared when you log out to ensure that you can only access restricted features and areas when logged in.</p>

                       <h2>Email newsletters related cookies</h2>
                       <p>+ This site offers newsletter or email subscription services and cookies may be used to remember if you are already registered and whether to show certain notifications which might only be valid to subscribed/unsubscribed users.</p>

                        <div class="terms-cta">
                            <p>Have questions about our CCPA Policy? We're here to help.</p>
                            <a href="<?php echo SN_HTTP_URL; ?>contact/" class="terms-cta-button">Contact Us</a>
                        </div>
                        <span class="last-updated">Last updated: <?php echo date('F d, Y'); ?></span>
                    </div>
                </div>
                <a href="#" class="back-to-top">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 15l-6-6-6 6"/>
                    </svg>
                </a>
            </div>
            <script>
                // Back to top button functionality
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTopButton = document.querySelector('.back-to-top');
                    
                    // Show button when user scrolls down 300px
                    window.addEventListener('scroll', function() {
                        if (window.pageYOffset > 300) {
                            backToTopButton.classList.add('visible');
                        } else {
                            backToTopButton.classList.remove('visible');
                        }
                    });
                    
                    // Smooth scroll to top when button is clicked
                    backToTopButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
            </script>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>