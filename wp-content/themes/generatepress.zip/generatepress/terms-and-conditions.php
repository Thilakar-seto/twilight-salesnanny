<?php
/*
Template Name: Terms and Conditions
*/
?>
<html>
<?php get_custom_head(); ?>
<body>
    <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
    <noscript>
        <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css"/>
    </noscript>
    <div>
        <style>
            body{margin:0;padding:0;font-family:"Lexend Deca",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif!important;color:#333;line-height:1.6;background-color:#f8f9fa;overflow-x:hidden}.terms-container{width:100%;margin:80px auto 0;padding:0}.terms-header{position:relative;background:linear-gradient(135deg,#c22034,#1e2154);padding:6rem 2rem;text-align:center;margin-bottom:0;box-shadow:0 10px 25px rgba(0,0,0,.15);display:flex;flex-direction:column;justify-content:center;align-items:center;min-height:350px;overflow:hidden}.terms-header::before{content:'';position:absolute;top:0;left:0;width:100%;height:100%;background-image:url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");opacity:.6}.terms-header h1{color:#fff;margin-bottom:1.5rem;font-size:3.5rem;font-weight:700;text-shadow:0 2px 4px rgba(0,0,0,.2);position:relative}.terms-header p{color:#fff;font-size:1.2rem;max-width:700px;margin:0 auto;opacity:.9;position:relative;line-height:1.6}.terms-content-wrapper{position:relative;margin-top:-50px;padding:0 20px;max-width:1200px;margin-left:auto;margin-right:auto}.terms-content{background-color:#fff;padding:3rem;border-radius:12px;margin:0 auto 4rem;box-shadow:0 15px 35px rgba(0,0,0,.1);position:relative;border-top:5px solid #c22034}.terms-content h2{color:#1e2154;font-size:1.8rem;font-weight:700;margin:2.5rem 0 1.5rem;padding-bottom:.5rem;border-bottom:2px solid rgba(194,32,52,.2)}.terms-content h2:first-child{margin-top:0}.terms-content p{color:#444;font-size:1.05rem;line-height:1.8;margin:1.5rem 0}.terms-content ol,.terms-content ul{margin:1.5rem 0 1.5rem 1rem;padding-left:1.5rem}.terms-content ol{list-style-type:decimal;counter-reset:item}.terms-content ol li{margin:1rem 0;color:#444;line-height:1.7}.terms-cta{text-align:center;margin:3rem 0 2rem;padding:2rem;background:rgba(194,32,52,.05);border-radius:8px;border-left:3px solid #c22034}.back-to-top,.terms-cta-button{background:#c22034;text-decoration:none;transition:.3s}.terms-cta p{font-size:1.1rem;margin-bottom:1.5rem}.terms-cta-button{display:inline-block;padding:.8rem 2rem;color:#fff;font-weight:600;border-radius:50px}.last-updated{display:block;text-align:right;margin-top:2rem;font-size:.9rem;color:#777;font-style:italic}.back-to-top{position:fixed;bottom:100px;right:30px;width:50px;height:50px;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;z-index:99;box-shadow:0 4px 10px rgba(0,0,0,.15)}
        </style>
        <?php salesnanny_nav_header(); ?>
            <div class="terms-container">
                <div class="terms-header">
                    <h1>Terms and Conditions</h1>
                    <p>Please read these terms and conditions carefully before using our services. By accessing and using our website, you agree to be bound by these terms.</p>
                </div>
                <div class="terms-content-wrapper">
                    <div class="terms-content">
                        <h2>Welcome to SalesNanny!</h2>
                        <p>These terms and conditions outline the rules and regulations for the use of SalesNanny’s Website, located at https://salesnanny.com/.</p>
                        <p>By accessing this website, we assume you accept these terms and conditions. Do not continue to use SalesNanny if you do not agree to take all of the terms and conditions stated on this page.</p>
                        <p>The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice, and all Agreements:</p>
                        <ol>
                            <li>“Client”, “You” and “Your” refers to you, the person who logs on to this website and is compliant with the Company’s terms and conditions.</li>
                            <li>“The Company”, “Ourselves”, “We”, “Our” and “Us”, refers to our Company (SalesNanny).</li>
                            <li>“Party”, “Parties”, or “Us”, refers to both the Client and ourselves.</li>
                        </ol>
                        <p>All terms refer to the offer, acceptance, and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of the provision of the Company’s stated services, in accordance with and subject to, prevailing law of in. Any use of the above terminology or other words in the singular, plural, capitalization, and/or he/she or they, are taken as interchangeable and therefore as referring to the same.</p>
                       
                        <h2>Cookies</h2>
                        <p>We employ the use of cookies. By accessing SalesNanny, you agreed to use cookies in agreement with the SalesNanny’s Privacy Policy.</p>
                        <p>Most interactive websites use cookies to let us retrieve the user’s details for each visit. Cookies are used by our website to enable the functionality of certain areas to make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.</p>
                        
                        <h2>License</h2>
                        <p>Unless otherwise stated, SalesNanny and/or its licensors own the intellectual property rights for all material on SalesNanny. All intellectual property rights are reserved. You may access this from SalesNanny for your own personal use subjected to restrictions set in these terms and conditions.</p>
                        <p>You must not:</p>
                        <ol>
                            <li>Republish material from SalesNanny</li>
                            <li>Sell, rent or sub-license material from SalesNanny</li>
                            <li>Reproduce, duplicate or copy material from SalesNanny</li>
                            <li>Redistribute content from SalesNanny</li>
                        </ol>
                        <p>Parts of this website offer an opportunity for users to post and exchange opinions and information in certain areas of the website. SalesNanny does not filter, edit, publish, or review Comments prior to their presence on the website. Comments do not reflect the views and opinions of SalesNanny, its agents, and/or affiliates. Comments reflect the views and opinions of the person who posts their views and opinions. To the extent permitted by applicable laws, SalesNanny shall not be liable for the Comments or for any liability, damages, or expenses caused and/or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website.</p>
                        <p>SalesNanny reserves the right to monitor all Comments and to remove any Comments which can be considered inappropriate, offensive, or causes a breach of these Terms and Conditions.</p>
                        <p>You warrant and represent that:</p>
                        <ol>
                            <li>You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;</li>
                            <li>The Comments do not invade any intellectual property right, including without limitation copyright, patent or trademark of any third party;</li>
                            <li>The Comments do not contain any defamatory, libellous, offensive, indecent, or otherwise unlawful material which is an invasion of privacy</li>
                            <li>The Comments will not be used to solicit or promote business or custom or present commercial activities and/or unlawful activity.</li>
                        </ol>
                        <p>You hereby grant SalesNanny a non-exclusive license to use, reproduce, edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats, or media.</p>

                        <h2>Hyperlinking to our Content</h2>
                        <p>The following organizations may link to our Website without prior written approval:</p>
                        <ol>
                            <li>Government agencies;</li>
                            <li>Search engines;</li>
                            <li>News organizations;</li>
                            <li>Online directory distributors may link to our Website in the same manner as they hyperlink to the Websites of other listed businesses; and</li> 
                            <li>System wide Accredited Businesses except soliciting non-profit organizations, charity shopping malls, and charity fundraising groups which may not hyperlink to our Web site.</li>
                        </ol>
                        <p>These organizations may link to our home page, to publications or to other Website information so long as the link: (a) is not in any way deceptive; (b) does not falsely imply sponsorship, endorsement or approval of the linking party and its products and/or services; and (c) fits within the context of the linking party's site.</p>
                        <p>We may consider and approve other link requests from the following types of organizations:</p>
                        <ol>
                            <li>commonly-known consumer and/or business information sources;</li>
                            <li>dot.com community sites;</li>
                            <li>associations or other groups representing charities;</li>
                            <li>online directory distributors;</li>
                            <li>internet portals;</li>
                            <li>accounting, law and consulting firms; and</li>
                            <li>educational institutions and trade associations.</li>
                        </ol>
                        <p>We will approve link requests from these organizations if we determine that: (a) the link would not make us look unfavorably to ourselves or to our accredited businesses; (b) the organization does not have any negative records with us; (c) the benefit to us from the visibility of the hyperlink compensates the absence of SalesNanny; and (d) the link is in the context of general resource information.</p>
                        <p>These organizations may link to our home page, to publications or to other Website information so long as the link: (a) is not in any way deceptive; (b) does not falsely imply sponsorship, endorsement or approval of the linking party and its products and/or services; and (c) fits within the context of the linking party's site.</p>
                        <p>If you are one of the organizations listed in paragraph 2 above and are interested in linking to our website, you must inform us by sending an e-mail to <a href="mailto:support@salesnanny.com">support@salesnanny.com</a>. Please include your name, your organization name, contact information as well as the URL of your site, a list of any URLs from which you intend to link to our Website, and a list of the URLs on our site to which you would like to link. Wait 2-3 weeks for a response.</p>
                        <p>Approved organizations may hyperlink to our Website as follows:</p>
                        <ol>
                            <li>By use of our corporate name; or</li>
                            <li>By use of the uniform resource locator being linked to; or</li>
                            <li>By use of any other description of our Website being linked to that makes sense within the context and format of content on the linking party's site.</li>
                        </ol>
                        <p>No use of SalesNanny's logo or other artwork will be allowed for linking absent a trademark license agreement.</p>

                        <h2>iFrames</h2>
                        <p>Without prior approval and written permission, you are not permitted to create frames around our Webpages that alter in any way the visual presentation or appearance of our Website.</p>

                        <h2>Content Liability</h2>
                        <p>We shall not be hold responsible for any content that appears on your Website. You agree to protect and defend us against all claims that is rising on your Website. No link(s) should appear on any Website that may be interpreted as libellous, obscene or criminal, or which infringes, otherwise violates, or advocates the infringement or other violation of, any third party rights.</p>

                        <h2>Reservation of Rights</h2>
                        <p>We reserve the right to request that you remove all links or any particular link to our Website. You approve to immediately remove all links to our Website upon request. We also reserve the right to amen these terms and conditions and it's linking policy at any time. By continuously linking to our Website, you agree to be bound to and follow these linking terms and conditions.</p>

                        <h2>Removal of links from our website</h2>
                        <p>If you find any link on our Website that is offensive for any reason, you are free to contact and inform us any moment. We will consider requests to remove links but we are not obligated to or so or to respond to you directly.</p>
                        <p>We do not ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we promise to ensure that the website remains available or that the material on the website is kept up to date.</p>

                        <h2>Disclaimer</h2>
                        <p>To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions relating to our website and the use of this website. Nothing in this disclaimer will:</p>
                        <ol>
                            <li>limit or exclude our or your liability for death or personal injury;</li>
                            <li>limit or exclude our or your liability for fraud or fraudulent misrepresentation;</li>
                            <li>limit any of our or your liabilities in any way that is not permitted under applicable law;</li>
                            <li>exclude any of our or your liabilities that may not be excluded under applicable law.</li>
                        </ol>
                        <p>The limitations and exclusions of liability set out in this Section and elsewhere in this disclaimer: (a) are subject to the preceding paragraph; and (b) govern all liabilities arising under the disclaimer, including liabilities arising in contract, in tort and for breach of statutory duty.</p>

                        <p>As long as the website and the information and services on the website are provided free of charge, we will not be liable for any loss or damage of any nature.</p>

                        <!-- <h2><span class="section-number">1.</span> Agreement to Terms</h2> -->
                       
                        <!-- Call to Action -->
                        <div class="terms-cta">
                            <p>Have questions about our Terms and Conditions? We're here to help.</p>
                            <a href="<?php echo SN_HTTP_URL; ?>contact/" class="terms-cta-button">Contact Us</a>
                        </div>

                        <!-- Last Updated -->
                        <span class="last-updated">Last updated: <?php echo date('F d, Y'); ?></span>
                    </div>
                </div>
                <a href="#" class="back-to-top">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 15l-6-6-6 6"/>
                    </svg>
                </a>
            </div>
            <script>
                // Back to top button functionality
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTopButton = document.querySelector('.back-to-top');
                    
                    // Show button when user scrolls down 300px
                    window.addEventListener('scroll', function() {
                        if (window.pageYOffset > 300) {
                            backToTopButton.classList.add('visible');
                        } else {
                            backToTopButton.classList.remove('visible');
                        }
                    });
                    
                    // Smooth scroll to top when button is clicked
                    backToTopButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
            </script>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>