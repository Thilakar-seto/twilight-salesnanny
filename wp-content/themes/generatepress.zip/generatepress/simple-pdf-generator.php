<?php
/**
 * Simple PDF Generator for SalesNanny using FPDF
 * A lightweight PDF generation solution when DomPDF is not available
 */

// Include FPDF
require_once(ABSPATH . 'vendor/fpdf.php');

if (!class_exists('SalesNannyPDFGenerator')) {
    class SalesNannyPDFGenerator extends FPDF {
        
        public function __construct() {
            parent::__construct('P', 'mm', 'A4');
            $this->SetAutoPageBreak(true, 20);
            $this->SetMargins(20, 20, 20);
            // Set default font encoding to handle UTF-8 properly
            $this->SetFont('Arial', '', 12);
        }
        
        // Helper function to properly encode text for FPDF
        private function cleanText($text) {
            // Convert HTML entities and clean up encoding issues
            $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
            // Replace common problematic characters
            $text = str_replace([
                "\xE2\x80\xA2", // •
                "\xE2\x80\x93", // –
                "\xE2\x80\x94", // —
                "\xE2\x80\x9C", // "
                "\xE2\x80\x9D", // "
                "\xE2\x80\x98", // '
                "\xE2\x80\x99", // '
                "\xE2\x80\xA6", // …
                'â€¢', 'â€"', 'â€œ', 'â€', 'â€™', 'â€˜', 'â€¦',
                'Â ', 'Ã', 'â', '€', 'œ', '™', '˜', '¦'
            ], [
                '- ', '-', '-', '"', '"', "'", "'", '...',
                '- ', '-', '"', '"', "'", "'", '...',
                ' ', '', '', '', '', '', '', ''
            ], $text);
            // Remove any remaining non-ASCII characters that might cause issues
            $text = preg_replace('/[^\x20-\x7E]/', '', $text);
            return trim($text);
        }
        
        // Helper function to wrap text properly
        private function addMultiLineText($text, $width = 170, $lineHeight = 6) {
            $text = $this->cleanText($text);
            $words = explode(' ', $text);
            $line = '';
            
            foreach ($words as $word) {
                $testLine = $line . ($line ? ' ' : '') . $word;
                $testWidth = $this->GetStringWidth($testLine);
                
                if ($testWidth > $width && $line !== '') {
                    $this->Cell(0, $lineHeight, $line, 0, 1, 'L');
                    $line = $word;
                } else {
                    $line = $testLine;
                }
            }
            
            if ($line !== '') {
                $this->Cell(0, $lineHeight, $line, 0, 1, 'L');
            }
        }
        
        // Helper function to download and cache logo
        private function downloadLogo($url) {
            $upload_dir = wp_upload_dir();
            $cache_dir = $upload_dir['basedir'] . '/salesnanny-cache/';
            
            // Create cache directory if it doesn't exist
            if (!file_exists($cache_dir)) {
                wp_mkdir_p($cache_dir);
            }
            
            $logo_filename = 'salesnanny-logo.png';
            $logo_path = $cache_dir . $logo_filename;
            
            // Check if logo already exists and is less than 24 hours old
            if (file_exists($logo_path) && (time() - filemtime($logo_path)) < 86400) {
                return $logo_path;
            }
            
            // Download logo
            $response = wp_remote_get($url, array(
                'timeout' => 10,
                'headers' => array(
                    'User-Agent' => 'SalesNanny PDF Generator'
                )
            ));
            
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
                $image_data = wp_remote_retrieve_body($response);
                if ($image_data && file_put_contents($logo_path, $image_data)) {
                    return $logo_path;
                }
            }
            
            return false;
        }
        
        // Header function
        public function Header() {
            // SalesNanny brand header with gradient
            $this->SetFillColor(30, 33, 84); // SalesNanny dark blue
            $this->Rect(0, 0, 210, 40, 'F');
            
            // Try to add logo image
            $logo_url = 'https://salesnanny.com/wp-content/themes/assets/logos/salesnanny-logo.png';
            $logo_path = $this->downloadLogo($logo_url);
            
            if ($logo_path && file_exists($logo_path)) {
                // Add logo on the left
                $this->Image($logo_path, 15, 8, 25, 0); // x, y, width, height (0 = auto height)
                
                // Add text next to logo
                $this->SetTextColor(255, 255, 255);
                $this->SetFont('Arial', 'B', 20);
                $this->SetXY(45, 15);
                $this->Cell(0, 10, 'SalesNanny', 0, 0, 'L');
            } else {
                // Fallback: text only with brand colors
                $this->SetTextColor(255, 255, 255);
                $this->SetFont('Arial', 'B', 24);
                $this->SetXY(20, 15);
                $this->Cell(0, 10, 'SalesNanny', 0, 1, 'L');
            }
            
            $this->SetFont('Arial', '', 12);
            $this->SetXY(45, 25);
            $this->SetTextColor(194, 32, 52); // SalesNanny red for subtitle
            $this->Cell(0, 10, 'Professional Website Analyzer', 0, 1, 'L');
            
            $this->Ln(20);
        }
        
        // Footer function
        public function Footer() {
            $this->SetY(-15);
            $this->SetFont('Arial', 'I', 8);
            $this->SetTextColor(128, 128, 128);
            $this->Cell(0, 10, 'Generated by SalesNanny - https://salesnanny.com', 0, 0, 'C');
        }
        
        public function createReport($data) {
            // Add first page
            $this->AddPage();
            
            // Title with SalesNanny branding
            $this->SetTextColor(30, 33, 84); // SalesNanny dark blue
            $this->SetFont('Arial', 'B', 20);
            $this->Cell(0, 15, 'Website Analysis Report', 0, 1, 'C');
            $this->Ln(5);
            
            // Website URL
            $this->SetTextColor(194, 32, 52); // SalesNanny red
            $this->SetFont('Arial', 'B', 14);
            $this->Cell(0, 10, 'Website: ' . $this->cleanText($data['url']), 0, 1, 'C');
            $this->Ln(5);
            
            // Date
            $this->SetFont('Arial', '', 12);
            $this->SetTextColor(128, 128, 128);
            $this->Cell(0, 10, 'Generated: ' . date('F j, Y \a\t g:i A'), 0, 1, 'C');
            $this->Ln(15);
            
            // Performance Section
            if (isset($data['mobile']['performance']['score']) || isset($data['desktop']['performance']['score'])) {
                $this->addSection('Performance Analysis', 'Performance');
                
                if (isset($data['mobile']['performance']['score'])) {
                    $this->addScoreItem('Mobile Performance', $data['mobile']['performance']['score']);
                    
                    // Add mobile metrics
                    if (isset($data['mobile']['metrics'])) {
                        $this->addMetrics('Mobile Metrics', $data['mobile']['metrics']);
                    }
                    
                    // Add mobile opportunities
                    if (isset($data['mobile']['opportunities']) && !empty($data['mobile']['opportunities'])) {
                        $this->addOpportunities('Mobile Optimization Opportunities', $data['mobile']['opportunities']);
                    }
                }
                
                if (isset($data['desktop']['performance']['score'])) {
                    $this->addScoreItem('Desktop Performance', $data['desktop']['performance']['score']);
                    
                    // Add desktop metrics
                    if (isset($data['desktop']['metrics'])) {
                        $this->addMetrics('Desktop Metrics', $data['desktop']['metrics']);
                    }
                    
                    // Add desktop opportunities
                    if (isset($data['desktop']['opportunities']) && !empty($data['desktop']['opportunities'])) {
                        $this->addOpportunities('Desktop Optimization Opportunities', $data['desktop']['opportunities']);
                    }
                }
            }
            
            // SEO Section
            if (isset($data['seo']['score'])) {
                $this->addSection('SEO Analysis', 'SEO');
                $this->addScoreItem('SEO Score', $data['seo']['score']);
                
                // Add SEO audits
                if (isset($data['seo']['audits'])) {
                    $this->addAudits('SEO Audit Results', $data['seo']['audits']);
                }
            }
            
            // Accessibility Section
            if (isset($data['accessibility']['score'])) {
                $this->addSection('Accessibility Analysis', 'Accessibility');
                $this->addScoreItem('Accessibility Score', $data['accessibility']['score']);
                
                // Add accessibility audits
                if (isset($data['accessibility']['audits'])) {
                    $this->addAudits('Accessibility Audit Results', $data['accessibility']['audits']);
                }
            }
            
            // Security Section
            if (isset($data['security'])) {
                $this->addSection('Security Analysis', 'Security');
                $this->SetFont('Arial', '', 11);
                $this->SetTextColor(0, 0, 0);
                
                $https_status = $data['security']['https'] ? 'Enabled' : 'Not Enabled';
                $this->addMultiLineText('- HTTPS: ' . $https_status, 170, 8);
                
                // Add security headers
                if (isset($data['security']['headers']) && is_array($data['security']['headers'])) {
                    foreach ($data['security']['headers'] as $header) {
                        $status = $header['present'] ? 'Present' : 'Missing';
                        $text = '- ' . $this->cleanText($header['name']) . ': ' . $status;
                        $this->addMultiLineText($text, 170, 8);
                    }
                }
                $this->Ln(5);
            }
            
            // Add footer page with SalesNanny branding
            $this->AddPage();
            
            // Thank you section with gradient effect
            $this->SetFillColor(30, 33, 84); // SalesNanny dark blue
            $this->Rect(0, 60, 210, 100, 'F');
            
            // Add accent stripe
            $this->SetFillColor(194, 32, 52); // SalesNanny red
            $this->Rect(0, 55, 210, 10, 'F');
            
            $this->SetTextColor(255, 255, 255);
            $this->SetFont('Arial', 'B', 24);
            $this->SetXY(20, 80);
            $this->Cell(0, 15, 'Thank You for Using SalesNanny!', 0, 1, 'C');
            
            $this->SetFont('Arial', '', 14);
            $this->SetXY(20, 100);
            $this->Cell(0, 10, 'Your trusted partner for website analysis and optimization', 0, 1, 'C');
            
            $this->SetTextColor(194, 32, 52); // SalesNanny red for website link
            $this->SetFont('Arial', 'B', 18);
            $this->SetXY(20, 120);
            $this->Cell(0, 10, 'https://salesnanny.com', 0, 1, 'C');
            
            $this->SetTextColor(255, 255, 255);
            $this->SetFont('Arial', '', 12);
            $this->SetXY(20, 135);
            $this->Cell(0, 8, 'For more website analysis tools, SEO services, and digital marketing solutions', 0, 1, 'C');
            $this->SetXY(20, 145);
            $this->Cell(0, 8, 'Contact: support@salesnanny.com', 0, 1, 'C');
            
            return $this->Output('S');
        }
        
        private function addSection($title, $icon) {
            $this->Ln(5);
            $this->SetTextColor(30, 33, 84); // SalesNanny dark blue
            $this->SetFont('Arial', 'B', 16);
            $this->Cell(0, 12, $title, 0, 1, 'L');
            $this->Ln(3);
        }
        
        private function addScoreItem($label, $score) {
            // Score circle background with SalesNanny brand colors
            $this->SetFillColor(254, 244, 244); // Light SalesNanny background
            $this->Rect(20, $this->GetY(), 170, 25, 'F');
            
            // Score circle
            $color = $this->getScoreColor($score);
            $this->SetFillColor($color[0], $color[1], $color[2]);
            $this->Circle(35, $this->GetY() + 12, 10, 'F');
            
            // Score text in circle
            $this->SetTextColor(255, 255, 255);
            $this->SetFont('Arial', 'B', 12);
            $this->SetXY(30, $this->GetY() + 8);
            $this->Cell(10, 8, $score, 0, 0, 'C');
            
            // Label and description
            $this->SetTextColor(30, 33, 84); // SalesNanny dark blue
            $this->SetFont('Arial', 'B', 13);
            $this->SetXY(55, $this->GetY() + 5);
            $this->Cell(0, 8, $label . ': ' . $score . '%', 0, 1, 'L');
            
            $this->SetFont('Arial', '', 10);
            $this->SetTextColor(120, 120, 120); // Neutral gray
            $this->SetX(55);
            $this->Cell(0, 8, $this->getScoreDescription($score), 0, 1, 'L');
            
            $this->Ln(8);
        }
        
        private function getScoreColor($score) {
            if ($score >= 90) return [40, 167, 69];      // Green (keep for excellent)
            if ($score >= 70) return [30, 33, 84];       // SalesNanny dark blue (good)
            if ($score >= 50) return [255, 193, 7];      // Yellow (needs improvement)
            return [194, 32, 52];                        // SalesNanny red (poor)
        }
        
        private function getScoreDescription($score) {
            if ($score >= 90) return 'Excellent performance!';
            if ($score >= 70) return 'Good performance with room for improvement';
            if ($score >= 50) return 'Average performance, optimization needed';
            return 'Poor performance, immediate attention required';
        }
        
        private function Circle($x, $y, $r, $style='D') {
            $this->Ellipse($x, $y, $r, $r, $style);
        }
        
        private function Ellipse($x, $y, $rx, $ry, $style='D') {
            if($style=='F')
                $op='f';
            elseif($style=='FD' || $style=='DF')
                $op='B';
            else
                $op='S';
            $lx=4/3*(M_SQRT2-1)*$rx;
            $ly=4/3*(M_SQRT2-1)*$ry;
            $k=$this->k;
            $h=$this->h;
            $this->_out(sprintf('%.2F %.2F m %.2F %.2F %.2F %.2F %.2F %.2F c',
                ($x+$rx)*$k,($h-$y)*$k,
                ($x+$rx)*$k,($h-($y-$ly))*$k,
                ($x+$lx)*$k,($h-($y-$ry))*$k,
                $x*$k,($h-($y-$ry))*$k));
            $this->_out(sprintf('%.2F %.2F %.2F %.2F %.2F %.2F c',
                ($x-$lx)*$k,($h-($y-$ry))*$k,
                ($x-$rx)*$k,($h-($y-$ly))*$k,
                ($x-$rx)*$k,($h-$y)*$k));
            $this->_out(sprintf('%.2F %.2F %.2F %.2F %.2F %.2F c',
                ($x-$rx)*$k,($h-($y+$ly))*$k,
                ($x-$lx)*$k,($h-($y+$ry))*$k,
                $x*$k,($h-($y+$ry))*$k));
            $this->_out(sprintf('%.2F %.2F %.2F %.2F %.2F %.2F c %s',
                ($x+$lx)*$k,($h-($y+$ry))*$k,
                ($x+$rx)*$k,($h-($y+$ly))*$k,
                ($x+$rx)*$k,($h-$y)*$k,
                $op));
        }
        
        private function addMetrics($title, $metrics) {
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(30, 33, 84); // SalesNanny dark blue
            $this->Cell(0, 10, $this->cleanText($title), 0, 1, 'L');
            $this->Ln(2);
            
            $this->SetFont('Arial', '', 10);
            $this->SetTextColor(0, 0, 0);
            
            foreach ($metrics as $metric_key => $metric) {
                $metric_name = ucwords(str_replace('-', ' ', $metric_key));
                $display_value = $this->cleanText($metric['displayValue'] ?? 'N/A');
                $score = isset($metric['score']) ? round($metric['score'] * 100) . '%' : 'N/A';
                
                $text = '- ' . $metric_name . ': ' . $display_value . ' (Score: ' . $score . ')';
                $this->addMultiLineText($text, 170, 6);
            }
            $this->Ln(5);
        }
        
        private function addOpportunities($title, $opportunities) {
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(30, 33, 84); // SalesNanny dark blue
            $this->Cell(0, 10, $this->cleanText($title), 0, 1, 'L');
            $this->Ln(2);
            
            $this->SetFont('Arial', '', 10);
            $this->SetTextColor(0, 0, 0);
            
            $count = 0;
            foreach ($opportunities as $opportunity) {
                if ($count >= 5) break; // Limit to top 5 opportunities
                
                $title_text = $this->cleanText($opportunity['title'] ?? 'Optimization Opportunity');
                $description = $this->cleanText($opportunity['description'] ?? '');
                
                // Add opportunity title
                $this->addMultiLineText('- ' . $title_text, 170, 6);
                
                // Add description if available (truncated to keep PDF readable)
                if (!empty($description)) {
                    $this->SetX(25);
                    $truncated_desc = strlen($description) > 100 ? substr($description, 0, 100) . '...' : $description;
                    $this->addMultiLineText($truncated_desc, 145, 5);
                }
                $this->Ln(3);
                $count++;
            }
            $this->Ln(5);
        }
        
        private function addAudits($title, $audits) {
            $this->SetFont('Arial', 'B', 12);
            $this->SetTextColor(30, 33, 84); // SalesNanny dark blue
            $this->Cell(0, 10, $this->cleanText($title), 0, 1, 'L');
            $this->Ln(2);
            
            $this->SetFont('Arial', '', 10);
            $this->SetTextColor(0, 0, 0);
            
            $count = 0;
            foreach ($audits as $audit_key => $audit) {
                if ($count >= 8) break; // Limit to top 8 audits
                
                $title_text = $this->cleanText($audit['title'] ?? ucwords(str_replace('-', ' ', $audit_key)));
                $score = isset($audit['score']) ? round($audit['score'] * 100) : 0;
                $status = $score >= 90 ? 'Pass' : ($score >= 50 ? 'Warning' : 'Fail');
                
                $text = '- ' . $title_text . ': ' . $status . ' (' . $score . '%)';
                $this->addMultiLineText($text, 170, 6);
                $count++;
            }
            $this->Ln(5);
        }
    }
}

/**
 * Generate PDF using our FPDF-based PDF generator
 */
if (!function_exists('generate_salesnanny_pdf')) {
    function generate_salesnanny_pdf($data) {
        $pdf = new SalesNannyPDFGenerator();
        
        // Create the complete PDF report
        return $pdf->createReport($data);
    }
}
?>
