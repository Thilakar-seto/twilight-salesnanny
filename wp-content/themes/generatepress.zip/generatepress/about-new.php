<?php
   /*
   Template Name: About Us New
   */
   ?>
<!DOCTYPE html>
<html>
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
   <body>
        <div>
            <?php salesnanny_nav_header(); ?>
                <style>
                    .sn-bento-images-grid img,.sn-bento-img,.sn-person img{height:100%;object-fit:cover}.sn-container,.sn-footer,.sn-hero,.sn-overlay,.sn-wrapper{box-sizing:border-box!important}:root{--sn-navy:#0F172A;--sn-text:#334155;--sn-bg:#F8FAFC;--card-bg:#FFFFFF;--overlay-navy:#0F172A;--overlay-red:#D9232D}html{scroll-behavior:smooth}.sn-wrapper{color:var(--sn-text);line-height:1.6;background-color:var(--sn-bg);background-image:radial-gradient(#cbd5e1 1px,transparent 1px);background-size:30px 30px;width:100%;text-align:left}.sn-container{max-width:1280px;margin:0 auto;padding:0 40px}h1,h2,h3,h4{color:var(--sn-navy);font-weight:700;margin:0;line-height:1.2}p{margin-bottom:1.5rem}.sn-hero{text-align:center;padding:50px 20px;background:linear-gradient(156deg,#0f172a 34%,#1e293be6 49%,#d9232d 100%);color:#fff;position:relative;box-shadow:0 10px 40px -10px rgba(15,23,42,.5);z-index:10;margin-top:80px}.sn-hero h1{font-size:46px;margin-bottom:25px;letter-spacing:-.03em;color:#fff}.sn-hero p{font-size:1.4rem;color:#e2e8f0;max-width:800px;margin:0 auto;font-weight:400}.sn-manifesto{padding:50px 0 60px;text-align:center}.sn-manifesto h2{font-size:46px;max-width:900px;margin:0 auto;color:var(--sn-navy)}.sn-highlight{color:#d9232d;background:#fff1f2;padding:0 10px;border-radius:8px}.sn-timeline-header h2{font-size:46px;margin-bottom:25px;letter-spacing:-.03em;color:var(--sn-navy);font-weight:700;line-height:1.2;text-align:center;margin-top:0}.sn-bento-section{padding:40px 0 100px}.sn-bento-grid{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:300px 300px;gap:20px}.sn-bento-item{background:#fff;border-radius:24px;overflow:hidden;position:relative;box-shadow:0 10px 30px -10px rgba(0,0,0,.05);border:1px solid rgba(255,255,255,.5);display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:30px;transition:transform .3s}.sn-bento-images-grid,.sn-bento-images-grid img,.sn-bento-img,.sn-bento-overlay{position:absolute;left:0;width:100%}.sn-bento-item:hover{transform:translateY(-5px)}.sn-item-large{grid-column:span 2}.sn-item-tall{grid-row:span 2;background:#0f172a;color:#fff;padding:0!important}.sn-bento-img{top:0;z-index:0}.sn-bento-images-grid{top:0;height:100%;display:flex;overflow:hidden;z-index:0}.sn-bento-images-grid img{flex-shrink:0;opacity:0;transition:opacity 1s ease-in-out;top:0}.sn-bento-images-grid img.active{opacity:1;position:relative}.sn-bento-item:hover .sn-bento-images-grid img.active{transform:scale(1.02);transition:transform .5s,opacity 1s ease-in-out}.sn-bento-overlay{bottom:0;padding:30px;background:linear-gradient(to top,rgba(0,0,0,.8),transparent);color:#fff;z-index:1;text-align:left}.sn-ig-bottom,.sn-ig-top{display:flex;padding:20px}.sn-bento-icon{font-size:3rem;margin-bottom:20px}.sn-bento-item h3{font-size:24px;color:#fff;margin-bottom:10px;z-index:2}.sn-bento-item p{font-size:1rem;opacity:.8;z-index:2;margin-bottom:0}.sn-info-graphic{display:flex;flex-direction:column;width:100%;height:100%}.sn-ig-top{flex:1;flex-direction:column;justify-content:center;align-items:center;background:rgba(255,255,255,.05);border-bottom:1px solid rgba(255,255,255,.1)}.sn-ig-bottom{flex:1.2;flex-direction:column;justify-content:center;align-items:center;background:#0f172a;position:relative}.sn-ig-arrow,.sn-ig-icon{align-items:center;border-radius:50%;display:flex}.sn-ig-icon-group{display:flex;gap:10px;margin-bottom:15px}.sn-ig-icon{width:40px;height:40px;background:rgba(255,255,255,.1);justify-content:center;font-size:1.2rem}.sn-ig-arrow,.sn-ig-highlight{background:#d9232d;color:#fff}.sn-ig-highlight{box-shadow:0 0 15px rgba(217,35,45,.5)}.sn-ig-label{font-size:.9rem;opacity:.7;text-transform:uppercase;letter-spacing:1px;margin-bottom:5px}.sn-ig-value{font-size:1.4rem;font-weight:800;color:#fff}.sn-ig-arrow{position:absolute;top:-15px;width:30px;height:30px;justify-content:center;font-weight:700;font-size:1.2rem;border:4px solid #0f172a}.sn-partners-section,.sn-timeline-section{padding:50px 0;background:#fff;border-top:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0}.sn-partners-header,.sn-section-header,.sn-timeline-header{text-align:center;margin-bottom:60px}.sn-timeline-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:30px;position:relative}.sn-timeline-grid::before{content:'';position:absolute;top:20px;left:0;width:100%;height:2px;background:#e2e8f0;z-index:0}.sn-year-card{position:relative;z-index:1;background:#fff;padding-top:40px}.sn-year-dot{width:20px;height:20px;background:#d9232d;border-radius:50%;position:absolute;top:11px;left:50%;transform:translateX(-50%);border:4px solid #fff;box-shadow:0 0 0 1px #e2e8f0}.sn-year{font-size:2rem;font-weight:800;color:#0f172a;margin-bottom:10px;text-align:center}.sn-year-desc{font-size:.95rem;text-align:center;color:#64748b}.sn-fun-fact,.sn-fun-title,.sn-overlay{text-align:center!important}.sn-process-section{padding:50px 0 0}.sn-process-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:center}.sn-step-list{counter-reset:sn-counter}.sn-step-item{position:relative;padding-left:60px;margin-bottom:40px}.sn-step-item::before{counter-increment:sn-counter;content:"0" counter(sn-counter);position:absolute;left:0;top:0;font-size:1.5rem;font-weight:800;color:#d9232d;background:#fff1f2;width:45px;height:45px;border-radius:50%;display:flex;align-items:center;justify-content:center}.sn-step-item h3{font-size:1.3rem;margin-bottom:10px}.sn-step-item p{font-size:1rem;color:#475569;margin-bottom:0}.sn-leadership-section{padding:50px 0;background:#fff;border-top:1px solid #e2e8f0}.sn-section-header h2{font-size:46px;margin-bottom:15px}.sn-gallery{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}.sn-person{position:relative;border-radius:20px;overflow:hidden;aspect-ratio:3/4;cursor:pointer;transform:translateZ(0);background:var(--card-bg);box-shadow:0 4px 6px -1px rgba(0,0,0,.1);transition:transform .4s ease-out,box-shadow .4s ease-out}.sn-info-pill,.sn-overlay{position:absolute;background:#0f172a}.sn-person:hover{transform:translateY(-8px);box-shadow:0 20px 40px -10px rgba(0,0,0,.15)}.sn-person img{width:100%;transition:transform .8s cubic-bezier(.25, .46, .45, .94)}.sn-person:hover img{transform:scale(1.15)}.sn-info-pill{bottom:20px;left:20px;color:#fff;padding:10px 20px;border-radius:50px;display:flex;align-items:center;gap:10px;z-index:2;transition:opacity .3s}.sn-info-pill strong{font-weight:700;font-size:.85rem}.sn-info-pill span{font-weight:400;font-size:.8rem;opacity:.8;padding-left:8px;border-left:1px solid rgba(255,255,255,.3)}.sn-person:hover .sn-info-pill{opacity:0}.sn-overlay{top:0;left:0;width:100%!important;height:100%!important;display:flex!important;flex-direction:column!important;justify-content:center!important;align-items:center!important;padding:20px!important;opacity:0;z-index:3;transition:opacity .4s}.leader-paulos .sn-overlay{background:linear-gradient(135deg,#ea580c,#d9232d)}.leader-surya .sn-overlay{background:linear-gradient(135deg,#0284c7,#2563eb)}.leader-muthu .sn-overlay{background:linear-gradient(135deg,#059669,#10b981)}.leader-hari .sn-overlay{background:linear-gradient(135deg,#7c3aed,#db2777)}.sn-person:hover .sn-overlay{opacity:1}.sn-overlay-content{width:100%!important;transform:translateY(20px);transition:transform .5s;display:flex;flex-direction:column;align-items:center}.sn-person:hover .sn-overlay-content{transform:translateY(0)}.sn-fun-title{color:#fff;font-size:1.4rem;font-weight:800;margin-bottom:10px}.sn-fun-fact{color:#f1f5f9;font-size:1rem;font-style:italic}.sn-faq-section{padding:50px 0;background:#f8fafc;border-top:1px solid #e2e8f0}.sn-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:40px}.sn-faq-item{background:#fff;padding:40px;border-radius:16px;border:1px solid #e2e8f0;box-shadow:0 4px 6px -1px rgba(0,0,0,.05);transition:transform .3s}.sn-faq-item:hover{transform:translateY(-5px);border-color:#cbd5e1}.sn-faq-item h3{font-size:1.3rem;margin-bottom:15px;color:#0f172a;line-height:1.4}.sn-faq-item p{font-size:1rem;color:#64748b;margin:0;line-height:1.6}.sn-footer{text-align:center;padding:50px 0;background:#0f172a;color:#fff}.sn-footer h2{color:#fff;font-size:46px;margin-bottom:30px;letter-spacing:-.02em}.sn-btn{display:inline-block;background:#d9232d;color:#fff;padding:10px 25px;border-radius:8px;font-size:16px;text-decoration:none;transition:.3s}.sn-btn:hover{background:#fff;color:#d9232d;transform:translateY(-3px)}.sn-partners-header h2{font-size:46px;margin-bottom:15px;color:var(--sn-navy);font-weight:700}.sn-partners-header p{font-size:1.1rem;color:#64748b;margin:0}.sn-partners-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:40px;align-items:center;justify-items:center}.sn-partner-logo{display:flex;align-items:center;justify-content:center;width:100%;max-width:150px;height:60px}.sn-partner-logo:hover{opacity:1;transform:scale(1.1);filter:grayscale(0%)}.sn-partner-logo img{width:100%;height:auto;max-width:150px;max-height:60px;object-fit:contain}@media (max-width:1024px){.sn-bento-grid{grid-template-columns:1fr;grid-template-rows:auto}.sn-item-large{grid-column:span 1;height:300px}.sn-gallery{grid-template-columns:repeat(2,1fr)}.sn-timeline-grid{grid-template-columns:1fr 1fr;gap:50px}.sn-timeline-grid::before{display:none}.sn-partners-grid{grid-template-columns:repeat(3,1fr);gap:30px}}@media (max-width:768px){.sn-faq-grid,.sn-gallery,.sn-process-grid{grid-template-columns:1fr}.sn-hero h1{font-size:3rem}.sn-process-grid{gap:40px}.sn-container{padding:0 20px}.sn-partners-section{padding:60px 0}.sn-partners-header h2{font-size:36px}.sn-partners-grid{grid-template-columns:repeat(2,1fr);gap:30px}}@media (max-width:480px){.sn-container{padding:0 15px}.sn-hero{padding:40px 15px;margin-top:60px}.sn-hero h1{font-size:28px;margin-bottom:15px;line-height:1.2}.sn-hero p{font-size:1rem;line-height:1.5}.sn-manifesto{padding:40px 0 50px}.sn-manifesto h2{font-size:24px;line-height:1.3;padding:0 15px}.sn-highlight{padding:0 6px;display:inline-block}.sn-bento-section{padding:30px 0 60px}.sn-bento-grid,.sn-gallery{gap:15px}.sn-bento-item{padding:20px;border-radius:16px}.sn-item-large,.sn-item-tall{height:250px}.sn-bento-icon{font-size:2rem;margin-bottom:15px}.sn-bento-item h3{font-size:18px;margin-bottom:8px}.sn-bento-item p,.sn-faq-item p,.sn-partners-header p,.sn-section-header p,.sn-step-item p,.sn-timeline-header p{font-size:.9rem}.sn-bento-overlay{padding:20px 15px}.sn-bento-overlay h3{font-size:18px}.sn-bento-overlay p,.sn-fun-fact,.sn-year-desc{font-size:.85rem}.sn-ig-bottom,.sn-ig-top{padding:15px}.sn-ig-icon{width:32px;height:32px;font-size:1rem}.sn-ig-icon-group{gap:8px;margin-bottom:10px}.sn-ig-label,.sn-info-pill strong{font-size:.75rem}.sn-ig-value{font-size:1.1rem}.sn-ig-arrow{width:24px;height:24px;font-size:1rem;top:-12px}.sn-faq-section,.sn-footer,.sn-leadership-section,.sn-partners-section,.sn-timeline-section{padding:40px 0}.sn-partners-header,.sn-section-header,.sn-timeline-header{margin-bottom:40px}.sn-process-grid h2,.sn-timeline-header h2{font-size:24px;margin-bottom:15px}.sn-timeline-grid{grid-template-columns:1fr;gap:30px}.sn-timeline-grid::before{display:none}.sn-year-card{padding-top:0}.sn-year-dot{position:static;transform:none;margin:0 auto 15px}.sn-year{font-size:1.5rem;margin-bottom:8px}.sn-process-section{padding:40px 0 0}.sn-process-grid{gap:30px}.sn-process-grid p{font-size:.9rem;margin-bottom:0}.sn-step-item{padding-left:50px;margin-bottom:30px}.sn-step-item::before{width:40px;height:40px;font-size:1.2rem}.sn-fun-title,.sn-step-item h3{font-size:1.1rem;margin-bottom:8px}.sn-partners-header h2,.sn-section-header h2{font-size:24px;margin-bottom:10px}.sn-info-pill{bottom:15px;left:15px;padding:8px 15px}.sn-info-pill span{font-size:.7rem;padding-left:6px}.sn-faq-grid{gap:20px}.sn-faq-item{padding:25px 20px;border-radius:12px}.sn-faq-item h3{font-size:1.1rem;margin-bottom:12px}.sn-footer h2{font-size:24px;margin-bottom:20px;line-height:1.3}.sn-btn{padding:12px 24px;font-size:14px}.sn-partners-grid{grid-template-columns:repeat(2,1fr);gap:20px}.sn-partner-logo{max-width:120px;height:50px}}
                </style>
                <div class="sn-wrapper">
                    <section class="sn-hero">
                        <div class="sn-container">
                        <h1>The Marketing Team That<br>Replaces Your Chaos With Growth.</h1>
                        <p>We are SalesNanny. A registered Private Limited agency of 18 experts building revenue engines for businesses worldwide.</p>
                        </div>
                    </section>
                    <section class="sn-manifesto">
                        <div class="sn-container">
                        <h2>We replaced the chaos of freelancing with the power of a <span class="sn-highlight">Unified Team</span>.</h2>
                        </div>
                    </section>
                    <section class="sn-bento-section">
                        <div class="sn-container">
                        <div class="sn-bento-grid">
                            
                            <div class="sn-bento-item sn-item-large">
                            <div class="sn-bento-images-grid" id="office-carousel">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/office-salesnanny.webp" alt="SalesNanny Chennai Headquarters workspace" loading="lazy" class="active">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/office-1-salesnanny.webp" alt="SalesNanny Chennai Headquarters team area" loading="lazy">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/office-2-salesnanny.webp" alt="SalesNanny Chennai Headquarters collaboration space" loading="lazy">
                            </div>
                            <div class="sn-bento-overlay">
                                <h3>Chennai HQ</h3>
                                <p>Our 3000 sq ft engine room in the SaaS Capital.</p>
                            </div>
                            </div>

                            <div class="sn-bento-item sn-item-tall">
                            <div class="sn-info-graphic">
                                <div class="sn-ig-top">
                                <span class="sn-ig-label">Others</span>
                                <div class="sn-ig-icon-group">
                                    <span class="sn-ig-icon">👤</span>
                                </div>
                                <span class="sn-ig-value">1 Hire</span>
                                </div>
                                <div class="sn-ig-bottom">
                                <span class="sn-ig-arrow">VS</span>
                                <span class="sn-ig-label" style="color:white; opacity:0.8;">SalesNanny</span>
                                <div class="sn-ig-icon-group">
                                    <span class="sn-ig-icon sn-ig-highlight">🛠️</span>
                                    <span class="sn-ig-icon sn-ig-highlight">🎨</span>
                                    <span class="sn-ig-icon sn-ig-highlight">📈</span>
                                    <span class="sn-ig-icon sn-ig-highlight">💻</span>
                                </div>
                                <span class="sn-ig-value">Entire Team</span>
                                <span style="font-size:0.8rem; margin-top:5px; color:#cbd5e1;">(For the same cost)</span>
                                </div>
                            </div>
                            </div>

                            <div class="sn-bento-item">
                            <span class="sn-bento-icon">🏢</span>
                            <h3>100% In-House</h3>
                            <p>No freelancers. No outsourcing. Just us.</p>
                            </div>

                            <div class="sn-bento-item">
                            <span class="sn-bento-icon">🎯</span>
                            <h3>Specialized</h3>
                            <p>We don't hire generalists. We hire experts.</p>
                            </div>

                        </div>
                        </div>
                    </section>
                    <section class="sn-timeline-section">
                        <div class="sn-container">
                        <div class="sn-timeline-header">
                            <h2>Our Journey</h2>
                            <p>From a small idea to a global engine.</p>
                        </div>
                        <div class="sn-timeline-grid">
                            <div class="sn-year-card">
                            <div class="sn-year-dot"></div>
                            <div class="sn-year">2022</div>
                            <div class="sn-year-desc">Founded in Chennai with a vision to fix broken agency models.</div>
                            </div>
                            <div class="sn-year-card">
                            <div class="sn-year-dot"></div>
                            <div class="sn-year">2023</div>
                            <div class="sn-year-desc">Grew to 5 core members. Landed first US & UK clients.</div>
                            </div>
                            <div class="sn-year-card">
                            <div class="sn-year-dot"></div>
                            <div class="sn-year">2024</div>
                            <div class="sn-year-desc">Expanded to 12 members. Moved into 3000sq ft HQ.</div>
                            </div>
                            <div class="sn-year-card">
                            <div class="sn-year-dot"></div>
                            <div class="sn-year">2025</div>
                            <div class="sn-year-desc">Now 18+ experts strong. Serving 200+ global brands.</div>
                            </div>
                        </div>
                        </div>
                    </section>
                    <section class="sn-partners-section">
                        <div class="sn-container">
                        <div class="sn-partners-header">
                            <h2>Trusted By</h2>
                            <p>Leading companies across industries</p>
                        </div>
                        <div class="sn-partners-grid">
                            <div class="sn-partner-logo">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/slideegg-logo.png" alt="Slideegg" loading="lazy" width="150" height="29">
                            </div>
                            <div class="sn-partner-logo">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/slidea-logo.png" alt="Slidea" loading="lazy" width="150" height="29">
                            </div>
                            <div class="sn-partner-logo">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/fosdesk-logo.svg" alt="Fosdesk" loading="lazy" width="150" height="29">
                            </div>
                            <div class="sn-partner-logo">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/elicit-logo.png" alt="Elicit" loading="lazy" width="150" height="29">
                            </div>
                            <div class="sn-partner-logo">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/wisebi-logo.png" alt="WiseBI" loading="lazy" width="150" height="29">
                            </div>
                            <div class="sn-partner-logo">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/carguber-logo.png" alt="Carguber" loading="lazy" width="150" height="29">
                            </div>
                        </div>
                        </div>
                    </section>
                    <section class="sn-process-section">
                        <div class="sn-container">
                        <div class="sn-process-grid">
                            <div>
                            <h2>The SalesNanny Method.</h2>
                            <p>We don't guess. We follow a proven framework that has generated revenue for 200+ companies. Here is how we will handle your brand.</p>
                            </div>
                            <div class="sn-step-list">
                            <div class="sn-step-item">
                                <h3>1. The Deep Audit</h3>
                                <p>We tear down your current strategy to find leaks in SEO, Ad Spend, and Brand Messaging.</p>
                            </div>
                            <div class="sn-step-item">
                                <h3>2. The Engine Build</h3>
                                <p>Our dev & design team revamps your assets while strategy prepares the roadmap.</p>
                            </div>
                            <div class="sn-step-item">
                                <h3>3. Growth Execution</h3>
                                <p>We launch. Daily content, weekly optimizations, and aggressive outreach.</p>
                            </div>
                            <div class="sn-step-item">
                                <h3>4. Scale & Report</h3>
                                <p>Transparent weekly reports. We double down on what works and cut what doesn't.</p>
                            </div>
                            </div>
                        </div>
                        </div>
                    </section>
                    <section class="sn-leadership-section">
                        <div class="sn-container">
                        <div class="sn-section-header">
                            <h2>Led by Functional Experts</h2>
                            <p>No hiding behind titles. Our leaders work directly on your account.</p>
                        </div>
                        <div class="sn-gallery">
                            <div class="sn-person leader-paulos">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/paulos-salesnanny.webp" alt="Paulos Raja - Head of Sales and Founder at SalesNanny">
                            <div class="sn-info-pill"><strong>Paulos</strong><span>Head of Sales</span></div>
                            <div class="sn-overlay"><div class="sn-overlay-content"><div class="sn-fun-title">The Rainmaker</div><div class="sn-fun-fact">"Ensures every campaign is built to convert."</div></div></div>
                            </div>
                            <div class="sn-person leader-surya">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/surya-salesnanny.webp" alt="Surya Prakash - Tech Lead and Digital Architect at SalesNanny">
                            <div class="sn-info-pill"><strong>Surya</strong><span>Tech Lead</span></div>
                            <div class="sn-overlay"><div class="sn-overlay-content"><div class="sn-fun-title">The Architect</div><div class="sn-fun-fact">"Bridges the gap between code and data."</div></div></div>
                            </div>
                            <div class="sn-person leader-muthu">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/jelshiya-salesnanny.webp" alt="Jelshiya - Business Dev at SalesNanny">
                            <div class="sn-info-pill"><strong>Jelshiya</strong><span>Business Dev</span></div>
                            <div class="sn-overlay"><div class="sn-overlay-content"><div class="sn-fun-title">Client Welcome</div><div class="sn-fun-fact">"Makes onboarding feel like a welcome party, not homework."</div></div></div>
                            </div>
                            <div class="sn-person leader-hari">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/hari-salesnanny.webp" alt="Hari - Creative Lead managing visual identity at SalesNanny">
                            <div class="sn-info-pill"><strong>Hari</strong><span>Creative Lead</span></div>
                            <div class="sn-overlay"><div class="sn-overlay-content"><div class="sn-fun-title">Pixel Perfect</div><div class="sn-fun-fact">"Manages visual identity for impact."</div></div></div>
                            </div>
                        </div>
                        </div>
                    </section>
                    <section class="sn-faq-section">
                        <div class="sn-container">
                        <div class="sn-section-header">
                            <h2>Common Questions</h2>
                        </div>
                        <div class="sn-faq-grid">
                            
                            <div class="sn-faq-item">
                            <h3>Why are you based in Chennai?</h3>
                            <p>Chennai is the SaaS Capital of India (home to Zoho and Freshworks). It allows us to access world-class engineering and creative talent while keeping costs efficient for you.</p>
                            </div>

                            <div class="sn-faq-item">
                            <h3>Do I get a dedicated manager?</h3>
                            <p>Yes. You are assigned a dedicated Project Manager who coordinates the 18-person team for you. You have one point of contact, not 18.</p>
                            </div>

                            <div class="sn-faq-item">
                            <h3>Are you really 100% in-house?</h3>
                            <p>Absolutely. We do not white-label or outsource to freelancers. Every person working on your account is a full-time SalesNanny employee sitting in our office.</p>
                            </div>

                            <div class="sn-faq-item">
                            <h3>How does the "One Employee Cost" work?</h3>
                            <p>For the salary of one mid-level US hire, you get access to our entire team—Designers, Developers, Writers, and Strategists. It's fractional access to a full department.</p>
                            </div>

                            <div class="sn-faq-item">
                            <h3>What time zones do you work in?</h3>
                            <p>We structure our shifts to overlap with US (EST/PST) and UK/EU business hours for seamless communication. We are awake when you are.</p>
                            </div>

                            <div class="sn-faq-item">
                            <h3>How do we communicate?</h3>
                            <p>We integrate into your workflow. We use Slack, Microsoft Teams, or WhatsApp for daily updates, plus scheduled weekly Zoom calls for strategy reviews.</p>
                            </div>

                        </div>
                        </div>
                    </section>
                    <section class="sn-footer">
                        <div class="sn-container">
                        <h2>Small Enough to Care.<br>Big Enough to Scale.</h2>
                        <a href="<?php echo SN_HTTP_URL; ?>our-team/" class="sn-btn">Meet the Full Team</a>
                        </div>
                    </section>
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            const carousel = document.getElementById('office-carousel');
                            if (!carousel) return;
                            
                            const images = carousel.querySelectorAll('img');
                            if (images.length === 0) return;
                            
                            let currentIndex = 0;
                            
                            function showNextImage() {
                                // Remove active class from current image
                                images[currentIndex].classList.remove('active');
                                
                                // Move to next image (loop back to 0 if at end)
                                currentIndex = (currentIndex + 1) % images.length;
                                
                                // Add active class to next image
                                images[currentIndex].classList.add('active');
                            }
                            
                            // Start the carousel - change image every 3 seconds
                            setInterval(showNextImage, 3000);
                        });
                    </script>
                </div>
            <?php salesnanny_footer(); ?>
        </div>
   </body>
</html>