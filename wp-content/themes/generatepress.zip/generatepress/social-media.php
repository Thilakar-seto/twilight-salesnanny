<?php
   /*
   Template Name: Social Media Blogs
   */
   ?>
<html>
<?php get_custom_head(); ?>
   <body>
      <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/blogs.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
      <noscript>
         <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/blogs.noncritical.css"/>
      </noscript>
      <div>
        <style>
            .resource-hero{background-color:#1e2154;padding:80px 20px;text-align:center;width:100%;margin-top:77px;height:auto;min-height:350px;display:flex;flex-direction:column;justify-content:center;align-items:center}.resource-hero__title{font-size:54px;color:#fff;margin-bottom:24px;font-weight:700;line-height:1.2;padding:0 15px}.resource-hero__description{font-size:20px;color:#fff;max-width:800px;margin:0 auto;line-height:1.5;padding:0 15px}.category-nav-container{background-color:#fff;box-shadow:0 4px 12px rgba(0,0,0,.05);z-index:100;padding:10px 20px;border-bottom:1px solid rgba(194,32,52,.1);overflow-x:auto;-webkit-overflow-scrolling:touch;position:sticky;top:77px}.category-nav{display:flex;justify-content:center;max-width:1200px;margin:0 auto;position:relative;gap:8px}.category-nav__item{padding:10px 35px;font-size:16px;font-weight:500;color:#000;text-decoration:none;position:relative;text-align:center;border-radius:20px;margin:8px 0;border:1px solid rgba(194,32,52,.05);background:rgb(194 32 52 / 28%);white-space:nowrap;flex-shrink:0}.category-nav__item.active{color:#c22034;font-weight:600;background:rgba(194,32,52,.05);border:2px solid}.category-nav-toggle{display:none}.blog-container{max-width:1300px;margin:40px auto;padding:0 20px}.blog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px}.blog-card{background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.08);transition:.4s cubic-bezier(.165, .84, .44, 1);height:100%;display:flex;flex-direction:column;position:relative;border:1px solid rgba(0,0,0,.05)}.blog-card__image-container{position:relative;overflow:hidden;height:220px}.blog-card__image{width:100%;height:auto;object-fit:cover;transition:transform .8s}.blog-card__category-badge{position:absolute;top:15px;right:15px;background-color:#c22034;color:#fff;font-weight:600;font-size:12px;padding:6px 12px;border-radius:30px;text-transform:uppercase;letter-spacing:.5px;box-shadow:0 4px 10px rgba(0,0,0,.1);z-index:2}.blog-card__content{padding:25px;flex-grow:1;display:flex;flex-direction:column;position:relative}.blog-card__date{font-size:13px;color:#888;margin-bottom:12px;display:block}.blog-card__title{font-size:20px;font-weight:700;margin-bottom:15px;color:#222;line-height:1.3;transition:color .3s}.blog-card__title a{color:inherit;text-decoration:none;background-image:linear-gradient(transparent calc(100% - 2px),#c22034 2px);background-size:0 100%;background-repeat:no-repeat;transition:background-size .3s}.blog-card__footer{display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:15px;border-top:1px solid #f0f0f0}.blog-card__read-more,.pagination .page-numbers{display:inline-flex;color:#333;text-decoration:none}.blog-card__read-more{align-items:center;font-weight:600;font-size:14px;transition:color .3s}.blog-card__read-more:after{content:"→";margin-left:5px;transition:transform .3s}.blog-card__author{display:flex;align-items:center}.blog-card__author-image{width:30px;height:30px;border-radius:50%;margin-right:8px;object-fit:cover}.blog-card__author-name{font-size:13px;color:#666;text-decoration:none;transition:color .3s}.pagination{display:flex;justify-content:center;margin:50px 0 30px}.pagination .page-numbers{align-items:center;justify-content:center;min-width:40px;height:40px;list-style:none;margin:0 5px;padding:0 12px;border-radius:8px;background:0 0;font-weight:500;transition:.3s}.pagination .page-numbers.current{background:#c22034;color:#fff;font-weight:600}.pagination .next,.pagination .prev{font-size:18px;padding:0 15px}@media (max-width:992px){.blog-grid{grid-template-columns:repeat(2,1fr)}.category-nav{flex-wrap:wrap}.category-nav__item{padding:15px;font-size:15px}.resource-hero{padding:60px 20px;min-height:300px}.resource-hero__title{font-size:42px}.resource-hero__description{font-size:18px}}@media (max-width:576px){.pagination .page-numbers{min-width:36px;height:36px;margin:0 3px;padding:0 10px;font-size:14px}.pagination .next,.pagination .prev{padding:0 12px}.blog-grid{grid-template-columns:1fr}.blog-card__image-container{height:200px}.resource-hero{padding:40px 10px;min-height:200px}.resource-hero__title{font-size:28px;margin-bottom:12px}.resource-hero__description{font-size:15px}}.blog-search-container{max-width:800px;margin:30px auto 20px;padding:0 20px;position:relative}.blog-search-form{display:flex;position:relative;box-shadow:0 5px 15px rgba(0,0,0,.08);border-radius:50px;overflow:hidden}.blog-search-input{flex:1;padding:15px 20px;border:2px solid rgba(194,32,52,.1);border-right:none;border-radius:50px 0 0 50px;font-size:16px;color:#333;background-color:#fff;transition:.3s;font-family:inherit}.blog-search-button{background-color:#c22034;color:#fff;border:none;padding:0 25px;font-size:16px;font-weight:600;cursor:pointer;border-radius:0 50px 50px 0;transition:background-color .3s;display:flex;align-items:center;justify-content:center}.blog-search-button i{margin-right:8px}@media (max-width:768px){.category-nav-container{padding:10px;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none;-ms-overflow-style:none}.category-nav-container::-webkit-scrollbar{display:none}.category-nav{justify-content:flex-start;padding:0;gap:8px;width:max-content;min-width:100%}.category-nav__item{padding:8px 20px;font-size:14px;margin:0;border-radius:15px}.resource-hero{padding:50px 15px;min-height:250px;margin-top:60px}.resource-hero__title{font-size:32px;margin-bottom:16px}.resource-hero__description{font-size:16px}.blog-search-container{margin:20px auto}.blog-search-input{padding:12px 15px;font-size:15px}.blog-search-button{padding:0 20px;font-size:15px}}@media (max-width:480px){.category-nav-container{padding:8px}.category-nav__item{padding:6px 15px;font-size:13px}.resource-hero{padding:40px 10px;min-height:300px}.resource-hero__title{font-size:28px;margin-bottom:12px}.resource-hero__description{font-size:15px}}@media (max-width:576px){.blog-search-button span{display:none}.blog-search-button i{margin-right:0}.blog-search-button{padding:0 15px}}
        </style>
        <?php salesnanny_nav_header(); ?>
        <section class="resource-hero">
        <h1 class="resource-hero__title"> Social Media Community: Build Connections and Engagements</h1>
        <p class="resource-hero__description">Stay ahead of the curve with our insights on emerging social media trends. Get predictions and strategies to prepare for the future of social.</p>
        </section>
        <div class="category-nav-container">
        <button class="category-nav-toggle">Categories</button>
        <nav class="category-nav">
            <a href="<?php echo SN_HTTP_URL; ?>blogs/" class="category-nav__item ">All</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/digital-marketing/" class="category-nav__item ">Digital marketing</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/seo/" class="category-nav__item">SEO</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/aeo/" class="category-nav__item">AEO</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/social-media/" class="category-nav__item active">Social media</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/ppc/" class="category-nav__item">PPC</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/web-development/" class="category-nav__item">Web Development</a>
            <a href="<?php echo SN_HTTP_URL; ?>blogs/designs/" class="category-nav__item">Designs</a>
        </nav>
        </div>
        <div class="blog-container">
        <div class="blog-grid">
            <?php
                // Get current page
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                
                // Define our six allowed categories
                $allowed_categories = array(
                    'social-media'
    
                );
                
                // Set up query arguments
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => 9,
                    'paged' => $paged
                );
                
                // Add category filter if set and valid
                if (isset($_GET['category']) && $_GET['category'] != 'all') {
                    $category = sanitize_text_field($_GET['category']);
                    if (in_array($category, $allowed_categories)) {
                        $args['category_name'] = $category;
                    }
                } else {
                    // If no category is selected or "all" is selected, show posts from all allowed categories
                    $args['category_name'] = implode(',', $allowed_categories);
                }
                
                // The Query
                $query = new WP_Query($args);
                
                // The Loop
                if ($query->have_posts()) {
                    while ($query->have_posts()) {
                        $query->the_post();
                        
                        // Get the first category
                        $categories = get_the_category();
                        $category_name = !empty($categories) ? esc_html($categories[0]->name) : 'Uncategorized';
                        
                        // Get author info
                        $author_id = get_the_author_meta('ID');
                        $author_name = get_the_author();
                        $author_url = get_author_posts_url($author_id);
                        $author_avatar = get_avatar_url($author_id, array('size' => 60));
                        ?>
            <article class="blog-card">
                <?php if (has_post_thumbnail()): ?>
                <div class="blog-card__image-container">
                    <a href="<?php the_permalink(); ?>">
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'medium_large')); ?>" 
                    alt="<?php the_title_attribute(); ?>" 
                    class="blog-card__image"
                    loading="lazy">
                    </a>
                    <?php if (!empty($categories)): ?>
                    <span class="blog-card__category-badge">
                    <?php echo $category_name; ?>
                    </span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="blog-card__content">
                    <span class="blog-card__date"><?php echo get_the_date(); ?></span>
                    <h2 class="blog-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="blog-card__footer">
                    <a href="<?php the_permalink(); ?>" class="blog-card__read-more">Read More</a>
                    <div class="blog-card__author">
                        <img src="<?php echo esc_url($author_avatar); ?>" 
                            alt="<?php echo esc_attr($author_name); ?>" 
                            class="blog-card__author-image"
                            loading="lazy">
                        <a href="<?php echo esc_url($author_url); ?>" class="blog-card__author-name">
                        <?php echo esc_html($author_name); ?>
                        </a>
                    </div>
                    </div>
                </div>
            </article>
            <?php
                }
                } else {
                echo '<div class="no-posts">No posts found in this category.</div>';
                }
                ?>
        </div>
        <?php
            // Pagination - moved outside the blog-grid div
            if ($query->max_num_pages > 1) {
                echo '<div class="pagination">';
                
                $big = 999999999; // need an unlikely integer
                echo paginate_links(array(
                    'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format' => '?paged=%#%',
                    'current' => max(1, $paged),
                    'total' => $query->max_num_pages,
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'type' => 'list'
                ));
                
                echo '</div>';
            }
            
            // Restore original Post Data
            wp_reset_postdata();
            ?>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const menuToggle = document.querySelector('.category-nav-toggle');
                const menu = document.querySelector('.category-nav');
                
                menuToggle.addEventListener('click', function() {
                    menu.classList.toggle('show');
                    if (menu.classList.contains('show')) {
                        menuToggle.textContent = 'Categories ×';
                    } else {
                        menuToggle.textContent = 'Categories';
                        menuToggle.innerHTML += '☰';
                    }
                });
            });
        </script>
        <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>