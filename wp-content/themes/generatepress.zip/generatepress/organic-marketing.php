<?php
/*
Template Name: Organic Marketing
*/
?>
<html>
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
<body>    
      <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/earned-media.non-critical.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
      <noscript>
            <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/earned-media.non-critical.css" />
      </noscript>
    <div>
        <style>
            .channel-card img,.illustration-column img,.process-diagram img{max-width:100%;height:auto}.hero-wrapper{background-color:#fdf3f3;width:100%}.hero-section{padding:80px 20px;min-height:600px;display:flex;align-items:center;margin-top:80px;width:100%;box-sizing:border-box}.hero-container{display:flex;align-items:center;justify-content:space-between;gap:12rem;width:100%;max-width:1250px;margin:0 auto}.hero-content{max-width:600px;flex:1}.hero-title{font-size:54px;line-height:1.2;margin-bottom:24px;color:#1a1a1a}.hero-title span{background:linear-gradient(120deg,gold 0,gold 100%);background-repeat:no-repeat;background-size:100% .4em;background-position:0 88%}.hero-description{font-size:1.25rem;line-height:1.6;color:#4a4a4a;margin-bottom:32px}.hero-cta{display:inline-block;cursor:pointer;background-color:#c82333;color:#fff;padding:.875rem 1.5rem;text-decoration:none;border-radius:4px;font-weight:600;transition:background-color .3s;box-shadow:rgba(0,0,0,.02) 0 1px 3px 0,rgba(27,31,35,.15) 0 0 0 1px}.channel-card,.process-diagram{border-radius:8px;padding:40px}.hero-image{flex:1;max-width:500px;aspect-ratio:1;position:relative;display:flex;align-items:center;justify-content:center}.hero-image img{width:100%;height:100%;object-fit:contain;position:relative}.channels-section,.features-section,.quotes-section,.sales-process-section{padding:80px 20px;width:100%;box-sizing:border-box}.channels-header,.feature-item{margin-bottom:60px}.channels-title{font-size:48px;font-weight:700;margin-bottom:20px;color:#1a1a1a}.channels-description{font-size:19px;line-height:1.6;color:#000;max-width:600px}.channels-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:30px;width:100%;max-width:1250px;margin:0 auto}.quotes-content,.sales-process-content{gap:60px;box-sizing:border-box;display:flex;width:100%}.channel-card{background:#f8f9fa;display:flex;flex-direction:column;align-items:center;text-align:center;padding:20px;box-sizing:border-box}.channel-card h3{font-size:28px;font-weight:600;margin:20px 0 10px;color:#1a1a1a}.channel-card p{font-size:17px;line-height:1.5;color:#4a4a4a;margin-bottom:20px}.channel-card img{border-radius:4px;max-height:95px;width:auto;object-fit:contain}.channels-header,.quotes-header,.sales-process-header{width:100%;max-width:1250px;margin:0 auto 60px;box-sizing:border-box}.sales-process-title{font-size:48px;line-height:1.2;font-weight:600;color:#1a1a1a;margin-bottom:24px}.quotes-description,.sales-process-description{font-size:1.125rem;line-height:1.6;color:#4a4a4a}.sales-process-content{background-color:#fdf3f3;align-items:flex-start;padding:40px;max-width:1250px;margin:0 auto}.features-column,.features-list{flex:1;max-width:400px}.feature-item:last-child,.quote-feature:last-child{margin-bottom:0}.feature-title{font-size:1.75rem;font-weight:600;color:#1a1a1a;margin-bottom:16px}.feature-description{font-size:1.125rem;line-height:1.5;color:#4a4a4a;margin-bottom:16px}.process-diagram{flex:1.5;min-height:600px;display:flex;align-items:center;justify-content:center}.quotes-title{font-size:3rem;line-height:1.2;font-weight:600;color:#1a1a1a;margin-bottom:24px}.quotes-content{align-items:center;background-color:#e8f5f0;border-radius:12px;padding:60px;position:relative;overflow:hidden;max-width:1250px;margin:0 auto}.features-column{position:relative;z-index:2}.quote-feature{margin-bottom:40px}.quote-feature-title{font-size:1.75rem;font-weight:600;color:#1a1a1a;margin-bottom:12px}.quote-feature-description{font-size:1rem;line-height:1.5;color:#4a4a4a;margin-bottom:16px}.feature-name,.features-title{font-weight:600;color:#1a1a1a}.illustration-column{flex:1;display:flex;justify-content:center;align-items:center;position:relative;z-index:1}.features-title{font-size:28px;line-height:1.2;text-align:center;margin-bottom:60px}.features-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:24px;width:100%;max-width:1200px;margin:0 auto}.feature-card{background:0 0;padding:32px 24px;border-radius:8px;text-align:center;transition:transform .3s;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;aspect-ratio:1}.feature-card:first-child{background-color:#ffe4e1}.feature-icon{width:48px;height:48px;margin-bottom:16px}.feature-name{font-size:1.25rem;margin:0}@media (max-width:968px){.hero-container{flex-direction:column;text-align:center;gap:2rem}.hero-content{order:1}.hero-section{min-height:400px;padding:60px 10px 40px}.hero-image{order:2;aspect-ratio:1/1;min-height:220px;max-width:320px;width:100%;margin:0 auto;height:auto;display:flex;align-items:center;justify-content:center}.hero-image img{width:100%;height:auto;max-height:320px;object-fit:contain;display:block}.hero-title{font-size:2rem}.hero-content{max-width:100%}}@media (max-width:1024px){.channels-header,.quotes-header,.sales-process-header{padding:0 20px}.quotes-content,.sales-process-content{padding:40px 20px;flex-direction:column}.features-column,.features-list{max-width:100%}.process-diagram{width:100%}.quotes-content{flex-direction:column}.illustration-column{margin-top:40px}.features-grid{grid-template-columns:repeat(3,1fr);gap:20px}}@media (max-width:768px){.channels-grid{grid-template-columns:1fr}.channels-title{font-size:2rem}.channel-card{height:auto;min-height:350px}.channel-card h3{font-size:24px}.channel-card p{font-size:16px}.channel-card img{max-height:150px}.quotes-title,.sales-process-title{font-size:2.5rem}.feature-title,.quote-feature-title{font-size:1.5rem}.process-diagram{padding:20px;min-height:400px}.features-grid{grid-template-columns:repeat(2,1fr);gap:16px}.features-title{font-size:2rem;margin-bottom:40px}}@media (max-width:480px){.channels-section,.features-section,.hero-section,.quotes-section,.sales-process-section{padding:50px 20px!important}.channels-title,.features-title,.hero-title,.quotes-title,.sales-process-title{font-size:24px}.hero-description,.quotes-description,.sales-process-description{font-size:18px}.hero-container{flex-direction:column;text-align:center;gap:2rem}.channel-card{height:auto;min-height:400px}.channel-card img{width:100%;height:auto}.features-grid{grid-template-columns:1fr;max-width:280px;margin:0 auto}.feature-card{padding:24px}.hero-section{min-height:320px;padding:40px 5px 30px}.hero-image{min-height:160px;max-width:200px}.hero-title{font-size:1.5rem}}
        </style>
        <?php salesnanny_nav_header(); ?>
        <div class="hero-wrapper">
            <section class="hero-section">
                <div class="hero-container">
                    <div class="hero-content">
                        <h1 class="hero-title">
                         <span>Generate Web Traffic and Leads</span> with Our Organic Marketing Solutions
                        </h1>
                        <p class="hero-description">
                            Build a powerful online presence and reach a wider audience with our Organic Marketing strategies. We help you attract your target audience, build brand awareness, and generate leads through a variety of organic channels.
                        </p>
                        <a class="calendly-trigger hero-cta">Schedule a Call</a>
                    </div>
                    <div class="hero-image">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/header-earn.png" alt="Rocket illustration representing organic marketing growth" fetchpriority="high" width="458" height="458">
                    </div>
                </div>
            </section>
        </div>
        <section class="channels-section">
            <div class="channels-header">
                <h2 class="channels-title">Grow Your Business Organically</h2>
                <p class="channels-description">We help you reach the right people at the right time. Our Organic Marketing solutions are designed to connect you with your ideal audience and achieve your marketing goals.</p>
            </div>
            
            <div class="channels-grid">
                <!-- CRM Mobile Card -->
                <div class="channel-card">
                    <h3>SEO (Search Engine Optimization)</h3>
                    <p>Help more people find your business online. We make your website easier for search engines to understand, so you get more visitors.</p>
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/seo.png" alt="Search engine optimization icon" loading="lazy" width="95" height="95">
                </div>

                <!-- Email Card -->
                <div class="channel-card">
                    <h3>Content Marketing</h3>
                    <p>Share useful and interesting information with your customers. We create articles, videos, and more to build trust and bring in new people.</p>
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/content-marketing.png" alt="Content marketing icon" loading="lazy" width="95" height="95">
                </div>

                <!-- Telephony Card -->
                <div class="channel-card">
                    <h3>Digital PR (Public Relations)</h3>
                    <p>Get your brand talked about online. We help you connect with websites and influencers to share your story and build a good name.</p>
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/digital-pr.png" alt="Digital PR icon" loading="lazy" width="95" height="95">
                </div>

                <!-- Social Media Card -->
                <div class="channel-card">
                    <h3>Social Media Marketing</h3>
                    <p>Connect with your customers on social media. We create posts and run ads to reach more people and build a community around your brand.</p>
                    <img src="<?php echo SN_HTTP_URL; ?>/wp-content/themes/assets/earn-media/socialmedia-marketing.png" alt="Social media marketing icon" loading="lazy" width="95" height="95">
                </div>

                <!-- Live Chat Card -->
                <div class="channel-card">
                    <h3>Email Marketing</h3>
                    <p>Talk directly to your customers through email. We create messages to share news, offers, and build relationships with the people who like your brand.</p>
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/email-marketing.png" alt="Email marketing icon" loading="lazy" width="95" height="95">
                </div>

                <!-- Online Meetings Card -->
                <div class="channel-card">
                    <h3>Video Marketing</h3>
                    <p>Show your brand with engaging videos. We help you make videos to tell your story, explain things, and connect with your audience visually.</p>
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/video-marketing.png" alt="Video marketing icon" loading="lazy" width="95" height="95">
                </div>
            </div>
        </section>
        <section class="sales-process-section">
            <div class="sales-process-header">
                <h2 class="sales-process-title">Our Proven Organic Marketing Approach</h2>
                <p class="sales-process-description">We work closely with you to develop customized Organic Marketing strategies that align with your business goals and target audience. Our collaborative approach ensures that your brand message is amplified effectively.</p>
            </div>
            <div class="sales-process-content">
                <div class="features-list">
                    <div class="feature-item">
                        <h3 class="feature-title">SEO (Search Engine Optimization)</h3>
                        <p class="feature-description">We optimize your website and content to rank higher in search results. This drives organic traffic and helps you reach more potential customers.</p>
                    </div>

                    <div class="feature-item">
                        <h3 class="feature-title">Content Marketing</h3>
                        <p class="feature-description">We create compelling content that attracts and engages your target audience. This builds trust and establishes your brand as an industry leader.</p>
                    </div>

                    <div class="feature-item">
                        <h3 class="feature-title">Digital PR (Public Relations)</h3>
                        <p class="feature-description">We help you get featured in relevant online publications and build relationships with influencers. This increases your brand's visibility and credibility.</p>
                    </div>
                </div>
                <div class="process-diagram">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/our-proven.png" alt="Diagram showing our organic marketing process" loading="lazy" width="430" height="560">
                </div>
            </div>
        </section>
        <section class="quotes-section">
            <div class="quotes-header">
                <h2 class="quotes-title">Working With Us Made Simple and Seamless</h2>
                <p class="quotes-description">
                We believe in making your experience smooth and efficient. From initial contact to project completion, we provide clear communication, streamlined processes, and dedicated support.</p>
            </div>
            <div class="quotes-content">
                <div class="features-column">
                    <div class="quote-feature">
                        <h3 class="quote-feature-title">Initial Consultation</h3>
                        <p class="quote-feature-description">Understand your needs, and tailor our services.</p>
                    </div>

                    <div class="quote-feature">
                        <h3 class="quote-feature-title">Clear Project Planning</h3>
                        <p class="quote-feature-description">Detailed plans, clear timelines, stay informed.</p>
                    </div>

                    <div class="quote-feature">
                        <h3 class="quote-feature-title">Dedicated Support</h3>
                        <p class="quote-feature-description">Always here to help, ensuring your satisfaction.</p>
                    </div>

                    <div class="quote-feature">
                        <h3 class="quote-feature-title">Easy Communication</h3>
                        <p class="quote-feature-description">Multiple channels, effortless communication.</p>
                    </div>
                </div>

                <div class="illustration-column">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/earn-media/work-seamless.png" alt="Illustration showing seamless workflow process" loading="lazy" width="670" height="670">
                </div>
            </div>
        </section>
        <section class="features-section">
            <h2 class="features-title">See What Else You Can Do with Salesnanny</h2>
            <div class="features-grid">
                <a href="<?php echo SN_HTTP_URL; ?>paid-marketing/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/paid-marketing-tab.png" alt="Paid marketing service icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Paid Marketing</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>website-development/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/web-development-tab.png" alt="Website development service icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Website Development</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>branding/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/branding-tab.png" alt="Branding service icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Branding</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>inside-sales/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/inside-sales-tab.png" alt="Inside sales service icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Inside Sales</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>creative/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/creative-tab.png" alt="Creative service icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Creative</h3>
                    </div>
                </a>
            </div>
        </section>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>
