<?php
   /*
   Template Name: Author
   */
   ?>
<html>
<?php get_custom_head(); ?>
   <body>
      <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/author.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
      <noscript>
         <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/author.noncritical.css"/>
      </noscript>
      <div>
        <style>
            .author-header{padding:4rem;display:flex;align-items:center;max-width:1200px;margin:120px auto;background:linear-gradient(135deg,#c22034 0,#1e2154 100%);border-radius:16px;box-shadow:0 8px 24px rgba(30,33,84,.15)}.author-image{flex:1;display:flex;justify-content:center;padding-right:2rem}.author-image img{width:250px;height:250px;border-radius:50%;object-fit:cover;border:4px solid #fff;box-shadow:0 4px 12px rgba(0,0,0,.15)}.author-info{flex:1;padding-left:2rem;border-left:2px solid rgba(255,255,255,.2)}.author-name{font-size:2.5rem;margin-bottom:1.5rem;color:#fff;text-shadow:0 2px 4px rgba(0,0,0,.1)}.author-description{margin-top:1.5rem;color:#fff;font-size:1.1rem;line-height:1.6;opacity:.9;margin-bottom:1.5rem}.social-links{display:flex;gap:1.2rem}.social-link{width:45px;height:45px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.9);border-radius:50%;transition:.3s;box-shadow:0 4px 12px rgba(0,0,0,.1)}.social-link svg{width:22px;height:22px;fill:#1E2154;transition:fill .3s}.blog-container{max-width:1300px;margin:80px auto;padding:0 20px}.blog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px}.blog-card{background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.08);transition:.4s cubic-bezier(.165, .84, .44, 1);height:100%;display:flex;flex-direction:column;position:relative;border:1px solid rgba(0,0,0,.05)}.blog-card__image-container{position:relative;overflow:hidden;height:220px}.blog-card__image{width:100%;height:auto;object-fit:cover;transition:transform .8s}.blog-card__category-badge{position:absolute;top:15px;right:15px;background-color:#c22034;color:#fff;font-weight:600;font-size:12px;padding:6px 12px;border-radius:30px;text-transform:uppercase;letter-spacing:.5px;box-shadow:0 4px 10px rgba(0,0,0,.1);z-index:2}.blog-card__content{padding:25px;flex-grow:1;display:flex;flex-direction:column;position:relative}.blog-card__date{font-size:13px;color:#888;margin-bottom:12px;display:block}.blog-card__title{font-size:20px;font-weight:700;margin-bottom:15px;color:#222;line-height:1.3;transition:color .3s}.blog-card__title a{color:inherit;text-decoration:none;background-image:linear-gradient(transparent calc(100% - 2px),#c22034 2px);background-size:0 100%;background-repeat:no-repeat;transition:background-size .3s}.blog-card__footer{display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:15px;border-top:1px solid #f0f0f0}.blog-card__read-more{display:inline-flex;align-items:center;color:#333;font-weight:600;font-size:14px;text-decoration:none;transition:color .3s}.blog-card__read-more:after{content:'→';margin-left:5px;transition:transform .3s}.blog-card__author{display:flex;align-items:center}.blog-card__author-image{width:30px;height:30px;border-radius:50%;margin-right:8px;object-fit:cover}.blog-card__author-name{font-size:13px;color:#666;text-decoration:none;transition:color .3s}.explore-heading{text-align:center;font-size:2.5rem;color:#1a202c;margin-bottom:40px;font-weight:700;position:relative;padding-bottom:15px}.explore-heading::after{content:'';position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:100%;height:3px;background:#c22034;border-radius:3px}.view-more-container{text-align:center;margin-top:40px}.view-more-button{display:inline-block;padding:15px 35px;background:#c22034;color:#fff;text-decoration:none;border-radius:30px;font-weight:600;font-size:1.1rem;transition:.3s;box-shadow:0 4px 15px rgba(194,32,52,.2)}@media (max-width:992px){.blog-grid{grid-template-columns:repeat(2,1fr)}}@media (max-width:576px){.blog-grid{grid-template-columns:1fr}.blog-card__image-container{height:200px}}@media (max-width:768px){.author-header{flex-direction:column;padding:2rem}.author-image{padding-right:0;padding-bottom:2rem}.author-info{padding-left:0;border-left:none;border-top:2px solid rgba(255,255,255,.2);padding-top:2rem;text-align:center}.author-image img{width:200px;height:200px}.social-links{justify-content:center}.author-description{font-size:1rem;text-align:center}.explore-heading{font-size:2rem;margin-bottom:30px}.view-more-button{padding:12px 30px;font-size:1rem}}@media (max-width:480px){.explore-heading{font-size:1.8rem}}
        </style>
         <?php salesnanny_nav_header(); ?>
         <div class="author-header">
            <div class="author-image">
               <?php
                  $author_id = get_the_author_meta('ID');
                  $author_avatar = get_avatar_url($author_id, [
                      'size' => 500,  // Increased from 150 to 500 for higher resolution
                      'default' => 'mystery',
                      'force_default' => false,
                      'rating' => 'G',
                      'scheme' => null,
                  ]);
                  ?>
                <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr(get_the_author()); ?>"loading="lazy" width="250" height="250">
            </div>
            <div class="author-info">
               <h1 class="author-name"><?php echo esc_html(get_the_author()); ?></h1>
               <?php 
                  $author_description = get_the_author_meta('author_description');
                  if ($author_description) : ?>
               <div class="author-description">
                  <?php echo wp_kses_post($author_description); ?>
               </div>
               <?php endif; ?>
               <div class="social-links">
                  <?php
                     $twitter = get_the_author_meta('social_twitter');
                     $facebook = get_the_author_meta('social_facebook');
                     $linkedin = get_the_author_meta('social_linkedin');
                     $instagram = get_the_author_meta('social_instagram');
                     ?>
                  <?php if ($twitter) : ?>
                  <a href="<?php echo esc_url($twitter); ?>" class="social-link" target="_blank" rel="noopener noreferrer" style="background: none;">
                     <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                     </svg>
                  </a>
                  <?php endif; ?>
                  <?php if ($facebook) : ?>
                  <a href="<?php echo esc_url($facebook); ?>" class="social-link" target="_blank" rel="noopener noreferrer" style="background: none;">
                     <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                     </svg>
                  </a>
                  <?php endif; ?>
                  <?php if ($linkedin) : ?>
                  <a href="<?php echo esc_url($linkedin); ?>" class="social-link" target="_blank" rel="noopener noreferrer" style="background: none;">
                     <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                     </svg>
                  </a>
                  <?php endif; ?>
                  <?php if ($instagram) : ?>
                  <a href="<?php echo esc_url($instagram); ?>" class="social-link" target="_blank" rel="noopener noreferrer" style="background: none;">
                     <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/>
                     </svg>
                  </a>
                  <?php endif; ?>
               </div>
            </div>
         </div>
         <div class="blog-container">
            <h2 class="explore-heading">Explore My Articles</h2>
            <div class="blog-grid">
               <?php
                  // Define our six allowed categories
                  $allowed_categories = array(
                      'digital-marketing',
                      'seo',
                      'social-media',
                      'ppc',
                      'tech-development',
                      'designs'
                  );
                  
                  // Set up query arguments
                  $args = array(
                      'post_type' => 'post',
                      'posts_per_page' => 9,
                      'author' => get_the_author_meta('ID'),
                      'post_status' => 'publish'
                  );
                  
                  // Add category filter if set and valid
                  if (isset($_GET['category']) && $_GET['category'] != 'all') {
                      $category = sanitize_text_field($_GET['category']);
                      if (in_array($category, $allowed_categories)) {
                          $args['category_name'] = $category;
                      }
                  } else {
                      // If no category is selected or "all" is selected, show posts from all allowed categories
                      $args['category_name'] = implode(',', $allowed_categories);
                  }
                  
                  // The Query
                  $query = new WP_Query($args);
                  
                  // The Loop
                  if ($query->have_posts()) {
                      while ($query->have_posts()) {
                          $query->the_post();
                          
                          // Get the first category
                          $categories = get_the_category();
                          $category_name = !empty($categories) ? esc_html($categories[0]->name) : 'Uncategorized';
                          
                          // Get author info
                          $author_id = get_the_author_meta('ID');
                          $author_name = get_the_author();
                          $author_url = get_author_posts_url($author_id);
                          $author_avatar = get_avatar_url($author_id, array('size' => 60));
                          ?>
               <article class="blog-card">
                  <?php if (has_post_thumbnail()): ?>
                  <div class="blog-card__image-container">
                     <a href="<?php the_permalink(); ?>">
                     <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'medium_large')); ?>" 
                        alt="<?php the_title_attribute(); ?>" 
                        class="blog-card__image"
                        loading="lazy">
                     </a>
                     <?php if (!empty($categories)): ?>
                     <span class="blog-card__category-badge">
                     <?php echo $category_name; ?>
                     </span>
                     <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <div class="blog-card__content">
                     <span class="blog-card__date"><?php echo get_the_date(); ?></span>
                     <h2 class="blog-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                     <div class="blog-card__footer">
                        <a href="<?php the_permalink(); ?>" class="blog-card__read-more">Read More</a>
                        <div class="blog-card__author">
                           <img src="<?php echo esc_url($author_avatar); ?>" 
                              alt="<?php echo esc_attr($author_name); ?>" 
                              class="blog-card__author-image"
                              loading="lazy">
                           <a href="<?php echo esc_url($author_url); ?>" class="blog-card__author-name">
                           <?php echo esc_html($author_name); ?>
                           </a>
                        </div>
                     </div>
                  </div>
               </article>
               <?php
                  }
                  } else {
                  echo '<div class="no-posts">No posts found in this category.</div>';
                  }
                  ?>
            </div>
            <!-- End of blog-grid -->
            <div class="view-more-container">
               <a href="<?php echo SN_HTTP_URL; ?>blogs/" class="view-more-button">View More Articles</a>
            </div>
            <?php
               // Restore original Post Data
               wp_reset_postdata();
               ?>
         </div>
         <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>