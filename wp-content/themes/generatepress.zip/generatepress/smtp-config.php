<?php
/**
 * SMTP Configuration for SalesNanny Email System
 * Production Configuration
 * 
 * SECURITY NOTE: Keep this file secure and do not commit passwords to version control
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// SMTP Configuration
define('SMTP_USERNAME', 'thilakar@salesnanny.com');
define('SMTP_PASSWORD', 'bzvq fsdb jmga qxfc');

// SMTP Server Settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
?>
