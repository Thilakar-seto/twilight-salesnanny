<?php
/**
 * Testimonial Admin Functionality
 * 
 * This file handles all the admin-side functionality for testimonials
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Custom Post Type for Testimonials
 */
function register_testimonial_post_type() {
    $labels = array(
        'name'               => 'Testimonials',
        'singular_name'      => 'Testimonial',
        'menu_name'          => 'Testimonials',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Testimonial',
        'edit_item'          => 'Edit Testimonial',
        'new_item'           => 'New Testimonial',
        'view_item'          => 'View Testimonial',
        'search_items'       => 'Search Testimonials',
        'not_found'          => 'No testimonials found',
        'not_found_in_trash' => 'No testimonials found in Trash',
    );

    $args = array(
        'labels'              => $labels,
        'public'              => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'query_var'           => true,
        'capability_type'     => 'post',
        'has_archive'         => false,
        'hierarchical'        => false,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-format-quote',
        'supports'            => array('title', 'editor'),
        'show_in_rest'        => true,
    );

    register_post_type('testimonial', $args);
}
add_action('init', 'register_testimonial_post_type');

/**
 * Add Meta Boxes for Testimonial Details
 */
function add_testimonial_meta_boxes() {
    add_meta_box(
        'testimonial_details',
        'Customer Details',
        'render_testimonial_meta_box',
        'testimonial',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_testimonial_meta_boxes');

/**
 * Add custom admin styles
 */
function testimonial_admin_styles() {
    global $post_type;
    if ('testimonial' == $post_type) {
        ?>
        <style type="text/css">
            /* Admin UI improvements */
            #titlediv .inside p.description {
                margin-top: 10px;
                color: #666;
            }
            
            .testimonial-admin-guide {
                background: #fff;
                border: 1px solid #ccd0d4;
                border-left: 4px solid #c22034;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
                margin: 20px 0;
                padding: 15px;
            }
            
            .testimonial-admin-guide h3 {
                margin-top: 0;
                color: #23282d;
            }
            
            .testimonial-field {
                margin-bottom: 20px;
                padding-bottom: 20px;
                border-bottom: 1px solid #eee;
            }
            
            .testimonial-field:last-child {
                border-bottom: none;
            }
            
            .testimonial-field label {
                display: block;
                font-weight: 600;
                margin-bottom: 8px;
            }
            
            .testimonial-field input[type="text"] {
                width: 100%;
                max-width: 400px;
            }
            
            .testimonial-field .image-preview {
                margin-top: 10px;
                display: inline-block;
                position: relative;
            }
            
            .testimonial-field .image-preview img {
                max-width: 100px;
                height: auto;
                border: 1px solid #ddd;
                padding: 3px;
                background: #f9f9f9;
            }
            
            .testimonial-field .remove-image {
                position: absolute;
                top: -8px;
                right: -8px;
                background: #e24c4c;
                color: white;
                border-radius: 50%;
                width: 20px;
                height: 20px;
                text-align: center;
                line-height: 18px;
                cursor: pointer;
                font-size: 12px;
            }
            
            .upload-buttons {
                display: flex;
                gap: 10px;
                margin-top: 5px;
            }
            
            .testimonial-category-field {
                margin-top: 15px;
            }
            
            .testimonial-category-field label {
                margin-right: 15px;
            }
        </style>
        <?php
    }
}
add_action('admin_head', 'testimonial_admin_styles');

/**
 * Add custom admin scripts
 */
function testimonial_admin_scripts($hook) {
    global $post_type;
    
    if ('testimonial' == $post_type) {
        wp_enqueue_media();
        
        wp_enqueue_script(
            'testimonial-admin-script',
            get_template_directory_uri() . '/js/testimonial-admin.js',
            array('jquery'),
            '1.0.0',
            true
        );
    }
}
add_action('admin_enqueue_scripts', 'testimonial_admin_scripts');

/**
 * Create the JS file for admin functionality
 */
function create_testimonial_admin_js() {
    $js_dir = get_template_directory() . '/js';
    
    // Create directory if it doesn't exist
    if (!file_exists($js_dir)) {
        mkdir($js_dir, 0755, true);
    }
    
    $js_file = $js_dir . '/testimonial-admin.js';
    
    // Only create file if it doesn't exist
    if (!file_exists($js_file)) {
        $js_content = '
jQuery(document).ready(function($) {
    // Image upload functionality
    $(".upload-image-button").click(function(e) {
        e.preventDefault();
        
        var targetInput = $(this).data("target");
        var image = wp.media({
            title: "Upload Image",
            multiple: false
        }).open().on("select", function() {
            var uploaded_image = image.state().get("selection").first();
            var image_url = uploaded_image.toJSON().url;
            
            // Update input field
            $("#" + targetInput).val(image_url);
            
            // Update preview
            $("#" + targetInput + "_preview").show().find("img").attr("src", image_url);
        });
    });
    
    // Remove image functionality
    $(".remove-image, .remove-image-button").click(function() {
        var targetInput = $(this).data("target");
        $("#" + targetInput).val("");
        $("#" + targetInput + "_preview").hide();
    });
    
    // Category selection
    $(".category-checkbox").change(function() {
        updateCategoryDisplay();
    });
    
    function updateCategoryDisplay() {
        var selectedCategories = [];
        $(".category-checkbox:checked").each(function() {
            selectedCategories.push($(this).val());
        });
        
        $("#selected_categories").val(selectedCategories.join(","));
    }
    
    // Initialize on page load
    updateCategoryDisplay();
});
        ';
        
        file_put_contents($js_file, $js_content);
    }
}
add_action('admin_init', 'create_testimonial_admin_js');

/**
 * Register Testimonial Categories Taxonomy
 */
function register_testimonial_taxonomy() {
    $labels = array(
        'name'              => 'Testimonial Categories',
        'singular_name'     => 'Testimonial Category',
        'search_items'      => 'Search Categories',
        'all_items'         => 'All Categories',
        'parent_item'       => 'Parent Category',
        'parent_item_colon' => 'Parent Category:',
        'edit_item'         => 'Edit Category',
        'update_item'       => 'Update Category',
        'add_new_item'      => 'Add New Category',
        'new_item_name'     => 'New Category Name',
        'menu_name'         => 'Categories',
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'testimonial-category'),
        'show_in_rest'      => true,
    );

    register_taxonomy('testimonial_category', array('testimonial'), $args);
    
    // Add default categories if they don't exist
    $default_categories = array(
        'Earned Media',
        'Paid Media',
        'Tech Development',
        'Inside Sales',
        'Creative'
    );
    
    foreach ($default_categories as $category) {
        if (!term_exists($category, 'testimonial_category')) {
            wp_insert_term($category, 'testimonial_category');
        }
    }
}
add_action('init', 'register_testimonial_taxonomy');

/**
 * Render Meta Box
 */
function render_testimonial_meta_box($post) {
    // Add nonce for security
    wp_nonce_field('save_testimonial_meta', 'testimonial_meta_nonce');
    
    // Get saved values
    $customer_name = get_post_meta($post->ID, 'customer_name', true);
    $customer_country = get_post_meta($post->ID, 'customer_country', true);
    $country_flag = get_post_meta($post->ID, 'country_flag', true);
    $customer_photo = get_post_meta($post->ID, 'customer_photo', true);
    $customer_company = get_post_meta($post->ID, 'customer_company', true);
    $customer_position = get_post_meta($post->ID, 'customer_position', true);
    ?>
    
    <div class="testimonial-admin-guide">
        <h3>How to Add a Customer Testimonial</h3>
        <ol>
            <li>Enter a reference title above (for admin use only)</li>
            <li>Add the testimonial text in the main content editor</li>
            <li>Fill in the customer details below</li>
            <li>Upload customer photo and country flag using the upload buttons</li>
            <li>Select relevant categories for this testimonial</li>
            <li>Click "Publish" or "Update" to save the testimonial</li>
        </ol>
    </div>
    
    <div class="testimonial-field">
        <label for="customer_name">Customer Name:</label>
        <input type="text" id="customer_name" name="customer_name" value="<?php echo esc_attr($customer_name); ?>" placeholder="John Smith">
        <p class="description">Enter the full name of the customer providing the testimonial.</p>
    </div>
    
    <div class="testimonial-field">
        <label for="customer_company">Company:</label>
        <input type="text" id="customer_company" name="customer_company" value="<?php echo esc_attr($customer_company); ?>" placeholder="ABC Corporation">
        <p class="description">Enter the company name (optional).</p>
    </div>
    
    <div class="testimonial-field">
        <label for="customer_position">Position/Title:</label>
        <input type="text" id="customer_position" name="customer_position" value="<?php echo esc_attr($customer_position); ?>" placeholder="CEO">
        <p class="description">Enter the customer's job title or position (optional).</p>
    </div>
    
    <div class="testimonial-field">
        <label for="customer_country">Country:</label>
        <input type="text" id="customer_country" name="customer_country" value="<?php echo esc_attr($customer_country); ?>" placeholder="United States">
        <p class="description">Enter the country where the customer is from.</p>
    </div>
    
    <div class="testimonial-field">
        <label for="country_flag">Country Flag:</label>
        <input type="text" id="country_flag" name="country_flag" value="<?php echo esc_url($country_flag); ?>" placeholder="https://example.com/flag.png">
        <div class="upload-buttons">
            <button type="button" class="button upload-image-button" data-target="country_flag">Upload Flag</button>
            <?php if ($country_flag) : ?>
                <button type="button" class="button remove-image-button" data-target="country_flag">Remove Flag</button>
            <?php endif; ?>
        </div>
        <?php if ($country_flag) : ?>
            <div class="image-preview" id="country_flag_preview">
                <img src="<?php echo esc_url($country_flag); ?>" alt="Country Flag">
                <span class="remove-image" data-target="country_flag">×</span>
            </div>
        <?php else: ?>
            <div class="image-preview" id="country_flag_preview" style="display:none;">
                <img src="" alt="Country Flag">
                <span class="remove-image" data-target="country_flag">×</span>
            </div>
        <?php endif; ?>
        <p class="description">Upload or enter the URL of the country flag image. Recommended size: 32×24 pixels.</p>
    </div>
    
    <div class="testimonial-field">
        <label for="customer_photo">Customer Photo:</label>
        <input type="text" id="customer_photo" name="customer_photo" value="<?php echo esc_url($customer_photo); ?>" placeholder="https://example.com/photo.jpg">
        <div class="upload-buttons">
            <button type="button" class="button upload-image-button" data-target="customer_photo">Upload Photo</button>
            <?php if ($customer_photo) : ?>
                <button type="button" class="button remove-image-button" data-target="customer_photo">Remove Photo</button>
            <?php endif; ?>
        </div>
        <?php if ($customer_photo) : ?>
            <div class="image-preview" id="customer_photo_preview">
                <img src="<?php echo esc_url($customer_photo); ?>" alt="Customer Photo">
                <span class="remove-image" data-target="customer_photo">×</span>
            </div>
        <?php else: ?>
            <div class="image-preview" id="customer_photo_preview" style="display:none;">
                <img src="" alt="Customer Photo">
                <span class="remove-image" data-target="customer_photo">×</span>
            </div>
        <?php endif; ?>
        <p class="description">Upload or enter the URL of the customer's photo. Recommended size: 200×200 pixels (square).</p>
    </div>
    <?php
}

/**
 * Save Meta Box Data
 */
function save_testimonial_meta_data($post_id) {
    // Check if nonce is set
    if (!isset($_POST['testimonial_meta_nonce'])) {
        return;
    }
    
    // Verify nonce
    if (!wp_verify_nonce($_POST['testimonial_meta_nonce'], 'save_testimonial_meta')) {
        return;
    }
    
    // Check if autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Save customer name
    if (isset($_POST['customer_name'])) {
        update_post_meta($post_id, 'customer_name', sanitize_text_field($_POST['customer_name']));
    }
    
    // Save customer company
    if (isset($_POST['customer_company'])) {
        update_post_meta($post_id, 'customer_company', sanitize_text_field($_POST['customer_company']));
    }
    
    // Save customer position
    if (isset($_POST['customer_position'])) {
        update_post_meta($post_id, 'customer_position', sanitize_text_field($_POST['customer_position']));
    }
    
    // Save customer country
    if (isset($_POST['customer_country'])) {
        update_post_meta($post_id, 'customer_country', sanitize_text_field($_POST['customer_country']));
    }
    
    // Save country flag URL
    if (isset($_POST['country_flag'])) {
        update_post_meta($post_id, 'country_flag', esc_url_raw($_POST['country_flag']));
    }
    
    // Save customer photo URL
    if (isset($_POST['customer_photo'])) {
        update_post_meta($post_id, 'customer_photo', esc_url_raw($_POST['customer_photo']));
    }
}
add_action('save_post_testimonial', 'save_testimonial_meta_data');

/**
 * Add custom columns to testimonial list
 */
function add_testimonial_columns($columns) {
    $new_columns = array();
    
    foreach ($columns as $key => $value) {
        if ($key == 'title') {
            $new_columns[$key] = $value;
            $new_columns['customer_photo'] = 'Photo';
            $new_columns['customer_name'] = 'Customer';
            $new_columns['customer_country'] = 'Country';
        } else if ($key == 'date') {
            $new_columns['testimonial_category'] = 'Categories';
            $new_columns[$key] = $value;
        } else {
            $new_columns[$key] = $value;
        }
    }
    
    return $new_columns;
}
add_filter('manage_testimonial_posts_columns', 'add_testimonial_columns');

/**
 * Display custom column content
 */
function display_testimonial_columns($column, $post_id) {
    switch ($column) {
        case 'customer_photo':
            $photo = get_post_meta($post_id, 'customer_photo', true);
            if ($photo) {
                echo '<img src="' . esc_url($photo) . '" alt="Customer" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">';
            } else {
                echo '—';
            }
            break;
            
        case 'customer_name':
            $name = get_post_meta($post_id, 'customer_name', true);
            $company = get_post_meta($post_id, 'customer_company', true);
            
            if ($name) {
                echo esc_html($name);
                if ($company) {
                    echo '<br><small>' . esc_html($company) . '</small>';
                }
            } else {
                echo '—';
            }
            break;
            
        case 'customer_country':
            $country = get_post_meta($post_id, 'customer_country', true);
            $flag = get_post_meta($post_id, 'country_flag', true);
            
            if ($country) {
                if ($flag) {
                    echo '<img src="' . esc_url($flag) . '" alt="Flag" style="width:16px;height:12px;margin-right:5px;vertical-align:middle;">';
                }
                echo esc_html($country);
            } else {
                echo '—';
            }
            break;
            
        case 'testimonial_category':
            $terms = get_the_terms($post_id, 'testimonial_category');
            if (!empty($terms)) {
                $term_names = array();
                foreach ($terms as $term) {
                    $term_names[] = $term->name;
                }
                echo esc_html(implode(', ', $term_names));
            } else {
                echo '—';
            }
            break;
    }
}
add_action('manage_testimonial_posts_custom_column', 'display_testimonial_columns', 10, 2);

/**
 * Make custom columns sortable
 */
function make_testimonial_columns_sortable($columns) {
    $columns['customer_name'] = 'customer_name';
    $columns['customer_country'] = 'customer_country';
    return $columns;
}
add_filter('manage_edit-testimonial_sortable_columns', 'make_testimonial_columns_sortable');

/**
 * Add filter for testimonial categories
 */
function add_testimonial_category_filter() {
    global $typenow;
    
    if ($typenow == 'testimonial') {
        $taxonomy = 'testimonial_category';
        $selected = isset($_GET[$taxonomy]) ? $_GET[$taxonomy] : '';
        $info_taxonomy = get_taxonomy($taxonomy);
        
        wp_dropdown_categories(array(
            'show_option_all' => sprintf(__('All %s', 'textdomain'), $info_taxonomy->label),
            'taxonomy' => $taxonomy,
            'name' => $taxonomy,
            'orderby' => 'name',
            'selected' => $selected,
            'show_count' => true,
            'hide_empty' => false,
        ));
    }
}
add_action('restrict_manage_posts', 'add_testimonial_category_filter');

/**
 * Convert category ID to slug for filtering
 */
function convert_testimonial_category_id_to_term_in_query($query) {
    global $pagenow;
    $qv = &$query->query_vars;
    
    if ($pagenow == 'edit.php' && 
        isset($qv['testimonial_category']) && 
        is_numeric($qv['testimonial_category']) && 
        $qv['testimonial_category'] != 0) {
        
        $term = get_term_by('id', $qv['testimonial_category'], 'testimonial_category');
        $qv['testimonial_category'] = $term->slug;
    }
}
add_filter('parse_query', 'convert_testimonial_category_id_to_term_in_query');