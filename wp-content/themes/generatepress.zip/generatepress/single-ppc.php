<?php
   /*
   Template Name: Designs
   */
   ?>
<html>
<?php get_custom_head(); ?>
   <body>
      <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/single-blog.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
      <noscript>
         <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/single-blog.noncritical.css"/>
      </noscript>
      <div>
        <style>
            .entry-meta a,.entry-meta span{position:relative;transition:.3s}.entry-content a,.entry-meta a{color:#c22034;text-decoration:none}.entry-header,.recent-posts-widget h3{border-bottom:2px solid rgba(0,0,0,.06)}.digital-marketing-container{padding:30px;max-width:1300px;margin:80px auto 0;border-radius:20px}.content-wrapper{display:grid;grid-template-columns:minmax(0,1fr) 350px;gap:50px;align-items:start}.content-area{border-radius:16px;transition:transform .3s}.entry-header{margin-bottom:35px;padding-bottom:25px;position:relative}.entry-header::after{content:'';position:absolute;bottom:-2px;left:0;width:100px;height:2px}.entry-title{font-size:2.8rem;margin-bottom:25px;color:#1a202c;line-height:1.2;font-weight:700}.entry-meta{margin-bottom:25px;color:#4a5568;font-size:.95rem;display:flex;gap:15px;flex-wrap:wrap;align-items:center}.entry-meta span{display:inline-flex;align-items:center;padding:8px 16px;background:rgba(194,32,52,.05);border-radius:30px;overflow:hidden;gap:5px}.entry-meta span:before{content:'';display:inline-block;width:18px;height:18px;margin-right:8px;background-size:contain;background-repeat:no-repeat;opacity:.8;position:relative;top:-1px}.posted-on:before{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23C22034' viewBox='0 0 24 24'%3E%3Cpath d='M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8zm-.5-13v5.25l4.5 2.67-.75 1.23L10 13V7z'/%3E%3C/svg%3E")}.posted-by:before{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23C22034' viewBox='0 0 24 24'%3E%3Cpath d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z'/%3E%3C/svg%3E")}.reading-time:before{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23C22034' viewBox='0 0 24 24'%3E%3Cpath d='M12 6.253v13h-2V6.253l-4.5 4.5-1.414-1.414L12 1.425l7.914 7.914-1.414 1.414L12 6.253z'/%3E%3C/svg%3E")}.entry-meta a{font-weight:500}.entry-meta a::after{content:'';position:absolute;bottom:-2px;left:0;width:100%;height:1px;background:currentColor;transform:scaleX(0);transform-origin:right;transition:transform .3s}.featured-image{margin-bottom:30px;border-radius:8px;overflow:hidden}.featured-image img{width:100%;height:auto;display:block;transition:transform .3s}.entry-content{font-size:1.15rem;line-height:1.8;color:#2d3748;text-align:justify}.author-info,.explore-heading,.share-title,.stat-item{text-align:center}.entry-content a{transition:color .3s}.entry-content p{margin-bottom:1.8em}.sidebar-area{width:350px;position:-webkit-sticky;position:sticky;top:100px}.sticky-sidebar{position:-webkit-sticky;position:sticky;top:100px;transition:.3s;max-height:calc(100vh - 120px);overflow-y:auto}.recent-posts-widget{background:#fff;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.06)}.recent-posts-widget h3{font-size:1.4rem;margin-bottom:25px;padding-bottom:15px;color:#1a202c;font-weight:700;position:relative}.recent-posts-widget h3::after{content:'';position:absolute;bottom:-2px;left:0;width:60px;height:2px}.recent-post-item a{color:#444;text-decoration:none;font-weight:500;display:block;line-height:1.4}.breadcrumbs a,.breadcrumbs span:last-child{color:#c22034;padding:5px 10px;border-radius:4px;font-weight:500}.breadcrumbs{padding:15px 20px;margin-bottom:50px;font-size:.95rem;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,.05);border-left:4px solid #c22034}.breadcrumbs-list{display:flex;flex-wrap:wrap;align-items:center;gap:12px}.breadcrumbs a{text-decoration:none;transition:.3s;position:relative}.breadcrumbs .separator{color:rgb(0 0 0 / 66%);font-weight:600;font-size:1.2rem;position:relative;top:-1px}.breadcrumbs span:last-child{background:rgba(194,32,52,.1)}.breadcrumbs a::after{content:'';position:absolute;width:0;height:2px;bottom:0;left:50%;background-color:#c22034;transition:.3s;transform:translateX(-50%)}.recent-post-item{display:flex;align-items:flex-start;gap:15px;padding:18px;margin-bottom:18px;background:#f8fafc;border-radius:12px;transition:.3s;border-left:4px solid transparent;box-shadow:0 2px 8px rgba(0,0,0,.02)}.recent-post-thumb{flex-shrink:0;width:80px;height:80px;border-radius:8px;overflow:hidden}.recent-post-thumb img{width:100%;height:100%;object-fit:cover;transition:transform .3s}.recent-post-content{flex-grow:1;display:flex;flex-direction:column;gap:8px}.recent-post-content a{color:#444;text-decoration:none;font-weight:500;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.post-date{font-size:.85rem;color:#666}.social-share-container{margin-top:40px;padding:25px;background:#fff}.share-title{font-size:1.2rem;margin-bottom:20px;color:#1a202c;font-weight:600}.social-share-buttons{display:flex;gap:15px;flex-wrap:wrap;justify-content:center}.blog-card__read-more,.share-button{align-items:center;text-decoration:none}.share-button{display:inline-flex;gap:10px;padding:10px 20px;border-radius:8px;border:none;cursor:pointer;font-size:.95rem;font-weight:500;transition:.3s;color:#fff}.comment-item,.comment-message{margin-bottom:20px;border-radius:8px}.share-button svg{width:20px;height:20px;fill:currentColor}.share-button.facebook{background-color:#1877f2}.x-twitter{background-color:#000}.share-button.linkedin{background-color:#0a66c2}.whatsapp{background-color:#25d366}.telegram{background-color:#08c}.share-button.copy-link{background-color:#c22034;color:#fff}.comment-message{padding:15px;display:none}.comments-display{margin-top:40px;padding-top:30px;border-top:1px solid rgba(0,0,0,.1)}.comments-display-left{display:grid;grid-template-columns:2fr 2fr;gap:20px}.comment-item{padding:20px;background:#f8fafc;border-left:4px solid #c22034;margin-top:20px}.comment-author{font-weight:600;color:#1a202c;margin-bottom:5px}.comment-date{font-size:.9rem;color:#666;margin-bottom:10px}.comment-textarea,.form-input{width:100%;font-size:.95rem;transition:.3s}.comment-content{color:#2d3748;line-height:1.6}.comments-section{padding:40px;background:#fff;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.06);margin:50px auto;width:100%;max-width:1300px}.comments-grid{display:grid;grid-template-columns:2fr 1fr;gap:40px;margin-bottom:40px}.comment-form-container{padding:30px;background:#f8fafc;border-radius:12px}.comment-form-container h3{margin-bottom:25px;color:#1a202c;font-size:1.5rem;font-weight:600}.comment-form{display:flex;flex-direction:column;gap:20px}.form-group{margin-bottom:15px}.form-row{display:grid;grid-template-columns:1fr 1fr;gap:20px}.comment-textarea{min-height:120px;padding:15px;border:1px solid #e2e8f0;border-radius:8px;resize:vertical}.form-input{padding:12px 15px;border:1px solid #e2e8f0;border-radius:8px}.post-comment-btn{background:#c22034;color:#fff;padding:12px 25px;border:none;border-radius:8px;font-weight:600;cursor:pointer;transition:.3s;align-self:flex-start}.author-info{padding:30px;background:#f8fafc;border-radius:12px;border-left:4px solid #c22034;transition:.3s}.author-image-link{display:block;width:120px;height:120px;margin:0 auto 20px;border-radius:50%;overflow:hidden;border:4px solid #fff;box-shadow:0 4px 12px rgba(0,0,0,.1);transition:.3s}.author-name{font-size:1.4rem;color:#1a202c;margin-bottom:10px;font-weight:600}.author-name a{color:#1a202c;text-decoration:none;transition:color .3s}.author-bio{color:#4a5568;font-size:.95rem;line-height:1.6;margin-bottom:25px}.author-stats{display:grid;gap:15px;padding-top:20px;border-top:1px solid rgba(0,0,0,.1);justify-content:center}.stat-number{display:block;font-size:1.5rem;font-weight:700;color:#c22034;margin-bottom:5px}.stat-label{font-size:.9rem;color:#4a5568}.blog-container{max-width:1300px;margin:80px auto;padding:0 20px}.blog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:30px}.blog-card{background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.08);transition:.4s cubic-bezier(.165, .84, .44, 1);height:100%;display:flex;flex-direction:column;position:relative;border:1px solid rgba(0,0,0,.05)}.blog-card__image-container{position:relative;overflow:hidden;height:220px}.blog-card__image{width:100%;height:auto;object-fit:cover;transition:transform .8s}.blog-card__category-badge{position:absolute;top:15px;right:15px;background-color:#c22034;color:#fff;font-weight:600;font-size:12px;padding:6px 12px;border-radius:30px;text-transform:uppercase;letter-spacing:.5px;box-shadow:0 4px 10px rgba(0,0,0,.1);z-index:2}.blog-card__content{padding:25px;flex-grow:1;display:flex;flex-direction:column;position:relative}.blog-card__date{font-size:13px;color:#888;margin-bottom:12px;display:block}.blog-card__title{font-size:20px;font-weight:700;margin-bottom:15px;color:#222;line-height:1.3;transition:color .3s}.blog-card__title a{color:inherit;text-decoration:none;background-image:linear-gradient(transparent calc(100% - 2px),#c22034 2px);background-size:0 100%;background-repeat:no-repeat;transition:background-size .3s}.blog-card__footer{display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:15px;border-top:1px solid #f0f0f0}.blog-card__read-more{display:inline-flex;color:#333;font-weight:600;font-size:14px;transition:color .3s}.blog-card__read-more:after{content:'→';margin-left:5px;transition:transform .3s}.blog-card__author{display:flex;align-items:center}.blog-card__author-image{width:30px;height:30px;border-radius:50%;margin-right:8px;object-fit:cover}.blog-card__author-name{font-size:13px;color:#666;text-decoration:none;transition:color .3s}.explore-heading{font-size:2.5rem;color:#1a202c;margin-bottom:40px;font-weight:700;position:relative;padding-bottom:15px}.explore-heading::after{content:'';position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:100%;height:3px;background:#c22034;border-radius:3px}.view-more-container{text-align:center;margin-top:40px}.view-more-button{display:inline-block;padding:15px 35px;background:#c22034;color:#fff;text-decoration:none;border-radius:30px;font-weight:600;font-size:1.1rem;transition:.3s;box-shadow:0 4px 15px rgba(194,32,52,.2)}@media (max-width:1200px){.recent-post-thumb{width:70px;height:70px}}@media (max-width:1366px){.digital-marketing-container{margin:80px 20px 0;width:auto}}@media (max-width:992px){.digital-marketing-container{padding:20px;margin:60px 15px 0}.content-wrapper{grid-template-columns:1fr}.sidebar-area{width:100%;margin-top:40px}.sticky-sidebar{position:relative;top:0}.blog-grid{grid-template-columns:repeat(2,1fr)}}@media (max-width:576px){.blog-grid{grid-template-columns:1fr}.blog-card__image-container{height:200px}}@media (max-width:768px){.entry-title{font-size:2rem}.entry-meta,.social-share-buttons{gap:10px}.entry-meta span{padding:6px 12px;font-size:.85rem;width:100%}.entry-meta span:before{width:16px;height:16px;margin-right:6px}.content-area,.recent-posts-widget,.social-share-container{padding:20px}.breadcrumbs{padding:12px 15px;font-size:.85rem;margin-bottom:20px}.breadcrumbs-list{gap:8px}.breadcrumbs a{padding:3px 8px}.breadcrumbs .separator{font-size:1rem}.recent-post-item{padding:15px;margin-bottom:15px}.recent-post-thumb{width:60px;height:60px}.recent-post-content a{font-size:.9rem}.post-date{font-size:.8rem}.share-button{padding:8px 16px;font-size:.9rem;flex:1 1 calc(50% - 10px);justify-content:center}.digital-marketing-container{padding:15px;margin:40px 10px 0;border-radius:15px}.content-area{padding:15px}.explore-heading{font-size:2rem;margin-bottom:30px}.view-more-button{padding:12px 30px;font-size:1rem}}@media (max-width:480px){.breadcrumbs{font-size:.8rem}.breadcrumbs-list{gap:6px}.share-button{flex:1 1 100%}.digital-marketing-container{padding:10px;margin:30px 8px 0;border-radius:10px}.content-area{padding:10px}.comments-display-left,.comments-grid{grid-template-columns:1fr}.no-comments{margin-top:20px}.explore-heading{font-size:1.8rem}}
               .entry-content .wp-block-image{margin:2em 0;max-width:100%}.entry-content .wp-block-image img{width:100%;height:auto;display:block;border-radius:8px;transition:transform .3s}.entry-content img{width: 100%;height: auto;}@media (max-width:768px){.entry-content .wp-block-image{margin:1.5em 0}}
        </style>
         <?php salesnanny_nav_header(); ?>
         <div class="digital-marketing-container">
            <div class="breadcrumbs">
               <div class="breadcrumbs-list">
                  <a href="<?php echo SN_HTTP_URL; ?>">Home</a>
                  <span class="separator">›</span>
                  <a href="<?php echo SN_HTTP_URL; ?>blogs/">Blogs</a>
                  <?php
                     $categories = get_the_category();
                     if (!empty($categories)) {
                         echo '<span class="separator">›</span>';
                         echo '<a href="' . esc_url(get_category_link($categories[0]->term_id)) . '">' . esc_html($categories[0]->name) . '</a>';
                     }
                     ?>
                  <span class="separator">›</span>
                  <span><?php the_title(); ?></span>
               </div>
            </div>
            <div class="content-wrapper">
               <!-- Main Content Area -->
               <div class="content-area">
                  <!-- Add Breadcrumbs -->
                  <header class="entry-header">
                     <h1 class="entry-title"><?php the_title(); ?></h1>
                     <div class="entry-meta">
                        <span class="posted-on">Posted On <?php echo get_the_date('F j, Y'); ?></span>
                        <span class="posted-by">By <?php 
                           if (have_posts()) : while (have_posts()) : the_post();
                               echo '<a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . get_the_author() . '</a>';
                           endwhile; endif;
                           ?></span>
                        <span class="reading-time"><?php echo get_reading_time(); ?> Mins Read</span>
                     </div>
                  </header>
                  <?php if (has_post_thumbnail()) : ?>
                  <div class="featured-image">
                     <?php the_post_thumbnail('full'); ?>
                  </div>
                  <?php endif; ?>
                  <div class="entry-content">
                     <?php the_content(); ?>
                  </div>
               </div>
               <!-- Sidebar -->
               <div class="sidebar-area">
                  <div class="sticky-sidebar" id="sticky-sidebar">
                     <div class="recent-posts-widget">
                        <h3>RELATED POSTS</h3>
                        <?php
                           $recent_posts = new WP_Query(array(
                               'post_type' => 'post',
                               'posts_per_page' => 5,
                               'orderby' => 'date',
                               'category_name' => 'ppc',
                               'order' => 'DESC',
                               'post__not_in' => array(get_the_ID())
                           ));
                           
                           if ($recent_posts->have_posts()) :
                               while ($recent_posts->have_posts()) : $recent_posts->the_post();
                           ?>
                        <div class="recent-post-item">
                           <?php if (has_post_thumbnail()) : ?>
                           <div class="recent-post-thumb">
                              <a href="<?php the_permalink(); ?>">
                              <?php the_post_thumbnail('thumbnail'); ?>
                              </a>
                           </div>
                           <?php endif; ?>
                           <div class="recent-post-content">
                              <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                              <span class="post-date"><?php echo get_the_date('M j, Y'); ?></span>
                           </div>
                        </div>
                        <?php
                           endwhile;
                           wp_reset_postdata();
                           endif;
                           ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <script>
            document.addEventListener('DOMContentLoaded', function() {
                const sidebar = document.getElementById('sticky-sidebar');
                const footer = document.querySelector('footer');
                
                // Check if elements exist
                if (!sidebar || !footer) return;
            
                function updateSidebarHeight() {
                    const viewportHeight = window.innerHeight;
                    const sidebarRect = sidebar.getBoundingClientRect();
                    const footerRect = footer.getBoundingClientRect();
                    
                    // If footer is in view, adjust sidebar
                    if (footerRect.top < viewportHeight) {
                        const newTop = footerRect.top - sidebarRect.height - 20;
                        sidebar.style.top = Math.max(0, newTop) + 'px';
                    } else {
                        sidebar.style.top = '100px'; // Reset to default
                    }
                }
            
                // Throttle scroll events
                let ticking = false;
                window.addEventListener('scroll', function() {
                    if (!ticking) {
                        window.requestAnimationFrame(function() {
                            updateSidebarHeight();
                            ticking = false;
                        });
                        ticking = true;
                    }
                }, { passive: true });
            
                // Handle resize events
                window.addEventListener('resize', updateSidebarHeight);
            
                // Initial setup
                updateSidebarHeight();
            });
         </script>
         <div class="social-share-container">
            <h3 class="share-title">Share this article</h3>
            <div class="social-share-buttons">
               <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" 
                  target="_blank" 
                  class="share-button facebook">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                  <span>Facebook</span>
               </a>
               <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" 
                  target="_blank" 
                  class="share-button x-twitter">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                     <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                  <span>X</span>
               </a>
               <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(get_permalink()); ?>&title=<?php echo urlencode(get_the_title()); ?>" 
                  target="_blank" 
                  class="share-button linkedin">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                     <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                  </svg>
                  <span>LinkedIn</span>
               </a>
               <a href="https://telegram.me/share/url?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" 
                  target="_blank" 
                  class="share-button telegram">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                     <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.306.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                  </svg>
                  <span>Telegram</span>
               </a>
               <button class="share-button copy-link" id="copyLinkBtn" data-url="<?php echo esc_url(get_permalink()); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                    <path d="M16 1H4C2.9 1 2 1.9 2 3v14h2V3h12V1zm3 4H8C6.9 5 6 5.9 6 7v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/>
                </svg>
                  <span>Copy Link</span>
               </button>
            </div>
         </div>
         <script>
            document.addEventListener('DOMContentLoaded', function() {
                const copyBtn = document.getElementById('copyLinkBtn');
                
                if (copyBtn) {
                    copyBtn.addEventListener('click', function() {
                        const url = this.getAttribute('data-url');
                        
                        // Create temporary input element
                        const tempInput = document.createElement('input');
                        tempInput.value = url;
                        document.body.appendChild(tempInput);
                        
                        // Select and copy the text
                        tempInput.select();
                        document.execCommand('copy');
                        
                        // Remove temporary element
                        document.body.removeChild(tempInput);
                        
                        // Visual feedback
                        const originalText = this.innerHTML;
                        this.classList.add('copy-success');
                        this.innerHTML = `
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                            </svg>
                            <span>Copied!</span>
                        `;
                        
                        // Reset button after 2 seconds
                        setTimeout(() => {
                            this.classList.remove('copy-success');
                            this.innerHTML = originalText;
                        }, 2000);
                    });
                }
            });
         </script>
         <div class="comments-section">
            <div class="comments-grid">
               <!-- Left Side: Comment Form -->
               <div class="comment-form-container">
                  <h3>Leave a Comment</h3>
                  <!-- Add success message div -->
                  <div id="comment-message" class="comment-message" style="display: none;"></div>
                  <form id="commentForm" class="comment-form">
                     <!-- Add nonce field -->
                     <?php wp_nonce_field('submit_comment', 'comment_nonce'); ?>
                     <!-- Add post ID -->
                     <input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>">
                     <div class="form-group">
                        <textarea 
                           name="comment"
                           placeholder="Write your comment here..." 
                           class="comment-textarea"
                           required
                           ></textarea>
                     </div>
                     <div class="form-row">
                        <div class="form-group">
                           <input 
                              type="text" 
                              name="author"
                              placeholder="Your Name" 
                              class="form-input"
                              required
                              >
                        </div>
                        <div class="form-group">
                           <input 
                              type="email" 
                              name="email"
                              placeholder="Your Email" 
                              class="form-input"
                              required
                              >
                        </div>
                     </div>
                     <button type="submit" class="post-comment-btn">Post Comment</button>
                  </form>
               </div>
               <!-- Right Side: Author Info -->
               <div class="author-info">
                  <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" class="author-image-link">
                  <?php echo get_avatar(get_the_author_meta('ID'), 120); ?>
                  </a>
                  <h4 class="author-name">
                     <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                     <?php the_author(); ?>
                     </a>
                  </h4>
                  <p class="author-bio"><?php the_author_meta('description'); ?></p>
                  <div class="author-stats">
                     <div class="stat-item">
                        <span class="stat-number"><?php echo count_user_posts(get_the_author_meta('ID')); ?></span>
                        <span class="stat-label">Articles</span>
                     </div>
                     <div class="social-links">
                        <?php
                           $twitter = get_the_author_meta('twitter');
                           $facebook = get_the_author_meta('facebook');
                           $linkedin = get_the_author_meta('linkedin');
                           $instagram = get_the_author_meta('instagram');
                           ?>
                        <?php if ($twitter) : ?>
                        <a href="<?php echo esc_url($twitter); ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                           <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                           </svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($facebook) : ?>
                        <a href="<?php echo esc_url($facebook); ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                           <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                           </svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($linkedin) : ?>
                        <a href="<?php echo esc_url($linkedin); ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                           <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                           </svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($instagram) : ?>
                        <a href="<?php echo esc_url($instagram); ?>" class="social-link" target="_blank" rel="noopener noreferrer">
                           <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.14.63c-.789.306-1.459.717-2.126 1.384S.935 3.35.63 4.14C.333 4.905.131 5.775.072 7.053.012 8.333 0 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.558 2.913.306.788.717 1.459 1.384 2.126.667.666 1.336 1.079 2.126 1.384.766.296 1.636.499 2.913.558C8.333 23.988 8.74 24 12 24s3.667-.015 4.947-.072c1.277-.06 2.148-.262 2.913-.558.788-.306 1.459-.718 2.126-1.384.666-.667 1.079-1.335 1.384-2.126.296-.765.499-1.636.558-2.913.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.558-2.913-.306-.789-.718-1.459-1.384-2.126C21.319 1.347 20.651.935 19.86.63c-.765-.297-1.636-.499-2.913-.558C15.667.012 15.26 0 12 0zm0 2.16c3.203 0 3.585.016 4.85.071 1.17.055 1.805.249 2.227.415.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.36 1.057.413 2.227.057 1.266.07 1.646.07 4.85s-.015 3.585-.074 4.85c-.061 1.17-.256 1.805-.421 2.227-.224.562-.479.96-.899 1.382-.419.419-.824.679-1.38.896-.42.164-1.065.36-2.235.413-1.274.057-1.649.07-4.859.07-3.211 0-3.586-.015-4.859-.074-1.171-.061-1.816-.256-2.236-.421-.569-.224-.96-.479-1.379-.899-.421-.419-.69-.824-.9-1.38-.165-.42-.359-1.065-.42-2.235-.045-1.26-.061-1.649-.061-4.844 0-3.196.016-3.586.061-4.861.061-1.17.255-1.814.42-2.234.21-.57.479-.96.9-1.381.419-.419.81-.689 1.379-.898.42-.166 1.051-.361 2.221-.421 1.275-.045 1.65-.06 4.859-.06l.045.03zm0 3.678c-3.405 0-6.162 2.76-6.162 6.162 0 3.405 2.76 6.162 6.162 6.162 3.405 0 6.162-2.76 6.162-6.162 0-3.405-2.76-6.162-6.162-6.162zM12 16c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm7.846-10.405c0 .795-.646 1.44-1.44 1.44-.795 0-1.44-.646-1.44-1.44 0-.794.646-1.439 1.44-1.439.793-.001 1.44.645 1.44 1.439z"/>
                           </svg>
                        </a>
                        <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Add comments display section -->
            <div class="comments-display">
               <h3>Comments</h3>
               <div class="comments-display-left">
                  <?php
                     // Get approved comments
                     $comments = get_comments(array(
                         'post_id' => get_the_ID(),
                         'status' => 'approve'
                     ));
                     
                     if ($comments) {
                         foreach ($comments as $comment) {
                             ?>
                  <div class="comment-item">
                     <div class="comment-author"><?php echo $comment->comment_author; ?></div>
                     <div class="comment-date"><?php echo date('F j, Y', strtotime($comment->comment_date)); ?></div>
                     <div class="comment-content"><?php echo $comment->comment_content; ?></div>
                  </div>
                  <?php
                     }
                     } else {
                     echo '<p class="no-comments">No comments yet. Be the first to comment!</p>';
                     }
                     ?>
               </div>
            </div>
         </div>
         <script>
            // Define ajaxurl for front-end
            var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
            
            document.addEventListener('DOMContentLoaded', function() {
                const commentForm = document.getElementById('commentForm');
                const messageDiv = document.getElementById('comment-message');
            
                commentForm.addEventListener('submit', function(e) {
                    e.preventDefault();
            
                    // Create FormData object
                    const formData = new FormData(commentForm);
                    formData.append('action', 'submit_comment');
            
                    // Send AJAX request
                    fetch(ajaxurl, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Show success message
                            messageDiv.innerHTML = data.data.message;
                            messageDiv.className = 'comment-message success';
                            messageDiv.style.display = 'block';
                            
                            // Clear form
                            commentForm.reset();
                            
                            // Hide message after 5 seconds
                            setTimeout(() => {
                                messageDiv.style.display = 'none';
                            }, 5000);
                        } else {
                            // Show error message
                            messageDiv.innerHTML = data.data || 'Error submitting comment';
                            messageDiv.className = 'comment-message error';
                            messageDiv.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        messageDiv.innerHTML = 'Error submitting comment';
                        messageDiv.className = 'comment-message error';
                        messageDiv.style.display = 'block';
                    });
                });
            });
         </script>
         <div class="blog-container">
            <h2 class="explore-heading">Explore More Articles</h2>
            <div class="blog-grid">
               <?php
                  // Define our six allowed categories
                  $allowed_categories = array(
                      'ppc'
                  );
                  
                  // Set up query arguments
                  $args = array(
                      'post_type' => 'post',
                      'post__not_in' => array(get_the_ID()),
                      'posts_per_page' => 3
                  );
                  
                  // Add category filter if set and valid
                  if (isset($_GET['category']) && $_GET['category'] != 'all') {
                      $category = sanitize_text_field($_GET['category']);
                      if (in_array($category, $allowed_categories)) {
                          $args['category_name'] = $category;
                      }
                  } else {
                      // If no category is selected or "all" is selected, show posts from all allowed categories
                      $args['category_name'] = implode(',', $allowed_categories);
                  }
                  
                  // The Query
                  $query = new WP_Query($args);
                  
                  // The Loop
                  if ($query->have_posts()) {
                      while ($query->have_posts()) {
                          $query->the_post();
                          
                          // Get the first category
                          $categories = get_the_category();
                          $category_name = !empty($categories) ? esc_html($categories[0]->name) : 'Uncategorized';
                          
                          // Get author info
                          $author_id = get_the_author_meta('ID');
                          $author_name = get_the_author();
                          $author_url = get_author_posts_url($author_id);
                          $author_avatar = get_avatar_url($author_id, array('size' => 60));
                          ?>
               <article class="blog-card">
                  <?php if (has_post_thumbnail()): ?>
                  <div class="blog-card__image-container">
                     <a href="<?php the_permalink(); ?>">
                     <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'medium_large')); ?>" 
                        alt="<?php the_title_attribute(); ?>" 
                        class="blog-card__image"
                        loading="lazy">
                     </a>
                     <?php if (!empty($categories)): ?>
                     <span class="blog-card__category-badge">
                     <?php echo $category_name; ?>
                     </span>
                     <?php endif; ?>
                  </div>
                  <?php endif; ?>
                  <div class="blog-card__content">
                     <span class="blog-card__date"><?php echo get_the_date(); ?></span>
                     <h2 class="blog-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                     <div class="blog-card__footer">
                        <a href="<?php the_permalink(); ?>" class="blog-card__read-more">Read More</a>
                        <div class="blog-card__author">
                           <img src="<?php echo esc_url($author_avatar); ?>" 
                              alt="<?php echo esc_attr($author_name); ?>" 
                              class="blog-card__author-image"
                              loading="lazy">
                           <a href="<?php echo esc_url($author_url); ?>" class="blog-card__author-name">
                           <?php echo esc_html($author_name); ?>
                           </a>
                        </div>
                     </div>
                  </div>
               </article>
               <?php
                  }
                  } else {
                  echo '<div class="no-posts">No posts found in this category.</div>';
                  }
                  ?>
            </div>
            <!-- End of blog-grid -->
            <div class="view-more-container">
               <a href="<?php echo SN_HTTP_URL; ?>blogs/" class="view-more-button">View More Articles</a>
            </div>
            <?php
               // Restore original Post Data
               wp_reset_postdata();
               ?>
         </div>
         <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>