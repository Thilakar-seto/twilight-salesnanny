<?php
   /*
   Template Name: Glossary
   */
   ?>
<html>
   <body>
      <div>
        <?php salesnanny_nav_header(); ?>
        <style>
            .glossary-hero {
                background:  url('https://www.fosdesk.com/wp-content/themes/fosdesk/image/glossary1.webp');
                background-size: cover;
                background-position: center;
                padding: 100px 0;
                color: #fff;
                margin-top: 80px;
                position: relative;
                overflow: hidden;
            }

            /* Add hero background overlay with subtle animation */
            .glossary-hero:before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                animation: pulseOverlay 8s infinite alternate;
            }

            @keyframes pulseOverlay {
                0% { background: rgba(0, 0, 0, 0.5); }
                100% { background: rgba(0, 0, 0, 0.65); }
            }

            .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 20px;
                position: relative; /* For z-index over the overlay */
            }

            .glossary-hero__content {
                max-width: 800px;
                opacity: 0;
                transform: translateY(30px);
                animation: fadeInUp 1s ease forwards 0.3s;
            }

            @keyframes fadeInUp {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .glossary-hero__content h1 {
                font-size: 4rem;
                margin-bottom: 1rem;
                font-weight: bold;
                position: relative;
                display: inline-block;
            }
            
            /* Animated underline for heading */
            .glossary-hero__content h1:after {
                content: '';
                position: absolute;
                bottom: -5px;
                left: 0;
                width: 0;
                height: 3px;
                background-color: #C22034;
                animation: expandWidth 1.2s ease-out forwards 1s;
            }
            
            @keyframes expandWidth {
                to { width: 100%; }
            }

            .hero-subtitle {
                font-size: 1.5rem;
                line-height: 1.5;
                opacity: 0;
                animation: fadeIn 1s ease forwards 1.2s;
            }
            
            @keyframes fadeIn {
                to { opacity: 1; }
            }
            
            /* Floating animation for visual interest */
            .glossary-hero__content {
                animation: float 6s ease-in-out infinite;
            }
            
            @keyframes float {
                0% { transform: translateY(0px); }
                50% { transform: translateY(-10px); }
                100% { transform: translateY(0px); }
            }

            /* Responsive styles */
            @media (max-width: 768px) {
                .glossary-hero {
                    padding: 60px 0;
                }
                
                .glossary-hero__content h1 {
                    font-size: 2.5rem;
                }
                
                .hero-subtitle {
                    font-size: 1.2rem;
                }
                
                /* Simplify animations on smaller screens */
                .glossary-hero__content {
                    animation: fadeInUp 0.8s ease forwards 0.2s;
                }
            }

            @media (max-width: 480px) {
                .glossary-hero__content h1 {
                    font-size: 2rem;
                }
                
                .hero-subtitle {
                    font-size: 1rem;
                }
                
                /* Further reduce animation complexity */
                @keyframes float {
                    0% { transform: translateY(0px); }
                    50% { transform: translateY(-5px); }
                    100% { transform: translateY(0px); }
                }
            }
            
            /* Respect user preferences for reduced motion */
            @media (prefers-reduced-motion: reduce) {
                .glossary-hero:before,
                .glossary-hero__content,
                .glossary-hero__content h1:after {
                    animation: none !important;
                    transition: none !important;
                }
                
                .glossary-hero__content,
                .hero-subtitle {
                    opacity: 1;
                    transform: none;
                }
            }

            .glossary-card {
                position: relative;
            }

            .card-letter {
                position: absolute;
                bottom: 20px;
                right: 30px;
                font-size: 80px;
                font-weight: bold;
                color: #333;
                opacity: 0.3;
            }

            .glossary-card:hover .card-letter {
                color: #fff;
            }
        </style>
        <section class="glossary-hero">
            <div class="container">
                <div class="glossary-hero__content">
                    <h1>Logistics Glossary</h1>
                    <p class="hero-subtitle">Get to know the vital terms of Logistics and Supply Chain Management.</p>
                </div>
            </div>
        </section>
        <style>
            .glossary-grid {
                padding: 60px 0;
                background-color: #f8f9fa;
            }

            .glossary-cards {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 30px;
                margin-top: 40px;
            }

            .glossary-card {
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
                height: 100%;
                box-shadow: 4px 4px 0 .5px #C22034;
                /* Add transform origin for better flip effect */
                transform-origin: center;
                /* Add animation on load */
                opacity: 0;
                transform: translateY(20px);
                animation: fadeInUp 0.6s ease forwards;
            }
            
            /* Card appearance animation on page load */
            @keyframes fadeInUp {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            /* Add sequential delay to cards */
            .glossary-cards .glossary-card:nth-child(1) { animation-delay: 0.1s; }
            .glossary-cards .glossary-card:nth-child(2) { animation-delay: 0.2s; }
            .glossary-cards .glossary-card:nth-child(3) { animation-delay: 0.3s; }
            .glossary-cards .glossary-card:nth-child(4) { animation-delay: 0.4s; }
            .glossary-cards .glossary-card:nth-child(5) { animation-delay: 0.5s; }
            .glossary-cards .glossary-card:nth-child(6) { animation-delay: 0.6s; }

            .glossary-card:hover {
                background-color: #C22034;
                color: #fff;
                transform: translateY(-5px) scale(1.02);
                box-shadow: 6px 6px 0 0.5px rgba(194, 32, 52, 0.8);
            }
            
            .glossary-card:active {
                transform: translateY(0) scale(0.98);
                transition: transform 0.1s;
            }

            .glossary-card:hover .term-list a {
                color: #fff;
            }
            
            .glossary-card:hover .more-definitions {
                color: #fff;
            }

            .card-content {
                padding: 30px;
            }

            .term-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .term-list li {
                margin-bottom: 15px;
                transform: translateX(-10px);
                opacity: 0.8;
                transition: all 0.3s ease;
            }
            
            .glossary-card:hover .term-list li {
                transform: translateX(0);
                opacity: 1;
            }
            
            /* Add sequential animation to list items on hover */
            .glossary-card:hover .term-list li:nth-child(1) { transition-delay: 0.05s; }
            .glossary-card:hover .term-list li:nth-child(2) { transition-delay: 0.1s; }
            .glossary-card:hover .term-list li:nth-child(3) { transition-delay: 0.15s; }
            .glossary-card:hover .term-list li:nth-child(4) { transition-delay: 0.2s; }
            .glossary-card:hover .term-list li:nth-child(5) { transition-delay: 0.25s; }
            .glossary-card:hover .term-list li:nth-child(6) { transition-delay: 0.3s; }
            .glossary-card:hover .term-list li:nth-child(7) { transition-delay: 0.35s; }
            .glossary-card:hover .term-list li:nth-child(8) { transition-delay: 0.4s; }

            .term-list a {
                color: #333;
                text-decoration: none;
                font-size: 16px;
                transition: color 0.3s ease;
                display: block;
                position: relative;
                padding-left: 12px;
            }
            
            .term-list a:before {
                content: '→';
                position: absolute;
                left: 0;
                opacity: 0;
                transform: translateX(-10px);
                transition: all 0.3s ease;
            }
            
            .term-list a:hover:before {
                opacity: 1;
                transform: translateX(-5px);
            }

            .term-list a:hover {
                color: #ff0000; /* Your site's primary color */
                transform: translateX(5px);
            }

            .more-definitions {
                display: inline-block;
                margin-top: 20px;
                color: #ff0000; /* Your site's primary color */
                text-decoration: none;
                font-weight: 600;
                position: relative;
                transition: all 0.3s ease;
                overflow: hidden;
            }

            .more-definitions:after {
                content: '';
                position: absolute;
                bottom: -2px;
                left: 0;
                width: 100%;
                height: 2px;
                background-color: #ff0000; /* Your site's primary color */
                transform: scaleX(0);
                transition: transform 0.3s ease;
                transform-origin: left;
            }

            .glossary-card:hover .more-definitions:after {
                background-color: #fff;
            }

            .more-definitions:hover:after {
                transform: scaleX(1);
            }
            
            .more-definitions:hover {
                letter-spacing: 0.5px;
            }

            .card-letter {
                position: absolute;
                bottom: 20px;
                right: 30px;
                font-size: 80px;
                font-weight: bold;
                color: #333;
                opacity: 0.3;
                transition: all 0.4s ease;
                transform: translateY(0) rotate(0);
            }

            .glossary-card:hover .card-letter {
                color: #fff;
                opacity: 0.4;
                transform: translateY(-10px) rotate(-5deg);
            }

            /* Responsive Styles */
            @media (max-width: 992px) {
                .glossary-cards {
                    grid-template-columns: repeat(2, 1fr);
                }
                
                /* Adjust animation delays for 2-column layout */
                .glossary-cards .glossary-card:nth-child(odd) { animation-delay: 0.1s; }
                .glossary-cards .glossary-card:nth-child(even) { animation-delay: 0.2s; }
            }

            @media (max-width: 768px) {
                .glossary-cards {
                    grid-template-columns: 1fr;
                }
                
                .glossary-grid {
                    padding: 40px 0;
                }
                
                .card-content {
                    padding: 20px;
                }
                
                /* Simplify animations on mobile for better performance */
                .glossary-card {
                    animation-delay: 0.1s !important;
                }
                
                .glossary-card:hover {
                    transform: translateY(-3px);
                }
                
                .card-letter {
                    font-size: 60px;
                    bottom: 15px;
                    right: 20px;
                }
            }
            
            @media (prefers-reduced-motion: reduce) {
                .glossary-card, .term-list li, .term-list a, .more-definitions, .card-letter {
                    animation: none !important;
                    transition: color 0.3s ease, background-color 0.3s ease !important;
                    transform: none !important;
                }
            }
        </style>
        <section class="glossary-grid">
            <div class="container">
                <div class="glossary-cards">
                    <!-- Card 1 -->
                    <div class="glossary-card">
                        <div class="card-content">
                            <ul class="term-list">
                                <li><a href="#">A House Air Waybill (HAWB)</a></li>
                                <li><a href="#">A Perfect Order</a></li>
                                <li><a href="#">Acceptable Quality Level (AQL)</a></li>
                                <li><a href="#">Accessibility</a></li>
                                <li><a href="#">Accessorial Fees</a></li>
                                <li><a href="#">Accountability</a></li>
                                <li><a href="#">Accounts Payable (A/P)</a></li>
                                <li><a href="#">Accounts Receivable (A/R)</a></li>
                            </ul>
                            <a href="#" class="more-definitions">9 More Definitions</a>
                            <span class="card-letter">A</span>
                        </div>
                    </div>

                    <!-- Card 2 -->
                    <div class="glossary-card">
                        <div class="card-content">
                            <ul class="term-list">
                                <li><a href="#">Beneficial Cargo Owner (BCO)</a></li>
                                <li><a href="#">Bill of Lading (BOL)</a></li>
                                <li><a href="#">Bill of Lading Number</a></li>
                                <li><a href="#">Blind Shipping</a></li>
                                <li><a href="#">Bonded Goods</a></li>
                                <li><a href="#">Bonded Warehouse</a></li>
                                <li><a href="#">Booking Confirmation</a></li>
                                <li><a href="#">Booking Fee</a></li>
                            </ul>
                            <a href="#" class="more-definitions">11 More Definitions</a>
                            <span class="card-letter">B</span>
                        </div>
                    </div>

                    <!-- Card 3 -->
                    <div class="glossary-card">
                        <div class="card-content">
                            <ul class="term-list">
                                <li><a href="#">Cargo</a></li>
                                <li><a href="#">Cargo Arrival Certificate (CAN)</a></li>
                                <li><a href="#">Cargo Insurance</a></li>
                                <li><a href="#">Carrier</a></li>
                                <li><a href="#">Carrier Certificate and Release Order</a></li>
                                <li><a href="#">Carrier Liability</a></li>
                                <li><a href="#">Carriers Lien</a></li>
                                <li><a href="#">Cartel</a></li>
                            </ul>
                            <a href="#" class="more-definitions">32 More Definitions</a>
                            <span class="card-letter">C</span>
                        </div>
                    </div>
                    <div class="glossary-card">
                        <div class="card-content">
                            <ul class="term-list">
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                                <li><a href="#">Dangerous Goods</a></li>
                            </ul>
                            <a href="#" class="more-definitions">32 More Definitions</a>
                            <span class="card-letter">D</span>
                        </div>
                    </div>
                    <div class="glossary-card">
                        <div class="card-content">
                            <ul class="term-list">
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                                <li><a href="#">E</a></li>
                            </ul>
                            <a href="#" class="more-definitions">32 More Definitions</a>
                            <span class="card-letter">E</span>
                        </div>
                    </div>

                    <div class="glossary-card">
                        <div class="card-content">
                            <ul class="term-list">
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                                <li><a href="#">F</a></li>
                            </ul>
                            <a href="#" class="more-definitions">32 More Definitions</a>
                            <span class="card-letter">F</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>