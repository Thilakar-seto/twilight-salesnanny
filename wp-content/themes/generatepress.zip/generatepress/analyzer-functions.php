<?php
/**
 * Website Analyzer Functions
 * 
 * Separate file for all analyzer-related functionality to avoid conflicts
 * with other theme functions.
 * 
 * @package GeneratePress
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Include analyzer configuration
require_once get_template_directory() . '/analyzer-config.php';

/**
 * Enhanced AJAX handler for website analysis
 */
function handle_enhanced_analysis() {
    try {
        // Check if required data is present
        if (!isset($_POST['nonce']) || !isset($_POST['url'])) {
            wp_send_json_error('Missing required data');
            return;
        }
        
        // Verify nonce (allow for both logged-in and non-logged-in users)
        $nonce_verified = wp_verify_nonce($_POST['nonce'], 'enhanced_analysis_nonce');
        if (!$nonce_verified) {
            // For debugging: log the nonce verification failure
            error_log('Nonce verification failed for enhanced analysis. Nonce: ' . $_POST['nonce'] . ', User logged in: ' . (is_user_logged_in() ? 'yes' : 'no'));
            wp_send_json_error('Security check failed');
            return;
        }
        
        $url = sanitize_url($_POST['url']);
        $options = $_POST['options'] ?? [];
        
        // Debug: error_log('AJAX Handler - URL: ' . $url . ', Options: ' . print_r($options, true));
        
        if (empty($url)) {
            wp_send_json_error('Please provide a website URL');
            return;
        }
        
        // Check if WebsiteAnalyzerConfig class exists
        if (!class_exists('WebsiteAnalyzerConfig')) {
            wp_send_json_error('Analyzer configuration not found');
            return;
        }
        
        // Check daily usage limit
        if (!WebsiteAnalyzerConfig::checkDailyLimit()) {
            wp_send_json_error('Daily analysis limit reached. Please try again tomorrow.');
            return;
        }
    } catch (Exception $e) {
        wp_send_json_error('Configuration error: ' . $e->getMessage());
        return;
    }
    
    try {
        $analysis_result = [
            'url' => $url,
            'timestamp' => time()
        ];
        
        // Performance analysis using Google PageSpeed Insights API
        if (($options['analyze_mobile'] ?? false) || ($options['analyze_desktop'] ?? false)) {
            $performance_data = get_enhanced_pagespeed_insights($url, $options);
            // Debug: error_log('Performance data: ' . print_r($performance_data, true));
            if ($performance_data) {
                $analysis_result = array_merge($analysis_result, $performance_data);
            }
        }
        
        // SEO analysis
        if ($options['analyze_seo'] ?? false) {
            $seo_data = perform_enhanced_seo_analysis($url);
            // Debug: error_log('SEO data: ' . print_r($seo_data, true));
            if ($seo_data) {
                $analysis_result['seo'] = $seo_data;
            }
        }
        
        // Security analysis
        if ($options['analyze_security'] ?? false) {
            $security_data = perform_enhanced_security_analysis($url);
            // Debug: error_log('Security data: ' . print_r($security_data, true));
            if ($security_data) {
                $analysis_result['security'] = $security_data;
            }
        }
        
        // Accessibility analysis - combine Google PageSpeed data with custom analysis
        if ($options['analyze_accessibility'] ?? false) {
            $accessibility_data = [];
            
            // First, try to get accessibility data from Google PageSpeed API results
            if (!empty($analysis_result['mobile']['accessibility']) || !empty($analysis_result['desktop']['accessibility'])) {
                // Use Google PageSpeed accessibility data as primary source
                $mobile_accessibility = $analysis_result['mobile']['accessibility'] ?? null;
                $desktop_accessibility = $analysis_result['desktop']['accessibility'] ?? null;
                
                // Use the better score between mobile and desktop
                if ($mobile_accessibility && $desktop_accessibility) {
                    $accessibility_data = $mobile_accessibility['score'] >= $desktop_accessibility['score'] ? 
                        $mobile_accessibility : $desktop_accessibility;
                } else {
                    $accessibility_data = $mobile_accessibility ?? $desktop_accessibility;
                }
                
                // Add custom accessibility audits to supplement Google data
                $custom_accessibility = perform_enhanced_accessibility_analysis($url);
                if ($custom_accessibility && isset($custom_accessibility['audits'])) {
                    // Merge custom audits with Google PageSpeed data
                    $accessibility_data['custom_audits'] = $custom_accessibility['audits'];
                    $accessibility_data['custom_score'] = $custom_accessibility['score'];
                }
            } else {
                // Fallback to custom accessibility analysis if no Google data available
                $accessibility_data = perform_enhanced_accessibility_analysis($url);
            }
            
            // Debug: error_log('Accessibility data: ' . print_r($accessibility_data, true));
            if ($accessibility_data) {
                $analysis_result['accessibility'] = $accessibility_data;
            }
        }
        
        // Technology detection
        if ($options['analyze_tech'] ?? false) {
            $tech_data = detect_website_technologies($url);
            if ($tech_data) {
                $analysis_result['technologies'] = $tech_data;
            }
        }
        
        // Increment usage counter
        WebsiteAnalyzerConfig::incrementUsage();
        
        // Debug: error_log('Final analysis result: ' . print_r($analysis_result, true));
        wp_send_json_success($analysis_result);
        
    } catch (Exception $e) {
        wp_send_json_error('Analysis failed: ' . $e->getMessage());
    }
}

// Register AJAX handlers
add_action('wp_ajax_enhanced_website_analysis', 'handle_enhanced_analysis');
add_action('wp_ajax_nopriv_enhanced_website_analysis', 'handle_enhanced_analysis');

// Register PDF generation AJAX handlers with unique names
add_action('wp_ajax_generate_analyzer_pdf_report', 'handle_analyzer_pdf_generation');
add_action('wp_ajax_nopriv_generate_analyzer_pdf_report', 'handle_analyzer_pdf_generation');

/**
 * Get enhanced PageSpeed Insights data
 */
function get_enhanced_pagespeed_insights($url, $options) {
    $api_key = WebsiteAnalyzerConfig::getPageSpeedApiKey();
    
    if (empty($api_key)) {
        error_log('Google PageSpeed API key is not configured');
        return [];
    }
    
    $result = [];
    $strategies = [];
    
    if ($options['analyze_mobile'] ?? false) {
        $strategies['mobile'] = 'mobile';
    }
    if ($options['analyze_desktop'] ?? false) {
        $strategies['desktop'] = 'desktop';
    }
    
    foreach ($strategies as $key => $strategy) {
        $api_url = WebsiteAnalyzerConfig::GOOGLE_PAGESPEED_API_URL;
        // Build URL with multiple category parameters
        $params = [
            'url' => $url,
            'key' => $api_key,
            'strategy' => $strategy
        ];
        
        $request_url = $api_url . '?' . http_build_query($params) . 
                      '&category=performance&category=seo&category=accessibility&category=best-practices';
        
        // Debug: error_log('PageSpeed API Request URL for ' . $key . ': ' . $request_url);
        
        $response = wp_remote_get($request_url, [
            'timeout' => WebsiteAnalyzerConfig::MAX_ANALYSIS_TIME,
            'headers' => [
                'User-Agent' => 'WordPress Website Analyzer'
            ]
        ]);
        
        if (!is_wp_error($response)) {
            $response_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            
            if ($response_code == 200) {
                $data = json_decode($body, true);
                
                if ($data && isset($data['lighthouseResult'])) {
                    $result[$key] = parse_enhanced_lighthouse_result($data['lighthouseResult']);
                } else {
                    // Log API response for debugging
                    error_log('PageSpeed API returned invalid data for ' . $key . ': ' . substr($body, 0, 500));
                    if (isset($data['error'])) {
                        error_log('PageSpeed API Error: ' . $data['error']['message']);
                    }
                }
            } else {
                error_log('PageSpeed API HTTP Error ' . $response_code . ' for ' . $key . ': ' . substr($body, 0, 500));
            }
        } else {
            error_log('PageSpeed API Request Failed for ' . $key . ': ' . $response->get_error_message());
        }
    }
    
    return $result;
}

/**
 * Parse Lighthouse result data
 */
function parse_enhanced_lighthouse_result($lighthouse_data) {
    $result = [];
    
    // Categories scores (including accessibility)
    if (isset($lighthouse_data['categories'])) {
        foreach ($lighthouse_data['categories'] as $category => $data) {
            $result[str_replace('-', '_', $category)] = [
                'score' => round($data['score'] * 100),
                'title' => $data['title'] ?? ucfirst($category)
            ];
        }
    }
    
    // Extract accessibility audits from Google PageSpeed if available
    if (isset($lighthouse_data['audits'])) {
        $accessibility_audits = [];
        $accessibility_audit_keys = [
            'image-alt',
            'label',
            'link-name',
            'color-contrast',
            'heading-order',
            'html-has-lang',
            'html-lang-valid',
            'button-name',
            'form-field-multiple-labels',
            'frame-title',
            'input-image-alt',
            'aria-allowed-attr',
            'aria-required-children',
            'aria-required-parent',
            'aria-roles',
            'aria-valid-attr-value',
            'aria-valid-attr',
            'duplicate-id-aria',
            'duplicate-id-active',
            'focus-traps',
            'focusable-controls',
            'interactive-element-affordance',
            'logical-tab-order',
            'managed-focus',
            'offscreen-content-hidden',
            'use-landmarks',
            'visual-order-follows-dom'
        ];
        
        foreach ($accessibility_audit_keys as $audit_key) {
            if (isset($lighthouse_data['audits'][$audit_key])) {
                $audit = $lighthouse_data['audits'][$audit_key];
                $accessibility_audits[$audit_key] = [
                    'title' => $audit['title'] ?? ucfirst(str_replace('-', ' ', $audit_key)),
                    'description' => strip_tags($audit['description'] ?? ''),
                    'score' => $audit['score'] ?? 0,
                    'scoreDisplayMode' => $audit['scoreDisplayMode'] ?? 'binary',
                    'displayValue' => $audit['displayValue'] ?? null
                ];
            }
        }
        
        if (!empty($accessibility_audits)) {
            $result['accessibility_audits'] = $accessibility_audits;
        }
    }
    
    // Core Web Vitals and other metrics
    if (isset($lighthouse_data['audits'])) {
        $metrics = [
            'first-contentful-paint',
            'largest-contentful-paint',
            'first-input-delay',
            'cumulative-layout-shift',
            'speed-index',
            'total-blocking-time'
        ];
        
        $result['metrics'] = [];
        foreach ($metrics as $metric) {
            if (isset($lighthouse_data['audits'][$metric])) {
                $audit = $lighthouse_data['audits'][$metric];
                $result['metrics'][$metric] = [
                    'displayValue' => $audit['displayValue'] ?? 'N/A',
                    'score' => $audit['score'] ?? 0,
                    'title' => $audit['title'] ?? ucfirst(str_replace('-', ' ', $metric))
                ];
            }
        }
        
        // Opportunities for improvement with real savings data
        $result['opportunities'] = [];
        
        // Key performance opportunity audits from Google PageSpeed Insights
        $opportunity_audits = [
            'unused-css-rules',
            'unused-javascript', 
            'render-blocking-resources',
            'unminified-css',
            'unminified-javascript',
            'efficient-animated-content',
            'modern-image-formats',
            'offscreen-images',
            'properly-size-images',
            'uses-optimized-images',
            'uses-webp-images',
            'uses-responsive-images',
            'server-response-time',
            'redirects',
            'uses-text-compression',
            'preconnect',
            'font-display',
            'critical-request-chains',
            'uses-rel-preload',
            'total-byte-weight',
            'dom-size',
            'third-party-summary'
        ];
        
        foreach ($opportunity_audits as $audit_id) {
            if (isset($lighthouse_data['audits'][$audit_id])) {
                $audit = $lighthouse_data['audits'][$audit_id];
                
                // Only include if it's actually an opportunity (score < 1.0)
                if (($audit['score'] ?? 1) < 1.0) {
                    $opportunity = [
                        'id' => $audit_id,
                        'title' => $audit['title'] ?? ucfirst(str_replace('-', ' ', $audit_id)),
                        'description' => strip_tags($audit['description'] ?? ''),
                        'score' => $audit['score'] ?? 0,
                        'scoreDisplayMode' => $audit['scoreDisplayMode'] ?? 'numeric'
                    ];
                    
                    // Extract savings information
                    $savings = [];
                    
                    if (isset($audit['details']['overallSavingsMs'])) {
                        $savings_ms = (int)$audit['details']['overallSavingsMs'];
                        if ($savings_ms > 0) {
                            $savings['time'] = $savings_ms >= 1000 ? 
                                round($savings_ms / 1000, 1) . 's' : 
                                $savings_ms . 'ms';
                        }
                    }
                    
                    if (isset($audit['details']['overallSavingsBytes'])) {
                        $savings_bytes = (int)$audit['details']['overallSavingsBytes'];
                        if ($savings_bytes > 0) {
                            if ($savings_bytes >= 1024 * 1024) {
                                $savings['size'] = round($savings_bytes / (1024 * 1024), 1) . ' MB';
                            } elseif ($savings_bytes >= 1024) {
                                $savings['size'] = round($savings_bytes / 1024, 1) . ' KB';
                            } else {
                                $savings['size'] = $savings_bytes . ' B';
                            }
                        }
                    }
                    
                    // Extract display value if available
                    if (isset($audit['displayValue']) && !empty($audit['displayValue'])) {
                        $display_value = strip_tags($audit['displayValue']);
                        // Extract potential savings from display value
                        if (preg_match('/(\d+(?:\.\d+)?)\s*(s|ms|KB|MB|B)\b/i', $display_value, $matches)) {
                            $value = $matches[1];
                            $unit = strtoupper($matches[2]);
                            if (in_array($unit, ['S', 'MS'])) {
                                if (!isset($savings['time'])) {
                                    $savings['time'] = $value . strtolower($unit);
                                }
                            } elseif (in_array($unit, ['KB', 'MB', 'B'])) {
                                if (!isset($savings['size'])) {
                                    $savings['size'] = $value . ' ' . $unit;
                                }
                            }
                        }
                        $opportunity['displayValue'] = $display_value;
                    }
                    
                    // Extract numeric value for sorting
                    if (isset($audit['numericValue'])) {
                        $opportunity['numericValue'] = $audit['numericValue'];
                    }
                    
                    // Add impact level based on score
                    if ($audit['score'] <= 0.5) {
                        $opportunity['impact'] = 'High';
                        $opportunity['impactColor'] = '#dc3545';
                    } elseif ($audit['score'] <= 0.8) {
                        $opportunity['impact'] = 'Medium';
                        $opportunity['impactColor'] = '#ffc107';
                    } else {
                        $opportunity['impact'] = 'Low';
                        $opportunity['impactColor'] = '#28a745';
                    }
                    
                    $opportunity['savings'] = $savings;
                    $result['opportunities'][] = $opportunity;
                }
            }
        }
        
        // Sort by impact (lower score = higher impact, then by numeric value)
        usort($result['opportunities'], function($a, $b) {
            // Primary sort: by score (lower is worse, so higher priority)
            $score_diff = $a['score'] <=> $b['score'];
            if ($score_diff !== 0) return $score_diff;
            
            // Secondary sort: by numeric value (higher is worse for most metrics)
            $a_numeric = $a['numericValue'] ?? 0;
            $b_numeric = $b['numericValue'] ?? 0;
            return $b_numeric <=> $a_numeric;
        });
        
        // Limit to top 8 opportunities
        $result['opportunities'] = array_slice($result['opportunities'], 0, 8);
    }
    
    return $result;
}

/**
 * Perform enhanced SEO analysis
 */
function perform_enhanced_seo_analysis($url) {
    $response = wp_remote_get($url, [
        'timeout' => 30,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (compatible; WordPress Website Analyzer)'
        ]
    ]);
    
    if (is_wp_error($response)) {
        // Return comprehensive SEO structure with default scores when request fails
        return [
            'score' => 50,
            'audits' => [
                'title' => ['title' => 'Page title could not be analyzed', 'score' => 0.5, 'description' => 'Unable to fetch page title'],
                'meta-description' => ['title' => 'Meta description could not be analyzed', 'score' => 0.5, 'description' => 'Unable to fetch meta description'],
                'headings' => ['title' => 'Heading structure could not be analyzed', 'score' => 0.5, 'description' => 'Unable to analyze heading structure'],
                'images' => ['title' => 'Image alt attributes could not be analyzed', 'score' => 0.5, 'description' => 'Unable to check image alt attributes'],
                'robots' => ['title' => 'Robots meta tag could not be analyzed', 'score' => 0.5, 'description' => 'Unable to check robots directives'],
                'canonical' => ['title' => 'Canonical URL could not be analyzed', 'score' => 0.5, 'description' => 'Unable to check canonical URL'],
                'structured-data' => ['title' => 'Structured data could not be analyzed', 'score' => 0.5, 'description' => 'Unable to detect schema markup'],
                'social-meta' => ['title' => 'Social media meta tags could not be analyzed', 'score' => 0.5, 'description' => 'Unable to check Open Graph and Twitter Card tags']
            ]
        ];
    }
    
    $html = wp_remote_retrieve_body($response);
    $headers = wp_remote_retrieve_headers($response);
    
    $dom = new DOMDocument();
    @$dom->loadHTML($html);
    $xpath = new DOMXPath($dom);
    
    $seo_result = ['audits' => []];
    $total_score = 0;
    $audit_count = 0;
    
    // 1. Title tag analysis
    $title_nodes = $xpath->query('//title');
    if ($title_nodes->length > 0) {
        $title = trim($title_nodes->item(0)->textContent);
        $title_length = strlen($title);
        
        if ($title_length >= 30 && $title_length <= 60) {
            $title_score = 1.0;
            $title_status = 'Page title is optimally sized';
        } elseif ($title_length > 0) {
            $title_score = 0.7;
            $title_status = $title_length < 30 ? 'Title is too short' : 'Title is too long';
        } else {
            $title_score = 0.0;
            $title_status = 'No title tag found';
        }
        
        $seo_result['audits']['title'] = [
            'title' => 'Page has a title tag',
            'score' => $title_score,
            'description' => $title_status . " (Current: {$title_length} characters)",
            'details' => ['content' => $title, 'length' => $title_length]
        ];
    } else {
        $seo_result['audits']['title'] = [
            'title' => 'Page has a title tag',
            'score' => 0.0,
            'description' => 'No title tag found on the page'
        ];
    }
    $total_score += $seo_result['audits']['title']['score'];
    $audit_count++;
    
    // 2. Meta description analysis
    $meta_desc = $xpath->query('//meta[@name="description"]');
    if ($meta_desc->length > 0) {
        $description = trim($meta_desc->item(0)->getAttribute('content'));
        $desc_length = strlen($description);
        
        if ($desc_length >= 120 && $desc_length <= 160) {
            $desc_score = 1.0;
            $desc_status = 'Meta description is optimally sized';
        } elseif ($desc_length > 0) {
            $desc_score = 0.7;
            $desc_status = $desc_length < 120 ? 'Description is too short' : 'Description is too long';
        } else {
            $desc_score = 0.0;
            $desc_status = 'Meta description is empty';
        }
        
        $seo_result['audits']['meta-description'] = [
            'title' => 'Page has a meta description',
            'score' => $desc_score,
            'description' => $desc_status . " (Current: {$desc_length} characters)",
            'details' => ['content' => $description, 'length' => $desc_length]
        ];
    } else {
        $seo_result['audits']['meta-description'] = [
            'title' => 'Page has a meta description',
            'score' => 0.0,
            'description' => 'No meta description found'
        ];
    }
    $total_score += $seo_result['audits']['meta-description']['score'];
    $audit_count++;
    
    // 3. Heading structure analysis
    $headings = [];
    $h1_count = 0;
    for ($i = 1; $i <= 6; $i++) {
        $heading_nodes = $xpath->query("//h{$i}");
        $count = $heading_nodes->length;
        $headings["h{$i}"] = $count;
        if ($i === 1) $h1_count = $count;
    }
    
    if ($h1_count === 1) {
        $heading_score = 1.0;
        $heading_status = 'Page has a single H1 tag';
    } elseif ($h1_count > 1) {
        $heading_score = 0.7;
        $heading_status = 'Page has multiple H1 tags';
    } else {
        $heading_score = 0.3;
        $heading_status = 'Page has no H1 tag';
    }
    
    $seo_result['audits']['headings'] = [
        'title' => 'Page has proper heading structure',
        'score' => $heading_score,
        'description' => $heading_status,
        'details' => $headings
    ];
    $total_score += $heading_score;
    $audit_count++;
    
    // 4. Images analysis
    $images = $xpath->query('//img');
    $images_without_alt = 0;
    $total_images = $images->length;
    
    foreach ($images as $img) {
        if (!$img->hasAttribute('alt') || empty(trim($img->getAttribute('alt')))) {
            $images_without_alt++;
        }
    }
    
    if ($total_images === 0) {
        $img_score = 1.0;
        $img_status = 'No images found on page';
    } elseif ($images_without_alt === 0) {
        $img_score = 1.0;
        $img_status = 'All images have alt attributes';
    } else {
        $img_score = max(0, 1 - ($images_without_alt / $total_images));
        $img_status = "{$images_without_alt} out of {$total_images} images missing alt attributes";
    }
    
    $seo_result['audits']['images'] = [
        'title' => 'Images have alt attributes',
        'score' => $img_score,
        'description' => $img_status,
        'details' => ['total' => $total_images, 'without_alt' => $images_without_alt]
    ];
    $total_score += $img_score;
    $audit_count++;
    
    // 5. Robots meta tag analysis
    $robots_meta = $xpath->query('//meta[@name="robots"]');
    if ($robots_meta->length > 0) {
        $robots_content = strtolower($robots_meta->item(0)->getAttribute('content'));
        if (strpos($robots_content, 'noindex') !== false || strpos($robots_content, 'nofollow') !== false) {
            $robots_score = 0.5;
            $robots_status = 'Page has restrictive robots directives';
        } else {
            $robots_score = 1.0;
            $robots_status = 'Page allows indexing and following';
        }
    } else {
        $robots_score = 1.0;
        $robots_status = 'No robots meta tag (default: index, follow)';
    }
    
    $seo_result['audits']['robots'] = [
        'title' => 'Page is indexable',
        'score' => $robots_score,
        'description' => $robots_status
    ];
    $total_score += $robots_score;
    $audit_count++;
    
    // 6. Canonical URL analysis
    $canonical = $xpath->query('//link[@rel="canonical"]');
    if ($canonical->length > 0) {
        $canonical_url = $canonical->item(0)->getAttribute('href');
        $canonical_score = 1.0;
        $canonical_status = 'Page has canonical URL';
    } else {
        $canonical_score = 0.7;
        $canonical_status = 'No canonical URL specified';
    }
    
    $seo_result['audits']['canonical'] = [
        'title' => 'Page has canonical URL',
        'score' => $canonical_score,
        'description' => $canonical_status
    ];
    $total_score += $canonical_score;
    $audit_count++;
    
    // 7. Structured data analysis
    $json_ld = $xpath->query('//script[@type="application/ld+json"]');
    $microdata = $xpath->query('//*[@itemscope]');
    
    if ($json_ld->length > 0 || $microdata->length > 0) {
        $schema_score = 1.0;
        $schema_status = 'Page has structured data markup';
    } else {
        $schema_score = 0.5;
        $schema_status = 'No structured data found';
    }
    
    $seo_result['audits']['structured-data'] = [
        'title' => 'Page has structured data',
        'score' => $schema_score,
        'description' => $schema_status
    ];
    $total_score += $schema_score;
    $audit_count++;
    
    // 8. Social media meta tags analysis
    $og_tags = [];
    $twitter_tags = [];
    
    // Open Graph tags
    $og_nodes = $xpath->query('//meta[starts-with(@property, "og:")]');
    foreach ($og_nodes as $node) {
        $property = $node->getAttribute('property');
        $content = $node->getAttribute('content');
        $og_tags[str_replace('og:', '', $property)] = $content;
    }
    
    // Twitter Card tags
    $twitter_nodes = $xpath->query('//meta[starts-with(@name, "twitter:")]');
    foreach ($twitter_nodes as $node) {
        $name = $node->getAttribute('name');
        $content = $node->getAttribute('content');
        $twitter_tags[str_replace('twitter:', '', $name)] = $content;
    }
    
    $social_score = 0;
    if (!empty($og_tags)) $social_score += 0.5;
    if (!empty($twitter_tags)) $social_score += 0.5;
    
    $social_status = [];
    if (!empty($og_tags)) $social_status[] = 'Open Graph tags found';
    if (!empty($twitter_tags)) $social_status[] = 'Twitter Card tags found';
    if (empty($social_status)) $social_status[] = 'No social media meta tags found';
    
    $seo_result['audits']['social-meta'] = [
        'title' => 'Page has social media meta tags',
        'score' => $social_score,
        'description' => implode(', ', $social_status),
        'details' => ['open_graph' => $og_tags, 'twitter' => $twitter_tags]
    ];
    $total_score += $social_score;
    $audit_count++;
    
    // Calculate overall SEO score
    $seo_result['score'] = $audit_count > 0 ? round(($total_score / $audit_count) * 100) : 0;
    
    return $seo_result;
}

/**
 * Perform enhanced accessibility analysis
 */
function perform_enhanced_accessibility_analysis($url) {
    $response = wp_remote_get($url, [
        'timeout' => 30,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (compatible; WordPress Website Analyzer)'
        ]
    ]);
    
    if (is_wp_error($response)) {
        // Return basic accessibility structure with default scores when request fails
        return [
            'score' => 50,
            'audits' => [
                'images' => ['title' => 'Images have alt text', 'score' => 0.5, 'description' => 'Unable to check image alt attributes'],
                'color-contrast' => ['title' => 'Background and foreground colors have sufficient contrast', 'score' => 0.5, 'description' => 'Unable to analyze color contrast'],
                'heading-order' => ['title' => 'Heading elements appear in sequentially-descending order', 'score' => 0.5, 'description' => 'Unable to check heading structure'],
                'html-has-lang' => ['title' => 'HTML element has lang attribute', 'score' => 0.5, 'description' => 'Unable to check language attributes'],
                'form-labels' => ['title' => 'Form elements have associated labels', 'score' => 0.5, 'description' => 'Unable to analyze form labels'],
                'link-text' => ['title' => 'Links have descriptive text', 'score' => 0.5, 'description' => 'Unable to check link accessibility']
            ]
        ];
    }
    
    $html = wp_remote_retrieve_body($response);
    
    $dom = new DOMDocument();
    @$dom->loadHTML($html);
    $xpath = new DOMXPath($dom);
    
    $accessibility_result = ['audits' => []];
    $total_score = 0;
    $audit_count = 0;
    
    // 1. Image alt text analysis
    $images = $xpath->query('//img');
    $images_without_alt = 0;
    $total_images = $images->length;
    
    foreach ($images as $img) {
        if (!$img->hasAttribute('alt') || empty(trim($img->getAttribute('alt')))) {
            $images_without_alt++;
        }
    }
    
    if ($total_images === 0) {
        $img_score = 1.0;
        $img_status = 'No images found on page';
    } elseif ($images_without_alt === 0) {
        $img_score = 1.0;
        $img_status = 'All images have alt attributes';
    } else {
        $img_score = max(0, 1 - ($images_without_alt / $total_images));
        $img_status = "{$images_without_alt} out of {$total_images} images missing alt text";
    }
    
    $accessibility_result['audits']['images'] = [
        'title' => 'Images have alt text',
        'score' => $img_score,
        'description' => $img_status,
        'details' => ['total' => $total_images, 'missing' => $images_without_alt]
    ];
    $total_score += $img_score;
    $audit_count++;
    
    // 2. HTML lang attribute
    $html_lang = $xpath->query('//html[@lang]');
    if ($html_lang->length > 0) {
        $lang_score = 1.0;
        $lang_status = 'HTML has lang attribute: ' . $html_lang->item(0)->getAttribute('lang');
    } else {
        $lang_score = 0.0;
        $lang_status = 'HTML element missing lang attribute';
    }
    
    $accessibility_result['audits']['html-has-lang'] = [
        'title' => 'HTML element has lang attribute',
        'score' => $lang_score,
        'description' => $lang_status
    ];
    $total_score += $lang_score;
    $audit_count++;
    
    // 3. Heading structure analysis
    $headings = [];
    $heading_issues = [];
    for ($i = 1; $i <= 6; $i++) {
        $heading_nodes = $xpath->query("//h{$i}");
        $headings[$i] = $heading_nodes->length;
    }
    
    // Check for proper heading hierarchy
    $prev_level = 0;
    $heading_score = 1.0;
    for ($i = 1; $i <= 6; $i++) {
        if ($headings[$i] > 0) {
            if ($prev_level > 0 && $i > $prev_level + 1) {
                $heading_score = 0.7;
                $heading_issues[] = "Heading level H{$i} found without H" . ($prev_level + 1);
            }
            $prev_level = $i;
        }
    }
    
    if (empty($heading_issues)) {
        $heading_status = 'Heading structure follows proper hierarchy';
    } else {
        $heading_status = 'Heading structure issues: ' . implode(', ', $heading_issues);
    }
    
    $accessibility_result['audits']['heading-order'] = [
        'title' => 'Heading elements appear in sequentially-descending order',
        'score' => $heading_score,
        'description' => $heading_status,
        'details' => $headings
    ];
    $total_score += $heading_score;
    $audit_count++;
    
    // 4. Form labels analysis
    $forms = $xpath->query('//form');
    $inputs = $xpath->query('//input[@type!="hidden" and @type!="submit" and @type!="button"] | //textarea | //select');
    $labels = $xpath->query('//label[@for] | //label[input or textarea or select]');
    
    if ($inputs->length === 0) {
        $form_score = 1.0;
        $form_status = 'No form inputs found';
    } else {
        $labeled_inputs = 0;
        foreach ($inputs as $input) {
            $input_id = $input->getAttribute('id');
            $input_name = $input->getAttribute('name');
            
            // Check for associated label
            if (!empty($input_id)) {
                $label_for_input = $xpath->query("//label[@for='{$input_id}']");
                if ($label_for_input->length > 0) {
                    $labeled_inputs++;
                    continue;
                }
            }
            
            // Check for wrapping label
            $parent_label = $xpath->query("ancestor::label", $input);
            if ($parent_label->length > 0) {
                $labeled_inputs++;
                continue;
            }
            
            // Check for aria-label or aria-labelledby
            if ($input->hasAttribute('aria-label') || $input->hasAttribute('aria-labelledby')) {
                $labeled_inputs++;
            }
        }
        
        $form_score = $inputs->length > 0 ? $labeled_inputs / $inputs->length : 1.0;
        $unlabeled = $inputs->length - $labeled_inputs;
        $form_status = $unlabeled === 0 ? 
            'All form inputs have proper labels' : 
            "{$unlabeled} out of {$inputs->length} form inputs missing labels";
    }
    
    $accessibility_result['audits']['form-labels'] = [
        'title' => 'Form elements have associated labels',
        'score' => $form_score,
        'description' => $form_status,
        'details' => ['total_inputs' => $inputs->length, 'labeled' => $labeled_inputs ?? 0]
    ];
    $total_score += $form_score;
    $audit_count++;
    
    // 5. Link text analysis
    $links = $xpath->query('//a[@href]');
    $links_with_poor_text = 0;
    $poor_link_texts = ['click here', 'read more', 'more', 'here', 'link', 'this'];
    
    foreach ($links as $link) {
        $link_text = strtolower(trim($link->textContent));
        $aria_label = strtolower(trim($link->getAttribute('aria-label')));
        $title = strtolower(trim($link->getAttribute('title')));
        
        $effective_text = !empty($aria_label) ? $aria_label : (!empty($link_text) ? $link_text : $title);
        
        if (empty($effective_text) || in_array($effective_text, $poor_link_texts) || strlen($effective_text) < 3) {
            $links_with_poor_text++;
        }
    }
    
    if ($links->length === 0) {
        $link_score = 1.0;
        $link_status = 'No links found on page';
    } else {
        $link_score = max(0, 1 - ($links_with_poor_text / $links->length));
        $link_status = $links_with_poor_text === 0 ? 
            'All links have descriptive text' : 
            "{$links_with_poor_text} out of {$links->length} links have poor or missing text";
    }
    
    $accessibility_result['audits']['link-text'] = [
        'title' => 'Links have descriptive text',
        'score' => $link_score,
        'description' => $link_status,
        'details' => ['total_links' => $links->length, 'poor_text' => $links_with_poor_text]
    ];
    $total_score += $link_score;
    $audit_count++;
    
    // 6. ARIA usage analysis
    $aria_elements = $xpath->query('//*[@aria-label or @aria-labelledby or @aria-describedby or @role]');
    $aria_score = $aria_elements->length > 0 ? 1.0 : 0.5;
    $aria_status = $aria_elements->length > 0 ? 
        "ARIA attributes found on {$aria_elements->length} elements" : 
        'No ARIA attributes detected';
    
    $accessibility_result['audits']['aria-usage'] = [
        'title' => 'ARIA attributes enhance accessibility',
        'score' => $aria_score,
        'description' => $aria_status,
        'details' => ['elements_with_aria' => $aria_elements->length]
    ];
    $total_score += $aria_score;
    $audit_count++;
    
    // Calculate overall accessibility score
    $accessibility_result['score'] = $audit_count > 0 ? round(($total_score / $audit_count) * 100) : 0;
    
    // Generate specific, actionable suggestions based on actual findings
    $accessibility_result['suggestions'] = generate_accessibility_suggestions($accessibility_result['audits']);
    
    return $accessibility_result;
}

/**
 * Generate specific accessibility suggestions based on actual audit results
 */
function generate_accessibility_suggestions($audits) {
    $suggestions = [
        'critical' => [],
        'important' => [],
        'recommended' => []
    ];
    
    foreach ($audits as $audit_key => $audit) {
        $score = $audit['score'];
        $details = $audit['details'] ?? [];
        
        if ($score < 0.5) {
            // Critical issues
            switch ($audit_key) {
                case 'images':
                    if (isset($details['missing']) && $details['missing'] > 0) {
                        $suggestions['critical'][] = "🚨 Fix {$details['missing']} images missing alt text - Critical for screen readers";
                    }
                    break;
                case 'html-has-lang':
                    $suggestions['critical'][] = "🚨 Add lang attribute to HTML element (e.g., <html lang=\"en\">) - Required for screen readers";
                    break;
                case 'form-labels':
                    if (isset($details['total_inputs']) && isset($details['labeled'])) {
                        $unlabeled = $details['total_inputs'] - $details['labeled'];
                        $suggestions['critical'][] = "🚨 Add proper labels to {$unlabeled} form inputs - Critical for form accessibility";
                    }
                    break;
                case 'link-text':
                    if (isset($details['poor_text']) && $details['poor_text'] > 0) {
                        $suggestions['critical'][] = "🚨 Improve {$details['poor_text']} links with descriptive text - Avoid 'click here', 'read more'";
                    }
                    break;
            }
        } elseif ($score < 0.9) {
            // Important improvements
            switch ($audit_key) {
                case 'heading-order':
                    if (isset($details) && is_array($details)) {
                        $suggestions['important'][] = "⚠️ Fix heading hierarchy - Ensure proper H1→H2→H3 sequence";
                    }
                    break;
                case 'images':
                    if (isset($details['missing']) && $details['missing'] > 0) {
                        $suggestions['important'][] = "⚠️ Add alt text to {$details['missing']} images for better accessibility";
                    }
                    break;
                case 'aria-usage':
                    if (isset($details['elements_with_aria']) && $details['elements_with_aria'] < 5) {
                        $suggestions['important'][] = "⚠️ Consider adding more ARIA labels for enhanced screen reader support";
                    }
                    break;
            }
        } else {
            // Recommended enhancements
            switch ($audit_key) {
                case 'aria-usage':
                    if (isset($details['elements_with_aria']) && $details['elements_with_aria'] > 0) {
                        $suggestions['recommended'][] = "✅ Good ARIA usage detected - Consider expanding to more interactive elements";
                    }
                    break;
                case 'images':
                    if ($score == 1.0) {
                        $suggestions['recommended'][] = "✅ Excellent image accessibility - All images have alt text";
                    }
                    break;
            }
        }
    }
    
    // Add general recommendations based on overall audit results
    $total_audits = count($audits);
    $passed_audits = count(array_filter($audits, function($audit) { return $audit['score'] >= 0.9; }));
    
    if ($passed_audits / $total_audits < 0.5) {
        $suggestions['critical'][] = "🚨 Multiple accessibility issues found - Consider professional accessibility audit";
    } elseif ($passed_audits / $total_audits < 0.8) {
        $suggestions['important'][] = "⚠️ Good foundation but room for improvement - Focus on critical issues first";
    } else {
        $suggestions['recommended'][] = "✅ Strong accessibility foundation - Minor enhancements will achieve full compliance";
    }
    
    return $suggestions;
}

/**
 * Perform enhanced security analysis
 */
function perform_enhanced_security_analysis($url) {
    $result = [
        'https' => strpos($url, 'https://') === 0,
        'headers' => []
    ];
    
    $response = wp_remote_get($url, ['timeout' => 20]);
    
    if (!is_wp_error($response)) {
        $headers = wp_remote_retrieve_headers($response);
        
        $security_headers = [
            'strict-transport-security' => 'HSTS',
            'content-security-policy' => 'CSP',
            'x-frame-options' => 'X-Frame-Options',
            'x-content-type-options' => 'X-Content-Type-Options',
            'x-xss-protection' => 'X-XSS-Protection',
            'referrer-policy' => 'Referrer-Policy'
        ];
        
        foreach ($security_headers as $header => $name) {
            $result['headers'][] = [
                'name' => $name,
                'present' => isset($headers[$header])
            ];
        }
    }
    
    return $result;
}

/**
 * Detect website technologies
 */
function detect_website_technologies($url) {
    $response = wp_remote_get($url, ['timeout' => 20]);
    
    if (is_wp_error($response)) {
        return [];
    }
    
    $html = wp_remote_retrieve_body($response);
    $headers = wp_remote_retrieve_headers($response);
    
    $technologies = [];
    
    // Server detection
    if (isset($headers['server'])) {
        $server = $headers['server'];
        if (stripos($server, 'apache') !== false) {
            $technologies[] = ['name' => 'Apache', 'category' => 'Web Server'];
        } elseif (stripos($server, 'nginx') !== false) {
            $technologies[] = ['name' => 'Nginx', 'category' => 'Web Server'];
        } elseif (stripos($server, 'iis') !== false) {
            $technologies[] = ['name' => 'IIS', 'category' => 'Web Server'];
        }
    }
    
    // CMS Detection
    if (stripos($html, 'wp-content') !== false || stripos($html, 'wordpress') !== false) {
        $technologies[] = ['name' => 'WordPress', 'category' => 'CMS'];
    }
    if (stripos($html, 'joomla') !== false) {
        $technologies[] = ['name' => 'Joomla', 'category' => 'CMS'];
    }
    if (stripos($html, 'drupal') !== false) {
        $technologies[] = ['name' => 'Drupal', 'category' => 'CMS'];
    }
    
    // JavaScript Libraries
    if (stripos($html, 'jquery') !== false) {
        $technologies[] = ['name' => 'jQuery', 'category' => 'JavaScript Library'];
    }
    if (stripos($html, 'react') !== false) {
        $technologies[] = ['name' => 'React', 'category' => 'JavaScript Framework'];
    }
    if (stripos($html, 'vue') !== false) {
        $technologies[] = ['name' => 'Vue.js', 'category' => 'JavaScript Framework'];
    }
    
    // CSS Frameworks
    if (stripos($html, 'bootstrap') !== false) {
        $technologies[] = ['name' => 'Bootstrap', 'category' => 'CSS Framework'];
    }
    if (stripos($html, 'tailwind') !== false) {
        $technologies[] = ['name' => 'Tailwind CSS', 'category' => 'CSS Framework'];
    }
    
    // Analytics
    if (stripos($html, 'google-analytics') !== false || stripos($html, 'gtag') !== false) {
        $technologies[] = ['name' => 'Google Analytics', 'category' => 'Analytics'];
    }
    
    return $technologies;
}

/**
 * Get demo PageSpeed data when API is not available
 */
function get_demo_pagespeed_data($url, $options) {
    // Return realistic demo data when API key is not configured
    // Debug: error_log('Getting demo data for: ' . $url . ' with options: ' . print_r($options, true));
    $demo_data = [];
    
    if ($options['analyze_mobile'] ?? false) {
        $demo_data['mobile'] = [
            'performance' => ['score' => mt_rand(65, 85)],
            'seo' => ['score' => mt_rand(80, 95)],
            'accessibility' => ['score' => mt_rand(70, 90)],
            'metrics' => [
                'first-contentful-paint' => ['displayValue' => mt_rand(15, 25) / 10 . 's', 'score' => mt_rand(60, 90) / 100],
                'largest-contentful-paint' => ['displayValue' => mt_rand(25, 45) / 10 . 's', 'score' => mt_rand(50, 80) / 100],
                'speed-index' => ['displayValue' => mt_rand(35, 55) / 10 . 's', 'score' => mt_rand(60, 85) / 100],
                'cumulative-layout-shift' => ['displayValue' => mt_rand(5, 15) / 100, 'score' => mt_rand(70, 95) / 100]
            ],
            'opportunities' => [
                ['title' => 'Optimize images', 'description' => 'Properly size images to save cellular data'],
                ['title' => 'Minify CSS', 'description' => 'Minifying CSS files can reduce network payload sizes']
            ]
        ];
    }
    
    if ($options['analyze_desktop'] ?? false) {
        $demo_data['desktop'] = [
            'performance' => ['score' => mt_rand(75, 95)],
            'seo' => ['score' => mt_rand(85, 98)],
            'accessibility' => ['score' => mt_rand(75, 95)],
            'metrics' => [
                'first-contentful-paint' => ['displayValue' => mt_rand(8, 18) / 10 . 's', 'score' => mt_rand(70, 95) / 100],
                'largest-contentful-paint' => ['displayValue' => mt_rand(15, 30) / 10 . 's', 'score' => mt_rand(65, 90) / 100],
                'speed-index' => ['displayValue' => mt_rand(18, 35) / 10 . 's', 'score' => mt_rand(70, 90) / 100],
                'cumulative-layout-shift' => ['displayValue' => mt_rand(2, 10) / 100, 'score' => mt_rand(80, 98) / 100]
            ],
            'opportunities' => [
                ['title' => 'Reduce unused CSS', 'description' => 'Reduce unused rules from stylesheets'],
                ['title' => 'Minify JavaScript', 'description' => 'Minifying JavaScript files can reduce payload sizes']
            ]
        ];
    }
    
    // Debug: error_log('Demo data result: ' . print_r($demo_data, true));
    return $demo_data;
}

/**
 * Handle PDF generation AJAX request for analyzer
 */
if (!function_exists('handle_analyzer_pdf_generation')) {
function handle_analyzer_pdf_generation() {
    try {
        // Check if required data is present
        if (!isset($_POST['nonce']) || !isset($_POST['analysis_data']) || !isset($_POST['user_email'])) {
            wp_die('Missing required data', 'Error', array('response' => 400));
        }
        
        // Verify nonce
        $nonce_verified = wp_verify_nonce($_POST['nonce'], 'pdf_generation_nonce');
        if (!$nonce_verified) {
            wp_die('Security check failed', 'Error', array('response' => 403));
        }
        
        $analysis_data = json_decode(stripslashes($_POST['analysis_data']), true);
        $user_email = sanitize_email($_POST['user_email']);
        
        if (!$analysis_data || !isset($analysis_data['url'])) {
            wp_die('Invalid analysis data', 'Error', array('response' => 400));
        }
        
        if (!is_email($user_email)) {
            wp_die('Invalid email address', 'Error', array('response' => 400));
        }
        
        // Generate PDF or HTML fallback
        $content = generate_analyzer_analysis_pdf($analysis_data);
        
        // Check if it's PDF content and save it temporarily for email attachment
        $temp_pdf_path = null;
        if (strpos($content, '<!DOCTYPE html>') === false && strpos($content, '<html>') === false) {
            // It's PDF content - save it temporarily
            $upload_dir = wp_upload_dir();
            $temp_dir = $upload_dir['basedir'] . '/salesnanny-temp-pdfs/';
            
            // Create temp directory if it doesn't exist
            if (!file_exists($temp_dir)) {
                wp_mkdir_p($temp_dir);
            }
            
            $filename = generate_analyzer_pdf_filename($analysis_data['url']);
            $temp_pdf_path = $temp_dir . $filename;
            
            // Save PDF content to temporary file
            if (file_put_contents($temp_pdf_path, $content)) {
                error_log('PDF saved temporarily for email attachment: ' . $temp_pdf_path);
            } else {
                error_log('Failed to save PDF temporarily for email attachment');
                $temp_pdf_path = null;
            }
        }
        
        // Send notification emails with PDF attachment
        send_analyzer_notification_emails($user_email, $analysis_data, $temp_pdf_path);
        
        // Check if it's HTML content (fallback) or PDF content
        if (strpos($content, '<!DOCTYPE html>') !== false || strpos($content, '<html>') !== false) {
            // HTML fallback - serve as HTML page
            $filename = generate_analyzer_pdf_filename($analysis_data['url']);
            $html_filename = str_replace('.pdf', '.html', $filename);
            
            header('Content-Type: text/html; charset=UTF-8');
            header('Content-Disposition: inline; filename="' . $html_filename . '"');
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            
            echo $content;
            exit;
        } else {
            // PDF content - serve as PDF
            $filename = generate_analyzer_pdf_filename($analysis_data['url']);
            
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . strlen($content));
            header('Cache-Control: private, max-age=0, must-revalidate');
            header('Pragma: public');
            
            echo $content;
            exit;
        }
        
    } catch (Exception $e) {
        error_log('PDF generation error: ' . $e->getMessage());
        wp_die('PDF generation failed: ' . $e->getMessage(), 'Error', array('response' => 500));
    }
}
}

/**
 * Generate PDF filename based on URL and timestamp for analyzer
 */
if (!function_exists('generate_analyzer_pdf_filename')) {
function generate_analyzer_pdf_filename($url) {
    $domain = preg_replace('/^https?:\/\//', '', $url);
    $domain = preg_replace('/[^a-zA-Z0-9\-.]/', '-', $domain);
    $domain = trim($domain, '-');
    $timestamp = date('Y-m-d-H-i-s');
    
    return "website-analysis-{$domain}-{$timestamp}.pdf";
}
}

/**
 * Generate PDF content from analysis data for analyzer
 */
if (!function_exists('generate_analyzer_analysis_pdf')) {
function generate_analyzer_analysis_pdf($data) {
    // Use our custom FPDF-based PDF generator directly
    // This avoids any issues with DomPDF or TCPDF dependencies
    return generate_simple_pdf_content($data);
}
}

/**
 * Generate HTML content for PDF - analyzer version
 */
if (!function_exists('generate_analyzer_pdf_html')) {
function generate_analyzer_pdf_html($data) {
    $url = esc_html($data['url']);
    $timestamp = isset($data['timestamp']) ? date('F j, Y \a\t g:i A', $data['timestamp']) : date('F j, Y \a\t g:i A');
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Website Analysis Report</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                margin: 0;
                padding: 20px;
            }
            .header {
                text-align: center;
                border-bottom: 3px solid #667eea;
                padding-bottom: 20px;
                margin-bottom: 30px;
            }
            .header h1 {
                color: #667eea;
                margin: 0 0 10px 0;
                font-size: 28px;
            }
            .header .url {
                font-size: 18px;
                color: #666;
                margin: 10px 0;
                word-break: break-all;
            }
            .header .timestamp {
                font-size: 14px;
                color: #888;
            }
            .section {
                margin-bottom: 40px;
                page-break-inside: avoid;
            }
            .section-title {
                color: #667eea;
                font-size: 22px;
                margin-bottom: 20px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e2e8f0;
            }
            .score-container {
                display: flex;
                align-items: center;
                margin-bottom: 20px;
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
            }
            .score-circle {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 24px;
                font-weight: bold;
                margin-right: 20px;
                flex-shrink: 0;
            }
            .score-excellent { background: #28a745; }
            .score-good { background: #17a2b8; }
            .score-average { background: #ffc107; color: #333; }
            .score-poor { background: #dc3545; }
            .score-details h3 {
                margin: 0 0 10px 0;
                color: #333;
            }
            .score-details p {
                margin: 0;
                color: #666;
            }
            .metrics-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                margin-bottom: 25px;
            }
            .metric-item {
                background: #f8fafc;
                padding: 15px;
                border-radius: 6px;
                border-left: 4px solid #667eea;
            }
            .metric-label {
                font-size: 12px;
                color: #666;
                margin-bottom: 5px;
                text-transform: uppercase;
            }
            .metric-value {
                font-size: 18px;
                font-weight: bold;
                color: #333;
            }
            .audit-item {
                background: white;
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                padding: 15px;
                margin-bottom: 10px;
                border-left: 4px solid;
            }
            .audit-pass { border-left-color: #28a745; }
            .audit-warning { border-left-color: #ffc107; }
            .audit-fail { border-left-color: #dc3545; }
            .audit-title {
                font-weight: bold;
                margin-bottom: 5px;
                color: #333;
            }
            .audit-description {
                font-size: 14px;
                color: #666;
                margin-bottom: 5px;
            }
            .audit-score {
                font-size: 12px;
                color: #888;
            }
            .opportunities {
                margin-top: 25px;
            }
            .opportunity-item {
                background: #fff8dc;
                border: 1px solid #ffc107;
                border-radius: 6px;
                padding: 15px;
                margin-bottom: 15px;
                border-left: 4px solid #ffc107;
            }
            .opportunity-title {
                font-weight: bold;
                color: #856404;
                margin-bottom: 8px;
            }
            .opportunity-description {
                font-size: 14px;
                color: #666;
                margin-bottom: 8px;
            }
            .opportunity-savings {
                font-size: 12px;
                color: #28a745;
                font-weight: bold;
            }
            .security-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 10px;
                margin-bottom: 20px;
            }
            .security-item {
                padding: 10px;
                border-radius: 4px;
                text-align: center;
                font-weight: bold;
                font-size: 12px;
            }
            .security-pass {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            .security-fail {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
            }
            .page-break {
                page-break-before: always;
            }
            .footer {
                margin-top: 40px;
                padding-top: 20px;
                border-top: 2px solid #e2e8f0;
                text-align: center;
                color: #888;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🚀 Website Analysis Report</h1>
            <div class="url">' . $url . '</div>
            <div class="timestamp">Generated on ' . $timestamp . '</div>
        </div>';

    // Performance Section
    if (isset($data['mobile']) || isset($data['desktop'])) {
        $html .= '<div class="section">
            <h2 class="section-title">⚡ Performance Analysis</h2>';
        
        foreach (['mobile' => '📱 Mobile', 'desktop' => '🖥️ Desktop'] as $device => $label) {
            if (isset($data[$device])) {
                $performance = $data[$device];
                $score = $performance['performance']['score'] ?? 0;
                $score_class = get_analyzer_pdf_score_class($score);
                
                $html .= '<h3>' . $label . ' Performance</h3>
                    <div class="score-container">
                        <div class="score-circle ' . $score_class . '">' . $score . '</div>
                        <div class="score-details">
                            <h3>Performance Score: ' . $score . '%</h3>
                            <p>' . get_analyzer_pdf_score_description($score) . '</p>
                        </div>
                    </div>';
                
                // Core Web Vitals
                if (isset($performance['metrics'])) {
                    $html .= '<h4>Core Web Vitals & Metrics</h4>
                        <div class="metrics-grid">';
                    
                    foreach ($performance['metrics'] as $metric_key => $metric) {
                        $metric_name = ucwords(str_replace('-', ' ', $metric_key));
                        $html .= '<div class="metric-item">
                            <div class="metric-label">' . $metric_name . '</div>
                            <div class="metric-value">' . ($metric['displayValue'] ?? 'N/A') . '</div>
                        </div>';
                    }
                    
                    $html .= '</div>';
                }
                
                // Opportunities
                if (isset($performance['opportunities']) && !empty($performance['opportunities'])) {
                    $html .= '<div class="opportunities">
                        <h4>🚀 Optimization Opportunities</h4>';
                    
                    foreach (array_slice($performance['opportunities'], 0, 5) as $opp) {
                        $savings_text = '';
                        if (isset($opp['savings'])) {
                            $savings_parts = [];
                            if (!empty($opp['savings']['time'])) $savings_parts[] = 'Time: ' . $opp['savings']['time'];
                            if (!empty($opp['savings']['size'])) $savings_parts[] = 'Size: ' . $opp['savings']['size'];
                            if (!empty($savings_parts)) {
                                $savings_text = '<div class="opportunity-savings">Potential savings: ' . implode(', ', $savings_parts) . '</div>';
                            }
                        }
                        
                        $html .= '<div class="opportunity-item">
                            <div class="opportunity-title">' . esc_html($opp['title']) . '</div>
                            <div class="opportunity-description">' . esc_html($opp['description']) . '</div>
                            ' . $savings_text . '
                        </div>';
                    }
                    
                    $html .= '</div>';
                }
            }
        }
        
        $html .= '</div>';
    }

    // SEO Section
    if (isset($data['seo'])) {
        $seo = $data['seo'];
        $seo_score = $seo['score'] ?? 0;
        $seo_score_class = get_analyzer_pdf_score_class($seo_score);
        
        $html .= '<div class="section page-break">
            <h2 class="section-title">🔍 SEO Analysis</h2>
            <div class="score-container">
                <div class="score-circle ' . $seo_score_class . '">' . $seo_score . '</div>
                <div class="score-details">
                    <h3>SEO Score: ' . $seo_score . '%</h3>
                    <p>' . get_analyzer_pdf_seo_score_description($seo_score) . '</p>
                </div>
            </div>';
        
        if (isset($seo['audits'])) {
            $html .= '<h4>📋 SEO Audit Results</h4>';
            
            foreach ($seo['audits'] as $audit_key => $audit) {
                $audit_class = get_analyzer_pdf_audit_class($audit['score']);
                $percentage = round($audit['score'] * 100);
                
                $html .= '<div class="audit-item ' . $audit_class . '">
                    <div class="audit-title">' . esc_html($audit['title']) . '</div>
                    <div class="audit-description">' . esc_html($audit['description']) . '</div>
                    <div class="audit-score">Score: ' . $percentage . '%</div>
                </div>';
            }
        }
        
        $html .= '</div>';
    }

    // Accessibility Section
    if (isset($data['accessibility'])) {
        $accessibility = $data['accessibility'];
        $acc_score = $accessibility['score'] ?? 0;
        $acc_score_class = get_analyzer_pdf_score_class($acc_score);
        
        $html .= '<div class="section page-break">
            <h2 class="section-title">♿ Accessibility Analysis</h2>
            <div class="score-container">
                <div class="score-circle ' . $acc_score_class . '">' . $acc_score . '</div>
                <div class="score-details">
                    <h3>Accessibility Score: ' . $acc_score . '%</h3>
                    <p>' . get_analyzer_pdf_accessibility_score_description($acc_score) . '</p>
                </div>
            </div>';
        
        if (isset($accessibility['audits'])) {
            $html .= '<h4>♿ WCAG Compliance Checklist</h4>';
            
            foreach ($accessibility['audits'] as $audit_key => $audit) {
                $audit_class = get_analyzer_pdf_audit_class($audit['score']);
                $percentage = round($audit['score'] * 100);
                
                $html .= '<div class="audit-item ' . $audit_class . '">
                    <div class="audit-title">' . esc_html($audit['title']) . '</div>
                    <div class="audit-description">' . esc_html($audit['description']) . '</div>
                    <div class="audit-score">Score: ' . $percentage . '%</div>
                </div>';
            }
        }
        
        $html .= '</div>';
    }

    // Security Section
    if (isset($data['security'])) {
        $security = $data['security'];
        
        $html .= '<div class="section">
            <h2 class="section-title">🛡️ Security Analysis</h2>
            <div class="security-grid">';
        
        // HTTPS Status
        $html .= '<div class="security-item ' . ($security['https'] ? 'security-pass' : 'security-fail') . '">
            HTTPS ' . ($security['https'] ? 'Enabled' : 'Not Enabled') . '
        </div>';
        
        // Security Headers
        if (isset($security['headers'])) {
            foreach ($security['headers'] as $header) {
                $html .= '<div class="security-item ' . ($header['present'] ? 'security-pass' : 'security-fail') . '">
                    ' . esc_html($header['name']) . '
                </div>';
            }
        }
        
        $html .= '</div></div>';
    }

    $html .= '<div class="footer">
        <p>This report was generated by Website Performance Analyzer</p>
        <p>For more detailed analysis and recommendations, visit our website</p>
    </div>

    </body>
    </html>';

    return $html;
}
}

/**
 * Get PDF score class for styling - analyzer version
 */
if (!function_exists('get_analyzer_pdf_score_class')) {
function get_analyzer_pdf_score_class($score) {
    if ($score >= 90) return 'score-excellent';
    if ($score >= 70) return 'score-good';
    if ($score >= 50) return 'score-average';
    return 'score-poor';
}
}

/**
 * Get PDF audit class for styling - analyzer version
 */
if (!function_exists('get_analyzer_pdf_audit_class')) {
function get_analyzer_pdf_audit_class($score) {
    if ($score >= 0.9) return 'audit-pass';
    if ($score >= 0.5) return 'audit-warning';
    return 'audit-fail';
}
}

/**
 * Get score description for PDF - analyzer version
 */
if (!function_exists('get_analyzer_pdf_score_description')) {
function get_analyzer_pdf_score_description($score) {
    if ($score >= 90) return 'Excellent performance! Your site loads quickly and provides a great user experience.';
    if ($score >= 70) return 'Good performance with room for improvement.';
    if ($score >= 50) return 'Average performance that needs optimization.';
    return 'Poor performance requiring immediate attention.';
}
}

/**
 * Get SEO score description for PDF - analyzer version
 */
if (!function_exists('get_analyzer_pdf_seo_score_description')) {
function get_analyzer_pdf_seo_score_description($score) {
    if ($score >= 90) return 'Excellent SEO optimization! Your page follows most best practices.';
    if ($score >= 70) return 'Good SEO foundation with room for improvement.';
    if ($score >= 50) return 'Basic SEO present but needs significant optimization.';
    return 'Poor SEO - immediate attention required for better search visibility.';
}
}

/**
 * Get accessibility score description for PDF - analyzer version
 */
if (!function_exists('get_analyzer_pdf_accessibility_score_description')) {
function get_analyzer_pdf_accessibility_score_description($score) {
    if ($score >= 90) return 'Excellent accessibility! Your site is highly usable for people with disabilities.';
    if ($score >= 70) return 'Good accessibility foundation with some areas for improvement.';
    if ($score >= 50) return 'Basic accessibility present but significant improvements needed.';
    return 'Poor accessibility - immediate attention required for WCAG compliance.';
}
}

/**
 * Generate PDF using DomPDF with SalesNanny branding
 */
if (!function_exists('generate_pdf_with_dompdf')) {
function generate_pdf_with_dompdf($data) {
    // Configure DomPDF options
    $options = new \Dompdf\Options();
    $options->set('defaultFont', 'Arial');
    $options->set('isRemoteEnabled', true);
    $options->set('isHtml5ParserEnabled', true);
    
    // Initialize DomPDF
    $dompdf = new \Dompdf\Dompdf($options);
    
    // Generate HTML content for PDF with branding
    $html = generate_branded_pdf_html($data);
    
    // Load HTML into DomPDF
    $dompdf->loadHtml($html);
    
    // Set paper size and orientation
    $dompdf->setPaper('A4', 'portrait');
    
    // Render PDF
    $dompdf->render();
    
    // Return PDF content
    return $dompdf->output();
}
}

/**
 * Generate PDF using TCPDF with SalesNanny branding
 */
if (!function_exists('generate_pdf_with_tcpdf')) {
function generate_pdf_with_tcpdf($data) {
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    
    // Set document information
    $pdf->SetCreator('SalesNanny');
    $pdf->SetAuthor('SalesNanny Website Analyzer');
    $pdf->SetTitle('Website Analysis Report');
    $pdf->SetSubject('Website Performance Analysis');
    
    // Set default header data
    $pdf->SetHeaderData('', 0, 'SalesNanny Website Analysis Report', $data['url']);
    
    // Set header and footer fonts
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    
    // Set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
    
    // Set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    
    // Set auto page breaks
    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
    
    // Add a page
    $pdf->AddPage();
    
    // Add SalesNanny logo and branding
    $pdf->SetFont('helvetica', 'B', 20);
    $pdf->Cell(0, 15, 'SalesNanny Website Analysis Report', 0, 1, 'C');
    
    // Add website URL
    $pdf->SetFont('helvetica', '', 14);
    $pdf->Cell(0, 10, 'Website: ' . $data['url'], 0, 1, 'C');
    $pdf->Cell(0, 10, 'Generated: ' . date('F j, Y \a\t g:i A'), 0, 1, 'C');
    $pdf->Ln(10);
    
    // Add content sections
    add_tcpdf_content_sections($pdf, $data);
    
    // Add footer page with website link
    $pdf->AddPage();
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 15, 'Thank You for Using SalesNanny!', 0, 1, 'C');
    $pdf->Ln(10);
    
    $pdf->SetFont('helvetica', '', 12);
    $pdf->Cell(0, 10, 'For more website analysis tools and services, visit:', 0, 1, 'C');
    $pdf->SetFont('helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'https://salesnanny.com', 0, 1, 'C');
    
    return $pdf->Output('', 'S');
}
}

/**
 * Generate simple PDF content when no PDF library is available
 */
if (!function_exists('generate_simple_pdf_content')) {
function generate_simple_pdf_content($data) {
    // Create a basic PDF structure using PHP
    $pdf_content = create_basic_pdf_structure($data);
    return $pdf_content;
}
}

/**
 * Generate HTML report fallback when PDF is not available
 */
if (!function_exists('generate_html_report_fallback')) {
function generate_html_report_fallback($data) {
    // Generate HTML content
    $html = generate_analyzer_pdf_html($data);
    
    // Instead of saving to file, return HTML content directly for download
    $html_with_download_styling = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Website Analysis Report</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
            .download-notice { 
                background: #e7f3ff; 
                border: 1px solid #b3d9ff; 
                padding: 15px; 
                border-radius: 5px; 
                margin-bottom: 20px;
                text-align: center;
            }
            .download-notice h3 { color: #0066cc; margin-top: 0; }
            .download-buttons { text-align: center; margin: 20px 0; }
            .btn { 
                display: inline-block; 
                padding: 10px 20px; 
                margin: 0 10px; 
                background: #0066cc; 
                color: white; 
                text-decoration: none; 
                border-radius: 5px; 
            }
            .btn:hover { background: #0052a3; }
            @media print { .download-notice, .download-buttons { display: none; } }
        </style>
        <script>
            function printReport() {
                window.print();
            }
        </script>
    </head>
    <body>
        <div class="download-notice">
            <h3>📄 Website Analysis Report</h3>
            <p><strong>Note:</strong> PDF generation requires additional setup. You can print this page to save as PDF.</p>
            <div class="download-buttons">
                <a href="#" class="btn" onclick="printReport(); return false;">🖨️ Print to PDF</a>
            </div>
        </div>
        ' . str_replace(['<!DOCTYPE html>', '<html>', '</html>', '<head>', '</head>', '<body>', '</body>'], '', $html) . '
    </body>
    </html>';
    
    return $html_with_download_styling;
}
}

/**
 * Generate branded HTML content for PDF
 */
if (!function_exists('generate_branded_pdf_html')) {
function generate_branded_pdf_html($data) {
    $url = esc_html($data['url']);
    $timestamp = isset($data['timestamp']) ? date('F j, Y \a\t g:i A', $data['timestamp']) : date('F j, Y \a\t g:i A');
    
    $html = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>SalesNanny Website Analysis Report</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                margin: 0;
                padding: 20px;
            }
            .cover-page {
                text-align: center;
                padding: 100px 20px;
                page-break-after: always;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                margin: -20px;
                padding: 150px 20px;
            }
            .logo-container {
                margin-bottom: 40px;
            }
            .logo-text {
                font-size: 48px;
                font-weight: bold;
                color: white;
                text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
                margin-bottom: 10px;
            }
            .logo-subtitle {
                font-size: 18px;
                opacity: 0.9;
                margin-bottom: 40px;
            }
            .cover-title {
                font-size: 36px;
                font-weight: bold;
                margin-bottom: 20px;
            }
            .cover-subtitle {
                font-size: 18px;
                margin-bottom: 10px;
                opacity: 0.9;
            }
            .cover-url {
                font-size: 24px;
                margin: 30px 0;
                background: rgba(255,255,255,0.2);
                padding: 15px;
                border-radius: 8px;
                word-break: break-all;
            }
            .cover-date {
                font-size: 14px;
                opacity: 0.8;
            }
            .header {
                text-align: center;
                border-bottom: 3px solid #667eea;
                padding-bottom: 20px;
                margin-bottom: 30px;
            }
            .header h1 {
                color: #667eea;
                margin: 0 0 10px 0;
                font-size: 28px;
            }
            .section {
                margin-bottom: 40px;
                page-break-inside: avoid;
            }
            .section-title {
                color: #667eea;
                font-size: 22px;
                margin-bottom: 20px;
                padding-bottom: 10px;
                border-bottom: 2px solid #e2e8f0;
            }
            .score-container {
                display: flex;
                align-items: center;
                margin-bottom: 20px;
                background: #f8fafc;
                padding: 20px;
                border-radius: 8px;
            }
            .score-circle {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 24px;
                font-weight: bold;
                margin-right: 20px;
                flex-shrink: 0;
            }
            .score-excellent { background: #28a745; }
            .score-good { background: #17a2b8; }
            .score-average { background: #ffc107; color: #333; }
            .score-poor { background: #dc3545; }
            .footer-page {
                page-break-before: always;
                text-align: center;
                padding: 100px 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                margin: -20px;
            }
            .footer-title {
                font-size: 36px;
                font-weight: bold;
                margin-bottom: 30px;
            }
            .footer-text {
                font-size: 18px;
                margin-bottom: 20px;
                opacity: 0.9;
            }
            .footer-website {
                font-size: 28px;
                font-weight: bold;
                background: rgba(255,255,255,0.2);
                padding: 20px;
                border-radius: 8px;
                margin: 40px 0;
            }
            .footer-contact {
                font-size: 16px;
                opacity: 0.8;
                margin-top: 40px;
            }
        </style>
    </head>
    <body>
        <!-- Cover Page -->
        <div class="cover-page">
            <div class="logo-container">
                <div class="logo-text">SalesNanny</div>
                <div class="logo-subtitle">Professional Website Analyzer</div>
            </div>
            <div class="cover-title">Website Analysis Report</div>
            <div class="cover-subtitle">Comprehensive Performance & SEO Analysis</div>
            <div class="cover-url">' . $url . '</div>
            <div class="cover-date">Generated on ' . $timestamp . '</div>
        </div>
        
        <!-- Report Content -->';

    // Add the same content sections as the original function
    $html .= generate_analyzer_pdf_html($data);

    // Footer page
    $html .= '
        <div class="footer-page">
            <div class="footer-title">Thank You for Using SalesNanny!</div>
            <div class="footer-text">Your trusted partner for website analysis and optimization</div>
            <div class="footer-website">https://salesnanny.com</div>
            <div class="footer-text">
                For more website analysis tools, SEO services, and digital marketing solutions
            </div>
            <div class="footer-contact">
                Contact us for professional website optimization services<br>
                Email: contact@salesnanny.com | Website: https://salesnanny.com
            </div>
        </div>

    </body>
    </html>';

    return $html;
}
}

/**
 * Create basic PDF structure when no PDF library is available
 */
if (!function_exists('create_basic_pdf_structure')) {
function create_basic_pdf_structure($data) {
    // Include our simple PDF generator
    require_once get_template_directory() . '/simple-pdf-generator.php';
    
    // Generate PDF using our simple generator
    return generate_salesnanny_pdf($data);
}
}

/**
 * Configure WordPress mail settings for better delivery with SMTP
 */
if (!function_exists('configure_analyzer_mail_settings')) {
function configure_analyzer_mail_settings() {
    // Set content type to HTML
    add_filter('wp_mail_content_type', function() {
        return 'text/html';
    });
    
    // Set from email and name
    add_filter('wp_mail_from', function($from_email) {
        return 'team@salesnanny.com';
    });
    
    add_filter('wp_mail_from_name', function($from_name) {
        return 'SalesNanny';
    });
    
    // Configure SMTP settings for wp_mail
    add_action('phpmailer_init', function($phpmailer) {
        // Load SMTP configuration
        $smtp_config_file = get_template_directory() . '/smtp-config.php';
        if (file_exists($smtp_config_file)) {
            require_once $smtp_config_file;
        }
        
        // Only configure SMTP if credentials are available
        if (defined('SMTP_USERNAME') && defined('SMTP_PASSWORD') && 
            SMTP_PASSWORD !== 'your-16-character-app-password' &&
            strlen(SMTP_PASSWORD) > 10) {
            
            $phpmailer->isSMTP();
            $phpmailer->Host = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $phpmailer->SMTPAuth = true;
            $phpmailer->Port = defined('SMTP_PORT') ? SMTP_PORT : 587;
            $phpmailer->SMTPSecure = defined('SMTP_SECURE') ? SMTP_SECURE : 'tls';
            $phpmailer->Username = SMTP_USERNAME;
            $phpmailer->Password = SMTP_PASSWORD;
            
            // Enable debug output for testing
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $phpmailer->SMTPDebug = 1;
            }
        }
    });
}
}

/**
 * Send notification emails for analyzer PDF downloads
 */
if (!function_exists('send_analyzer_notification_emails')) {
function send_analyzer_notification_emails($user_email, $analysis_data, $pdf_attachment_path = null) {
    // Configure mail settings
    configure_analyzer_mail_settings();
    $website_url = $analysis_data['url'];
    $timestamp = date('F j, Y \a\t g:i A');
    
    // Email to user (confirmation)
    $user_subject = 'Your SalesNanny Website Analysis Report is Ready!';
    $user_message = "
    <html>
    <head>
        <title>Your Website Analysis Report</title>
    </head>
    <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
        <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='background: linear-gradient(135deg, #1e2154 0%, #c22034 100%); color: white; padding: 30px; border-radius: 10px; text-align: center; margin-bottom: 30px;'>
                <h1 style='margin: 0; font-size: 28px;'>SalesNanny</h1>
                <p style='margin: 10px 0 0 0; font-size: 16px;'>Professional Website Analyzer</p>
            </div>
            
            <h2 style='color: #1e2154;'>Your Website Analysis is Complete!</h2>
            
            <p>Hello!</p>
            
            <p>Thank you for using SalesNanny's Website Analyzer. Your comprehensive analysis report for <strong style='color: #c22034;'>{$website_url}</strong> has been generated and is attached to this email.</p>
            
            <div style='background: #fef4f4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #c22034;'>
                <h3 style='color: #1e2154; margin-top: 0;'>📊 Your Report Includes:</h3>
                <ul style='margin: 0; padding-left: 20px;'>
                    <li>⚡ <strong>Performance Analysis</strong> - Mobile & Desktop scores with Core Web Vitals</li>
                    <li>🔍 <strong>SEO Optimization</strong> - Complete meta tags and structured data analysis</li>
                    <li>🛡️ <strong>Security Assessment</strong> - HTTPS status and security headers check</li>
                    <li>♿ <strong>Accessibility Evaluation</strong> - WCAG compliance and usability insights</li>
                </ul>
            </div>
            
            <p><strong>Generated on:</strong> {$timestamp}</p>
            
            <div style='text-align: center; margin: 30px 0;'>
                <a href='https://salesnanny.com' style='background: #c22034; color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; display: inline-block; font-weight: bold;'>Visit SalesNanny →</a>
            </div>
            
            <p>Need help improving your website's performance? Our team of experts is here to help you optimize your site for better search rankings and user experience.</p>
            
            <hr style='border: none; border-top: 1px solid #eee; margin: 30px 0;'>
            
            <div style='text-align: center; color: #666; font-size: 14px;'>
                <p><strong>SalesNanny</strong><br>
                Professional Website Analysis & SEO Services<br>
                <a href='https://salesnanny.com' style='color: #c22034;'>https://salesnanny.com</a> | 
                <a href='mailto:team@salesnanny.com' style='color: #c22034;'>team@salesnanny.com</a></p>
            </div>
        </div>
    </body>
    </html>";
    
    // Email headers for user
    $user_headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: SalesNanny <team@salesnanny.com>',
        'Reply-To: team@salesnanny.com'
    );
    
    // Add PDF attachment if available
    $attachments = array();
    if ($pdf_attachment_path && file_exists($pdf_attachment_path)) {
        $attachments[] = $pdf_attachment_path;
        error_log('PDF attachment added to email: ' . $pdf_attachment_path);
    }
    
    // Send email to user with attachment
    $user_sent = wp_mail($user_email, $user_subject, $user_message, $user_headers, $attachments);
    if (!$user_sent) {
        error_log('WordPress mail failed for user email. Trying PHP mail() function...');
        // Fallback to PHP mail function
        $user_sent = send_email_fallback($user_email, $user_subject, $user_message);
        if (!$user_sent) {
            error_log('Failed to send user confirmation email to: ' . $user_email . ' (both wp_mail and PHP mail failed)');
        } else {
            error_log('User confirmation email sent successfully via PHP mail() to: ' . $user_email);
        }
    } else {
        error_log('User confirmation email sent successfully to: ' . $user_email);
    }
    
    // Clean up temporary PDF file if it was created
    if ($pdf_attachment_path && file_exists($pdf_attachment_path)) {
        if (unlink($pdf_attachment_path)) {
            error_log('Temporary PDF file cleaned up: ' . $pdf_attachment_path);
        } else {
            error_log('Failed to clean up temporary PDF file: ' . $pdf_attachment_path);
        }
    }
    
    // Email to admin (notification)
    $admin_email = 'team@salesnanny.com'; // Your notification email
    $admin_subject = '📊 New Website Analysis Download - SalesNanny';
    $admin_message = "
    <html>
    <head>
        <title>New Website Analysis Download</title>
    </head>
    <body style='font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
        <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
            <div style='background: #1e2154; color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;'>
                <h2 style='margin: 0;'>📊 New Website Analysis Download</h2>
            </div>
            
            <p><strong>A user has downloaded a website analysis report from SalesNanny.</strong></p>
            
            <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>
                <h3 style='color: #1e2154; margin-top: 0;'>Download Details:</h3>
                <p><strong>Website Analyzed:</strong> <span style='color: #c22034;'>{$website_url}</span></p>
                <p><strong>User Email:</strong> <span style='color: #c22034;'>{$user_email}</span></p>
                <p><strong>Download Time:</strong> {$timestamp}</p>
                <p><strong>User IP:</strong> " . $_SERVER['REMOTE_ADDR'] . "</p>
            </div>
            
            <p>This user might be interested in your website optimization services. Consider following up with them!</p>
            
            <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
            <p style='font-size: 14px; color: #666;'>This is an automated notification from SalesNanny Website Analyzer.</p>
        </div>
    </body>
    </html>";
    
    // Email headers for admin
    $admin_headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: SalesNanny Analyzer <noreply@salesnanny.com>',
        'Reply-To: ' . $user_email
    );
    
    // Send email to admin
    $admin_sent = wp_mail($admin_email, $admin_subject, $admin_message, $admin_headers);
    if (!$admin_sent) {
        error_log('WordPress mail failed for admin email. Trying PHP mail() function...');
        // Fallback to PHP mail function
        $admin_sent = send_email_fallback($admin_email, $admin_subject, $admin_message);
        if (!$admin_sent) {
            error_log('Failed to send admin notification email to: ' . $admin_email . ' (both wp_mail and PHP mail failed)');
        } else {
            error_log('Admin notification email sent successfully via PHP mail() to: ' . $admin_email);
        }
    } else {
        error_log('Admin notification email sent successfully to: ' . $admin_email);
    }
}
}

/**
 * Fallback email function using PHP mail()
 */
if (!function_exists('send_email_fallback')) {
function send_email_fallback($to, $subject, $message) {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: SalesNanny <team@salesnanny.com>" . "\r\n";
    $headers .= "Reply-To: team@salesnanny.com" . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}
}
