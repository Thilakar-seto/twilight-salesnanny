<?php
   /*
   Template Name: Home
   */
?>
<html lang="en-US">
   <?php get_custom_head(); ?>
   <?php salesnanny_side_panel(); ?>
   <body>
        <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/home.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
        <noscript>
         <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/home.noncritical.css"/>
        </noscript>
      <div>
        <style>
            .customers-grid,.hero-section,.marketing-team-section,.redefining-work-section,.reliable-grid,.reliable-section,.sn-departments-section,.sn-pricing-section,.sn-waywork-section,.stats-grid,.stats-section,.success-grid,.success-stories{max-width:1300px;margin:0 auto;width:100%}.container,.redefining-container,.reliable-container,.sn-container,.sn-waywork-container,.stats-container,.success-container,.team-container{max-width:1300px;margin:0 auto;width:100%;padding:0 20px}@media (max-width:1300px){.hero-section,.marketing-team-section,.redefining-work-section,.reliable-section,.sn-departments-section,.sn-pricing-section,.sn-waywork-section,.stats-section,.success-stories{max-width:100%;padding:0 20px}}.container,.hero-section{max-width:1300px;width:100%}.redefining-tab,.sn-tab-button{font-family:inherit;text-transform:none;letter-spacing:normal}.btn,.container,.customer-card,.customer-count,.customer-link,.customer-text,.customers-grid,.hero-image,.hero-image img,.hero-section,.main-title,.marketing-team-section,.price-tag,.pricing-card,.pricing-content,.pricing-header,.pricing-section,.pricing-title,.reviews-row,.star-icon,.stat-item,.stat-label,.stat-number,.stats-card,.stats-section,.stats-text,.team-container,.team-cta,.team-header,.team-illustration,.video-name{position:relative}.hero-section::after,.hero-section::before{background-color:rgba(194,32,52,.1);border-radius:50%;z-index:0;position:absolute;content:""}.btn,.hero-section{transition:.3s;overflow:hidden}.customers-grid,.reliable-grid,.stats-grid{grid-template-columns:repeat(3,1fr)}.redefining-tab,.zn-tab-button{white-space:nowrap;cursor:pointer}.btn,.customer-link,.speak-expert-btn,.success-link,.zn-learn-more{text-decoration:none}.hero-section{padding:60px 0;background:#fff;margin:80px auto 0;min-height:600px;position:relative}.hero-section::before{top:-50px;right:-50px;width:200px;display:none;height:200px;animation:15s ease-in-out infinite floatBubble}.hero-section::after{bottom:-50px;left:-50px;width:180px;display:none;height:180px;animation:18s ease-in-out infinite reverse floatBubble}.container{display:flex;flex-direction:column;margin:0 auto;padding:0 20px;box-sizing:border-box}.main-title{font-size:60px;font-weight:700;line-height:1.2;margin-bottom:20px;color:#1e2154;display:inline-block}.main-title::after{content:"";position:absolute;bottom:-10px;left:0;width:60px;height:3px;background:linear-gradient(to right,#1e2154,#7f7f7f);transition:width .4s}.btn::before,.hero-image::after,.marketing-team-section::before{height:100%;position:absolute;width:100%}.hero-description{font-size:20px;line-height:1.6;color:#787878;margin-bottom:30px;max-width:900px;text-align:justify;margin-top:30px;font-weight:500}.cta-buttons{display:flex;gap:15px;margin-top:25px}.btn{padding:.875rem 1.5rem;font-size:16px;font-weight:600;border-radius:4px}.btn-primary,.btn-secondary{border-radius:4px;cursor:pointer;background:#c22034;color:#fff}.btn::before{content:"";top:0;display:none;left:-100%;background:linear-gradient(to right,rgba(255,255,255,0),rgba(255,255,255,.2),rgba(255,255,255,0));transition:left .7s}.hero-content{flex:1;order:1;opacity:1;transform:none;margin:0 auto;text-align:center;width:60%;min-height:300px}.hero-image,.hero-image img{max-width:100%}.hero-image{display:flex;justify-content:center;align-items:center;z-index:1;order:2;margin-top:40px;opacity:1;transform:none;width:40%;aspect-ratio:1}.hero-image img{width:100%;height:auto;max-height:470px;object-fit:contain;z-index:1;display:block;transition:.4s}@media (min-width:992px){.container{flex-direction:row;align-items:center;justify-content:space-between;gap:40px}.hero-content{order:1;text-align:left;padding-right:40px;width:60%}.hero-image{order:2;margin-top:0;width:40%}}@media (max-width:991px){.hero-content{width:100%;min-height:auto}.hero-image{width:100%;max-width:500px;margin:40px auto 0}}.customer-card,.reliable-title,.sn-app-icon,.sn-panel-image,.sn-pricing-title,.stats-grid,.team-cta,.team-description,.team-header,.zn-title{text-align:center}.hero-image::after{content:"";top:20px;left:20px;border-radius:4px;z-index:-1}.marketing-team-section{padding:40px;overflow:hidden}.marketing-team-section::after{content:"";position:absolute;top:10%;right:5%;width:300px;height:300px;display:none;background-color:rgba(194,32,52,.1);border-radius:30% 70% 70% 30%/30% 30% 70% 70%;z-index:0;animation:15s ease-in-out infinite alternate morphShape}.team-cta::before,.team-illustration::after{content:"";position:absolute;z-index:-1;top:-10px}.team-container{max-width:1200px;margin:0 auto;display:flex;flex-direction:column;align-items:center}.team-header{margin-bottom:clamp(30px,5vw,60px);width:100%}.team-header::after{content:"";position:absolute;bottom:-15px;left:50%;transform:translateX(-50%);width:80px;height:3px;background:linear-gradient(to right,#1e2154,#7f7f7f);border-radius:3px;transition:width .3s}.team-title{font-size:54px;font-weight:700;line-height:1.2;margin-bottom:.5rem;color:#1e2154}.rating-box,.team-description p,.team-subtitle{color:#7f7f7f}.team-subtitle{font-size:1.8rem;font-weight:500;color:#787878}.team-description p{font-size:1.125rem;font-size:clamp(1rem, 1.5vw, 1.2rem);line-height:1.6;color:#fff}.customer-link,.role-tag{font-size:.875rem;font-weight:600}.team-image{width:100%;height:auto;display:block;margin-bottom:40px;border-radius:10px}.team-illustration::after{display:none;left:-10px;right:-10px;bottom:-10px;border-radius:20px;background:linear-gradient(135deg,rgba(30,33,84,.05),rgba(127,127,127,.05));animation:3s ease-in-out infinite pulse}.team-roles-mobile{display:none;flex-wrap:wrap;justify-content:center;gap:10px;margin-top:20px}.team-description{max-width:800px;padding:20px;background-color:#c22034;border-radius:10px;border-left:3px solid #1e2154;box-shadow:0 5px 15px rgba(0,0,0,.03);opacity:0;animation:.8s ease-out .7s forwards fadeInUp}.stats-section::after,.stats-section::before{content:""}.cta-button::before,.speak-expert-btn::before{content:"";position:absolute;top:0;display:none;left:-100%;width:100%;height:100%;background:linear-gradient(to right,rgba(255,255,255,0),rgba(255,255,255,.3),rgba(255,255,255,0));transition:left .7s}.stats-section::before{top:-100px;right:-100px;width:300px;height:300px;background-color:rgba(194,32,52,.1);animation:18s ease-in-out infinite floatBubble}.stats-section::after{bottom:-80px;left:-80px;width:250px;height:250px;background-color:rgba(127,127,127,.04);animation:15s ease-in-out infinite reverse floatBubble}.pricing-container,.redefining-container,.reliable-container,.stats-container,.success-container,.zn-container{max-width:1250px;margin:0 auto;position:relative;z-index:1}.reviews-row,.stats-grid{margin-bottom:2rem;text-align:center}.customers-grid::before,.stat-item::after,.stat-item::before,.stat-number::after{content:"";position:absolute}.review-platforms{display:inline-flex;gap:.8rem;margin-left:1rem}.platform-icon{object-fit:contain;transition:.3s}.reliable-grid,.stats-grid{display:grid;gap:2rem}.stat-item{display:flex;flex-direction:column;align-items:center;padding:2rem;border-radius:10px;background:linear-gradient(135deg,#fff,rgba(30,33,84,.02));transition:.3s;overflow:hidden}.stat-item::after{bottom:-20px;right:-20px;width:80px;height:80px;border-radius:50%;z-index:0}.stat-number::after{bottom:-5px;left:50%;transform:translateX(-50%);width:40px;height:2px;background:linear-gradient(to right,#1e2154,#7f7f7f);transition:width .3s}.stat-label{z-index:1}.customer-card,.customer-link,.sn-department-tabs .sn-tab-button{transition:.3s}.customer-link svg,.play-button svg,.redefining-tab svg,.stats-author svg,.video-info,.zn-learn-more-icon{transition:transform .3s}.customers-grid{display:flex;justify-content:center;align-items:center;padding:1rem 0;max-width:1200px;margin:0 auto}.customers-grid::before{top:50%;left:33%;right:33%;height:1px;background:linear-gradient(90deg,rgba(127,127,127,0),rgba(127,127,127,.2),rgba(127,127,127,0));z-index:0}.customer-card{grid-column:2;box-shadow:0 10px 30px rgba(30,33,84,.2)}.customer-card::before{content:"";position:absolute;top:0;left:0;width:100%;height:100%;background-image:radial-gradient(circle at 90% 10%,rgba(255,255,255,.1) 0,transparent 30%),radial-gradient(circle at 10% 90%,rgba(255,255,255,.05) 0,transparent 30%);opacity:.4;z-index:0}.customer-link{display:inline-flex;align-items:center;gap:.5rem;padding:8px 16px;border-radius:20px;background-color:rgba(255,255,255,.1)}.customer-card,.customer-logo,.ease-content,.ease-title,.icon-grid-wrapper,.pricing-card,.pricing-title,.redefining-content,.redefining-cta,.redefining-tabs,.redefining-title,.reliable-card,.reliable-title,.reviews-row,.stat-item,.stats-card,.success-link,.success-title,.video-card,.zn-tabs-container,.zn-title{opacity:0;animation:.8s ease-out forwards fadeInUp}.ease-title,.redefining-title,.reviews-row,.success-title,.zn-title{animation-delay:.1s}.reliable-card:first-child,.stat-item:first-child,.success-link{animation-delay:.2s}.ease-content,.feature-item:first-child,.redefining-tabs,.stat-item:nth-child(2),.video-card:first-child,.zn-tabs-container{animation-delay:.3s}.feature-item:nth-child(2),.reliable-card:nth-child(2),.stat-item:nth-child(3){animation-delay:.4s}.customer-card,.feature-item:nth-child(3),.icon-grid-wrapper,.redefining-content,.stats-card{animation-delay:.5s}.redefining-description,.redefining-tab svg,.zn-content-wrapper,.zn-dashboard-image{z-index:1;position:relative}.redefining-tab::before,.redefining-work-section::after,.redefining-work-section::before,.zn-content-right::before,.zn-tab-content::before{z-index:0;position:absolute;content:""}.redefining-cta,.redefining-title{text-align:center;position:relative}.redefining-work-section{padding:6rem 0;color:#fff;position:relative;overflow:hidden}.redefining-work-section::before{top:-80px;right:-80px;width:250px;height:250px;background:radial-gradient(circle,rgba(127,127,127,.2) 0,rgba(127,127,127,0) 70%);border-radius:50%;animation:15s ease-in-out infinite floatElement}.redefining-work-section::after{bottom:-50px;left:-50px;width:200px;display:none;height:200px;background:radial-gradient(circle,rgba(255,255,255,.1) 0,rgba(255,255,255,0) 70%);border-radius:30% 70% 70% 30%/30% 30% 70% 70%;animation:20s ease-in-out infinite alternate morphShape}.redefining-title{font-size:54px;font-weight:700;line-height:1.2;margin-bottom:3rem;color:#fff;text-align:left}.redefining-title::after{content:"";display:block;width:80px;height:3px;background:linear-gradient(to right,#fff,#7f7f7f);margin-top:20px;border-radius:2px;transition:width .3s}.redefining-subtitle{margin-bottom:20px;font-size:32px;color:#fff;position:relative;display:inline-block}.redefining-subtitle::before{content:"";position:absolute;display:none;left:-15px;top:50%;transform:translateY(-50%);width:5px;height:70%;background:linear-gradient(to bottom,#fff,#7f7f7f);border-radius:3px}.redefining-description{font-size:18px;color:#fff;line-height:1.6}.redefining-tabs{display:flex;gap:80px;margin-bottom:4rem;overflow-x:auto;justify-content:center;scrollbar-width:none;flex-wrap:nowrap;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);border-radius:8px;padding:10px 7px;-webkit-overflow-scrolling:touch;-ms-overflow-style:none}.redefining-tabs::-webkit-scrollbar{display:none}.redefining-tab{display:flex;align-items:center;gap:.75rem;padding:1rem 1.5rem;background:0 0;border:0 solid rgba(255,255,255,.2);border-radius:8px;color:#fff;font-size:16px;transition:.3s;position:relative;overflow:hidden;line-height:1.5;font-weight:500;white-space:nowrap;flex-shrink:0}@media (max-width:1024px){.redefining-tabs{gap:40px;justify-content:flex-start}.redefining-tab{padding:.8rem 1.2rem;font-size:15px}}@media (max-width:768px){.redefining-tabs{gap:20px;margin-bottom:2rem;padding:8px 5px}.redefining-tab{padding:.7rem 1rem;font-size:14px}.redefining-tab svg{width:18px;height:18px}}@media (max-width:480px){.stat-number{font-size:36px}.redefining-tabs{gap:15px;margin-bottom:1.5rem}.redefining-tab{padding:.6rem .8rem;font-size:13px}.redefining-tab svg{width:16px;height:16px}}.redefining-tab::before{top:0;left:-100%;width:100%;height:100%;background:linear-gradient(to right,rgba(255,255,255,0),rgba(255,255,255,.2),rgba(255,255,255,0));transition:left .7s}.redefining-tab svg{width:20px;height:20px;fill:currentColor}.redefining-tab.active{background:#c22034;color:#fff;border-color:transparent;box-shadow:0 5px 15px rgba(0,0,0,.2)}.redefining-content{transform:translateY(20px);transition:.5s;border-radius:12px;backdrop-filter:blur(5px)}.speak-expert-btn,.success-link,.video-card{overflow:hidden;transition:.3s}.redefining-content.visible{opacity:1;transform:translateY(0)}.redefining-content img{width:100%;height:auto;border-radius:12px;box-shadow:0 20px 40px rgba(0,0,0,.2);transition:.5s;border:1px solid rgba(255,255,255,.1)}.redefining-content-wrapper{display:grid;grid-template-columns:minmax(300px,1fr) minmax(400px,1.5fr);gap:4rem;align-items:center}.redefining-text-content{order:1;position:relative}.redefining-text-content::after{content:"";position:absolute;bottom:-20px;left:0;display:none;width:60%;height:1px;background:linear-gradient(to right,#fff,transparent);opacity:.5}.redefining-image{order:2;position:relative}.redefining-image::before{content:"";position:absolute;top:50%;left:50%;width:80%;height:80%;background:radial-gradient(circle,rgba(127,127,127,.4) 0,rgba(127,127,127,0) 70%);border-radius:50%;transform:translate(-50%,-50%);z-index:-1;animation:3s ease-in-out infinite pulse}.speak-expert-btn{display:inline-block;color:#fff;border-radius:4px;background:#c22034;padding:1rem 2rem;font-size:16px;font-weight:600;margin-bottom:.5rem;position:relative;cursor:pointer}.not-sales-text{display:block;color:rgba(255,255,255,.7);font-size:16px;margin-top:8px}.success-link,.success-title{color:#1e2154;position:relative}.redefining-cta::before{content:"";position:absolute;width:150px;height:60px;background-image:radial-gradient(circle,rgba(255,255,255,.3) 1px,transparent 1px);background-size:15px 15px;opacity:.2;z-index:-1;right:5%;top:-30px;transform:rotate(-10deg)}.reliable-section::after,.success-link::before,.success-stories::before{position:absolute;z-index:0;content:""}.redefining-cta{margin-top:6rem;animation-delay:.7s}.reliable-section,.success-stories{padding:25px 0;overflow:hidden}.ease-section{background:#fff;overflow:hidden;max-width:1250px;margin:0 auto;padding:10px 0}.success-stories::before{top:-80px;right:-80px;width:250px;display:none;height:250px;background-color:rgba(194,32,52,.1);border-radius:60% 40% 50% 50%/40% 50% 50% 60%;animation:20s ease-in-out infinite alternate morphShape}.reliable-section::after{bottom:-100px;left:-100px;width:300px;height:300px;background-color:rgba(127,127,127,.03);border-radius:50%;animation:15s ease-in-out infinite floatElement}.success-title{font-size:42px;font-weight:700;line-height:1.2;margin-bottom:1.5rem}.sn-waywork-title::after,.success-title::after{content:"";position:absolute;bottom:-10px;left:0;width:80px;height:3px;background:linear-gradient(to right,#1e2154,#7f7f7f);border-radius:2px;transition:width .3s}.success-link{display:inline-flex;align-items:center;gap:.5rem;font-weight:600;padding:8px 16px;border-radius:30px;background-color:rgba(30,33,84,.05);text-decoration:underline}.success-link::before{top:0;left:-100%;width:100%;height:100%;background:linear-gradient(to right,rgba(255,255,255,0),rgba(255,255,255,.5),rgba(255,255,255,0));transition:left .7s}.success-link svg{position:relative;z-index:1;transition:transform .3s;border-radius:50%;border:1px solid;padding:3px}.success-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1.5rem;align-items:center;max-width:1200px;margin:0 auto}.video-card{position:relative;border-radius:12px;cursor:pointer;aspect-ratio:16/9;box-shadow:0 10px 25px rgba(0,0,0,.1);border:1px solid rgba(30,33,84,.1)}.play-button,.play-button::before{border-radius:50%;position:absolute}.video-card::before{content:"";position:absolute;top:0;left:0;width:100%;height:100%;background:linear-gradient(to top,rgba(30,33,84,.8) 0,rgba(30,33,84,0) 70%);z-index:1;opacity:.8;transition:opacity .3s}.video-thumbnail{width:100%;height:100%;object-fit:cover;transition:transform .5s}.play-button{left:20px;bottom:20px;width:48px;height:48px;background:#1e2154;display:flex;align-items:center;justify-content:center;z-index:2;transition:.3s}.image-display,.stats-card{border-radius:12px;overflow:hidden}.play-button::before{content:"";top:-5px;left:-5px;right:-5px;bottom:-5px;background:rgba(30,33,84,.3);animation:2s infinite pulse;z-index:-1}.play-button svg{width:24px;height:24px;fill:white}.video-info{position:absolute;bottom:20px;left:80px;right:20px;color:#fff;z-index:2}.stats-card,.video-popup{height:100%;transition:.3s}.video-name{font-size:1.25rem;font-weight:600;margin-bottom:.5rem;padding-bottom:8px}.video-name::after{content:"";position:absolute;bottom:0;left:0;width:30px;height:2px;background:#fff;transition:width .3s}.video-title{font-size:.875rem;opacity:.9}.stats-card{background:#c22034;padding:2.5rem 2rem;text-align:left;display:flex;flex-direction:column;justify-content:center;box-shadow:0 10px 25px rgba(30,33,84,.15);gap:20px}.stats-author,.stats-number{display:flex;align-items:center;position:relative;z-index:1}.stats-card::before{content:"";position:absolute;top:0;right:0;width:120px;height:120px;background-image:radial-gradient(circle,rgba(255,255,255,.1) 1px,transparent 1px);background-size:10px 10px;opacity:.3;z-index:0;pointer-events:none}.stats-number{font-size:72px;font-weight:700;margin-bottom:.5rem;color:#fff;line-height:1}.stats-number::after{content:"%";font-size:2.5rem;margin-left:5px;opacity:.8}.stats-text{font-size:24px;line-height:1.4;color:#fff;margin-bottom:1.5rem;z-index:1}.ease-container,.ease-title{margin:0 auto;max-width:1250px}.ease-container,.ease-step-header{align-items:center;position:relative;z-index:1}.feature-item:nth-child(5),.video-card:nth-child(3){animation-delay:.7s}.ease-section::before{content:"";position:absolute;top:-100px;right:-100px;display:none;width:300px;height:300px;background-color:rgba(194,32,52,.1);border-radius:60% 40% 50% 50%/40% 50% 50% 60%;z-index:0;animation:20s ease-in-out infinite alternate floatBubble}.ease-section::after{content:"";position:absolute;bottom:-80px;left:-80px;width:250px;height:250px;background-color:rgba(127,127,127,.03);border-radius:50%;z-index:0;animation:15s ease-in-out infinite pulseBubble}.ease-container{display:grid;grid-template-columns:1fr 1fr;gap:4rem}.ease-content{padding-top:2rem}.ease-title{font-size:56px;font-weight:700;line-height:1.1;color:#1e2154;padding:20px 0;position:relative;display:block}.ease-title::after{content:"";position:absolute;bottom:10px;left:50%;transform:translateX(-50%);width:100px;height:3px;background:linear-gradient(to right,#1e2154,#7f7f7f);border-radius:3px;transition:width .4s}.ease-step::before,.icon-grid-wrapper::before{position:absolute;border-radius:50%;content:""}.ease-steps{display:flex;flex-direction:column;gap:20px}.ease-step{border-radius:10px;padding:20px;cursor:pointer;transition:.3s;display:flex;background:#fff;border-left:3px solid transparent;box-shadow:0 5px 15px rgba(0,0,0,.03);position:relative;overflow:hidden}.ease-step::before{top:-10px;right:-10px;width:80px;display:none;height:80px;background-image:radial-gradient(circle,rgba(127,127,127,.05) 1px,transparent 1px);background-size:10px 10px;opacity:.5;z-index:0;transition:.3s}.ease-step-header svg{width:24px;height:24px;flex-shrink:0;transition:.3s;color:#7f7f7f;position:relative;z-index:1}.ease-step.active .ease-step-header svg,.ease-step:hover .ease-step-header svg{color:#1e2154;transform:scale(1.2)}.ease-step.active{background:rgba(194,32,52,.1);border-left:3px solid #1e2154;box-shadow:0 8px 25px rgba(30,33,84,.1);transform:translateX(8px)}.ease-step-header{gap:1rem}.step-title{font-size:24px;font-weight:600;color:#1e2154;margin:0;transition:color .3s;position:relative;z-index:1}.step-description{margin-top:1rem;font-size:16px;line-height:1.6;color:#7f7f7f;display:none;position:relative;z-index:1}.ease-step.active .step-description{display:block;animation:.3s fadeIn}.icon-grid-wrapper{border-radius:20px;padding:2rem;position:relative;z-index:1}.icon-grid-wrapper::before{top:50%;left:50%;width:90%;height:90%;display:none;transform:translate(-50%,-50%);background:radial-gradient(circle,rgba(30,33,84,.08) 0,rgba(30,33,84,0) 70%);z-index:-1;animation:4s ease-in-out infinite pulse}.image-display{position:relative;width:100%;height:470px;transition:.5s}.step-image{position:absolute;width:100%;height:auto object-fit: cover;border-radius:12px;opacity:0;transition:.5s;display:none;transform:scale(1.1)}.step-image.active{opacity:1;display:block;transform:scale(1)}.reliable-section::before{content:"";position:absolute;top:-80px;right:-80px;width:250px;display:none;height:250px;background-color:rgba(30,33,84,.03);border-radius:40% 60% 60% 40%/50% 40% 60% 50%;z-index:0;animation:20s ease-in-out infinite alternate morphShape}.reliable-title{font-size:56px;font-weight:700;margin-bottom:4rem;color:#1e2154;position:relative;padding-bottom:20px}.reliable-title::after,.sn-pricing-title::after{content:"";position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:80px;height:3px;background:linear-gradient(to right,#1e2154,#7f7f7f);border-radius:2px;transition:width .3s}.sn-waywork-title:hover::after{width:100%}.card-icon-wrapper,.reliable-card{display:flex;transition:.3s;position:relative}.reliable-card{background:#1e2154;border-radius:12px;padding:2.5rem;color:#fff;box-shadow:0 10px 30px rgba(30,33,84,.15);overflow:hidden;flex-direction:column;height:100%}.reliable-card::before{content:"";position:absolute;top:0;right:0;display:none;width:150px;height:150px;background-image:radial-gradient(circle,#c22034 1px,transparent 1px);background-size:10px 10px;border-radius:0 0 0 100%;z-index:0;transition:.3s}.reliable-card::after{content:"";position:absolute;bottom:0;left:0;width:100%;height:5px;background:linear-gradient(to right,rgba(255,255,255,.3),rgba(255,255,255,0));transition:.3s;opacity:0}.card-title::after,.pricing-title::after{transform:translateX(-50%);transition:width .3s;content:""}.reliable-card:nth-child(2){background:linear-gradient(135deg,#1e2154 0,#2a2d6a 100%)}.reliable-card:nth-child(3){background:linear-gradient(135deg,#1e2154 0,#151942 100%)}.card-icon-wrapper,.card-icon-wrapper::before{border-radius:50%}.card-icon-wrapper{align-items:center;justify-content:center;width:120px;height:120px;margin:0 auto 2rem}.card-icon-wrapper::before{content:"";position:absolute;top:-5px;left:-5px;display:none;right:-5px;bottom:-5px;z-index:-1;animation:2s infinite pulse}.card-icon{width:108px;height:108px}.card-title{font-size:24px;font-weight:600;margin-bottom:1rem;color:#fff;position:relative;padding-bottom:15px;height:80px}.card-title::after{position:absolute;bottom:0;left:50%;width:40px;height:2px;background:#c22034;border-radius:2px}.card-description{font-size:16px;line-height:1.6;color:rgba(255,255,255,.9);flex-grow:1}.audit-popup,.calendly-popup{width:100%;background-color:rgba(30,33,84,.85);justify-content:center;display:none;left:0;backdrop-filter:blur(5px)}.feature-item:nth-child(4),.reliable-card:nth-child(3){animation-delay:.6s}.audit-popup{position:fixed;top:80px;height:570px;z-index:1000;align-items:center;opacity:0;transition:opacity .4s cubic-bezier(.19, 1, .22, 1);padding:20px}#audit-popup{z-index:999999!important}.ease-section,.pricing-section,.reliable-section,.success-stories{position:relative;z-index:1}@media (max-height:500px){.audit-popup{align-items:flex-start;overflow-y:auto}}.customer-card,.stats-section{overflow:hidden;position:relative}.calendly-popup{position:fixed;top:0;height:100%;z-index:1000;align-items:center}.stats-section{padding:2.5rem 0;background:#fff}.stats-section::after,.stats-section::before{content:"";position:absolute;border-radius:50%;z-index:0;display:none}.stats-container{max-width:1000px;margin:0 auto;padding:0 15px;position:relative;z-index:1}.rating-row{display:flex;justify-content:center;align-items:center;flex-wrap:wrap;max-width:1000px;margin:15px auto}.star-rating{display:flex;align-items:center;margin-right:.8rem}.rating{font-size:24px;font-weight:700;color:#1e2154;margin-right:8px}.review-count{font-size:16px;color:#787878;font-weight:500}.review-platforms{display:flex;gap:8px}.platform-icon{width:24px;height:24px;object-fit:contain}.stats-grid{display:grid;gap:1.5rem;max-width:1000px;margin:48px auto 2rem}.stat-item{display:flex;flex-direction:column;align-items:center;border-left:1px solid #083D301A;border-right:1px solid #083D301A}.stat-number{font-size:56px;font-weight:700;color:#1e2154;margin-bottom:.3rem;line-height:1.2}@media (max-width:1024px){.stat-number{font-size:48px}.hero-image img{max-height:380px}.main-title{font-size:42px}}.stat-label{font-size:16px;color:#787878;margin-top:20px;font-weight:500}.customer-card{background:#c22034;padding:1.8rem 1.5rem;border-radius:15px;color:#fff;box-shadow:0 8px 20px rgba(30,33,84,.2);max-width:250px}.customer-count{font-size:40px;font-weight:700;margin-bottom:.6rem;position:relative;z-index:1}.customer-link,.customer-text{font-size:16px;z-index:1;position:relative}.customer-text{margin-top:20px;margin-bottom:20px}.customer-link{display:inline-flex;align-items:center;gap:.3rem;color:#fff;text-decoration:none;font-weight:600}.customer-link svg{width:18px;height:18px}.customers-grid{display:flex;justify-content:space-between;align-items:center;gap:2rem;flex-wrap:wrap}.customer-logos-left,.customer-logos-right{display:grid;grid-template-columns:repeat(2,1fr);gap:1.5rem;flex:1}.customer-logo-item{display:flex;justify-content:center;align-items:center;padding:1rem}.customer-logo-img{max-width:100%;object-fit:contain}.sn-departments-section{padding:4rem 0}.learn-more-icon{border-radius:50%;border:1px solid;width:15px;height:15px;margin-top:7px}.sn-main-title{font-size:54px;color:#1e2154;margin-bottom:3rem}.sn-main-title::after{content:"";display:block;width:80px;height:3px;background:linear-gradient(to right,#1e2154,#c22034);margin-top:20px;border-radius:2px;transition:width .3s}.sn-department-tabs{display:flex;justify-content:center;gap:10px;margin-bottom:2rem;flex-wrap:nowrap;border:1px solid #e2dbca;border-radius:10px;background:#fff;padding:10px;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none;-ms-overflow-style:none}.sn-department-tabs::-webkit-scrollbar{display:none}.sn-tab-button{display:flex;align-items:center;gap:.5rem;padding:.8rem 1.5rem;border:none;background:#fff;border-radius:10px;cursor:pointer;transition:.3s;font-size:16px;font-weight:500;color:#000;line-height:1.5;white-space:nowrap;flex-shrink:0}@media (max-width:768px){.stat-number{font-size:42px}.sn-department-tabs{justify-content:flex-start;padding:10px 5px}.sn-tab-button{padding:.6rem 1rem;font-size:14px}.sn-tab-icon{width:20px;height:20px}.hero-section{padding:60px 0 40px;margin-top:70px}.main-title{font-size:36px}.hero-description{font-size:16px}.cta-buttons{flex-direction:column;width:100%;max-width:400px;margin-left:auto;margin-right:auto}.btn{width:100%;text-align:center}.hero-image img{max-height:350px}}.sn-tab-button.active{background:#c22034;color:#fff;font-weight:500}.sn-tab-icon{width:24px;height:24px;fill:currentColor}.sn-department-content{position:relative;min-height:400px}.sn-department-panel{display:none;opacity:0;transition:opacity .3s}.sn-department-panel.active{display:block;opacity:1}.sn-panel-wrapper{display:flex;gap:2rem;align-items:center}.sn-feature-col,.sn-panel-image,.sn-panel-text{flex:1}.sn-panel-text p{font-size:16px;color:#787878;margin-bottom:1.5rem;line-height:1.6}.sn-panel-image img{max-width:100%;height:auto;border-radius:8px}.sn-content-title{font-size:32px;color:#1e2154;margin-bottom:20px}.sn-content-description{font-size:16px;color:#666;margin-bottom:30px;line-height:1.6}.sn-learn-more{display:inline-flex;align-items:center;gap:8px;color:#c22034;text-decoration:underline;font-weight:600;margin-bottom:30px}.sn-app-icons{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:20px}.sn-app-icon{display:flex;flex-direction:column;align-items:center}.sn-app-image{width:50px;height:50px;object-fit:contain;margin-bottom:10px}.sn-app-name{font-size:14px;color:#333}.sn-department-tabs .sn-tab-button.active .sn-tab-icon,.sn-department-tabs .sn-tab-button:hover .sn-tab-icon{filter:brightness(0) invert(1)}.sn-department-tabs .sn-tab-button.active{color:#fff}.sn-video-popup{display:none;position:fixed;top:0;left:0;width:100%;height:100vh;background:rgba(0,0,0,.95);z-index:999999;opacity:0;transition:opacity .3s;overflow:hidden;backdrop-filter:blur(5px)}.sn-pricing-section{padding:80px 20px;background:#fff}.side-panel{top:50%!important}.sn-pricing-title{font-size:54px;color:#1a237e;margin-bottom:50px;font-weight:700;position:relative}.sn-pricing-title:after{content:'';position:absolute;bottom:-15px;left:50%;transform:translateX(-50%);width:80px;height:4px;background-color:#dc3545;border-radius:2px}.sn-pricing-card{background:#1a237e;border-radius:20px;padding:40px;color:#fff;box-shadow:0 10px 30px rgba(26,35,126,.15)}.sn-pricing-subtitle{font-size:32px;margin-bottom:40px;font-weight:600;line-height:1.3}.sn-pricing-features{display:flex;justify-content:space-between;gap:40px;margin-bottom:40px}.sn-feature-item{display:flex;align-items:center;margin-bottom:20px;font-size:18px}.sn-feature-item svg{width:24px;height:24px;margin-right:12px;stroke:#dc3545}.sn-pricing-right{display:flex;flex-direction:column;align-items:center;gap:20px;border-bottom:1px solid rgba(255,255,255,.1)}.sn-price-tag{display:flex;align-items:baseline;justify-content:center}.sn-currency{font-size:32px;font-weight:600;margin-right:5px}.sn-amount{font-size:64px;font-weight:700;line-height:1}.sn-cta-button{background:#dc3545;color:#fff;padding:15px 30px;border-radius:8px;text-decoration:none;font-weight:600;transition:.3s;display:inline-block}@media (max-width:576px){.hero-section,.redefining-work-section,.reliable-section,.sn-departments-section,.sn-pricing-section,.success-stories{padding:50px 30px 30px}.main-title{font-size:32px}.hero-image img{max-height:300px}}@media (max-width:480px){.stats-card{gap:40px}.stats-number{font-size:35px!important;margin-bottom:-1rem!important}.stat-number{font-size:36px}.hero-image img{max-height:250px}}@media (max-width:380px){.stat-number{font-size:32px}.main-title{font-size:28px}.hero-image{margin-top:20px}.hero-image img{max-height:200px}}@media (max-width:1200px){.team-title{font-size:2.25rem}.team-subtitle{font-size:1.6rem}}@media (max-width:992px){.team-title{font-size:2rem}.team-subtitle{font-size:1.5rem}.team-description p{font-size:1.0625rem}}@media (max-width:768px){.team-title{font-size:1.75rem}.team-subtitle{font-size:1.35rem}.team-description p{font-size:1rem}.role-tag{font-size:.8125rem}.audit-popup{align-items:center;padding:20px}.customers-grid{flex-direction:column}.customer-logos-left,.customer-logos-right{grid-template-columns:repeat(2,1fr);width:100%}}@media (max-width:576px){.team-title{font-size:1.5rem}.team-subtitle{font-size:1.25rem}.cta-button,.team-description p{font-size:.9375rem}.audit-popup{padding:15px}}@media (max-width:991px){.sn-pricing-title{font-size:36px}.sn-pricing-subtitle{font-size:28px}.sn-pricing-card{padding:30px}.sn-feature-item{font-size:16px}.sn-amount{font-size:48px}}@media (max-width:767px){.sn-pricing-section{padding:60px 15px}.sn-pricing-title{font-size:32px}.sn-pricing-subtitle{font-size:24px;margin-bottom:30px}.sn-pricing-features{flex-direction:column;gap:20px}.sn-pricing-right{flex-direction:column;gap:20px;text-align:center}.sn-price-tag{justify-content:center}}@media (max-width:480px){.container{justify-content:center}.redefining-content-wrapper,.stats-grid{grid-template-columns:repeat(1,1fr)!important}.ease-title,.redefining-title,.reliable-title,.sn-main-title,.sn-pricing-title,.sn-waywork-title,.success-title{font-size:28px!important}.sn-panel-wrapper{display:grid}.sn-content-title{font-size:20px}.redefining-description,.sn-content-description{font-size:16px}.redefining-subtitle{font-size:24px}.customer-logos-left,.customer-logos-right{grid-template-columns:1fr}.sn-video-popup__close{top:-3px;right:3px}.ease-container{display:flow}.reliable-grid{grid-template-columns:repeat(1,1fr)}.sn-pricing-card{padding:20px}.sn-feature-item{font-size:14px}.sn-amount{font-size:42px}.sn-cta-button{padding:12px 25px;font-size:14px}.sn-waywork-section{padding:0!important}.main-title::after,.redefining-title::after,.reliable-title::after,.sn-main-title::after,.sn-pricing-title::after,.sn-waywork-title::after,.success-title::after,.team-header::after{display:none}}.contact-btn,.explore-btn{display:inline-block;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:500;text-align:center;width:180px;height:48px;line-height:24px}.contact-btn{background:#c52a3d;color:#fff;border:1px solid #c52a3d}.explore-btn{background:0 0;color:#c52a3d;border:1px solid #c52a3d}.marketing-team-section,.redefining-work-section,.reliable-section,.sn-departments-section,.success-stories{width:100%;background:#fef4f4;max-width:none}.redefining-work-section{background:#1e2154}.success-stories{background:#fff5f5}
        </style>
        <?php salesnanny_nav_header(); ?>
        <div class="hero-section">
            <div class="container">
                <div class="hero-content">
                    <h1 class="main-title">The Marketing Team for Your Business</h1>
                    <p class="hero-description">
                        Our all-in-one digital marketing services package covers <b style="color:#000;">AEO, SEO, social media, graphic design, content marketing, website development,</b> and everything your business needs to grow.<b style="color:#000;"> One package, One team, One cost </b> saving you time and hiring expenses!
                    </p>
                    <div class="cta-buttons">
                        <a  href="<?php echo SN_HTTP_URL; ?>website-analyzer/" class="btn btn-primary">Free Website Audit</a>
                        <!-- <a  class="calendly-trigger btn btn-secondary">Schedule a Call</a> -->
                    </div>
                </div>
                <div class="hero-image">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/home-header-1.webp" alt="Business operations illustration showing workflow" width="572" height="570" fetchpriority="high">
                </div>
                <!-- <div id="audit-popup" class="audit-popup">
                    <div class="audit-popup-content">
                        <span class="close-popup">&times;</span>
                        <h2>Free Website Audit</h2>
                        <p>Enter your details below and we'll analyze your website for free.</p>
                        <form id="audit-form">
                        <div class="form-group">
                            <label for="audit-email">Email Address</label>
                            <input type="email" id="audit-email" name="email" placeholder="your@email.com" required>
                        </div>
                        <div class="form-group">
                            <label for="audit-website">Website</label>
                            <input type="text" id="audit-website" name="website" placeholder="yourwebsite.com" required>
                        </div>
                        <div class="form-buttons">
                            <button type="submit" id="submit-audit" class="btn-submit">Submit</button>
                        </div>
                        </form>
                        <div id="form-status" class="form-status"></div>
                    </div>
                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        // Get elements
                        const auditButton = document.querySelector('.btn-primary');
                        const popup = document.getElementById('audit-popup');
                        const closeButton = document.querySelector('.close-popup');
                        const auditForm = document.getElementById('audit-form');
                        const formStatus = document.getElementById('form-status');
                        const submitButton = document.getElementById('submit-audit');
                        
                        // Google Apps Script URL - REPLACE THIS with your actual deployed web app URL
                        const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbyyK5yWzYd5xtE6F-hbYOdhUOT-ozzrtAnYQMyEB44TQDnhxR35VoRUtcYDJkkXDdetJQ/exec';
                        
                        // Open popup when audit button is clicked
                        auditButton.addEventListener('click', function(e) {
                            e.preventDefault();
                            popup.classList.add('active');
                            document.body.style.overflow = 'hidden'; // Prevent scrolling
                        });
                        
                        // Close popup when close button is clicked
                        closeButton.addEventListener('click', function() {
                            popup.classList.remove('active');
                            document.body.style.overflow = ''; // Re-enable scrolling
                        });
                        
                        // Close popup when clicking outside the content
                        popup.addEventListener('click', function(e) {
                            if (e.target === popup) {
                                popup.classList.remove('active');
                                document.body.style.overflow = ''; // Re-enable scrolling
                            }
                        });
                        
                        // Handle form submission
                        auditForm.addEventListener('submit', function(e) {
                            e.preventDefault();
                            
                            // Get form data
                            const email = document.getElementById('audit-email').value;
                            let website = document.getElementById('audit-website').value;
                            
                            // Validate form data
                            if (!email || !website) {
                                showStatus('Please fill in all fields', 'error');
                                return;
                            }
                            
                            // Validate email format
                            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                            if (!emailRegex.test(email)) {
                                showStatus('Please enter a valid email address', 'error');
                                return;
                            }
                            
                            // Validate URL format
                            try {
                                // Remove any @ symbol if present
                                website = website.replace('@', '');
                                
                                // If the input doesn't start with http:// or https://, add https://
                                if (!website.startsWith('http://') && !website.startsWith('https://')) {
                                    website = 'https://' + website;
                                }
                                
                                // Validate URL format
                                new URL(website);
                            } catch (e) {
                                showStatus('Please enter a valid website URL', 'error');
                                return;
                            }
                            
                            // Show loading state
                            submitButton.disabled = true;
                            submitButton.innerHTML = '<span class="loading-spinner"></span>Submitting...';
                            
                            // Create data object for JSON submission
                            const formDataObj = {
                                email: email,
                                website: website,
                                formType: 'audit',
                                timestamp: new Date().toISOString(),
                                sourcePage: window.location.pathname
                            };
                            
                            // Send data to Google Apps Script using fetch with JSON
                            fetch(APPS_SCRIPT_URL, {
                                method: 'POST',
                                mode: 'no-cors', // Important for handling CORS issues
                                cache: 'no-cache',
                                headers: {
                                    'Content-Type': 'application/json',
                                },
                                redirect: 'follow',
                                body: JSON.stringify(formDataObj)
                            })
                            .then(response => {
                                // Since we're using no-cors, we can't actually read the response
                                // So we'll just assume success after a delay
                                setTimeout(() => {
                                    showStatus('Thank you! Your audit request has been submitted. We\'ll email you the results within 12 hours.', 'success');
                                    auditForm.reset();
                                    submitButton.disabled = false;
                                    submitButton.innerHTML = 'Submit Audit Request';
                                    
                                    // Close popup after 3 seconds
                                    setTimeout(() => {
                                        popup.classList.remove('active');
                                        document.body.style.overflow = ''; // Re-enable scrolling
                                    }, 3000);
                                }, 1500);
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                showStatus('There was an error submitting your request. Please try again.', 'error');
                                submitButton.disabled = false;
                                submitButton.innerHTML = 'Submit Audit Request';
                            });
                        });
                        
                        // Helper function to show status messages
                        function showStatus(message, type) {
                            formStatus.textContent = message;
                            formStatus.className = 'form-status ' + type;
                        }
                    });
                </script> -->
            </div>
        </div>
        <section class="marketing-team-section">
            <div class="team-container">
                <div class="team-header">
                    <h2 class="team-title">Too Many Roles to Manage?</h2>
                    <h3 class="team-subtitle">Get a Full Marketing Team For The <b>Cost of One Employee</b></h3>
                </div>
                <div class="team-illustration">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/home-team.webp" alt="Marketing team roles illustration showing different positions" class="team-image" loading="lazy" width="1000" height="555">
                    <!-- Fallback for mobile or if SVG fails to load -->
                    <div class="team-roles-mobile">
                        <div class="role-tag">SEO</div>
                        <div class="role-tag">PPC</div>
                        <div class="role-tag">SALES</div>
                        <div class="role-tag">DESIGNER</div>
                        <div class="role-tag">SMM</div>
                        <div class="role-tag">DEVELOPMENT</div>
                    </div>
                </div>
                <div class="team-description">
                    <p>Avoid the expense and delay of hiring. Get a ready-to-go marketing team at <br> one hire cost and one hire time!</br></p>
                </div>
                <!-- <div class="team-cta">
                    <a href="<?php echo SN_HTTP_URL; ?>contact/" class="cta-button">Get Your Team Today</a>
                </div> -->
            </div>
        </section>
        <section class="stats-section">
            <div class="stats-container">
            
                <div class="stats-grid">
                    <div class="stat-item">
                <div class="stat-number">200+</div>
                <div class="stat-label">Most satisfied customers</div>
                    </div>
                    <div class="stat-item">
                <div class="stat-number">5+</div>
                <div class="stat-label">Years of experience</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">250+</div>
                <div class="stat-label">Projects completed</div>
                    </div>
                </div>
            
                <div class="customers-grid">
                    <div class="customer-logos-left">
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/slideegg-logo.webp" alt="SlideEgg" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/slidone-logo.webp" alt="Slidone" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/cargo-docket.webp" alt="Deckez" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/supplyhoop-logo.webp" alt="WiseBI" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                    </div>
            
                    <div class="customer-card">
                        <div class="customer-count">200+</div>
                        <div class="customer-text">Customers all over the world</div>
                        <a href="<?php echo SN_HTTP_URL; ?>testimonials/" class="customer-link">VIEW CUSTOMERS 
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </a>
                    </div>
            
                    <div class="customer-logos-right">
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/deckez.webp" alt="Cargo Docket" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/carguber-logo.webp" alt="Carguber" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/wisebi-logo.webp" alt="SupplyHoop" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                        <div class="customer-logo-item">
                            <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/elicit-logo.webp" alt="WiseBI" class="customer-logo-img" width="100" height="30" loading="lazy">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="sn-departments-section">
            <div class="sn-container">
                <h2 class="sn-main-title">One Solution for All Business Requirements</h2>
                
                <div class="sn-department-tabs">
                    <button class="sn-tab-button active" data-department="organic-marketing">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/earned-media-tab.webp" alt="Earned Media" class="sn-tab-icon" loading="lazy">
                        Organic Marketing
                    </button>
                    <button class="sn-tab-button" data-department="paid-marketing">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/paid-media-tab.webp" alt="Paid Media" class="sn-tab-icon" loading="lazy">
                        Paid Marketing
                    </button>
                    <button class="sn-tab-button" data-department="website-development">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/web-development-tab.webp" alt="Web Development" class="sn-tab-icon" loading="lazy">
                        Website Development
                    </button>
                    <button class="sn-tab-button" data-department="branding">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/branding-tab.webp" alt="Data Management" class="sn-tab-icon" loading="lazy">
                        Branding
                    </button>
                    <button class="sn-tab-button" data-department="inside-sales">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/inside-sales-tab.webp" alt="Inside Sales" class="sn-tab-icon" loading="lazy">
                        Inside Sales
                    </button>
                    <button class="sn-tab-button" data-department="creative">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/creative-tab.webp" alt="Creative" class="sn-tab-icon" loading="lazy">
                        Creative
                    </button>
                </div>
                
                <div class="sn-department-content">
                    <!-- Earned Media Content -->
                    <div class="sn-department-panel active" data-department="organic-marketing">
                        <div class="sn-panel-wrapper">
                            <div class="sn-panel-text">
                                <h2 class="sn-content-title">Grow Your Business Organically</h2>
                                <p class="sn-content-description">Organic marketing is about getting people to talk about you without paying for ads. <b style="color:#000;">It's like free advertising!</b> We help you get featured on <b style="color:#000;">news stories, blogs, and social media</b>. This will help your brand be seen again by customers and build their trust.</p>
                                <a href="<?php echo SN_HTTP_URL; ?>organic-marketing/" class="sn-learn-more">LEARN MORE 
                                    <svg class="learn-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                                <div class="sn-app-icons">
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/seo.png" alt="CRM" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">SEO</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/content-marketing.png" alt="Bigin" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Content Marketing</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/digitalpr.png" alt="Bookings" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Digital PR</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/socialmedia.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">socialmedia</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/emailmarketing.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Email Marketing</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/videomarketing.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Video Marketing</span>
                                    </div>
                                </div>
                            </div>
                            <div class="sn-panel-image">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/organic-marketing.webp" alt="Earned Media Services" loading="lazy" width="600" height="340"> 
                            </div>
                        </div>
                    </div>

                    <!-- Paid Media Content -->
                    <div class="sn-department-panel" data-department="paid-marketing">
                        <div class="sn-panel-wrapper">
                            <div class="sn-panel-text">
                                <h2 class="sn-content-title">Reach More Customers with Targeted Ads</h2>
                                <p class="sn-content-description">Want to reach the right people with your message? Paid Marketing helps you do that. <b style="color:#000;">We create and manage online ads</b> that target your ideal customers. This means your ads are seen by people who are most likely to be interested in what you offer.</p>
                                <a href="<?php echo SN_HTTP_URL; ?>paid-marketing/" class="sn-learn-more">LEARN MORE 
                                    <svg class="learn-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                                <div class="sn-app-icons">
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/paid-search.png" alt="CRM" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Paid Search</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/paidsocial.png" alt="Bigin" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Paid Social</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/paidstragies.png" alt="Bookings" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Paid Marketing<br>Strategy</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/market-place.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Marketplace<br>Optimization</span>
                                    </div>
                                </div>
                            </div>
                            <div class="sn-panel-image">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/paid-marketing.webp" alt="Earned Media Services" loading="lazy" width="600" height="340">
                            </div>
                        </div>
                    </div>

                    <!-- Web Development Content -->
                    <div class="sn-department-panel" data-department="website-development">
                        <div class="sn-panel-wrapper">
                            <div class="sn-panel-text">
                                <h2 class="sn-content-title">Build the Websites You Need to Succeed Online</h2>
                                <p class="sn-content-description">Need a new website or online tool? We can build it for you. Our team creates unique <b style="color:#000;">static websites, dynamic websites, and e-commerce websites</b> that help your business grow.  We work closely with you to understand your needs and deliver the perfect solution.</p>
                                <a href="<?php echo SN_HTTP_URL; ?>website-development/" class="sn-learn-more">LEARN MORE 
                                    <svg class="learn-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                                <div class="sn-app-icons">
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/static-web.png" alt="CRM" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Static Websites</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/dynamic-web.png" alt="Bigin" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Dynamic Websites</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/ecommerce-web.png" alt="Bookings" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">E-commerce<br>Websites</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/integration-web.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Website<br>Integrations</span>
                                    </div>
                                </div>
                            </div>
                            <div class="sn-panel-image">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/website-development.webp" alt="Earned Media Services" loading="lazy" width="600" height="340">
                            </div>
                        </div>
                    </div>

                    <!-- Data Management Content -->
                    <div class="sn-department-panel" data-department="branding">
                        <div class="sn-panel-wrapper">
                            <div class="sn-panel-text">
                                <h2 class="sn-content-title"> Build Your Brand Identity with Expert Design.</h2>
                                <p class="sn-content-description">Connecting with your audience requires a strong brand. We help you craft and communicate your brand so you can build meaningful relationships. We design <b style="color:#000;">your brand identity, define your brand personality,</b> develop your key messages, and then give you clear strategies that are easy to understand. This helps you resonate with your target market on a deeper level.</p>
                                <a href="<?php echo SN_HTTP_URL; ?>branding/" class="sn-learn-more">LEARN MORE 
                                    <svg class="learn-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                                <div class="sn-app-icons">
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/logo-design.png" alt="CRM" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Logo Design</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/brand-guide.png" alt="Bigin" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Brand Guidelines</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/brand-message.png" alt="Bookings" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Brand Messaging</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/visual-identity.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Visual Identity</span>
                                    </div>
                                </div>
                            </div>
                            <div class="sn-panel-image">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/branding.webp" alt="Earned Media Services" loading="lazy" width="600" height="340">
                            </div>
                        </div>
                    </div>

                    <!-- Inside Sales Content -->
                    <div class="sn-department-panel" data-department="inside-sales">
                        <div class="sn-panel-wrapper">
                            <div class="sn-panel-text">
                                <h2 class="sn-content-title"> Increase Your Sales with Our Expert Team</h2>
                                <p class="sn-content-description">Need help closing more deals? Our inside sales team can help. We have experienced sales professionals who can handle your <b style="color:#000;">sales calls, emails, and customer interactions</b>. We focus on building relationships and finding the right solutions for your customers, so you can focus on growing your business.</p>
                                <a href="<?php echo SN_HTTP_URL; ?>inside-sales/" class="sn-learn-more">LEARN MORE 
                                    <svg class="learn-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                                <div class="sn-app-icons">
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/lead-generation.png" alt="CRM" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Lead Generation</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/sales-funnel.png" alt="Bigin" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Sales Funnel<br>Optimization</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/email-drip.png" alt="Bookings" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Email Drip<br>Campaigns</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/sales-support.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Sales Support</span>
                                    </div>
                                </div>
                            </div>
                            <div class="sn-panel-image">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/inside-sales.webp" alt="Earned Media Services" loading="lazy" width="600" height="340">
                            </div>
                        </div>
                    </div>

                    <!-- Creative Content -->
                    <div class="sn-department-panel" data-department="creative">
                        <div class="sn-panel-wrapper">
                            <div class="sn-panel-text">
                                <h2 class="sn-content-title">Make Your Brand Stand Out with Great Design</h2>
                                <p class="sn-content-description">Want to make a great first impression? We create eye-catching designs that help your brand stand out. We design <b style="color:#000;">logos, websites, social media posts, brochures, presentations, and more.</b> Our creative team brings your ideas to life with visuals that capture attention and communicate your message effectively.</p>
                                <a href="<?php echo SN_HTTP_URL; ?>creative/" class="sn-learn-more">LEARN MORE 
                                    <svg class="learn-more-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </a>
                                <div class="sn-app-icons">
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/graphic-design.png" alt="CRM" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Graphic Design</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/motion-design.png" alt="Bigin" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Motion Design</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/video-editing.png" alt="Bookings" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Video Editing</span>
                                    </div>
                                    <div class="sn-app-icon">
                                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/presentation-design.png" alt="SalesIQ" class="sn-app-image" loading="lazy">
                                        <span class="sn-app-name">Presentation<br>Design</span>
                                    </div>
                                </div>
                            </div>
                            <div class="sn-panel-image">
                                <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/creative.webp" alt="Earned Media Services" loading="lazy" width="600" height="340">
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </section>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const tabButtons = document.querySelectorAll('.sn-tab-button');
                const contentPanels = document.querySelectorAll('.sn-department-panel');
                
                // Function to show panel
                function showPanel(department) {
                    contentPanels.forEach(panel => {
                        if (panel.getAttribute('data-department') === department) {
                            panel.classList.add('active');
                        } else {
                            panel.classList.remove('active');
                        }
                    });
                }
                
                // Set first tab as active by default
                if (tabButtons.length > 0) {
                    const firstDepartment = tabButtons[0].getAttribute('data-department');
                    showPanel(firstDepartment);
                }
                
                // Add click event listeners to tab buttons
                tabButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        // Remove active class from all buttons
                        tabButtons.forEach(btn => btn.classList.remove('active'));
                        
                        // Add active class to clicked button
                        this.classList.add('active');
                        
                        // Show corresponding panel
                        const department = this.getAttribute('data-department');
                        showPanel(department);
                    });
                });
            });
        </script>
        <section class="redefining-work-section">
                <div class="redefining-container">
                    <h2 class="redefining-title">We Make Your Marketing Easy</h2>
                    <div class="redefining-tabs">
                        <button class="redefining-tab active" data-tab="communications">
                            <img class="sn-tab-icon" src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/communication-1.webp" alt="Communications" class="tab-icon" loading="lazy">
                            Communications
                        </button>
                        <button class="redefining-tab" data-tab="collaboration">
                            <img class="sn-tab-icon" src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/collabration-1.webp" alt="Collaboration" class="tab-icon" loading="lazy">
                            Collaboration
                        </button>
                        <button class="redefining-tab" data-tab="content">
                            <img class="sn-tab-icon" src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/expertise-1.webp" alt="Expertise" class="tab-icon" loading="lazy">
                            Expertise
                        </button>
                        <button class="redefining-tab" data-tab="projects">
                            <img class="sn-tab-icon" src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/transperancy-1.webp" alt="Transparency" class="tab-icon" loading="lazy">
                            Transparency
                        </button>
                        <button class="redefining-tab" data-tab="productivity">
                            <img class="sn-tab-icon" src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/result-1.webp" alt="Results" class="tab-icon" loading="lazy">
                            Results
                        </button>
                    </div>
                    <div class="redefining-content visible" id="redefiningContent">
                    </div>
                    <div class="redefining-cta">
                        <a class="calendly-trigger speak-expert-btn">Let's Have a Chat</a>
                        <!-- <span class="not-sales-text">Not a sales call</span> -->
                    </div>
                </div>
        </section>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const tabContent = {
                    communications: {
                        title: "Easy to reach, always in touch",
                        description: "We believe in open and frequent communication. You'll have a dedicated point of contact who will keep you updated on our progress and answer any questions you have. We're always here to listen and discuss your needs.",
                        image: "<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/communication.webp"
                    },
                    collaboration: {
                        title: "We work together as one team.",
                        description: "We believe in teamwork. Your success is our success. We work closely with you, sharing ideas and finding solutions together. We're not just a service provider, we're your partner.",
                        image: "<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/collabration.webp"
                    },
                    content: {
                        title: "Unlock your Growth Through Experters",
                        description: "We're a team of experienced professionals. We know marketing and sales. We have the skills to get the job done right. You can trust us to deliver results.",
                        image: "<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/expertise.webp"
                    },
                    projects: {
                        title: "You always know what's happening.",
                        description: "We believe in keeping things open and honest. You can see what we're doing and how we're doing it. No surprises, just clear communication and reporting.",
                        image: "<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/transperancy.webp"
                    },
                    productivity: {
                        title: "We help your business grow.",
                        description: "We don't just talk about results, we deliver them. We track our progress and measure our success. You'll see the difference in your business.",
                        image: "<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/results.webp"
                    }
                };

                function updateRedefiningContent(tab) {
                    const contentEl = document.getElementById('redefiningContent');
                    const content = tabContent[tab];

                    // Remove visible class
                    contentEl.classList.remove('visible');

                    // Update content after a short delay
                    setTimeout(() => {
                        contentEl.innerHTML = `
                            <div class="redefining-content-wrapper">
                                <div class="redefining-text-content">
                                    <h3 class="redefining-subtitle">${content.title}</h3>
                                    <p class="redefining-description">${content.description}</p>
                                </div>
                                <div class="redefining-image">
                                    <img src="${content.image}" alt="${tab} interface" width="710" height="270" loading="lazy">
                                </div>
                            </div>
                        `;

                        // Add visible class back
                        setTimeout(() => {
                            contentEl.classList.add('visible');

                            // Add entrance animations for new content
                            const textContent = contentEl.querySelector('.redefining-text-content');
                            const imageContent = contentEl.querySelector('.redefining-image');

                            if (textContent) {
                                textContent.style.opacity = '0';
                                textContent.style.transform = 'translateX(-20px)';
                                setTimeout(() => {
                                    textContent.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                                    textContent.style.opacity = '1';
                                    textContent.style.transform = 'translateX(0)';
                                }, 50);
                            }

                            if (imageContent) {
                                imageContent.style.opacity = '0';
                                imageContent.style.transform = 'translateX(20px)';
                                setTimeout(() => {
                                    imageContent.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                                    imageContent.style.opacity = '1';
                                    imageContent.style.transform = 'translateX(0)';
                                }, 200);
                            }
                        }, 50);
                    }, 300);
                }

                // Initialize with communications tab
                updateRedefiningContent('communications');

                // Handle tab clicks
                const tabs = document.querySelectorAll('.redefining-tab');
                tabs.forEach(tab => {
                    tab.addEventListener('click', () => {
                        // Remove active class from all tabs
                        tabs.forEach(t => t.classList.remove('active'));
                        // Add active class to clicked tab
                        tab.classList.add('active');
                        // Update content
                        updateRedefiningContent(tab.dataset.tab);
                    });
                });

                // Animate on scroll functionality
                const animateOnScroll = function() {
                    const section = document.querySelector('.redefining-work-section');
                    if (!section) return;

                    const position = section.getBoundingClientRect();

                    // If section is in viewport and not already animated
                    if (position.top < window.innerHeight * 0.8 && !section.classList.contains('animated')) {
                        section.classList.add('animated');

                        // Animate title
                        const title = section.querySelector('.redefining-title');
                        if (title) {
                            title.style.opacity = '1';
                            title.style.transform = 'translateY(0)';
                        }

                        // Animate tabs
                        const tabs = section.querySelector('.redefining-tabs');
                        if (tabs) {
                            setTimeout(() => {
                                tabs.style.opacity = '1';
                                tabs.style.transform = 'translateY(0)';
                            }, 200);
                        }

                        // Animate content
                        const content = section.querySelector('.redefining-content');
                        if (content) {
                            setTimeout(() => {
                                content.style.opacity = '1';
                                content.style.transform = 'translateY(0)';
                            }, 400);
                        }

                        // Animate CTA
                        const cta = section.querySelector('.redefining-cta');
                        if (cta) {
                            setTimeout(() => {
                                cta.style.opacity = '1';
                                cta.style.transform = 'translateY(0)';
                            }, 600);
                        }
                    }
                };

                // Run animations on page load and scroll
                setTimeout(animateOnScroll, 100);
                window.addEventListener('scroll', animateOnScroll);
            });
        </script>
        <section class="sn-waywork-section">
            <div class="sn-waywork-container">
                <h2 class="sn-waywork-title">Hire Your Expert Marketing Team<br>at One FTE Cost</h2>
                <div class="sn-waywork-left">
                
                <div class="sn-waywork-feature-card" data-tab="import">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/assemble-team-icon.webp" alt="Import" class="sn-waywork-feature-icon" />
                    <div>
                    <h3 class="sn-waywork-feature-title">Assemble Your Multi-Skilled Marketing Team</h3>
                    <p class="sn-waywork-feature-desc">
                        Need a designer, a writer, and a marketer? You get them all for the price of one person. Our FTE model gives you a whole team of experts.
                    </p>
                    </div>
                </div>
                <div class="sn-waywork-feature-card" data-tab="user-access">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/cost-effective-icon.webp" alt="Import" class="sn-waywork-feature-icon" />
                    <div>
                    <h3 class="sn-waywork-feature-title">Cost-Effective Expertise</h3>
                    <p class="sn-waywork-feature-desc">
                        Don't invest money on many hires. Our FTE model gives you a whole team for the price of one. It's like getting a discount on experts.
                    </p>
                    </div>
                </div>
                <div class="sn-waywork-feature-card" data-tab="integrate">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/core-business-icon.webp" alt="Import" class="sn-waywork-feature-icon" />
                    <div>
                    <h3 class="sn-waywork-feature-title">Focus on Your Core Business</h3>
                    <p class="sn-waywork-feature-desc">
                        Don't worry about managing many people. Our FTE team takes care of everything. You focus on what you do best: growing your business.
                    </p>
                    </div>
                </div>
                <div class="sn-waywork-feature-card" data-tab="automate">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/flexibility-icon.webp" alt="Import" class="sn-waywork-feature-icon" />
                    <div>
                    <h3 class="sn-waywork-feature-title">Flexible and Scalable Solutions</h3>
                    <p class="sn-waywork-feature-desc">
                        Need to change your team? Our FTE model makes it easy. Add or remove skills as you need. It's like having a team that grows with you.
                    </p>
                    </div>
                </div>
                </div>
                <div class="sn-waywork-right">
                <div class="sn-waywork-image-container">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/multi-skilled-team.webp" alt="Import" class="sn-waywork-image active" data-tab="import" width="400" height="400" />
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/cost-effective.webp" alt="User Access" class="sn-waywork-image" data-tab="user-access" width="400" height="400" />
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/focus-on-your-core-business.webp" alt="Integrate" class="sn-waywork-image" data-tab="integrate" width="400" height="400" />
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/flexible-and-scalable.webp" alt="Automate" class="sn-waywork-image" data-tab="automate" width="400" height="400" />
                </div>
                </div>
            </div>
        </section>
        <style>
            .sn-waywork-section {
                background: #fff;
                padding: 60px 0;
            }
            .sn-waywork-container {
                display: flex;
                flex-wrap: wrap;
                max-width: 1300px;
                margin: 0 auto;
                gap: 20px;
                align-items: center;
                justify-content: space-between;
            }
            .sn-waywork-left {
                flex: 1 1 350px;
                min-width: 320px;
                max-width: 500px;
            }
            .sn-waywork-title {
                font-size: 54px;
                font-weight: 700;
                margin-bottom: 32px;
                color: #1e2154;
                width: 100%;
                position: relative;
                margin-top: 20px;
            }
            .sn-waywork-feature-card {
                display: flex;
                align-items: flex-start;
                gap: 18px;
                margin-bottom: 32px;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .sn-waywork-feature-card:hover {
                transform: translateX(10px);
            }
            .sn-waywork-feature-card.active {
                background: #FFF5F5;
                border-radius: 16px;
                padding: 24px 20px;
            }
            .sn-waywork-feature-icon {
                width: 36px;
                height: 36px;
                flex-shrink: 0;
            }
            .sn-waywork-feature-title {
                font-size: 24px;
                font-weight: 700;
                margin-bottom: 6px;
                color:#1e2154;
                cursor: pointer;
            }
            .sn-waywork-feature-desc {
                font-size: 16px;
                color: #444;
                margin: 0;
                max-height: 0;
                overflow: hidden;
            }
            .sn-waywork-feature-card.active .sn-waywork-feature-desc {
                max-height: 200px;
                margin-top: 12px;
            }
            .sn-waywork-right {
                flex: 1 1 350px;
                min-width: 320px;
                display: flex;
                justify-content: center;
            }
            .sn-waywork-image-container {
                position: relative;
                width: 400px;
                height: 400px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .sn-waywork-image {
                position: absolute;
                width: 100%;
                height: auto;
                object-fit: contain;
                opacity: 0;
                transform: scale(0.8);
                transition: all 0.5s ease;
                pointer-events: none;
            }
            .sn-waywork-image.active {
                opacity: 1;
                transform: scale(1);
                pointer-events: auto;
            }

            @media (max-width: 900px) {
                .sn-waywork-container {
                    flex-direction: column;
                    gap: 32px;
                }
                .sn-waywork-right {
                    margin-top: 32px;
                }
                .sn-waywork-image-container {
                    width: 300px;
                    height: 300px;
                }
                .sn-waywork-image {
                    width: 200px;
                    height: 200px;
                }
            }
            @media (max-width: 600px) {
                .sn-waywork-section{
                    padding: 50px 30px 30px;
                }
                .sn-waywork-title {
                    font-size: 32px;
                    text-align: center;
                }
                .sn-waywork-feature-title {
                    font-size: 18px;
                }
                .sn-waywork-feature-card {
                    padding: 16px 10px;
                }
            }
        </style>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const features = document.querySelectorAll('.sn-waywork-feature-card');
                const images = document.querySelectorAll('.sn-waywork-image');
                
                // Hide all descriptions initially
                features.forEach(feature => {
                    const desc = feature.querySelector('.sn-waywork-feature-desc');
                    desc.style.maxHeight = '0';
                });
                
                // Set initial active state for first feature
                features[0].classList.add('active');
                const firstDesc = features[0].querySelector('.sn-waywork-feature-desc');
                firstDesc.style.maxHeight = firstDesc.scrollHeight + 'px';
                
                features.forEach(feature => {
                    feature.addEventListener('click', function() {
                        const tabId = this.getAttribute('data-tab');
                        const desc = this.querySelector('.sn-waywork-feature-desc');
                        
                        // Remove active class from all features
                        features.forEach(f => {
                            f.classList.remove('active');
                            const d = f.querySelector('.sn-waywork-feature-desc');
                            d.style.maxHeight = '0';
                        });
                        
                        // Add active class to clicked feature
                        this.classList.add('active');
                        desc.style.maxHeight = desc.scrollHeight + 'px';
                        
                        // Hide all images
                        images.forEach(img => {
                            img.classList.remove('active');
                        });
                        
                        // Show corresponding image
                        const activeImage = document.querySelector(`.sn-waywork-image[data-tab="${tabId}"]`);
                        if (activeImage) {
                            activeImage.classList.add('active');
                        }
                    });
                });
            });
        </script>
        <section class="reliable-section">
            <div class="reliable-container">
                <h2 class="reliable-title">Your All-in-One Growth Partner</h2>
                <div class="reliable-grid">
                    <!-- Card 1 -->
                    <div class="reliable-card">
                        <div class="card-icon-wrapper">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/seamless-onboarding.webp" alt="Rocket Launch Icon" class="card-icon" loading="lazy" width="108" height="108">
                        </div>
                        <h3 class="card-title">Seamless Onboarding & Strategy</h3>
                        <p class="card-description">
                        We work with you to create a marketing and sales plan that fits your business. We help you grow without the stress.
                        </p>
                        <!-- <span class="card-number">01</span> -->
                    </div>
                    <!-- Card 2 -->
                    <div class="reliable-card">
                        <div class="card-icon-wrapper">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/dedicated-support.webp" alt="Globe Support Icon" class="card-icon" loading="lazy" width="108" height="108">
                        </div>
                        <h3 class="card-title">Dedicated Support</h3>
                        <p class="card-description">
                        Get help from our team of experts. We provide ongoing support and guidance. We're here to answer your questions and help you succeed.
                        </p>
                        <!-- <span class="card-number">02</span> -->
                    </div>
                    <!-- Card 3 -->
                    <div class="reliable-card">
                        <div class="card-icon-wrapper">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/new-home/secure-result.webp" alt="Security Shield Icon" class="card-icon" loading="lazy" width="108" height="108">
                        </div>
                        <h3 class="card-title">Secure and Result-Driven Approach</h3>
                        <p class="card-description">
                        We focus on getting you real results. We use proven methods to increase your sales and grow your business. Your data is safe with us.
                        </p>
                        <!-- <span class="card-number">03</span> -->
                    </div>
                </div>
            </div>
        </section>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Animate elements when they enter viewport
                const animateOnScroll = function() {
                    const section = document.querySelector('.reliable-section');
                    if (!section) return;
                    
                    const position = section.getBoundingClientRect();
                    
                    // If section is in viewport and not already animated
                    if (position.top < window.innerHeight * 0.8 && !section.classList.contains('animated')) {
                        section.classList.add('animated');
                        
                        // Animate title
                        const title = section.querySelector('.reliable-title');
                        if (title) {
                            title.style.opacity = '1';
                            title.style.transform = 'translateY(0)';
                        }
                        
                        // Animate cards with staggered delay
                        const cards = section.querySelectorAll('.reliable-card');
                        cards.forEach((card, index) => {
                            setTimeout(() => {
                                card.style.opacity = '1';
                                card.style.transform = 'translateY(0)';
                            }, 200 * (index + 1));
                        });
                    }
                };
                
                // Run animations on page load and scroll
                setTimeout(animateOnScroll, 100);
                window.addEventListener('scroll', animateOnScroll);
            });
        </script>
        <section class="sn-pricing-section">
            <div class="sn-container">
                <h2 class="sn-pricing-title">Get Your Dream Team, At One Simple Price</h2>
                
                <div class="sn-pricing-card">
                    <div class="sn-pricing-content">
                        <h3 class="sn-pricing-subtitle">Build Your Dream Marketing Team, At One FTE Price</h3>
                        
                        <div class="sn-pricing-features">
                            <div class="sn-feature-col">
                                <div class="sn-feature-item">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                    <span>We Work on Your Clock</span>
                                </div>
                                <div class="sn-feature-item">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                    <span>Customized Marketing Strategies</span>
                                </div>
                                <div class="sn-feature-item">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                    <span>Flexible Team Scaling</span>
                                </div>
                            </div>
                            <div class="sn-feature-col">
                                <div class="sn-feature-item">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                    <span>Centralized Team Management</span>
                                </div>
                                <div class="sn-feature-item">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                    <span>Performance Reporting & Analytics</span>
                                </div>
                                <div class="sn-feature-item">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                    <span>Dedicated Marketing Specialists</span>
                                </div>
                            </div>
                            <div class="sn-pricing-right">
                                <div class="sn-price-tag">
                                    <!-- <span class="sn-currency">$</span> -->
                                    <span class="sn-amount">$2,500</span>
                                </div>
                                <a href="<?php echo SN_HTTP_URL; ?>pricing/" class="sn-cta-button">KNOW MORE</a>
                            </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        </section>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Animate elements when they enter viewport
                const animatePricingSection = function() {
                    const section = document.querySelector('.pricing-section');
                    if (!section) return;
                    
                    const position = section.getBoundingClientRect();
                    
                    // If section is in viewport and not already animated
                    if (position.top < window.innerHeight * 0.8 && !section.classList.contains('animated')) {
                        section.classList.add('animated');
                        
                        // Reset animations to ensure they run
                        const title = section.querySelector('.pricing-title');
                        const card = section.querySelector('.pricing-card');
                        const features = section.querySelectorAll('.feature-item');
                        
                        if (title) title.style.animation = 'none';
                        if (card) card.style.animation = 'none';
                        features.forEach(item => item.style.animation = 'none');
                        
                        // Force reflow
                        void section.offsetWidth;
                        
                        // Re-add animations
                        if (title) {
                            title.style.animation = 'fadeInUp 0.8s ease-out forwards';
                            title.style.opacity = '0';
                        }
                        
                        if (card) {
                            card.style.animation = 'fadeInUp 0.8s ease-out forwards 0.2s';
                            card.style.opacity = '0';
                        }
                        
                        features.forEach((item, index) => {
                            item.style.animation = `fadeInUp 0.5s ease-out forwards ${0.3 + (index * 0.1)}s`;
                            item.style.opacity = '0';
                        });
                    }
                };
                
                // Run animation on page load and scroll
                setTimeout(animatePricingSection, 100);
                window.addEventListener('scroll', animatePricingSection);
            });
        </script>
        <?php salesnanny_footer(); ?>
      </div>
    </body>
</html>