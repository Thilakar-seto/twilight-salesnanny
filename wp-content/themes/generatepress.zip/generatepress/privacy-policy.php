<?php
/*
Template Name: Privacy Policy
*/
?>
<html>
<?php get_custom_head(); ?>
<body>
    <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
    <noscript>
        <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css"/>
    </noscript>
    <div>
        <style>
            body{margin:0;padding:0;font-family:"Lexend Deca",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif!important;color:#333;line-height:1.6;background-color:#f8f9fa;overflow-x:hidden}.terms-container{width:100%;margin:80px auto 0;padding:0}.terms-header{position:relative;background:linear-gradient(135deg,#c22034,#1e2154);padding:6rem 2rem;text-align:center;margin-bottom:0;box-shadow:0 10px 25px rgba(0,0,0,.15);display:flex;flex-direction:column;justify-content:center;align-items:center;min-height:350px;overflow:hidden}.terms-header::before{content:'';position:absolute;top:0;left:0;width:100%;height:100%;background-image:url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");opacity:.6}.terms-header h1{color:#fff;margin-bottom:1.5rem;font-size:3.5rem;font-weight:700;text-shadow:0 2px 4px rgba(0,0,0,.2);position:relative}.terms-header p{color:#fff;font-size:1.2rem;max-width:700px;margin:0 auto;opacity:.9;position:relative;line-height:1.6}.terms-content-wrapper{position:relative;margin-top:-50px;padding:0 20px;max-width:1200px;margin-left:auto;margin-right:auto}.terms-content{background-color:#fff;padding:3rem;border-radius:12px;margin:0 auto 4rem;box-shadow:0 15px 35px rgba(0,0,0,.1);position:relative;border-top:5px solid #c22034}.terms-content h2{color:#1e2154;font-size:1.8rem;font-weight:700;margin:2.5rem 0 1.5rem;padding-bottom:.5rem;border-bottom:2px solid rgba(194,32,52,.2)}.terms-content h2:first-child{margin-top:0}.terms-content p{color:#444;font-size:1.05rem;line-height:1.8;margin:1.5rem 0}.terms-content ol,.terms-content ul{margin:1.5rem 0 1.5rem 1rem;padding-left:1.5rem}.terms-content ol{list-style-type:decimal;counter-reset:item}.terms-content ol li{margin:1rem 0;color:#444;line-height:1.7}.terms-cta{text-align:center;margin:3rem 0 2rem;padding:2rem;background:rgba(194,32,52,.05);border-radius:8px;border-left:3px solid #c22034}.back-to-top,.terms-cta-button{background:#c22034;text-decoration:none;transition:.3s}.terms-cta p{font-size:1.1rem;margin-bottom:1.5rem}.terms-cta-button{display:inline-block;padding:.8rem 2rem;color:#fff;font-weight:600;border-radius:50px}.last-updated{display:block;text-align:right;margin-top:2rem;font-size:.9rem;color:#777;font-style:italic}.back-to-top{position:fixed;bottom:100px;right:30px;width:50px;height:50px;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;z-index:99;box-shadow:0 4px 10px rgba(0,0,0,.15)}
        </style>
        <?php salesnanny_nav_header(); ?>
            <div class="terms-container">
                <div class="terms-header">
                    <h1>Privacy Policy</h1>
                    <p>Please read these terms and conditions carefully before using our services. By accessing and using our website, you agree to be bound by these terms.</p>
                </div>
                <div class="terms-content-wrapper">
                    <div class="terms-content">
                        <h2>Welcome to SalesNanny!</h2>
                        <p>This privacy policy for SalesNanny ("Company," "we," "us," or "our"), describes how and why we might collect, store, use, and/or share ("process") your information when you use our services ("Services"), such as when you:</p>
                        <p>Visit our website at https://www.SalesNanny.com, or any website of ours that links to this privacy policy.</p>
                        <p>Engage with us in other related ways, including any sales, marketing, or events questions or concerns. Reading this privacy policy will help you understand your privacy rights and choices.</p>
                        <p>If you do not agree with our policies and practices, please do not use our Services. If you still have any questions or concerns, please contact us at support@SalesNanny.com.</p>
                       
                        <h2>Summary of Key Points</h2>
                        <p>This summary provides key points from our privacy policy, but you can find out more details about any of these topics by clicking the link following each key point or by using our table of contents below to find the section you are looking for.</p>
                       
                        <h2><span class="section-number">1.</span>+ What personal information do we process?</h2>
                        <p>When you visit, use, or navigate our Services, we may process personal information depending on how you interact with SalesNanny and the Services, the choices you make, and the products and features you use. Learn more about the personal information you disclose to us.</p>
                       
                        <h2><span class="section-number">2.</span>+ Do we process any sensitive personal information?</h2>
                        <p>We do not process sensitive personal information.</p>

                        <h2><span class="section-number">3.</span>+ Do we receive any information from third parties?</h2>
                        <p>We do not receive any information from third parties.</p>

                        <h2><span class="section-number">4.</span>+ How do you process my information?</h2>
                        <p>We process your information to provide, improve, and administer our Services, communicate with you, for security and fraud prevention, and to comply with law. We may also process your information for other purposes with your consent.</p>

                        <h2><span class="section-number">5.</span>+ How do you keep my information safe?</h2>
                        <p>We implement a variety of security measures to protect your personal information. However, no method of transmission over the internet is 100% secure.</p>
                       
                        <h2><span class="section-number">6.</span>+ In what situations and with which parties do we share personal information?</h2>
                        <p>We may share information in specific situations and with specific third parties. Learn more about when and with whom we share your personal information.</p>
                       
                        <h2><span class="section-number">7.</span>+ How do you keep my information safe?</h2>
                        <p>We implement a variety of security measures to protect your personal information. However, no method of transmission over the internet is 100% secure.</p>

                        <h2><span class="section-number">8.</span>+ What are your rights?</h2>
                        <p>Depending on where you are located geographically, the applicable privacy law may mean you have certain rights regarding your personal information. Learn more about your privacy rights.</p>
                        <p>Want to learn more about what SalesNanny does with any information we collect? Review the privacy policy in full.</p>
                        

                        <h2>TABLE OF CONTENTS</h2>
                        <ol>
                            <li>What Information do We Collect?</li>
                            <li>How do We Process Your Information?</li>
                            <li>What legal bases do we rely on to process your personal information?</li>
                            <li>Do We Use Cookies and Other Tracking Technologies?</li>
                            <li>How do We Handle Your Social Logins?</li>
                            <li>How Long do We Keep Your Information?</li>
                            <li>How do We Keep Your Information Safe?</li>
                            <li>Do We Collect Information from Minors?</li>
                            <li>What are Your Privacy Rights?</li>
                            <li>Do We Make Updates to this Policy?</li>
                            <li>How can You Contact Us About this Policy?</li>
                            <li>How can You Review, Update, or Delete the Data We Collect from You?</li>
                        </ol>
                       
                       
                       <h2>1. What Information do We Collect?</h2>
                       <p>Personal information you disclose to us</p>
                       <p>+ We collect personal information that you voluntarily provide to us when you register on the Services, express an interest in obtaining information about us or our products and Services when you participate in activities on the Services, or otherwise when you contact us.</p>
                       <p>+ Personal Information Provided by You. The personal information that we collect depends on the context of your interactions with us and the Services, the choices you make, and the products and features you use. The personal information we collect may include the following:</p>
                       <ul>
                            <li>Names</li>
                            <li>phone numbers</li>
                            <li>email addresses</li>
                            <li>contact preferences</li>
                            <li>contact or authentication data</li>
                            <li>billing addresses</li>
                            <li>business details</li>
                            <li>Payment Data: We may collect data necessary to process your payment if you make purchases, such as your payment instrument number, and the security code associated with your payment instrument. All payment data is stored by PayPal, Razorpay, and Stripe.</li>
                            <li>Social Media Login Data: We may provide you with the option to register with us using your existing social media accounts details, like your Facebook, Twitter, or other social media account.</li>
                            
                       </ul>
                       <p>+ Note: All personal information that you provide to us must be true, complete, and accurate, and you must notify us of any changes to such personal information.</p>
                       
                       <h2>1.1 Information automatically collected:</h2>
                       <p>+ We automatically collect certain information when you visit, use, or navigate the Services.</p>
                       <p>+ This information does not reveal your specific identity (like your name or contact information) but may include device and usage information, such as your IP address, browser and device characteristics, operating system, language preferences, referring URLs, device name, country, location, information about how and when you use our Services, and other technical information. This information is primarily needed to maintain the security and operation of our Services and for our internal analytics and reporting purposes.</p>

                       <h2>+ The information we collect includes:</h2>
                       <p>Log and Usage Data: Log and usage data is service-related, diagnostic, usage, and performance information our servers automatically collect when you access or use our Services and which we record in log files. Depending on how you interact with us, this log data may include your IP address, device information, browser type, and settings and information about your activity in the Services (such as the date/time stamps associated with your usage, pages and files viewed, searches, and other actions you take such as which features you use), device event information (such as system activity, error reports (sometimes called “crash dumps”), and hardware settings).</p>
                       <ul>
                            <li>Device Data: We collect device data such as information about your computer, phone, tablet, or other device you use to access the Services. Depending on the device used, this device data may include information such as your IP address (or proxy server), device and application identification numbers, location, browser type, hardware model, Internet service provider and/or mobile carrier, operating system, and system configuration information.</li>
                            <li>Location Data: We may collect and process information about your actual location, such as your IP address, GPS, and other sensors that may, for example, provide us with information about nearby devices, Wi-Fi networks, and cell towers.</li>
                        </ul>

                        <h2>2. How do We Process Your Information?</h2>
                        <p>We process your personal information for a variety of reasons, depending on how you interact with our Services, including:</p>
                        <ul>
                            <li>To facilitate account creation and authentication and otherwise manage user accounts. We may process your information so you can create and log in to your account, as well as keep your account in working order.</li>
                            <li>To deliver and facilitate the delivery of services to the user. We may process your information to provide you with the requested service.</li>
                            <li>To respond to user inquiries/offer support to users. We may process your information to respond to your inquiries and solve any potential issues you might have with the requested service.</li>
                            <li>To send administrative information to you. We may process your information to send you details about our products and services, changes to our terms and policies, and other similar information.</li>
                            <li>To fulfill and manage your orders. We may process your information to fulfill and manage your orders, payments, returns, and exchanges made through the Services.</li>
                            <li>To enable user-to-user communications. We may process your information if you choose to use any of our offerings that allow for communication with another user.</li>
                            <li>To portray our potential customer list on our website.</li>
                            <li>To request feedback & post them on our site as customer reviews.</li>
                            <li>To send you marketing and promotional communications.</li>
                            <li>To deliver targeted advertising to you.</li>
                            <li>To identify usage trends.</li>
                            <li>To determine the effectiveness of our marketing and promotional campaigns.</li>
                            <li>To save or protect an individual’s vital interest.</li>
                        </ul>
                        
                        <h2>3. What Legal Bases do We Rely on to Process Your Information? If you are located in the EU or UK, this section applies to you.</h2>
                        <p>+ The General Data Protection Regulation (GDPR) and UK GDPR require us to explain the valid legal bases we rely on in order to process your personal information. As such, we may rely on the following legal bases to process your personal information:</p>
                        <ol>
                            <li>i) Consent: We may process your information if you have given us permission (i.e., consent) to use your personal information for a specific purpose. You can withdraw your consent at any time. Learn more about withdrawing your consent.</li>
                            <li>ii) Performance of a Contract: We may process your personal information when we believe it is necessary to fulfill our contractual obligations to you, including providing our Services or at your request prior to entering into a contract with you.</li>
                            <li>iii) Legitimate Interests: We may process your information when we believe it is reasonably necessary to achieve our legitimate business interests and those interests do not outweigh your interests and fundamental rights and freedoms. For example, we may process your personal information for some of the purposes described in order to:</li>
                        </ol>
                        <ul>
                            <li>Send users information about special offers and discounts on our products and services</li>
                            <li>Develop and display personalized and relevant advertising content for our users</li>
                            <li>Analyze how our Services are used so we can improve them to engage and retain users</li>
                            <li>Support our marketing activities</li>
                            <li>Understand how our users use our products and services so we can improve user experience</li>
                        </ul>
                        <ol>
                            <li>iv) Legal Obligations: We may process your information where we believe it is necessary for compliance with our legal obligations, such as to cooperate with a law enforcement body or regulatory agency, exercise or defend our legal rights, or disclose your information as evidence in litigation in which we are involved.</li>
                            <li>v) Vital Interests: We may process your information where we believe it is necessary to protect your vital interests or the vital interests of a third party, such as situations involving potential threats to the safety of any person.</li>
                        </ol>

                        <h2>If you are located in Canada, this section applies to you.</h2>
                        <p>+ We may process your information if you have given us specific permission (i.e., express consent) to use your personal information for a specific purpose, or in situations where your permission can be inferred (i.e., implied consent). You can withdraw your consent at any time.</p>
                        <p>+ In some exceptional cases, we may be legally permitted under applicable law to process your information without your consent, including, for example:</p>
                        <ol>
                            <li>If collection is clearly in the interests of an individual and consent cannot be obtained in a timely way.</li>
                            <li>For investigations and fraud detection and prevention.</li>
                            <li>For business transactions provided certain conditions are met.</li>
                            <li>If it is contained in a witness statement and the collection is necessary to assess, process, or settle an insurance claim.</li>
                            <li>For identifying injured, ill, or deceased persons and communicating with next of kin.</li>
                            <li>If we have reasonable grounds to believe that an individual has been, is, or may be victim of financial abuse.</li>
                            <li>If it is reasonable to expect collection and use with consent would compromise the availability or the accuracy of the information and the collection is reasonable for purposes related to investigating a breach of an agreement or a contravention of the laws of Canada or a province.</li>
                            <li>If disclosure is required to comply with a subpoena, warrant, court order, or rules of the court relating to the production of records.</li>
                            <li>If it was produced by an individual in the course of their employment, business, or profession and the collection is consistent with the purposes for which the information was produced.</li>
                            <li>If the collection is solely for journalistic, artistic, or literary purposes.</li>
                            <li>If the information is publicly available and is specified by the regulations.</li>
                        </ol>
                        
                        <h2>4. Do We Use Cookies and Other Tracking Technologies?</h2>
                        <p>+ We may use cookies and similar tracking technologies (like web beacons and pixels) to access or store information</p>

                        <h2>5. How do We Handle Your Social Logins?</h2>
                        <p>+ Our Services offer you the ability to register and log in using your third-party social media account details (like your Facebook or Twitter logins). Where you choose to do this, we will receive certain profile information about you from your social media provider. The profile information we receive may vary depending on the social media provider concerned, but will often include your name, email address, friends list, and profile picture, as well as other information you choose to make public on such a social media platform.</p>
                        <p>+ We will use the information we receive only for the purposes that are described in this privacy policy or that are otherwise made clear to you on the relevant Services. Please note that we do not control, and are not responsible for, other uses of your personal information by your third-party social media provider. We recommend that you review their privacy policy to understand how they collect, use, and share your personal information, and how you can set your privacy preferences on their sites and apps.</p>

                        <h2>6. How Long do We Keep Your Information?</h2>
                        <p>+ We will only keep your personal information for as long as it is necessary for the purposes set out in this privacy policy unless a longer retention period is required or permitted by law (such as tax, accounting, or other legal requirements). No purpose in this notice will require us to keep your personal information for longer than the period of time in which users have an account with us.</p>
                        <p>+ When we have no ongoing legitimate business need to process your personal information, we will either delete or anonymize such information, or, if this is not possible (for example, because your personal information has been stored in backup archives), then we will securely store your personal information and isolate it from any further processing until deletion is possible.</p>

                        <h2>7. How do We Keep Your Information Safe?</h2>
                        <p>+ We have implemented appropriate and reasonable technical and organizational security measures designed to protect the security of any personal information we process. However, despite our safeguards and efforts to secure your information, no electronic transmission over the Internet or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security and improperly collect, access, steal, or modify your information.</p>
                        <p>+ Although we will do our best to protect your personal information, the transmission of personal information to and from our Services is at your own risk. You should only access the Services within a secure environment.</p>
                        
                        <h2>8. Do We Collect Information from Minors?</h2>
                        <p>+ We do not knowingly solicit data from or market to children under 18 years of age. By using the Services, you represent that you are at least 18 or that you are the parent or guardian of such a minor and consent to such minor dependent’s use of the Services.</p>
                        <p>+ If we learn that personal information from users less than 18 years of age has been collected, we will deactivate the account and take reasonable measures to promptly delete such data from our records.xx</p>
                        <p>+ If you become aware of any data we may have collected from children under the age of 18, please contact us at support@SalesNanny.com.</p>

                        <h2>9. What are Your Privacy Rights?</h2>
                        <p>+ In some regions (like the EEA, UK, and Canada), you have certain rights under applicable data protection laws. These may include the right</p>
                        <p>(i) to request access and obtain a copy of your personal information,</p>
                        <p>(ii) to request rectification or erasure;</p>
                        <p>(iii) to restrict the processing of your personal information; and</p>
                        <p>(iv) if applicable, to data portability. In certain circumstances, you may also have the right to object to the processing of your personal information. You can make such a request by contacting us via email (support@SalesNanny.com)</p>
                        <p>+ We will consider and act upon any request in accordance with applicable data protection laws.</p>
                        <p>+ If you are located in the EEA or UK and you believe we are unlawfully processing your personal information, you also have the right to complain to your Member State data protection authority or UK data protection authority.</p>
                        <p>+ If you are located in Switzerland, you may contact the Federal Data Protection and Information Commissioner.</p>
                        <p>+ If we are relying on your consent to process your personal information, which may be express and/or implied consent depending on the applicable law, you have the right to withdraw your consent at any time. You can withdraw your consent at any time by contacting us via email (support@SalesNanny.com).;</p>
                        <p>+ However, please note that this will not affect the lawfulness of the processing before its withdrawal nor when applicable law allows, will it affect the processing of your personal information conducted in reliance on lawful processing grounds other than consent.</p>
                        <p>+ You can unsubscribe from our marketing and promotional communications at any time by clicking on the unsubscribe link in the emails that we send, replying “STOP” or “UNSUBSCRIBE” to the SMS messages that we send, by sending mail to support@SalesNanny.com.</p>
                        <p>+ You will then be removed from the marketing lists. However, we may still communicate with you — for example, to send you service-related messages that are necessary for the administration and use of your account, to respond to service requests, or for other non-marketing purposes.</p>
                        <p>+ If you would at any time like to review or change the information in your account or terminate your account, you can:</p>
                        <ol>
                            <li>Log in to your account settings and update your user account.</li>
                            <li>Contact us using the contact information provided.</li>
                            <li>Mail at support@SalesNanny.com</li>
                        </ol>
                        <p>+ Upon your request to terminate your account, we will deactivate or delete your account and information from our active databases. However, we may retain some information in our files to prevent fraud, troubleshoot problems, assist with any investigations, enforce our legal terms, and/or comply with applicable legal requirements.</p>
                        <p>+ Most Web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove cookies and to reject cookies. If you choose to remove cookies or reject cookies, this could affect certain features or services of our Services. You may also opt out of interest-based advertising by advertisers on our Services.</p>
                        <p>+ If you have questions or comments about your privacy rights, you may email us at support@SalesNanny.com.</p>

                        <h2>10. Do We Make Updates to this Policy?</h2>
                        <p>+ We may update this privacy policy from time to time. The updated version will be indicated by an updated “Revised” date and the updated version will be effective as soon as it is accessible.</p>
                        <p>+ If we make material changes to this privacy notice, we may notify you either by prominently posting a notice of such changes or by directly sending you a notification. We encourage you to review this privacy notice frequently to be informed of how we are protecting your information.</p>
                        
                        <h2>11. How can You Contact Us About this Policy?</h2>
                        <p>+ If you have questions or comments about this notice, you may email us at support@SalesNanny.com or contact us by post at:</p>
                        <p>SalesNanny</p>
                        <p>13, Customs Colony, Off OMR, Parthasarathy Nagar,</p>
                        <p>Customs Colony, Sakthi Nagar, Thoraipakkam,</p>
                        <p>Tamil Nadu, India – 600097.7</p>

                        <h2>12. How can You Review, Update, or Delete the Data We Collect from You?</h2>
                        <p>+ You have the right to request access to the personal information we collect from you, change that information, or delete it. To request to review, update, or delete your personal information, please mail support@SalesNanny.com.</p>
                        <div class="terms-cta">
                            <p>Have questions about our Privacy Policy? We're here to help.</p>
                            <a href="<?php echo SN_HTTP_URL; ?>contact/" class="terms-cta-button">Contact Us</a>
                        </div>
                        <span class="last-updated">Last updated: <?php echo date('F d, Y'); ?></span>
                    </div>
                </div>
                <a href="#" class="back-to-top">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 15l-6-6-6 6"/>
                    </svg>
                </a>
            </div>
            <script>
                // Back to top button functionality
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTopButton = document.querySelector('.back-to-top');
                    
                    // Show button when user scrolls down 300px
                    window.addEventListener('scroll', function() {
                        if (window.pageYOffset > 300) {
                            backToTopButton.classList.add('visible');
                        } else {
                            backToTopButton.classList.remove('visible');
                        }
                    });
                    
                    // Smooth scroll to top when button is clicked
                    backToTopButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
            </script>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>