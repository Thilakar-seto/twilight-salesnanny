<?php
/**
 * Website Analyzer Configuration
 * 
 * Configuration file for API keys and settings
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class WebsiteAnalyzerConfig {
    
    // API Keys - Add your API keys here
    const GOOGLE_PAGESPEED_API_KEY = 'AIzaSyCj0WWunhya1bSyKZFdI72jIohSobxWA18'; // Google PageSpeed Insights API Key
    
    // API Endpoints
    const GOOGLE_PAGESPEED_API_URL = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
    
    // Analysis settings
    const MAX_ANALYSIS_TIME = 60; // Maximum time for analysis in seconds
    const CACHE_DURATION = 3600; // Cache results for 1 hour
    
    // Free tier limits
    const DAILY_ANALYSIS_LIMIT = 100; // Limit per day for free usage
    
    /**
     * Get Google PageSpeed Insights API key
     */
    public static function getPageSpeedApiKey() {
        // First check for environment variable (recommended)
        if (defined('GOOGLE_PAGESPEED_API_KEY')) {
            return GOOGLE_PAGESPEED_API_KEY;
        }
        
        // Fallback to constant
        return self::GOOGLE_PAGESPEED_API_KEY;
    }
    
    /**
     * Check if API key is configured
     */
    public static function isApiKeyConfigured() {
        return !empty(self::getPageSpeedApiKey());
    }
    
    /**
     * Get analysis options
     */
    public static function getAnalysisOptions() {
        return [
            'categories' => ['performance', 'seo', 'accessibility', 'best-practices'],
            'strategies' => ['mobile', 'desktop'],
            'timeout' => self::MAX_ANALYSIS_TIME,
            'cache_duration' => self::CACHE_DURATION
        ];
    }
    
    /**
     * Check daily usage limit
     */
    public static function checkDailyLimit() {
        $today = date('Y-m-d');
        $usage_key = 'analyzer_usage_' . $today;
        $current_usage = get_transient($usage_key) ?: 0;
        
        return $current_usage < self::DAILY_ANALYSIS_LIMIT;
    }
    
    /**
     * Increment daily usage
     */
    public static function incrementUsage() {
        $today = date('Y-m-d');
        $usage_key = 'analyzer_usage_' . $today;
        $current_usage = get_transient($usage_key) ?: 0;
        
        set_transient($usage_key, $current_usage + 1, DAY_IN_SECONDS);
    }
}

/**
 * Setup instructions for API configuration
 */
class AnalyzerSetupGuide {
    
    public static function getGoogleApiSetupInstructions() {
        return [
            'step1' => [
                'title' => 'Create Google Cloud Project',
                'description' => 'Visit Google Cloud Console and create a new project',
                'url' => 'https://console.cloud.google.com/'
            ],
            'step2' => [
                'title' => 'Enable PageSpeed Insights API',
                'description' => 'Navigate to APIs & Services > Library and enable PageSpeed Insights API',
                'url' => 'https://console.cloud.google.com/apis/library'
            ],
            'step3' => [
                'title' => 'Create API Key',
                'description' => 'Go to APIs & Services > Credentials and create an API key',
                'url' => 'https://console.cloud.google.com/apis/credentials'
            ],
            'step4' => [
                'title' => 'Configure API Key',
                'description' => 'Add your API key to the configuration file or wp-config.php',
                'example' => "define('GOOGLE_PAGESPEED_API_KEY', 'your-api-key-here');"
            ]
        ];
    }
    
    public static function displaySetupInstructions() {
        if (!WebsiteAnalyzerConfig::isApiKeyConfigured()) {
            echo '<div class="notice notice-warning">';
            echo '<h3>API Configuration Required</h3>';
            echo '<p>To use real API data, please configure your Google PageSpeed Insights API key:</p>';
            echo '<ol>';
            
            foreach (self::getGoogleApiSetupInstructions() as $step) {
                echo '<li>';
                echo '<strong>' . $step['title'] . '</strong><br>';
                echo $step['description'];
                if (isset($step['url'])) {
                    echo ' <a href="' . $step['url'] . '" target="_blank">→ Open</a>';
                }
                if (isset($step['example'])) {
                    echo '<br><code>' . $step['example'] . '</code>';
                }
                echo '</li>';
            }
            
            echo '</ol>';
            echo '<p><strong>Free Tier:</strong> 25,000 requests per day</p>';
            echo '</div>';
        }
    }
}
