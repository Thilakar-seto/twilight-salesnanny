<?php
/**
 * Template Name: Real API Website Analyzer
 * 
 * A comprehensive website analysis tool that uses real APIs:
 * - Google PageSpeed Insights API for performance data
 * - Custom SEO analysis
 * - Security checks
 * - Accessibility testing
 * - Technology detection
 * 
 * @package GeneratePress
 */

// Enqueue dependencies
function enqueue_real_api_analyzer_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0');
}
add_action('wp_enqueue_scripts', 'enqueue_real_api_analyzer_scripts');

// Ensure jQuery is loaded in header for this page
add_action('wp_head', function() {
    if (is_page_template('real-api-website-analyzer.php')) {
        wp_print_scripts('jquery');
    }
});

get_header(); ?>

<div class="real-api-analyzer-container">
    <div class="container">
        <div class="analyzer-header">
            <h1><i class="fas fa-analytics"></i> Real API Website Analyzer</h1>
            <p>Get comprehensive website analysis using real APIs - Google PageSpeed Insights, SEO analysis, and more!</p>
        </div>

        <div class="analyzer-form-section">
            <div class="form-card">
                <h3>Enter Website URL for Analysis</h3>
                <form id="real-api-analyzer-form">
                    <div class="form-group">
                        <label for="website_url">Website URL *</label>
                        <input type="url" id="website_url" name="website_url" placeholder="https://example.com" required>
                        <small>Enter the complete URL including https://</small>
                    </div>
                    <div class="analysis-options">
                        <h4>Analysis Options</h4>
                        <div class="options-grid">
                            <label class="option-card">
                                <input type="checkbox" name="analyze_mobile" checked>
                                <div class="option-content">
                                    <i class="fas fa-mobile-alt"></i>
                                    <span>Mobile Analysis</span>
                                </div>
                            </label>
                            <label class="option-card">
                                <input type="checkbox" name="analyze_desktop" checked>
                                <div class="option-content">
                                    <i class="fas fa-desktop"></i>
                                    <span>Desktop Analysis</span>
                                </div>
                            </label>
                            <label class="option-card">
                                <input type="checkbox" name="analyze_seo" checked>
                                <div class="option-content">
                                    <i class="fas fa-search"></i>
                                    <span>SEO Analysis</span>
                                </div>
                            </label>
                            <label class="option-card">
                                <input type="checkbox" name="analyze_security" checked>
                                <div class="option-content">
                                    <i class="fas fa-shield-alt"></i>
                                    <span>Security Check</span>
                                </div>
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="analyze-btn">
                        <span class="btn-text">
                            <i class="fas fa-rocket"></i> Start Analysis
                        </span>
                        <span class="btn-loading" style="display: none;">
                            <i class="fas fa-spinner fa-spin"></i> Analyzing...
                        </span>
                    </button>
                </form>
            </div>
        </div>

        <div id="analysis-progress" class="progress-section" style="display: none;">
            <div class="progress-card">
                <h3>Analysis in Progress</h3>
                <div class="progress-steps">
                    <div class="step" id="step-pagespeed">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>PageSpeed Analysis</span>
                        <div class="step-status">Waiting...</div>
                    </div>
                    <div class="step" id="step-seo">
                        <i class="fas fa-search"></i>
                        <span>SEO Analysis</span>
                        <div class="step-status">Waiting...</div>
                    </div>
                    <div class="step" id="step-security">
                        <i class="fas fa-shield-alt"></i>
                        <span>Security Check</span>
                        <div class="step-status">Waiting...</div>
                    </div>
                    <div class="step" id="step-accessibility">
                        <i class="fas fa-universal-access"></i>
                        <span>Accessibility</span>
                        <div class="step-status">Waiting...</div>
                    </div>
                </div>
                <div class="overall-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progress-fill"></div>
                    </div>
                    <div class="progress-text" id="progress-text">0% Complete</div>
                </div>
            </div>
        </div>

        <div id="analysis-results" class="results-section" style="display: none;">
            <!-- Results will be populated here -->
        </div>
    </div>
</div>

<style>
.real-api-analyzer-container {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 20px 0;
    margin: 80px auto 0px;
}

.analyzer-header {
    text-align: center;
    color: white;
    margin-bottom: 40px;
}

.analyzer-header h1 {
    font-size: 2.5rem;
    margin-bottom: 15px;
    font-weight: 700;
}

.analyzer-header p {
    font-size: 1.2rem;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
}

.form-card {
    background: white;
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.form-card h3 {
    text-align: center;
    margin-bottom: 30px;
    color: #333;
    font-size: 1.8rem;
}

.form-group {
    margin-bottom: 25px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #555;
}

.form-group input[type="url"] {
    width: 100%;
    padding: 15px;
    border: 2px solid #e1e5e9;
    border-radius: 10px;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

.form-group input[type="url"]:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-group small {
    color: #666;
    font-size: 0.9rem;
    margin-top: 5px;
    display: block;
}

.analysis-options {
    margin: 30px 0;
}

.analysis-options h4 {
    margin-bottom: 20px;
    color: #333;
    font-size: 1.2rem;
}

.options-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
}

.option-card {
    background: #f8f9fa;
    border-radius: 15px;
    padding: 20px;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px solid transparent;
}

.option-card:hover {
    background: #e9ecef;
    transform: translateY(-2px);
}

.option-card input[type="checkbox"] {
    display: none;
}

.option-card input[type="checkbox"]:checked + .option-content {
    color: #667eea;
}

.option-card input[type="checkbox"]:checked {
    background: #667eea;
}

.option-card.checked {
    border-color: #667eea;
    background: #f0f4ff;
}

.option-content i {
    font-size: 1.5rem;
    margin-bottom: 10px;
    display: block;
}

.option-content span {
    font-weight: 600;
    font-size: 0.9rem;
}

.analyze-btn {
    width: 100%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    padding: 18px;
    border-radius: 15px;
    font-size: 18px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.analyze-btn:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
}

.progress-section {
    margin-bottom: 30px;
}

.progress-card {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
}

.progress-card h3 {
    text-align: center;
    margin-bottom: 30px;
    color: #333;
}

.progress-steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.step {
    text-align: center;
    padding: 20px;
    border-radius: 15px;
    background: #f8f9fa;
    transition: all 0.3s ease;
}

.step.active {
    background: #e3f2fd;
    border: 2px solid #2196f3;
}

.step.completed {
    background: #e8f5e8;
    border: 2px solid #4caf50;
}

.step i {
    font-size: 2rem;
    margin-bottom: 10px;
    display: block;
    color: #666;
}

.step.active i {
    color: #2196f3;
}

.step.completed i {
    color: #4caf50;
}

.step span {
    font-weight: 600;
    display: block;
    margin-bottom: 10px;
}

.step-status {
    font-size: 0.9rem;
    color: #666;
}

.overall-progress {
    text-align: center;
}

.progress-bar {
    width: 100%;
    height: 20px;
    background: #e1e5e9;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 15px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    width: 0%;
    transition: width 0.5s ease;
}

.progress-text {
    font-weight: 600;
    color: #333;
    font-size: 1.1rem;
}

.results-section {
    background: white;
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .analyzer-header h1 {
        font-size: 2rem;
    }
    
    .form-card {
        padding: 25px;
    }
    
    .options-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .progress-steps {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Handle option card selection
    $('.option-card').click(function() {
        const checkbox = $(this).find('input[type="checkbox"]');
        checkbox.prop('checked', !checkbox.prop('checked'));
        
        if (checkbox.prop('checked')) {
            $(this).addClass('checked');
        } else {
            $(this).removeClass('checked');
        }
    });

    // Initialize checked state
    $('.option-card input[type="checkbox"]:checked').each(function() {
        $(this).closest('.option-card').addClass('checked');
    });

    $('#real-api-analyzer-form').on('submit', function(e) {
        e.preventDefault();
        
        const url = $('#website_url').val();
        
        if (!url) {
            alert('Please enter a website URL.');
            return;
        }

        // Get selected analysis options
        const options = {
            mobile: $('input[name="analyze_mobile"]').prop('checked'),
            desktop: $('input[name="analyze_desktop"]').prop('checked'),
            seo: $('input[name="analyze_seo"]').prop('checked'),
            security: $('input[name="analyze_security"]').prop('checked')
        };

        startAnalysis(url, options);
    });

    function startAnalysis(url, options) {
        // Show loading state
        $('.btn-text').hide();
        $('.btn-loading').show();
        $('.analyze-btn').prop('disabled', true);
        
        // Show progress section
        $('#analysis-progress').show();
        $('#analysis-results').hide();
        
        // Reset progress
        updateProgress(0);
        resetSteps();
        
        // Start the analysis
        performRealAPIAnalysis(url, options);
    }

    function performRealAPIAnalysis(url, options) {
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'real_api_website_analysis',
                url: url,
                options: options,
                nonce: '<?php echo wp_create_nonce('real_api_analysis_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    displayRealResults(response.data);
                } else {
                    alert('Analysis failed: ' + (response.data || 'Unknown error'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Analysis error:', error);
                alert('An error occurred during analysis. Please try again.');
            },
            complete: function() {
                // Reset button state
                $('.btn-text').show();
                $('.btn-loading').hide();
                $('.analyze-btn').prop('disabled', false);
            }
        });
    }

    function updateProgress(percentage) {
        $('#progress-fill').css('width', percentage + '%');
        $('#progress-text').text(percentage + '% Complete');
    }

    function updateStep(stepId, status) {
        const step = $('#' + stepId);
        step.removeClass('active completed');
        
        if (status === 'active') {
            step.addClass('active');
            step.find('.step-status').text('Processing...');
        } else if (status === 'completed') {
            step.addClass('completed');
            step.find('.step-status').text('Completed');
        }
    }

    function resetSteps() {
        $('.step').removeClass('active completed');
        $('.step-status').text('Waiting...');
    }

    function displayRealResults(data) {
        // Hide progress, show results
        $('#analysis-progress').hide();
        $('#analysis-results').show();
        
        // Populate results
        const resultsHtml = generateResultsHTML(data);
        $('#analysis-results').html(resultsHtml);
        
        // Scroll to results
        $('html, body').animate({
            scrollTop: $('#analysis-results').offset().top - 50
        }, 500);
    }

    function generateResultsHTML(data) {
        return `
            <div class="results-header">
                <h2>Analysis Results for ${data.url}</h2>
                <div class="analysis-date">Analyzed on: ${new Date().toLocaleDateString()}</div>
            </div>
            
            <div class="overall-scores">
                <div class="score-card mobile-score">
                    <h3>Mobile Score</h3>
                    <div class="score-circle ${getScoreClass(data.mobile?.performance?.score)}">
                        ${data.mobile?.performance?.score || 'N/A'}
                    </div>
                </div>
                <div class="score-card desktop-score">
                    <h3>Desktop Score</h3>
                    <div class="score-circle ${getScoreClass(data.desktop?.performance?.score)}">
                        ${data.desktop?.performance?.score || 'N/A'}
                    </div>
                </div>
            </div>
            
            <div class="detailed-results">
                ${data.mobile ? generateDeviceResults('Mobile', data.mobile) : ''}
                ${data.desktop ? generateDeviceResults('Desktop', data.desktop) : ''}
                ${data.seo ? generateSEOResults(data.seo) : ''}
                ${data.security ? generateSecurityResults(data.security) : ''}
            </div>
        `;
    }

    function generateDeviceResults(deviceType, data) {
        return `
            <div class="result-section">
                <h3>${deviceType} Performance Analysis</h3>
                <div class="metrics-grid">
                    <div class="metric-card">
                        <h4>Performance Score</h4>
                        <div class="metric-value ${getScoreClass(data.performance?.score)}">${data.performance?.score || 'N/A'}</div>
                    </div>
                    <div class="metric-card">
                        <h4>First Contentful Paint</h4>
                        <div class="metric-value">${data.metrics?.['first-contentful-paint']?.displayValue || 'N/A'}</div>
                    </div>
                    <div class="metric-card">
                        <h4>Largest Contentful Paint</h4>
                        <div class="metric-value">${data.metrics?.['largest-contentful-paint']?.displayValue || 'N/A'}</div>
                    </div>
                    <div class="metric-card">
                        <h4>Speed Index</h4>
                        <div class="metric-value">${data.metrics?.['speed-index']?.displayValue || 'N/A'}</div>
                    </div>
                </div>
                
                ${data.opportunities && data.opportunities.length > 0 ? `
                    <div class="opportunities-section">
                        <h4>Optimization Opportunities</h4>
                        <ul class="opportunities-list">
                            ${data.opportunities.map(opp => `
                                <li>
                                    <strong>${opp.title}</strong>
                                    <p>${opp.description}</p>
                                    ${opp.details?.savings ? `<span class="savings">Potential savings: ${opp.details.savings}</span>` : ''}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                ` : ''}
            </div>
        `;
    }

    function generateSEOResults(data) {
        return `
            <div class="result-section">
                <h3>SEO Analysis</h3>
                <div class="seo-grid">
                    <div class="seo-card">
                        <h4>SEO Score</h4>
                        <div class="metric-value ${getScoreClass(data.score)}">${data.score || 'N/A'}</div>
                    </div>
                    <div class="seo-details">
                        ${data.audits ? `
                            <h4>SEO Audits</h4>
                            <ul class="audit-list">
                                ${Object.values(data.audits).slice(0, 5).map(audit => `
                                    <li class="${audit.score >= 0.9 ? 'pass' : 'fail'}">
                                        ${audit.title}: ${audit.score >= 0.9 ? 'PASS' : 'NEEDS ATTENTION'}
                                    </li>
                                `).join('')}
                            </ul>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    function generateSecurityResults(data) {
        return `
            <div class="result-section">
                <h3>Security Analysis</h3>
                <div class="security-items">
                    ${data.https ? `<div class="security-item pass">✓ HTTPS Enabled</div>` : `<div class="security-item fail">✗ HTTPS Not Enabled</div>`}
                    ${data.headers?.map(header => `
                        <div class="security-item ${header.present ? 'pass' : 'fail'}">
                            ${header.present ? '✓' : '✗'} ${header.name}
                        </div>
                    `).join('') || ''}
                </div>
            </div>
        `;
    }

    function getScoreClass(score) {
        if (!score) return 'no-score';
        if (score >= 90) return 'excellent';
        if (score >= 70) return 'good';
        if (score >= 50) return 'average';
        return 'poor';
    }
});
</script>

<style>
.results-header {
    text-align: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 2px solid #e1e5e9;
}

.results-header h2 {
    color: #333;
    margin-bottom: 10px;
}

.analysis-date {
    color: #666;
    font-size: 0.9rem;
}

.overall-scores {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 40px;
}

.score-card {
    text-align: center;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 15px;
}

.score-circle {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    color: white;
    font-size: 1.5rem;
    font-weight: bold;
}

.score-circle.excellent { background: #4caf50; }
.score-circle.good { background: #2196f3; }
.score-circle.average { background: #ff9800; }
.score-circle.poor { background: #f44336; }
.score-circle.no-score { background: #666; }

.result-section {
    margin-bottom: 40px;
    padding: 30px;
    border: 1px solid #e1e5e9;
    border-radius: 15px;
}

.result-section h3 {
    margin-bottom: 20px;
    color: #333;
    border-bottom: 2px solid #667eea;
    padding-bottom: 10px;
}

.metrics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.metric-card {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 10px;
    text-align: center;
}

.metric-card h4 {
    margin-bottom: 10px;
    font-size: 0.9rem;
    color: #666;
}

.metric-value {
    font-size: 1.2rem;
    font-weight: bold;
    color: #333;
}

.opportunities-list {
    list-style: none;
    padding: 0;
}

.opportunities-list li {
    background: #fff3cd;
    margin-bottom: 10px;
    padding: 15px;
    border-radius: 8px;
    border-left: 4px solid #ffc107;
}

.opportunities-list strong {
    color: #856404;
}

.savings {
    background: #d4edda;
    color: #155724;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.8rem;
}

.audit-list {
    list-style: none;
    padding: 0;
}

.audit-list li {
    padding: 8px 0;
    border-bottom: 1px solid #e1e5e9;
}

.audit-list li.pass {
    color: #155724;
}

.audit-list li.fail {
    color: #721c24;
}

.security-items {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 10px;
}

.security-item {
    padding: 10px;
    border-radius: 8px;
    font-weight: 600;
}

.security-item.pass {
    background: #d4edda;
    color: #155724;
}

.security-item.fail {
    background: #f8d7da;
    color: #721c24;
}
</style>

<?php
// AJAX handler for real API analysis
add_action('wp_ajax_real_api_website_analysis', 'handle_real_api_analysis');
add_action('wp_ajax_nopriv_real_api_website_analysis', 'handle_real_api_analysis');

function handle_real_api_analysis() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'real_api_analysis_nonce')) {
        wp_send_json_error('Security check failed');
    }
    
    $url = sanitize_url($_POST['url']);
    $options = $_POST['options'];
    
    if (empty($url)) {
        wp_send_json_error('Please provide a website URL');
    }
    
    $analysis_result = [];
    
    // Google PageSpeed Insights Analysis
    if ($options['mobile'] || $options['desktop']) {
        $pagespeed_data = get_pagespeed_insights($url, $options);
        if ($pagespeed_data) {
            $analysis_result = array_merge($analysis_result, $pagespeed_data);
        }
    }
    
    // SEO Analysis
    if ($options['seo']) {
        $seo_data = analyze_seo($url);
        if ($seo_data) {
            $analysis_result['seo'] = $seo_data;
        }
    }
    
    // Security Analysis
    if ($options['security']) {
        $security_data = analyze_security($url);
        if ($security_data) {
            $analysis_result['security'] = $security_data;
        }
    }
    
    $analysis_result['url'] = $url;
    $analysis_result['timestamp'] = time();
    
    wp_send_json_success($analysis_result);
}

function get_pagespeed_insights($url, $options) {
    // You can get a free API key from Google Cloud Console
    $api_key = ''; // Add your Google PageSpeed Insights API key here
    $base_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
    
    $result = [];
    
    if ($options['mobile']) {
        $mobile_url = $base_url . '?' . http_build_query([
            'url' => $url,
            'strategy' => 'mobile',
            'category' => 'performance',
            'category' => 'seo',
            'key' => $api_key
        ]);
        
        $mobile_response = wp_remote_get($mobile_url, ['timeout' => 30]);
        if (!is_wp_error($mobile_response)) {
            $mobile_data = json_decode(wp_remote_retrieve_body($mobile_response), true);
            if ($mobile_data && isset($mobile_data['lighthouseResult'])) {
                $result['mobile'] = parse_lighthouse_result($mobile_data['lighthouseResult']);
            }
        }
    }
    
    if ($options['desktop']) {
        $desktop_url = $base_url . '?' . http_build_query([
            'url' => $url,
            'strategy' => 'desktop',
            'category' => 'performance',
            'category' => 'seo',
            'key' => $api_key
        ]);
        
        $desktop_response = wp_remote_get($desktop_url, ['timeout' => 30]);
        if (!is_wp_error($desktop_response)) {
            $desktop_data = json_decode(wp_remote_retrieve_body($desktop_response), true);
            if ($desktop_data && isset($desktop_data['lighthouseResult'])) {
                $result['desktop'] = parse_lighthouse_result($desktop_data['lighthouseResult']);
            }
        }
    }
    
    return $result;
}

function parse_lighthouse_result($lighthouse_data) {
    $result = [];
    
    // Performance score
    if (isset($lighthouse_data['categories']['performance']['score'])) {
        $result['performance']['score'] = round($lighthouse_data['categories']['performance']['score'] * 100);
    }
    
    // Core metrics
    $metrics = ['first-contentful-paint', 'largest-contentful-paint', 'speed-index', 'interactive', 'total-blocking-time', 'cumulative-layout-shift'];
    foreach ($metrics as $metric) {
        if (isset($lighthouse_data['audits'][$metric])) {
            $result['metrics'][$metric] = [
                'displayValue' => $lighthouse_data['audits'][$metric]['displayValue'] ?? 'N/A',
                'score' => $lighthouse_data['audits'][$metric]['score'] ?? 0
            ];
        }
    }
    
    // Opportunities
    if (isset($lighthouse_data['audits'])) {
        $opportunities = [];
        foreach ($lighthouse_data['audits'] as $audit_id => $audit) {
            if (isset($audit['details']['type']) && $audit['details']['type'] === 'opportunity' && $audit['score'] < 1) {
                $opportunities[] = [
                    'title' => $audit['title'],
                    'description' => $audit['description'],
                    'details' => $audit['details'] ?? []
                ];
            }
        }
        $result['opportunities'] = array_slice($opportunities, 0, 5); // Top 5 opportunities
    }
    
    return $result;
}

function analyze_seo($url) {
    // Custom SEO analysis
    $response = wp_remote_get($url, ['timeout' => 30]);
    if (is_wp_error($response)) {
        return null;
    }
    
    $html = wp_remote_retrieve_body($response);
    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    
    $seo_score = 100;
    $audits = [];
    
    // Check for title tag
    $titles = $doc->getElementsByTagName('title');
    if ($titles->length > 0) {
        $title = $titles->item(0)->textContent;
        $audits['title'] = [
            'title' => 'Document has a title element',
            'score' => 1,
            'value' => $title
        ];
    } else {
        $audits['title'] = [
            'title' => 'Document has a title element',
            'score' => 0
        ];
        $seo_score -= 20;
    }
    
    // Check for meta description
    $meta_description = '';
    $metas = $doc->getElementsByTagName('meta');
    for ($i = 0; $i < $metas->length; $i++) {
        $meta = $metas->item($i);
        if ($meta->getAttribute('name') === 'description') {
            $meta_description = $meta->getAttribute('content');
            break;
        }
    }
    
    if (!empty($meta_description)) {
        $audits['meta-description'] = [
            'title' => 'Document has a meta description',
            'score' => 1,
            'value' => $meta_description
        ];
    } else {
        $audits['meta-description'] = [
            'title' => 'Document has a meta description',
            'score' => 0
        ];
        $seo_score -= 15;
    }
    
    // Check for heading structure
    $h1_count = $doc->getElementsByTagName('h1')->length;
    if ($h1_count === 1) {
        $audits['heading-order'] = [
            'title' => 'Heading elements appear in sequentially-descending order',
            'score' => 1
        ];
    } else {
        $audits['heading-order'] = [
            'title' => 'Heading elements appear in sequentially-descending order',
            'score' => 0
        ];
        $seo_score -= 10;
    }
    
    // Check for alt text on images
    $images = $doc->getElementsByTagName('img');
    $images_without_alt = 0;
    for ($i = 0; $i < $images->length; $i++) {
        if (!$images->item($i)->hasAttribute('alt') || empty($images->item($i)->getAttribute('alt'))) {
            $images_without_alt++;
        }
    }
    
    if ($images_without_alt === 0) {
        $audits['image-alt'] = [
            'title' => 'Image elements have alt attributes',
            'score' => 1
        ];
    } else {
        $audits['image-alt'] = [
            'title' => 'Image elements have alt attributes',
            'score' => 0
        ];
        $seo_score -= 15;
    }
    
    return [
        'score' => max(0, $seo_score),
        'audits' => $audits
    ];
}

function analyze_security($url) {
    $result = [];
    
    // Check HTTPS
    $result['https'] = strpos($url, 'https://') === 0;
    
    // Check security headers
    $response = wp_remote_head($url);
    if (!is_wp_error($response)) {
        $headers = wp_remote_retrieve_headers($response);
        
        $security_headers = [
            'Strict-Transport-Security' => 'HSTS',
            'Content-Security-Policy' => 'CSP',
            'X-Frame-Options' => 'X-Frame-Options',
            'X-Content-Type-Options' => 'X-Content-Type-Options',
            'Referrer-Policy' => 'Referrer Policy'
        ];
        
        $result['headers'] = [];
        foreach ($security_headers as $header => $name) {
            $result['headers'][] = [
                'name' => $name,
                'present' => isset($headers[$header])
            ];
        }
    }
    
    return $result;
}

get_footer(); ?>
