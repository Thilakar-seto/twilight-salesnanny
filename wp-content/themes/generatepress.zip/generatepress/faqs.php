<?php
   /*
   Template Name: FAQs
   */
   ?>
<html>
<?php get_custom_head(); ?>
   <body>
        <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/faqs.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
        <noscript>
            <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/faqs.noncritical.css"/>
        </noscript>
      <div>
        <style>
            .faq-container{margin:80px auto}.faq-header{background:#1e2154;padding:60px 20px;margin-bottom:40px;align-content:center;height:350px}.faq-header-content{max-width:800px;margin:0 auto;text-align:center}.faq-search,.faq-search-container{max-width:600px;margin:0 auto}.faq-header h1{color:#fff;margin-bottom:30px;font-size:54px;}.faq-search{position:relative}.faq-search input{width:100%;padding:15px 20px;border:none;border-radius:30px;font-size:16px;box-shadow:0 4px 6px rgba(0,0,0,.1)}.faq-search button{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:0 0;border:none;color:#c22034;cursor:pointer}.faq-main{display:grid;grid-template-columns:250px 1fr;gap:40px;max-width:1200px;width:100%;justify-content:center;margin:0 auto;padding:0 15px}.faq-categories{background:#f8f9fa;padding:20px;border-radius:10px;position:sticky;top:20px;height:fit-content}.faq-item,.search-results{background:#fff;border-radius:8px;margin-top:20px}.category-list{list-style:none;padding:0;margin-top:20px}.category-list li{padding:12px 15px;margin:5px 0;cursor:pointer;border-radius:5px;transition:.3s}.category-list li.active{background:#C22034;color:#fff}.faq-item{margin-bottom:15px;box-shadow:0 2px 4px rgba(0,0,0,.1)}.faq-question{padding:20px;display:flex;justify-content:space-between;align-items:center;cursor:pointer}.faq-question h4{margin:0;font-size:1.1em}.toggle-icon{font-size:1.5em;color:#c22034}.faq-answer{padding:0 20px;max-height:0;overflow:hidden;transition:.3s}.search-results{max-height:300px;overflow-y:auto;display:none;box-shadow:0 4px 6px rgba(0,0,0,.1)}@media (max-width:1240px){.faq-main{gap:30px;max-width:100%}}@media (max-width:992px){.faq-main{grid-template-columns:220px 1fr;gap:25px}}@media (max-width:768px){.faq-container{margin: 70px auto;}.faq-main{grid-template-columns:1fr;gap:20px;padding:0 10px}.faq-categories{position:relative;top:0;margin-bottom:20px}.faq-header{padding:40px 20px}.faq-header h1{font-size:2em}}@media (max-width:576px){.faq-main{padding:0 5px}}.faq-item.active .faq-answer{background: rgba(194, 32, 52, .1);padding:20px;max-height:1000px}.search-result-item{padding:15px 20px;border-bottom:1px solid #eee;cursor:pointer}
        </style>
         <?php salesnanny_nav_header(); ?>
         <div class="faq-container">
            <!-- FAQ Header Section -->
            <section class="faq-header">
               <div class="faq-header-content">
                  <h1>Frequently Asked Questions</h1>
                  <div class="faq-search-container">
                     <div class="faq-search">
                        <input type="text" id="faqSearch" placeholder="Search your question here...">
                        <button type="button"><i class="fas fa-search"></i></button>
                     </div>
                     <div id="searchResults" class="search-results"></div>
                  </div>
               </div>
            </section>
            <!-- FAQ Main Content -->
            <div class="faq-main">
               <!-- Categories Sidebar -->
               <aside class="faq-categories">
                  <h2>Categories</h2>
                  <ul class="category-list">
                     <li class="active" data-category="general">General Questions</li>
                     <li data-category="account">Account & Billing</li>
                     <li data-category="services">Services</li>
                     <li data-category="technical">Technical Support</li>
                  </ul>
               </aside>
               <!-- FAQ Content -->
               <main class="faq-content" style="padding:20px;">
                  <div class="faq-group" id="general">
                     <h3>General Questions</h3>
                     <div class="faq-item">
                        <div class="faq-question">
                           <h4>What services do you offer?</h4>
                           <span class="toggle-icon">+</span>
                        </div>
                        <div class="faq-answer">
                           <p>We offer a comprehensive range of services including...</p>
                        </div>
                     </div>
                     <!-- Add more FAQ items as needed -->
                  </div>
                  <!-- More FAQ groups for other categories -->
               </main>
            </div>
         </div>
        <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const searchInput = document.getElementById('faqSearch');
                    const searchButton = document.querySelector('.faq-search button');
                    const searchResults = document.getElementById('searchResults');
                
                    function performSearch() {
                        const searchTerm = searchInput.value.toLowerCase().trim();
                        const faqItems = document.querySelectorAll('.faq-item');
                        searchResults.innerHTML = '';
                        
                        if (searchTerm === '') {
                            searchResults.style.display = 'none';
                            return;
                        }
                
                        let resultsFound = false;
                        faqItems.forEach(item => {
                            const question = item.querySelector('h4').textContent;
                            const answer = item.querySelector('.faq-answer').textContent;
                            
                            if (question.toLowerCase().includes(searchTerm) || 
                                answer.toLowerCase().includes(searchTerm)) {
                                resultsFound = true;
                                const resultItem = document.createElement('div');
                                resultItem.className = 'search-result-item';
                                resultItem.textContent = question;
                                
                                resultItem.addEventListener('click', () => {
                                    // Scroll to the FAQ item
                                    item.scrollIntoView({ behavior: 'smooth' });
                                    // Open the FAQ item
                                    item.classList.add('active');
                                    item.querySelector('.toggle-icon').textContent = '-';
                                    // Clear search
                                    searchInput.value = '';
                                    searchResults.style.display = 'none';
                                });
                                
                                searchResults.appendChild(resultItem);
                            }
                        });
                
                        if (!resultsFound) {
                            const noResults = document.createElement('div');
                            noResults.className = 'no-results';
                            noResults.textContent = 'No matching questions found';
                            searchResults.appendChild(noResults);
                        }
                
                        searchResults.style.display = 'block';
                    }
                
                    // Handle search button click
                    searchButton.addEventListener('click', performSearch);
                
                    // Handle input changes with debounce
                    let debounceTimer;
                    searchInput.addEventListener('input', () => {
                        clearTimeout(debounceTimer);
                        debounceTimer = setTimeout(performSearch, 300);
                    });
                
                    // Handle Enter key press in search input
                    searchInput.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') {
                            performSearch();
                        }
                    });
                
                    // Close search results when clicking outside
                    document.addEventListener('click', (e) => {
                        if (!e.target.closest('.faq-search-container')) {
                            searchResults.style.display = 'none';
                        }
                    });
                
                    // FAQ Toggle functionality
                    const faqItems = document.querySelectorAll('.faq-item');
                    faqItems.forEach(item => {
                        item.querySelector('.faq-question').addEventListener('click', () => {
                            item.classList.toggle('active');
                            const icon = item.querySelector('.toggle-icon');
                            icon.textContent = item.classList.contains('active') ? '-' : '+';
                        });
                    });
                
                    // Category switching
                    const categoryItems = document.querySelectorAll('.category-list li');
                    categoryItems.forEach(item => {
                        item.addEventListener('click', () => {
                            // Remove active class from all categories
                            categoryItems.forEach(cat => cat.classList.remove('active'));
                            // Add active class to clicked category
                            item.classList.add('active');
                            
                            // Show/hide relevant FAQ groups
                            const category = item.getAttribute('data-category');
                            const faqGroups = document.querySelectorAll('.faq-group');
                            faqGroups.forEach(group => {
                                if (group.id === category) {
                                    group.style.display = 'block';
                                } else {
                                    group.style.display = 'none';
                                }
                            });
                        });
                    });
                });
        </script>
        <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>