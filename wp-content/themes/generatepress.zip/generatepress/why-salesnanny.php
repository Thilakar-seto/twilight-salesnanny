<?php
/*
Template Name: Why Salesnanny?
*/
?>
<html>
<body>  
    <div>
        <?php salesnanny_nav_header(); ?>
        <section class="why-zoho-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h1 class="section-title">Why<br>Salesnanny?</h1>
                    </div>
                    <div class="col-md-6">
                        <div class="content-wrapper">
                            <p class="lead-text">You do know that the gap between your business's unique needs and the plethora of software tools in the market is real, right? Amidst promises galore from other tools to help you build a bridge,</p>
                            
                            <p class="tagline">we at Zoho One don't build bridges —we are the bridge.</p>
                            
                            <a href="#" class="cta-button">ACCESS YOUR APPS</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <style>
            .why-zoho-section {
                padding: 80px 20px;
                max-width: 1200px;
                margin-top: 80px;
            }
            
            .container {
                width: 100%;
            }
            
            .row {
                display: flex;
                flex-wrap: wrap;
            }
            
            .col-md-6 {
                flex: 0 0 50%;
                max-width: 50%;
                padding: 0 30px;
            }
            
            .section-title {
                font-size: 50px;
                font-weight: bold;
                line-height: 1.3;
                margin-bottom: 30px;
            }
            
            .content-wrapper {
                padding: 20px 0;
            }
            
            .lead-text {
                font-size: 1.2rem;
                margin-bottom: 30px;
            }
            
            .tagline {
                font-size: 17px;
                font-weight: bold;
                margin-bottom: 40px;
            }
            
            .cta-button {
                display: inline-block;
                background-color: #F0483E;
                color: white;
                padding: 15px 30px;
                text-decoration: none;
                border-radius: 5px;
                font-weight: bold;
                transition: background-color 0.3s;
            }
            
            .cta-button:hover {
                background-color: #d94c3d;
            }
            
            /* Responsive styles */
            @media (max-width: 768px) {
                .col-md-6 {
                    flex: 0 0 100%;
                    max-width: 100%;
                }
                
                .section-title {
                    font-size: 3.5rem;
                    text-align: center;
                    margin-bottom: 20px;
                }
                
                .content-wrapper {
                    text-align: center;
                }
            }
        </style>

        <section class="dashboard-showcase">
            <div class="container">
                <div class="dashboard-wrapper">
                    <div class="dashboard-image">
                        <img src="https://www.zohowebstatic.com/sites/zweb/images/one/vd-wrap.png" alt="Zoho One Dashboard" class="main-dashboard">
                    </div>
                </div>
            </div>
        </section>

        <style>
            /* Dashboard Showcase Section */
            .dashboard-showcase {
                padding: 30px 80px;
                position: relative;
                overflow: hidden;
            }
            
            .dashboard-wrapper {
                max-width: 1000px;
                margin: 0 auto;
                position: relative;
            }
            
            .dashboard-image {
                position: relative;
                border-radius: 20px;
                padding: 20px;
                background-color: #ffdd00;
                box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.3);
            }
            
            .main-dashboard {
                width: 100%;
                height: auto;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                display: block;
            }
            
            /* Decorative elements */
            .decorative-element {
                position: absolute;
                border-radius: 50%;
            }
            
            .el-1 {
                width: 30px;
                height: 30px;
                background-color: #2ecc71;
                top: 10%;
                right: -15px;
                border-radius: 0;
                transform: rotate(45deg);
            }
            
            .el-2 {
                width: 20px;
                height: 20px;
                border: 3px solid #3498db;
                top: 20%;
                left: -10px;
                border-radius: 0;
            }
            
            .el-3 {
                width: 15px;
                height: 15px;
                background-color: #e74c3c;
                bottom: 15%;
                left: -7px;
            }
            
            .el-4 {
                width: 25px;
                height: 25px;
                border: 3px solid #9b59b6;
                bottom: 30%;
                right: -12px;
            }
            
            .el-5 {
                width: 10px;
                height: 40px;
                background-color: #3498db;
                top: 40%;
                right: -5px;
                border-radius: 5px;
            }
            
            .el-6 {
                width: 40px;
                height: 10px;
                background-color: #e74c3c;
                bottom: 10%;
                right: 20%;
                border-radius: 5px;
            }
            
            /* Responsive styles */
            @media (max-width: 768px) {
                .dashboard-showcase {
                    padding: 40px 15px;
                }
                
                .decorative-element {
                    display: none;
                }
            }
            
            @media (max-width: 480px) {
                .dashboard-image {
                    padding: 10px;
                }
            }
        </style>


        <section class="comparison-section">
            <div class="comparison-container">
                <div class="comparison-wrapper">
                    <div class="problem-column">
                        <h2 class="comparison-title">The disparate maze</h2>
                        <p class="comparison-text">With multiple software subscriptions and functionality-based add-ons, your business, over time, can get drawn into a software maze that demands exponential time, effort, and resources. Add issues of data traceability and the like to this, and you wind up with a complex, sinking ecosystem.</p>
                    </div>
                    <div class="solution-column">
                        <h2 class="comparison-title">Why not take that unified bridge instead?</h2>
                        <p class="comparison-text">Salesnanny, the operating system for business, encompasses a suite of 45+ apps along with added services and tools for all your business needs, giving you that much-needed unified business view. All these apps are interoperable, simplifying the software maze while also offering great value for businesses that are poised for the future.</p>
                    </div>
                </div>
            </div>
        </section>

        <style>
            .comparison-section {
                padding: 80px 20px;
                max-width: 1400px;
                margin: 0 auto;
                background-color: #f9f9f9;
            }
            
            .comparison-container {
                width: 100%;
            }
            
            .comparison-wrapper {
                display: flex;
                flex-wrap: wrap;
            }
            
            .problem-column, .solution-column {
                flex: 1 1 50%;
                padding: 30px;
                box-sizing: border-box;
            }
            
            .problem-column {
                border-right: 1px solid #eee;
            }
            
            .comparison-title {
                font-size: 2.5rem;
                font-weight: bold;
                margin-bottom: 25px;
                color: #333;
            }
            
            .comparison-text {
                font-size: 1.1rem;
                line-height: 1.6;
                color: #555;
            }
            
            /* Responsive styles */
            @media (max-width: 768px) {
                .comparison-section {
                    padding: 50px 15px;
                }
                
                .comparison-wrapper {
                    flex-direction: column;
                }
                
                .problem-column, .solution-column {
                    flex: 1 1 100%;
                    padding: 20px;
                }
                
                .problem-column {
                    border-right: none;
                    border-bottom: 1px solid #eee;
                    margin-bottom: 30px;
                }
                
                .comparison-title {
                    font-size: 2rem;
                    text-align: center;
                }
            }
        </style>


        <section class="ethos-section">
            <div class="ethos-container">
                <h2 class="ethos-title">The Salesnanny Ethos</h2>
                
                <div class="ethos-columns">
                    <div class="ethos-column">
                        <h3 class="ethos-heading">Work <span class="arrow">→</span> <span class="highlight">Uncluttered</span></h3>
                        <p class="ethos-text">Say goodbye to app overload and hello to a focused, efficient work environment where productivity flourishes. With software that grows at the same pace as your business, you can experience uncluttered working at its fullest.</p>
                    </div>
                    
                    <div class="ethos-column">
                        <h3 class="ethos-heading">Business <span class="arrow">→</span> <span class="highlight">Nourished</span></h3>
                        <p class="ethos-text">Cultivate growth with our best-of-suite approach that provides enterprise-level functionalities. You get an ecosystem of unified software that speak to each other and can integrate with 1,000+ third-party solutions.</p>
                    </div>
                    
                    <div class="ethos-column">
                        <h3 class="ethos-heading">Money <span class="arrow">→</span> <span class="highlight">Valued</span></h3>
                        <p class="ethos-text">Futureproof your operations without breaking the bank. With tools that cater to all business departments, such as sales, marketing, operations, and HR, rest assured that you'll get an unbelievable tech stack at an incredible value.</p>
                    </div>
                </div>
            </div>
        </section>

        <style>
            /* Ethos Section Styles */
            .ethos-section {
                background-color:#045540;
                color: white;
                padding: 80px 20px;
            }
            
            .ethos-container {
                max-width: 1200px;
                margin: 0 auto;
            }
            
            .ethos-title {
                font-size: 3rem;
                font-weight: bold;
                margin-bottom: 60px;
            }
            
            .ethos-columns {
                display: flex;
                flex-wrap: wrap;
                gap: 30px;
            }
            
            .ethos-column {
                flex: 1 1 calc(33.333% - 30px);
                min-width: 250px;
            }
            
            .ethos-heading {
                font-size: 1.8rem;
                font-weight: bold;
                margin-bottom: 20px;
            }
            
            .arrow {
                font-weight: normal;
                margin: 0 5px;
            }
            
            .highlight {
                color: #ffdd00;
            }
            
            .ethos-text {
                font-size: 1.1rem;
                line-height: 1.6;
            }
            
            /* Responsive styles */
            @media (max-width: 992px) {
                .ethos-column {
                    flex: 1 1 calc(50% - 30px);
                }
            }
            
            @media (max-width: 768px) {
                .ethos-title {
                    font-size: 2.5rem;
                    text-align: center;
                    margin-bottom: 40px;
                }
                
                .ethos-columns {
                    flex-direction: column;
                }
                
                .ethos-column {
                    flex: 1 1 100%;
                    margin-bottom: 30px;
                }
                
                .ethos-heading {
                    font-size: 1.6rem;
                }
            }
        </style>


        <section class="unified-experience-section">
            <div class="unified-container">
                <h2 class="unified-title">
                    Unlock the 
                    <span class="highlight-box">unified business suite</span> experience
                </h2>
                
                <div class="features-container">
                    <div class="feature-box">
                        <div class="feature-icon">
                            <img src="/wp-content/themes/generatepress/assets/icons/employee-icon.svg" alt="Employee icon">
                        </div>
                        <p class="feature-text">Empower your employees with intuitive software.</p>
                    </div>
                    
                    <div class="feature-box">
                        <div class="feature-icon">
                            <img src="/wp-content/themes/generatepress/assets/icons/process-icon.svg" alt="Process icon">
                        </div>
                        <p class="feature-text">Streamline processes and operations.</p>
                    </div>
                    
                    <div class="feature-box">
                        <div class="feature-icon">
                            <img src="/wp-content/themes/generatepress/assets/icons/flow-icon.svg" alt="Flow icon">
                        </div>
                        <p class="feature-text">Build a unified business flow.</p>
                    </div>
                    
                    <div class="feature-box">
                        <div class="feature-icon">
                            <img src="/wp-content/themes/generatepress/assets/icons/data-icon.svg" alt="Data icon">
                        </div>
                        <p class="feature-text">Easily find data whenever you need it.</p>
                    </div>
                    
                    <div class="feature-box">
                        <div class="feature-icon">
                            <img src="/wp-content/themes/generatepress/assets/icons/reports-icon.svg" alt="Reports icon">
                        </div>
                        <p class="feature-text">Gain access to intelligent business reports.</p>
                    </div>
                </div>
            </div>
        </section>

        <style>
            /* Unified Experience Section Styles */
            .unified-experience-section {
                padding: 80px 20px;
                max-width: 1200px;
                margin: 0 auto;
            }
            
            .unified-container {
                width: 100%;
            }
            
            .unified-title {
                font-size: 3rem;
                font-weight: bold;
                margin-bottom: 60px;
                line-height: 1.2;
            }
            
            .highlight-box {
                background-color: #0a5144;
                color: #ffdd00;
                padding: 5px 15px;
                border-radius: 5px;
                display: inline-block;
            }
            
            .features-container {
                display: flex;
                flex-wrap: wrap;
                gap: 20px;
                justify-content: space-between;
            }
            
            .feature-box {
                flex: 1 1 200px;
                padding: 20px;
                border-right: 1px solid #eee;
                max-width: 220px;
            }
            
            .feature-box:last-child {
                border-right: none;
            }
            
            .feature-icon {
                margin-bottom: 15px;
                height: 40px;
                display: flex;
                align-items: center;
            }
            
            .feature-icon img {
                max-height: 100%;
                width: auto;
            }
            
            .feature-text {
                font-size: 1.1rem;
                line-height: 1.4;
            }
            
            /* Responsive styles */
            @media (max-width: 992px) {
                .feature-box {
                    flex: 1 1 calc(33.333% - 20px);
                    border-right: none;
                    border-bottom: 1px solid #eee;
                    padding-bottom: 30px;
                    margin-bottom: 30px;
                    max-width: none;
                }
            }
            
            @media (max-width: 768px) {
                .unified-title {
                    font-size: 2.5rem;
                    text-align: center;
                }
                
                .features-container {
                    flex-direction: column;
                    align-items: center;
                }
                
                .feature-box {
                    flex: 1 1 100%;
                    text-align: center;
                    max-width: 300px;
                }
                
                .feature-icon {
                    justify-content: center;
                }
            }
        </style>



        <section class="data-insights-section">
            <div class="data-insights-container">
                <div class="data-insights-wrapper">
                    <div class="data-content">
                        <div class="accordion-item active" data-image="data-symphony-image">
                            <h3 class="accordion-title">Data in symphony <span class="accordion-icon">+</span></h3>
                            <div class="accordion-content">
                                <div class="progress-line"><div class="progress-fill"></div></div>
                                <p>Blend and manage data across 45+ applications with Salesnanny. Our unified approach ensures data silos are broken down, allowing for a comprehensive view of information that drives insightful decisions and strategies, simplifying complexity into clarity.</p>
                            </div>
                        </div>
                        
                        <div class="accordion-item" data-image="insights-image">
                            <h3 class="accordion-title">Insights, always in sight <span class="accordion-icon">+</span></h3>
                            <div class="accordion-content">
                                <div class="progress-line"><div class="progress-fill"></div></div>
                                <p>Access real-time insights across your entire business operations. With Salesnanny's integrated analytics, you'll always have the right information at your fingertips to make informed decisions quickly and confidently.</p>
                            </div>
                        </div>
                        
                        <div class="accordion-item" data-image="intelligence-image">
                            <h3 class="accordion-title">Intelligence as it happens <span class="accordion-icon">+</span></h3>
                            <div class="accordion-content">
                                <div class="progress-line"><div class="progress-fill"></div></div>
                                <p>Leverage AI-powered intelligence that works in real-time. Salesnanny's smart algorithms analyze patterns and provide actionable recommendations as events unfold, helping you stay ahead of market trends.</p>
                            </div>
                        </div>
                        
                        <div class="accordion-item" data-image="whole-picture-image">
                            <h3 class="accordion-title">The whole picture in one frame <span class="accordion-icon">+</span></h3>
                            <div class="accordion-content">
                                <div class="progress-line"><div class="progress-fill"></div></div>
                                <p>See your entire business ecosystem in a single, unified view. No more switching between applications or piecing together fragmented information—Salesnanny brings everything together for a complete perspective.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="data-visual">
                        <div id="data-symphony-image" class="visual-image active">
                            <img src="/wp-content/themes/generatepress/assets/images/data-symphony.png" alt="Data in symphony visualization">
                        </div>
                        <div id="insights-image" class="visual-image">
                            <img src="/wp-content/themes/generatepress/assets/images/insights-visualization.png" alt="Insights visualization">
                        </div>
                        <div id="intelligence-image" class="visual-image">
                            <img src="/wp-content/themes/generatepress/assets/images/intelligence-visualization.png" alt="Intelligence visualization">
                        </div>
                        <div id="whole-picture-image" class="visual-image">
                            <img src="/wp-content/themes/generatepress/assets/images/whole-picture-visualization.png" alt="Whole picture visualization">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <style>
            /* Data Insights Section Styles */
            .data-insights-section {
                padding: 80px 20px;
                max-width: 1200px;
                margin: 0 auto;
            }
            
            .data-insights-wrapper {
                display: flex;
                flex-wrap: wrap;
                gap: 40px;
            }
            
            .data-content {
                flex: 1 1 45%;
                min-width: 300px;
            }
            
            .data-visual {
                flex: 1 1 45%;
                min-width: 300px;
                background-color: #f9f7f0;
                border-radius: 10px;
                position: relative;
                min-height: 400px;
            }
            
            .visual-image {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                opacity: 0;
                transition: opacity 0.5s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
            }
            
            .visual-image.active {
                opacity: 1;
            }
            
            .visual-image img {
                max-width: 100%;
                max-height: 100%;
                object-fit: contain;
            }
            
            .accordion-item {
                margin-bottom: 20px;
                border-bottom: 1px solid #eee;
                padding-bottom: 10px;
            }
            
            .accordion-title {
                font-size: 1.8rem;
                font-weight: bold;
                margin-bottom: 10px;
                cursor: pointer;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .accordion-icon {
                font-size: 1.5rem;
                color: #999;
                transition: transform 0.3s ease;
            }
            
            .accordion-item.active .accordion-icon {
                transform: rotate(45deg);
            }
            
            .accordion-content {
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.5s ease;
            }
            
            .accordion-item.active .accordion-content {
                max-height: 300px;
            }
            
            .progress-line {
                height: 3px;
                background-color: #eee;
                margin: 15px 0;
                position: relative;
            }
            
            .progress-fill {
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                width: 0;
                background-color: #0a5144;
                transition: width 1s ease;
            }
            
            .accordion-item.active .progress-fill {
                width: 100%;
            }
            
            /* Responsive styles */
            @media (max-width: 768px) {
                .data-insights-wrapper {
                    flex-direction: column-reverse;
                }
                
                .data-visual {
                    min-height: 300px;
                }
                
                .accordion-title {
                    font-size: 1.5rem;
                }
            }
        </style>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const accordionItems = document.querySelectorAll('.accordion-item');
                
                accordionItems.forEach(item => {
                    item.querySelector('.accordion-title').addEventListener('click', function() {
                        // Close all items
                        accordionItems.forEach(otherItem => {
                            if (otherItem !== item) {
                                otherItem.classList.remove('active');
                            }
                        });
                        
                        // Toggle current item
                        item.classList.toggle('active');
                        
                        // Update images
                        const imageId = item.getAttribute('data-image');
                        document.querySelectorAll('.visual-image').forEach(img => {
                            img.classList.remove('active');
                        });
                        
                        if (item.classList.contains('active')) {
                            document.getElementById(imageId).classList.add('active');
                        }
                    });
                });
            });
        </script>


        <section class="peace-of-mind-section">
            <div class="peace-container">
                <div class="hands-container">
                    <div class="left-hand">
                        <img src="	https://www.zohowebstatic.com/sites/zweb/images/one/l-hand.png" alt="Decorative left hand">
                    </div>
                    
                    <div class="content-wrapper">
                        <h2 class="peace-title">Go from pieces of software<br>to peace of mind</h2>
                        <p class="peace-description">The peace of mind that comes from your all-in-one, privacy-first business management software stack has to be experienced, to be believed.</p>
                        <a href="#" class="access-button">ACCESS YOUR APPS</a>
                    </div>
                    
                    <div class="right-hand">
                        <img src="	https://www.zohowebstatic.com/sites/zweb/images/one/r-hand.png" alt="Decorative right hand">
                    </div>
                </div>
            </div>
        </section>

        <style>
            /* Peace of Mind Section Styles */
            .peace-of-mind-section {
                background-color: #f9f7f0;
                padding: 100px 20px;
                text-align: center;
            }
            
            .peace-container {
                max-width: 1200px;
                margin: 0 auto;
                position: relative;
            }
            
            .hands-container {
                display: flex;
                align-items: center;
                justify-content: center;
                position: relative;
            }
            
            .left-hand, .right-hand {
                width: 150px;
                position: relative;
            }
            
            .left-hand img, .right-hand img {
                width: 100%;
                height: auto;
            }
            
            .content-wrapper {
                max-width: 700px;
                padding: 0 20px;
                z-index: 2;
            }
            
            .peace-title {
                font-size: 3rem;
                font-weight: bold;
                margin-bottom: 30px;
                line-height: 1.2;
            }
            
            .peace-description {
                font-size: 1.2rem;
                line-height: 1.6;
                margin-bottom: 40px;
                max-width: 600px;
                margin-left: auto;
                margin-right: auto;
            }
            
            .access-button {
                display: inline-block;
                background-color: #F0483E;
                color: white;
                padding: 15px 40px;
                font-size: 1.1rem;
                font-weight: bold;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }
            
            .access-button:hover {
                background-color: #d94c3d;
            }
            
            /* Responsive styles */
            @media (max-width: 992px) {
                .left-hand, .right-hand {
                    width: 120px;
                }
                
                .peace-title {
                    font-size: 2.5rem;
                }
            }
            
            @media (max-width: 768px) {
                .peace-of-mind-section {
                    padding: 70px 20px;
                }
                
                .left-hand, .right-hand {
                    width: 80px;
                }
                
                .peace-title {
                    font-size: 2rem;
                }
                
                .peace-description {
                    font-size: 1.1rem;
                }
            }
            
            @media (max-width: 576px) {
                .hands-container {
                    flex-direction: column;
                }
                
                .left-hand {
                    align-self: flex-start;
                    margin-bottom: 20px;
                }
                
                .right-hand {
                    align-self: flex-end;
                    margin-top: 20px;
                }
                
                .peace-title {
                    font-size: 1.8rem;
                }
            }
        </style>

        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>
