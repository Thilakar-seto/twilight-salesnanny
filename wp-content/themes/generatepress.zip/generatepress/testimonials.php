<?php
/*
Template Name: Testimonials
*/
?>
<html>
<?php get_custom_head(); ?>
<body>
    <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/testimonials.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
      <noscript>
         <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/testimonials.noncritical.css"/>
      </noscript>    
    <div>
        <style>
            .testimonial-header{background:#1e2154;padding:80px 20px 60px;text-align:center;margin-top:80px}.stories-container,.testimonial-header-container{max-width:1200px;margin:0 auto}.testimonial-header h1{font-size:48px;color:#fff;margin-bottom:20px;font-weight:700}.testimonial-header p{font-size:18px;color:#fff;max-width:800px;margin:0 auto 30px;line-height:1.6}.testimonial-stats{display:flex;justify-content:center;flex-wrap:wrap;gap:40px;margin-top:40px}.stat-item{text-align:center;flex:1;min-width:180px;max-width:250px;background:#fff;padding:25px 15px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.05);transition:transform .3s}.stat-number{font-size:36px;font-weight:700;color:#c22034;margin-bottom:10px}.stat-label{font-size:16px;color:#555}.testimonial-filters{display:flex;justify-content:center;flex-wrap:wrap;gap:15px;margin:40px auto 0}.filter-button{padding:10px 20px;background:#fff;border:1px solid #ddd;border-radius:30px;font-size:15px;cursor:pointer;transition:.3s}.filter-button.active,.filter-button:hover{background:#c22034;color:#fff;border-color:#c22034}.customer-stories{padding:60px 20px;background-color:#f9f9f9}.section-title{text-align:center;font-size:36px;color:#333;margin-bottom:40px;position:relative}.quote-icon,.story-text p{margin-bottom:15px}.section-title:after{content:'';display:block;width:80px;height:3px;background:#c22034;margin:15px auto 0}.stories-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));grid-auto-rows:minmax(200px,auto);grid-auto-flow:dense;gap:25px}.story-item{background:#fff;border-radius:10px;box-shadow:0 5px 15px rgba(0,0,0,.05);overflow:hidden;transition:.3s;position:relative}.story-item.medium{grid-row:span 2}.story-item.large{grid-column:span 2;grid-row:span 2}.story-content{padding:30px;height:100%;display:flex;flex-direction:column}.quote-icon{opacity:.8}.story-text{flex-grow:1;font-size:16px;line-height:1.7;color:#444;margin-bottom:20px;position:relative}.customer-info{display:flex;align-items:center;border-top:1px solid #eee;padding-top:20px}.customer-photo{width:60px;height:60px;border-radius:50%;overflow:hidden;margin-right:15px;border:2px solid #f0f0f0}.customer-photo img{width:100%;height:100%;object-fit:cover}.customer-details{flex-grow:1}.customer-name{font-size:18px;font-weight:600;color:#333;margin:0 0 5px}.customer-location{display:flex;align-items:center;font-size:14px;color:#777}.country-flag{width:20px;height:14px;margin-right:8px;object-fit:cover;border-radius:2px}.story-item{animation:.5s forwards fadeInUp;opacity:0}.story-item:first-child{animation-delay:.1s}.story-item:nth-child(2){animation-delay:.2s}.story-item:nth-child(3){animation-delay:.3s}@media (max-width:992px){.testimonial-header{padding:100px 20px 50px}.testimonial-header h1{font-size:36px}.testimonial-stats{gap:20px}.stories-grid{grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px}.story-item.large{grid-column:span 1}}@media (max-width:768px){.testimonial-header{padding:90px 15px 40px}.testimonial-header h1{font-size:32px}.testimonial-header p{font-size:16px}.stat-item{min-width:140px;padding:20px 10px}.stat-number{font-size:30px}.testimonial-filters{margin-top:30px}.customer-stories{padding:40px 15px}.section-title{font-size:30px;margin-bottom:30px}.stories-grid{grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:15px}}@media (max-width:576px){.testimonial-header{padding:90px 15px 30px}.testimonial-header h1{font-size:28px;margin-bottom:15px}.testimonial-stats{flex-direction:column;align-items:center;gap:15px}.stat-item{width:100%;max-width:100%}.filter-button{padding:8px 15px;font-size:14px}.stories-grid{display:flex;flex-direction:column;gap:20px}.story-item{width:100%}.story-content{padding:20px}.customer-photo{width:50px;height:50px}}
        </style>
        <?php salesnanny_nav_header(); ?>
        <header class="testimonial-header">
            <div class="testimonial-header-container">
                <h1>Join Our Trusted Success Partner: Client Testimonials</h1>
                <p>Discover the proven success stories of businesses who've partnered with SalesNanny.</p>
                
                <div class="testimonial-stats">
                    <div class="stat-item">
                        <div class="stat-number">200+</div>
                        <div class="stat-label">Happy Clients</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">98%</div>
                        <div class="stat-label">Satisfaction Rate</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">5+</div>
                        <div class="stat-label">Years of Excellence</div>
                    </div>
                </div>
                
                <!-- <div class="testimonial-filters">
                    <button class="filter-button active">All</button>
                    <button class="filter-button">Earned Media</button>
                    <button class="filter-button">Paid Media</button>
                    <button class="filter-button">Tech Development</button>
                    <button class="filter-button">Inside Sales</button>
                </div> -->
            </div>
        </header>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Filter button functionality
                const filterButtons = document.querySelectorAll('.filter-button');
                
                filterButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        // Remove active class from all buttons
                        filterButtons.forEach(btn => btn.classList.remove('active'));
                        
                        // Add active class to clicked button
                        this.classList.add('active');
                        
                        // Filter logic would go here
                        const filterValue = this.textContent;
                        console.log('Filtering by:', filterValue);
                        
                        // You would typically filter testimonials here based on category
                    });
                });
            });
        </script>
        <section class="customer-stories">
            <div class="stories-container">
                <h2 class="section-title">Customer Success Stories</h2>
                
                <div class="stories-grid">
                    <?php
                    // Query for testimonials
                    $args = array(
                        'post_type' => 'testimonial',
                        'posts_per_page' => -1,
                        'orderby' => 'date',
                        'order' => 'DESC',
                    );
                    
                    $testimonials = new WP_Query($args);
                    
                    if ($testimonials->have_posts()) :
                        while ($testimonials->have_posts()) : $testimonials->the_post();
                            // Get custom fields
                            $customer_name = get_post_meta(get_the_ID(), 'customer_name', true);
                            $customer_country = get_post_meta(get_the_ID(), 'customer_country', true);
                            $country_flag = get_post_meta(get_the_ID(), 'country_flag', true);
                            $customer_photo = get_post_meta(get_the_ID(), 'customer_photo', true);
                            $story_length = strlen(get_the_content());
                            
                            // Determine size class based on content length
                            $size_class = ($story_length > 500) ? 'large' : (($story_length > 250) ? 'medium' : 'small');
                    ?>
                            <div class="story-item <?php echo $size_class; ?>">
                                <div class="story-content">
                                    <div class="quote-icon">
                                        <svg width="32" height="32" viewBox="0 0 24 24" fill="#c22034">
                                            <path d="M10,7L8,11H11V17H5V11L7,7H10M18,7L16,11H19V17H13V11L15,7H18Z" />
                                        </svg>
                                    </div>
                                    <div class="story-text"><?php the_content(); ?></div>
                                    <div class="customer-info">
                                        <?php if ($customer_photo) : ?>
                                            <div class="customer-photo">
                                                <img src="<?php echo esc_url($customer_photo); ?>" alt="<?php echo esc_attr($customer_name); ?>" loading="lazy">
                                            </div>
                                        <?php endif; ?>
                                        <div class="customer-details">
                                            <h4 class="customer-name"><?php echo esc_html($customer_name); ?></h4>
                                            <div class="customer-location">
                                                <?php if ($country_flag) : ?>
                                                    <img src="<?php echo esc_url($country_flag); ?>" alt="<?php echo esc_attr($customer_country); ?>" class="country-flag" loading="lazy">
                                                <?php endif; ?>
                                                <span><?php echo esc_html($customer_country); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                        // Fallback if no testimonials are found
                        echo '<div class="no-stories">No customer stories found. Please add some from the admin panel.</div>';
                    endif;
                    ?>
                </div>
            </div>
        </section>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>