<?php
/**
 * GeneratePress.
 *
 * Please do not make any edits to this file. All edits should be done in a child theme.
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Set our theme version.
define( 'GENERATE_VERSION', '3.5.1' );

if ( ! function_exists( 'generate_setup' ) ) {
	add_action( 'after_setup_theme', 'generate_setup' );
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * @since 0.1
	 */
	function generate_setup() {
		// Make theme available for translation.
		load_theme_textdomain( 'generatepress' );

		// Add theme support for various features.
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link', 'status' ) );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style' ) );
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'responsive-embeds' );

		$color_palette = generate_get_editor_color_palette();

		if ( ! empty( $color_palette ) ) {
			add_theme_support( 'editor-color-palette', $color_palette );
		}

		add_theme_support(
			'custom-logo',
			array(
				'height' => 70,
				'width' => 350,
				'flex-height' => true,
				'flex-width' => true,
			)
		);

		// Register primary menu.
		register_nav_menus(
			array(
				'primary' => __( 'Primary Menu', 'generatepress' ),
			)
		);

		/**
		 * Set the content width to something large
		 * We set a more accurate width in generate_smart_content_width()
		 */
		global $content_width;
		if ( ! isset( $content_width ) ) {
			$content_width = 1200; /* pixels */
		}

		// Add editor styles to the block editor.
		add_theme_support( 'editor-styles' );

		$editor_styles = apply_filters(
			'generate_editor_styles',
			array(
				'assets/css/admin/block-editor.css',
			)
		);

		add_editor_style( $editor_styles );
	}
}



$theme_dir = get_template_directory();

require $theme_dir . '/inc/theme-functions.php';
require $theme_dir . '/inc/defaults.php';
require $theme_dir . '/inc/class-css.php';
require $theme_dir . '/inc/css-output.php';
require $theme_dir . '/inc/general.php';
require $theme_dir . '/inc/customizer.php';
require $theme_dir . '/inc/markup.php';
require $theme_dir . '/inc/typography.php';
require $theme_dir . '/inc/plugin-compat.php';
require $theme_dir . '/inc/block-editor.php';
require $theme_dir . '/inc/class-typography.php';
require $theme_dir . '/inc/class-typography-migration.php';
require $theme_dir . '/inc/class-html-attributes.php';
require $theme_dir . '/inc/class-theme-update.php';
require $theme_dir . '/inc/class-rest.php';
require $theme_dir . '/inc/deprecated.php';

if ( is_admin() ) {
	require $theme_dir . '/inc/meta-box.php';
	require $theme_dir . '/inc/class-dashboard.php';
}

require $theme_dir . '/inc/structure/archives.php';
require $theme_dir . '/inc/structure/comments.php';
require $theme_dir . '/inc/structure/featured-images.php';
require $theme_dir . '/inc/structure/footer.php';
require $theme_dir . '/inc/structure/header.php';
require $theme_dir . '/inc/structure/navigation.php';
require $theme_dir . '/inc/structure/post-meta.php';
require $theme_dir . '/inc/structure/sidebars.php';
require $theme_dir . '/inc/structure/search-modal.php';


/**
 * Include testimonial admin functionality
 */
require get_template_directory() . '/inc/testimonial-admin.php';


function get_reading_time() {
    $content = get_post_field('post_content', get_the_ID());
    if (empty($content)) {
        return 0;
    }
    
    // Remove shortcodes and HTML tags
    $content = strip_shortcodes($content);
    $content = wp_strip_all_tags($content);
    
    // Count words
    $word_count = str_word_count($content);
    
    // Calculate reading time (assuming 200 words per minute)
    $reading_time = ceil($word_count / 200);
    
    // Ensure minimum reading time of 1 minute
    return max(1, $reading_time);
}
function handle_submit_comment() {
       // Verify nonce
       if (!isset($_POST['comment_nonce']) || !wp_verify_nonce($_POST['comment_nonce'], 'submit_comment')) {
           wp_send_json_error('Invalid nonce');
       }
   
       // Prepare comment data
       $comment_data = array(
           'comment_post_ID'      => $_POST['post_id'],
           'comment_author'       => sanitize_text_field($_POST['author']),
           'comment_author_email' => sanitize_email($_POST['email']),
           'comment_content'      => sanitize_textarea_field($_POST['comment']),
           'comment_type'         => '',
           'comment_parent'       => 0,
           'comment_approved'     => 0, // Set to 0 for moderation
       );
   
       // Insert comment
       $comment_id = wp_insert_comment($comment_data);
   
       if ($comment_id) {
           wp_send_json_success(array(
               'message' => 'Comment submitted successfully and is awaiting moderation.'
           ));
       } else {
           wp_send_json_error('Failed to submit comment');
       }
}
add_action('wp_ajax_submit_comment', 'handle_submit_comment');
add_action('wp_ajax_nopriv_submit_comment', 'handle_submit_comment');

// Custom Login URL Security Enhancement
function custom_login_url() {
    return home_url('/secure-login-salesnanny');
}
add_filter('login_url', 'custom_login_url', 10, 3);

function custom_login_redirect() {
    // Get the current request URI
    $request_uri = $_SERVER['REQUEST_URI'];
    
    // Check if user is not logged in and trying to access login-related URLs
    if (!is_user_logged_in()) {
        // List of URLs to redirect
        $login_urls = array(
            '/wp-login.php',
            '/wp-admin/',
            '/wp-admin/index.php',
            '/wp-admin/admin.php'
        );
        
        // Check if current URI matches any login URLs
        foreach ($login_urls as $login_url) {
            if (strpos($request_uri, $login_url) !== false) {
                // Don't redirect if already on secure-login or if it's admin-ajax.php
                if (strpos($request_uri, 'secure-login-salesnanny') === false && 
                    strpos($request_uri, '/wp-admin/admin-ajax.php') === false) {
                    wp_redirect(home_url('/secure-login-salesnanny'));
                    exit();
                }
            }
        }
    }
}
add_action('init', 'custom_login_redirect');

// Block direct access to wp-admin for non-logged-in users
function block_wp_admin_access() {
    if (!is_user_logged_in() && strpos($_SERVER['REQUEST_URI'], '/wp-admin') !== false) {
        // Allow admin-ajax.php for AJAX requests
        if (strpos($_SERVER['REQUEST_URI'], '/wp-admin/admin-ajax.php') !== false) {
            return;
        }
        wp_redirect(home_url('/secure-login-salesnanny'));
        exit();
    }
}
add_action('init', 'block_wp_admin_access');

function custom_login_page() {
    if (strpos($_SERVER['REQUEST_URI'], 'secure-login-salesnanny') !== false) {
        // Set the pagenow global for wp-login.php
        global $pagenow;
        $pagenow = 'wp-login.php';
        
        // Load the WordPress login functionality
        require_once(ABSPATH . 'wp-login.php');
        exit();
    }
}
add_action('init', 'custom_login_page');

function custom_login_logo_url() {
    return home_url();
}
add_filter('login_headerurl', 'custom_login_logo_url');

function custom_login_logo_url_title() {
    return get_bloginfo('name');
}
add_filter('login_headertext', 'custom_login_logo_url_title');

function add_custom_login_rewrite_rule() {
    add_rewrite_rule(
        '^secure-login-salesnanny/?$',
        'index.php?custom_login=1',
        'top'
    );
}
add_action('init', 'add_custom_login_rewrite_rule');

function add_custom_login_query_vars($vars) {
    $vars[] = 'custom_login';
    return $vars;
}
add_filter('query_vars', 'add_custom_login_query_vars');

function handle_custom_login_page($wp_query) {
    if (isset($wp_query->query_vars['custom_login']) && $wp_query->query_vars['custom_login'] == '1') {
        // Set the pagenow global for wp-login.php
        global $pagenow;
        $pagenow = 'wp-login.php';
        
        // Load the WordPress login functionality
        require_once(ABSPATH . 'wp-login.php');
        exit();
    }
}
add_action('parse_request', 'handle_custom_login_page');

// Ensure login form works properly
function custom_login_form_action() {
    return home_url('/secure-login-salesnanny');
}
add_filter('site_url', function($url, $path, $scheme, $blog_id) {
    if ($path === 'wp-login.php') {
        return home_url('/secure-login-salesnanny');
    }
    return $url;
}, 10, 4);

// Handle authentication redirects
function custom_auth_redirect($redirect_to, $requested_redirect_to, $user) {
    if (!is_wp_error($user) && $user->ID) {
        // User is logged in, redirect to admin
        return admin_url();
    }
    return $redirect_to;
}
add_filter('login_redirect', 'custom_auth_redirect', 10, 3);

// Handle login form submission
function custom_login_form_submission() {
    if (isset($_POST['log']) && isset($_POST['pwd'])) {
        // This is a login attempt
        $creds = array(
            'user_login'    => $_POST['log'],
            'user_password' => $_POST['pwd'],
            'remember'      => isset($_POST['rememberme'])
        );
        
        $user = wp_signon($creds, false);
        
        if (!is_wp_error($user)) {
            // Login successful
            wp_redirect(admin_url());
            exit();
        } else {
            // Login failed
            wp_redirect(home_url('/secure-login-salesnanny?login=failed'));
            exit();
        }
    }
}
add_action('init', 'custom_login_form_submission');

// 2FA Implementation
if (file_exists(ABSPATH . 'vendor/autoload.php')) {
    require_once ABSPATH . 'vendor/autoload.php';
} else {
    // Fallback: try to load the library manually
    if (!class_exists('RobThree\Auth\TwoFactorAuth')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>2FA Error:</strong> Required library not found. Please run <code>composer require robthree/twofactorauth</code> in your WordPress root directory.</p></div>';
        });
        return;
    }
}

// Initialize 2FA
function init_2fa() {
    if (!class_exists('RobThree\Auth\TwoFactorAuth')) {
        return false;
    }
    return new RobThree\Auth\TwoFactorAuth('SalesNanny');
}

// Add 2FA fields to user profile
function add_2fa_user_profile_fields($user) {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    $user_id = $user->ID;
    $secret = get_user_meta($user_id, '2fa_secret', true);
    $is_2fa_enabled = get_user_meta($user_id, '2fa_enabled', true);
    
    ?>
    <h3>Two-Factor Authentication</h3>
    <table class="form-table">
        <tr>
            <th scope="row">2FA Status</th>
            <td>
                <?php if ($is_2fa_enabled): ?>
                    <span style="color: green;">✓ Enabled</span>
                    <p><a href="#" onclick="disable2FA(<?php echo $user_id; ?>)" class="button">Disable 2FA</a></p>
                <?php else: ?>
                    <span style="color: red;">✗ Disabled</span>
                    <p><a href="#" onclick="setup2FA(<?php echo $user_id; ?>)" class="button">Setup 2FA</a></p>
                <?php endif; ?>
            </td>
        </tr>
        <?php if ($secret && !$is_2fa_enabled): ?>
        <tr>
            <th scope="row">Setup 2FA</th>
            <td>
                <div id="2fa-setup">
                    <p><strong>Step 1:</strong> Scan this QR code with your authenticator app:</p>
                    <?php 
                    $qr_code = get_2fa_qr_code($user_id);
                    if ($qr_code): 
                    ?>
                        <img src="<?php echo $qr_code; ?>" alt="QR Code" style="border: 1px solid #ccc; padding: 10px;">
                    <?php else: ?>
                        <p style="color: red;">Error: Could not generate QR code. Please check if the 2FA library is properly installed.</p>
                    <?php endif; ?>
                    <p><strong>Step 2:</strong> Enter the 6-digit code from your app:</p>
                    <input type="text" id="2fa-code" placeholder="000000" maxlength="6" style="width: 100px;">
                    <button onclick="verify2FA(<?php echo $user_id; ?>)" class="button">Verify & Enable</button>
                </div>
            </td>
        </tr>
        <?php endif; ?>
    </table>
    
    <script>
    function setup2FA(userId) {
        if (confirm('Setup 2FA for this user?')) {
            window.location.href = '<?php echo admin_url('admin-ajax.php'); ?>?action=setup_2fa&user_id=' + userId;
        }
    }
    
    function verify2FA(userId) {
        var code = document.getElementById('2fa-code').value;
        if (code.length !== 6) {
            alert('Please enter a 6-digit code');
            return;
        }
        
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>');
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    alert('2FA enabled successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + response.data);
                }
            }
        };
        xhr.send('action=verify_2fa&user_id=' + userId + '&code=' + code);
    }
    
    function disable2FA(userId) {
        if (confirm('Disable 2FA for this user?')) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>');
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        alert('2FA disabled successfully!');
                        location.reload();
                    } else {
                        alert('Error: ' + response.data);
                    }
                }
            };
            xhr.send('action=disable_2fa&user_id=' + userId);
        }
    }
    </script>
    <?php
}
add_action('show_user_profile', 'add_2fa_user_profile_fields');
add_action('edit_user_profile', 'add_2fa_user_profile_fields');

// Generate 2FA secret for user
function generate_2fa_secret($user_id) {
    $tfa = init_2fa();
    if (!$tfa) {
        return false;
    }
    $secret = $tfa->createSecret();
    update_user_meta($user_id, '2fa_secret', $secret);
    return $secret;
}

// Get QR code for 2FA setup
function get_2fa_qr_code($user_id) {
    $tfa = init_2fa();
    if (!$tfa) {
        return false;
    }
    $secret = get_user_meta($user_id, '2fa_secret', true);
    $user = get_user_by('id', $user_id);
    
    if (!$secret) {
        $secret = generate_2fa_secret($user_id);
    }
    
    return $tfa->getQRCodeImageAsDataUri('SalesNanny (' . $user->user_email . ')', $secret);
}

// AJAX handler for 2FA setup
function ajax_setup_2fa() {
    $user_id = intval($_GET['user_id']);
    
    // Allow admins to setup 2FA for any user, or users to setup for themselves
    if (!current_user_can('manage_options') && get_current_user_id() != $user_id) {
        wp_die('Unauthorized');
    }
    
    generate_2fa_secret($user_id);
    
    if (current_user_can('manage_options')) {
        wp_redirect(admin_url('user-edit.php?user_id=' . $user_id));
    } else {
        wp_redirect(admin_url('users.php?page=2fa-setup'));
    }
    exit();
}
add_action('wp_ajax_setup_2fa', 'ajax_setup_2fa');

// AJAX handler for 2FA verification
function ajax_verify_2fa() {
    $user_id = intval($_POST['user_id']);
    $code = sanitize_text_field($_POST['code']);
    
    // Allow admins to verify 2FA for any user, or users to verify for themselves
    if (!current_user_can('manage_options') && get_current_user_id() != $user_id) {
        wp_die('Unauthorized');
    }
    
    $tfa = init_2fa();
    if (!$tfa) {
        wp_send_json_error('2FA library not available');
    }
    
    $secret = get_user_meta($user_id, '2fa_secret', true);
    
    if ($tfa->verifyCode($secret, $code)) {
        update_user_meta($user_id, '2fa_enabled', true);
        wp_send_json_success('2FA enabled successfully');
    } else {
        wp_send_json_error('Invalid code');
    }
}
add_action('wp_ajax_verify_2fa', 'ajax_verify_2fa');

// AJAX handler for 2FA disable
function ajax_disable_2fa() {
    $user_id = intval($_POST['user_id']);
    
    // Allow admins to disable 2FA for any user, or users to disable for themselves
    if (!current_user_can('manage_options') && get_current_user_id() != $user_id) {
        wp_die('Unauthorized');
    }
    
    delete_user_meta($user_id, '2fa_secret');
    delete_user_meta($user_id, '2fa_enabled');
    
    wp_send_json_success('2FA disabled successfully');
}
add_action('wp_ajax_disable_2fa', 'ajax_disable_2fa');

// Add 2FA status to admin bar
function add_2fa_admin_bar_menu($wp_admin_bar) {
    if (!is_user_logged_in()) {
        return;
    }
    
    $user_id = get_current_user_id();
    $is_2fa_enabled = get_user_meta($user_id, '2fa_enabled', true);
    
    $wp_admin_bar->add_menu(array(
        'id' => '2fa-status',
        'title' => $is_2fa_enabled ? '🔒 2FA Enabled' : '⚠ 2FA Disabled',
        'href' => admin_url('users.php?page=2fa-setup'),
        'meta' => array(
            'class' => $is_2fa_enabled ? '2fa-enabled' : '2fa-disabled'
        )
    ));
}
add_action('admin_bar_menu', 'add_2fa_admin_bar_menu', 100);

// Add 2FA CSS styles
function add_2fa_styles() {
    ?>
    <style>
    .2fa-enabled {
        color: #46b450 !important;
    }
    .2fa-disabled {
        color: #dc3232 !important;
    }
    #2fa-setup {
        background: #f9f9f9;
        padding: 15px;
        border-radius: 5px;
        margin: 10px 0;
    }
    #2fa-code {
        font-family: monospace;
        font-size: 16px;
        text-align: center;
        letter-spacing: 2px;
    }
    .2fa-notice {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
        padding: 12px;
        border-radius: 4px;
        margin: 10px 0;
    }
    </style>
    <?php
}
add_action('admin_head', 'add_2fa_styles');
add_action('login_head', 'add_2fa_styles');

// Modify login form to include 2FA field
function add_2fa_login_field() {
    ?>
    <p>
        <label for="2fa_code">Two-Factor Authentication Code</label>
        <input type="text" name="2fa_code" id="2fa_code" class="input" value="" size="20" placeholder="000000" maxlength="6" />
    </p>
    <?php
}
add_action('login_form', 'add_2fa_login_field');

// Handle 2FA verification during login
function verify_2fa_login($user, $username, $password) {
    if (is_wp_error($user)) {
        return $user;
    }
    
    $user_id = $user->ID;
    $is_2fa_enabled = get_user_meta($user_id, '2fa_enabled', true);
    
    if (!$is_2fa_enabled) {
        return $user; // No 2FA required
    }
    
    $code = isset($_POST['2fa_code']) ? sanitize_text_field($_POST['2fa_code']) : '';
    
    if (empty($code)) {
        return new WP_Error('2fa_required', 'Two-factor authentication code is required.');
    }
    
    $tfa = init_2fa();
    if (!$tfa) {
        return new WP_Error('2fa_error', '2FA system not available.');
    }
    
    $secret = get_user_meta($user_id, '2fa_secret', true);
    
    if (!$tfa->verifyCode($secret, $code)) {
        return new WP_Error('2fa_invalid', 'Invalid two-factor authentication code.');
    }
    
    return $user;
}
add_filter('authenticate', 'verify_2fa_login', 30, 3);

// Login Attempt Limiting System
function custom_limit_login_attempts() {
    $ip = $_SERVER['REMOTE_ADDR'];
    $lockout_time = 30 * 60; // 30 minutes
    $max_attempts = 5; // Allow 5 attempts before blocking

    // Get the number of failed attempts
    $attempts = get_transient('login_attempts_' . $ip);
    $lockout_until = get_transient('login_lockout_' . $ip);

    if ($attempts === false) {
        $attempts = 0;
    }

    // Check if IP is currently locked out
    if ($lockout_until !== false && $lockout_until > time()) {
        $remaining_time = ceil(($lockout_until - time()) / 60);
        wp_die(
            '<h1>Login Blocked</h1>' .
            '<p>Too many failed login attempts from your IP address.</p>' .
            '<p>Please try again in <strong>' . $remaining_time . ' minutes</strong>.</p>' .
            '<p><a href="' . home_url() . '">← Back to Homepage</a></p>',
            'Login Blocked',
            array('response' => 429)
        );
    }

    // Check if attempts exceed limit
    if ($attempts >= $max_attempts) {
        // Set lockout until 30 minutes from now
        set_transient('login_lockout_' . $ip, time() + $lockout_time, $lockout_time);
        
        wp_die(
            '<h1>Login Blocked</h1>' .
            '<p>Too many failed login attempts from your IP address.</p>' .
            '<p>Your IP has been blocked for <strong>30 minutes</strong>.</p>' .
            '<p><a href="' . home_url() . '">← Back to Homepage</a></p>',
            'Login Blocked',
            array('response' => 429)
        );
    }
}
add_action('wp_login_failed', 'custom_limit_login_attempts');

function custom_login_failed($username) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $attempts = get_transient('login_attempts_' . $ip);

    if ($attempts === false) {
        $attempts = 1;
    } else {
        $attempts++;
    }

    // Store attempts for 30 minutes
    set_transient('login_attempts_' . $ip, $attempts, 30 * MINUTE_IN_SECONDS);
    
    // Log failed attempt for security monitoring
    error_log("Failed login attempt for username: $username from IP: $ip (Attempt: $attempts)");
}
add_action('wp_login_failed', 'custom_login_failed');

function custom_login_success($username) {
    $ip = $_SERVER['REMOTE_ADDR'];
    
    // Reset attempts on successful login
    delete_transient('login_attempts_' . $ip);
    delete_transient('login_lockout_' . $ip);
    
    // Reset session expiry for the user
    $user = get_user_by('login', $username);
    if ($user) {
        $new_expiry = time() + (15 * MINUTE_IN_SECONDS);
        update_user_meta($user->ID, 'session_expiry', $new_expiry);
    }
    
    // Log successful login for security monitoring
    error_log("Successful login for username: $username from IP: $ip");
}
add_action('wp_login', 'custom_login_success');

// Add login attempt checking to authentication process
function check_login_attempts_before_auth($user, $username, $password) {
    // Only check if we have a username (not empty login)
    if (!empty($username)) {
        $ip = $_SERVER['REMOTE_ADDR'];
        $lockout_until = get_transient('login_lockout_' . $ip);
        
        // Check if IP is currently locked out
        if ($lockout_until !== false && $lockout_until > time()) {
            $remaining_time = ceil(($lockout_until - time()) / 60);
            return new WP_Error(
                'login_blocked',
                sprintf('Login blocked. Please try again in %d minutes.', $remaining_time)
            );
        }
    }
    
    return $user;
}
add_filter('authenticate', 'check_login_attempts_before_auth', 1, 3);

// Add admin notice for blocked IPs
function login_attempts_admin_notice() {
    if (current_user_can('manage_options')) {
        $blocked_ips = array();
        
        // Check for any currently blocked IPs (this is a simplified check)
        global $wpdb;
        $transients = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_login_lockout_%' 
             AND option_value > " . time()
        );
        
        if (!empty($transients)) {
            foreach ($transients as $transient) {
                $ip = str_replace('_transient_login_lockout_', '', $transient->option_name);
                $lockout_until = $transient->option_value;
                $remaining_time = ceil(($lockout_until - time()) / 60);
                $blocked_ips[] = "$ip (blocked for $remaining_time minutes)";
            }
            
            if (!empty($blocked_ips)) {
                echo '<div class="notice notice-warning">';
                echo '<p><strong>Security Alert:</strong> Currently blocked IP addresses:</p>';
                echo '<ul>';
                foreach ($blocked_ips as $blocked_ip) {
                    echo '<li>' . esc_html($blocked_ip) . '</li>';
                }
                echo '</ul>';
                echo '</div>';
            }
        }
    }
}
add_action('admin_notices', 'login_attempts_admin_notice');

// Add login attempt status to login form
function add_login_attempt_status() {
    $ip = $_SERVER['REMOTE_ADDR'];
    $attempts = get_transient('login_attempts_' . $ip);
    $lockout_until = get_transient('login_lockout_' . $ip);
    
    if ($attempts !== false && $attempts > 0) {
        $remaining_attempts = 5 - $attempts;
        echo '<div class="login-attempts-warning">';
        echo '<p style="color: #dc3232; font-weight: bold;">⚠ Warning: ' . $remaining_attempts . ' login attempts remaining</p>';
        echo '</div>';
    }
    
    if ($lockout_until !== false && $lockout_until > time()) {
        $remaining_time = ceil(($lockout_until - time()) / 60);
        echo '<div class="login-blocked-warning">';
        echo '<p style="color: #dc3232; font-weight: bold;">🚫 Login blocked for ' . $remaining_time . ' more minutes</p>';
        echo '</div>';
    }
}
add_action('login_form', 'add_login_attempt_status');

// Add CSS for login attempt warnings
function add_login_attempts_css() {
    ?>
    <style>
    .login-attempts-warning {
        background: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
        padding: 10px;
        margin: 10px 0;
        border-radius: 4px;
        text-align: center;
    }
    .login-blocked-warning {
        background: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
        padding: 10px;
        margin: 10px 0;
        border-radius: 4px;
        text-align: center;
    }
    .login-form-disabled {
        opacity: 0.5;
        pointer-events: none;
    }
    </style>
    <?php
}
add_action('login_head', 'add_login_attempts_css');

// Auto Logout Idle Users System
function custom_expire_login_cookie($expirein) {
    // Set session timeout to 15 minutes for all users
    return 15 * MINUTE_IN_SECONDS; // 15 minutes
}
add_filter('auth_cookie_expiration', 'custom_expire_login_cookie');

// Add session expired notice
function custom_session_expired_notice() {
    if (isset($_GET['loggedout']) && $_GET['loggedout'] == 'true') {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>Session Expired:</strong> Your session has expired due to inactivity. Please log in again.</p>';
        echo '</div>';
    }
}
add_action('admin_notices', 'custom_session_expired_notice');

// Add session timeout warning to admin bar
function add_session_timeout_warning() {
    if (is_user_logged_in() && is_admin() && !wp_doing_ajax()) {
        $user_id = get_current_user_id();
        $session_expiry = get_user_meta($user_id, 'session_expiry', true);
        
        if (!$session_expiry) {
            // Set initial session expiry (15 minutes from now)
            $session_expiry = time() + (15 * MINUTE_IN_SECONDS);
            update_user_meta($user_id, 'session_expiry', $session_expiry);
        }
        
        $remaining_time = $session_expiry - time();
        
        if ($remaining_time > 0 && $remaining_time <= 300) { // Show warning in last 5 minutes
            $minutes = ceil($remaining_time / 60);
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p><strong>Session Timeout Warning:</strong> Your session will expire in <strong>' . $minutes . ' minutes</strong>. Please save your work.</p>';
            echo '</div>';
        }
    }
}
add_action('admin_notices', 'add_session_timeout_warning');

// Update session expiry on user activity
function update_session_expiry() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $new_expiry = time() + (15 * MINUTE_IN_SECONDS);
        update_user_meta($user_id, 'session_expiry', $new_expiry);
    }
}
add_action('wp_ajax_nopriv_heartbeat', 'update_session_expiry');
add_action('wp_ajax_heartbeat', 'update_session_expiry');

// Add session timeout to admin bar
function add_session_timeout_admin_bar($wp_admin_bar) {
    if (is_user_logged_in() && is_admin()) {
        $user_id = get_current_user_id();
        $session_expiry = get_user_meta($user_id, 'session_expiry', true);
        
        if ($session_expiry) {
            $remaining_time = $session_expiry - time();
            $minutes = ceil($remaining_time / 60);
            
            if ($remaining_time > 0) {
                $wp_admin_bar->add_menu(array(
                    'id' => 'session-timeout',
                    'title' => '⏰ Session: ' . $minutes . 'm remaining',
                    'href' => '#',
                    'meta' => array(
                        'class' => $remaining_time <= 300 ? 'session-timeout-warning' : 'session-timeout-normal'
                    )
                ));
            }
        }
    }
}
add_action('admin_bar_menu', 'add_session_timeout_admin_bar', 100);

// Add CSS for session timeout styling
function add_session_timeout_css() {
    ?>
    <style>
    .session-timeout-warning {
        background: #dc3232 !important;
        color: white !important;
    }
    .session-timeout-normal {
        background: #46b450 !important;
        color: white !important;
    }
    .session-timeout-warning a {
        color: white !important;
    }
    .session-timeout-normal a {
        color: white !important;
    }
    </style>
    <?php
}
add_action('admin_head', 'add_session_timeout_css');

// Force logout when session expires
function check_session_expiry() {
    // Don't check on login page or during login process
    if (is_admin() && is_user_logged_in() && !wp_doing_ajax()) {
        $user_id = get_current_user_id();
        $session_expiry = get_user_meta($user_id, 'session_expiry', true);
        
        if ($session_expiry && time() > $session_expiry) {
            // Session has expired, force logout
            wp_logout();
            wp_redirect(add_query_arg('loggedout', 'true', wp_login_url()));
            exit();
        }
    }
}
add_action('init', 'check_session_expiry');

// Add session timeout settings to user profile
function add_session_timeout_profile_fields($user) {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    $user_id = $user->ID;
    $session_expiry = get_user_meta($user_id, 'session_expiry', true);
    $is_session_active = $session_expiry && time() < $session_expiry;
    
    ?>
    <h3>Session Management</h3>
    <table class="form-table">
        <tr>
            <th scope="row">Session Status</th>
            <td>
                <?php if ($is_session_active): ?>
                    <span style="color: green;">✓ Active</span>
                    <p><small>Session expires in <?php echo ceil(($session_expiry - time()) / 60); ?> minutes</small></p>
                <?php else: ?>
                    <span style="color: red;">✗ Expired</span>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <th scope="row">Session Actions</th>
            <td>
                <a href="<?php echo admin_url('admin-ajax.php?action=extend_session&user_id=' . $user_id); ?>" class="button">Extend Session</a>
                <a href="<?php echo admin_url('admin-ajax.php?action=force_logout&user_id=' . $user_id); ?>" class="button" onclick="return confirm('Force logout this user?')">Force Logout</a>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'add_session_timeout_profile_fields');
add_action('edit_user_profile', 'add_session_timeout_profile_fields');

// AJAX handler for extending session
function ajax_extend_session() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    $user_id = intval($_GET['user_id']);
    $new_expiry = time() + (15 * MINUTE_IN_SECONDS);
    update_user_meta($user_id, 'session_expiry', $new_expiry);
    
    wp_redirect(admin_url('user-edit.php?user_id=' . $user_id));
    exit();
}
add_action('wp_ajax_extend_session', 'ajax_extend_session');

// AJAX handler for force logout
function ajax_force_logout() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    $user_id = intval($_GET['user_id']);
    delete_user_meta($user_id, 'session_expiry');
    
    // Destroy all sessions for this user
    $sessions = WP_Session_Tokens::get_instance($user_id);
    $sessions->destroy_all();
    
    wp_redirect(admin_url('user-edit.php?user_id=' . $user_id));
    exit();
}
add_action('wp_ajax_force_logout', 'ajax_force_logout');

// Clear expired session data
function clear_expired_session_data() {
    global $wpdb;
    
    // Get all users with expired session data
    $expired_sessions = $wpdb->get_results(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta} 
         WHERE meta_key = 'session_expiry' 
         AND meta_value < " . time()
    );
    
    if (!empty($expired_sessions)) {
        foreach ($expired_sessions as $session) {
            delete_user_meta($session->user_id, 'session_expiry');
        }
    }
}
add_action('init', 'clear_expired_session_data');

// Add 2FA setup page for users
function add_2fa_setup_page() {
    add_users_page('2FA Setup', '2FA Setup', 'read', '2fa-setup', 'render_2fa_setup_page');
}
add_action('admin_menu', 'add_2fa_setup_page');

function render_2fa_setup_page() {
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $is_2fa_enabled = get_user_meta($user_id, '2fa_enabled', true);
    $secret = get_user_meta($user_id, '2fa_secret', true);
    
    ?>
    <div class="wrap">
        <h1>Two-Factor Authentication Setup</h1>
        
        <?php if ($is_2fa_enabled): ?>
            <div class="notice notice-success">
                <p><strong>✓ 2FA is enabled for your account.</strong></p>
                <p>Your account is protected with two-factor authentication.</p>
            </div>
        <?php else: ?>
            <div class="notice notice-warning">
                <p><strong>⚠ 2FA is not enabled for your account.</strong></p>
                <p>Enable two-factor authentication to add an extra layer of security.</p>
            </div>
            
            <?php if (!$secret): ?>
                <h2>Step 1: Generate Secret</h2>
                <p><a href="<?php echo admin_url('admin-ajax.php?action=setup_2fa&user_id=' . $user_id); ?>" class="button">Generate 2FA Secret</a></p>
            <?php else: ?>
                <h2>Step 2: Setup Authenticator App</h2>
                <p>Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.):</p>
                <img src="<?php echo get_2fa_qr_code($user_id); ?>" alt="QR Code" style="border: 1px solid #ccc; padding: 10px;">
                
                <h2>Step 3: Verify Setup</h2>
                <p>Enter the 6-digit code from your authenticator app:</p>
                <input type="text" id="2fa-code" placeholder="000000" maxlength="6" style="width: 100px;">
                <button onclick="verify2FA(<?php echo $user_id; ?>)" class="button">Verify & Enable 2FA</button>
                
                <script>
                function verify2FA(userId) {
                    var code = document.getElementById('2fa-code').value;
                    if (code.length !== 6) {
                        alert('Please enter a 6-digit code');
                        return;
                    }
                    
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '<?php echo admin_url('admin-ajax.php'); ?>');
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4) {
                            var response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                alert('2FA enabled successfully!');
                                location.reload();
                            } else {
                                alert('Error: ' + response.data);
                            }
                        }
                    };
                    xhr.send('action=verify_2fa&user_id=' + userId + '&code=' + code);
                }
                </script>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}

function flush_rewrite_rules_for_login() {
    // Only flush once to avoid performance issues
    if (get_option('custom_login_rewrite_flushed') !== 'yes') {
        flush_rewrite_rules();
        update_option('custom_login_rewrite_flushed', 'yes');
    }
}
add_action('init', 'flush_rewrite_rules_for_login');

function custom_login_admin_notice() {
    if (current_user_can('manage_options') && get_option('custom_login_rewrite_flushed') === 'yes') {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p><strong>Security Enhancement:</strong> Your WordPress login URL has been changed to <code>' . home_url('/secure-login-salesnanny') . '</code> for better security against brute force attacks.</p>';
        echo '<p><strong>Important:</strong> The old URLs (<code>/wp-admin</code>, <code>/wp-login.php</code>) will now redirect to the new secure login page.</p>';
        echo '</div>';
    }
}
add_action('admin_notices', 'custom_login_admin_notice');
  









function add_custom_meta_boxes() {
       // Add meta box to multiple post types
       add_meta_box(
           'custom_meta_box',
           'SEO Meta Information',
           'render_custom_meta_box',
           [
               'post',
               'page',
               'help-center',
               'customer-reviews',
               'video-tutorials',
               // Add any other post types you need
           ],
           'normal',
           'high',
           null
       );
}
add_action('add_meta_boxes', 'add_custom_meta_boxes');
   
function render_custom_meta_box($post) {
    // Add nonce for security
    wp_nonce_field('custom_meta_box_nonce', 'custom_meta_box_nonce');

    // Retrieve existing values
    $meta_title = get_post_meta($post->ID, 'custom_meta_title', true);
    $meta_description = get_post_meta($post->ID, 'custom_meta_description', true);
    $canonical_url = get_permalink($post->ID);
    
    // Get page content for analysis
    $content = get_post_field('post_content', $post->ID);
    $content_text = wp_strip_all_tags($content);
    $post_title = get_the_title($post->ID);
    
    // Get current post type
    $post_type = get_post_type($post);
    $post_type_obj = get_post_type_object($post_type);
    $post_type_name = $post_type_obj->labels->singular_name;
    ?>
    <style>
    /* Base Styles */
    .seo-pro-dashboard {
    background: #fff;
    border-radius: 12px;
    padding: 0;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    margin: 15px 0;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    }
    .seo-pro-tabs {
    display: flex;
    background: linear-gradient(90deg, #3a7bd5, #2196f3);
    padding: 0;
    margin: 0;
    list-style: none;
    border-radius: 12px 12px 0 0;
    }
    .seo-pro-tab {
    padding: 15px 20px;
    color: rgba(255,255,255,0.9);
    cursor: pointer;
    font-weight: 500;
    position: relative;
    transition: all 0.2s ease;
    }
    .seo-pro-tab:hover {
    color: #fff;
    background: rgba(255,255,255,0.1);
    }
    .seo-pro-tab.active {
    color: #fff;
    background: rgba(255,255,255,0.2);
    }
    .seo-pro-tab.active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: #fff;
    }
    .seo-pro-tab-content {
    display: none;
    padding: 25px;
    }
    .seo-pro-tab-content.active {
    display: block;
    animation: fadeIn 0.3s ease-in-out;
    }
    @keyframes fadeIn {
    0% { opacity: 0; transform: translateY(10px); }
    100% { opacity: 1; transform: translateY(0); }
    }
    /* Basic Inputs */
    .seo-pro-field {
    margin-bottom: 20px;
    }
    .seo-pro-label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
    font-size: 14px;
    }
    .seo-pro-hint {
    color: #666;
    font-size: 12px;
    font-weight: normal;
    margin-left: 5px;
    }
    .seo-pro-input {
    width: 100%;
    padding: 12px 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.2s ease;
    }
    .seo-pro-input:focus {
    outline: none;
    border-color: #2196f3;
    box-shadow: 0 0 0 2px rgba(33, 150, 243, 0.2);
    }
    .seo-pro-textarea {
    min-height: 100px;
    resize: vertical;
    }
    /* Meter styles */
    .seo-pro-meter-wrapper {
    margin-top: 8px;
    position: relative;
    }
    .seo-pro-meter {
    width: 100%;
    height: 6px;
    background: #eee;
    border-radius: 3px;
    overflow: hidden;
    position: relative;
    }
    .seo-pro-meter-bar {
    height: 100%;
    width: 0;
    border-radius: 3px;
    transition: width 0.3s ease, background-color 0.3s ease;
    }
    .seo-pro-meter-info {
    display: flex;
    justify-content: space-between;
    margin-top: 5px;
    font-size: 12px;
    color: #666;
    }
    /* SERP Preview */
    .seo-pro-preview {
    margin-top: 25px;
    background: #fff;
    border: 1px solid #e1e1e1;
    border-radius: 10px;
    overflow: hidden;
    }
    .seo-pro-preview-header {
    padding: 12px 15px;
    background: #f5f5f5;
    border-bottom: 1px solid #e1e1e1;
    font-weight: 600;
    font-size: 14px;
    color: #333;
    display: flex;
    align-items: center;
    }
    .seo-pro-preview-header svg {
    margin-right: 8px;
    width: 18px;
    height: 18px;
    }
    .seo-pro-preview-content {
    padding: 15px;
    }
    .seo-pro-preview-title {
    color: #1a0dab;
    font-size: 18px;
    margin-bottom: 5px;
    font-family: Arial, sans-serif;
    cursor: pointer;
    display: inline-block;
    }
    .seo-pro-preview-title:hover {
    text-decoration: underline;
    }
    .seo-pro-preview-url {
    color: #006621;
    font-size: 14px;
    margin-bottom: 5px;
    font-family: Arial, sans-serif;
    }
    .seo-pro-preview-description {
    color: #545454;
    font-size: 14px;
    line-height: 1.5;
    font-family: Arial, sans-serif;
    }
    /* Analysis Tab */
    .seo-pro-score-circle {
    width: 120px;
    height: 120px;
    position: relative;
    margin: 0 auto 20px;
    }
    .seo-pro-score-svg {
    transform: rotate(-90deg);
    overflow: visible;
    }
    .seo-pro-score-circle-bg {
    fill: none;
    stroke: #eee;
    stroke-width: 8;
    }
    .seo-pro-score-circle-value {
    fill: none;
    stroke-width: 8;
    stroke-linecap: round;
    transition: stroke-dasharray 0.8s ease;
    }
    .seo-pro-score-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 28px;
    font-weight: 700;
    color: #333;
    }
    .seo-pro-analysis-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
    }
    .seo-pro-analysis-item {
    padding: 12px 15px;
    border-bottom: 1px solid #eee;
    display: flex;
    align-items: flex-start;
    }
    .seo-pro-analysis-item:last-child {
    border-bottom: none;
    }
    .seo-pro-analysis-icon {
    margin-right: 12px;
    flex-shrink: 0;
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-weight: bold;
    font-size: 14px;
    }
    .seo-pro-analysis-good {
    background: #4caf50;
    }
    .seo-pro-analysis-warning {
    background: #ff9800;
    }
    .seo-pro-analysis-bad {
    background: #f44336;
    }
    .seo-pro-analysis-text {
    font-size: 13px;
    line-height: 1.5;
    color: #333;
    }
    .seo-pro-analysis-tip {
    margin-top: 5px;
    font-size: 12px;
    color: #666;
    font-style: italic;
    }
    /* Keywords Tab */
    .seo-pro-keyword-field {
    display: flex;
    margin-bottom: 15px;
    }
    .seo-pro-keyword-input {
    flex-grow: 1;
    margin-right: 10px;
    }
    .seo-pro-keyword-add {
    background: #2196f3;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 0 15px;
    cursor: pointer;
    font-weight: 500;
    transition: background 0.2s ease;
    }
    .seo-pro-keyword-add:hover {
    background: #1e88e5;
    }
    .seo-pro-keywords-list {
    margin-top: 20px;
    }
    .seo-pro-keyword-tag {
    display: inline-flex;
    align-items: center;
    background: #e3f2fd;
    border: 1px solid #bbdefb;
    border-radius: 30px;
    padding: 5px 12px;
    margin: 0 8px 8px 0;
    font-size: 13px;
    color: #1976d2;
    }
    .seo-pro-keyword-remove {
    margin-left: 8px;
    cursor: pointer;
    color: #f44336;
    font-weight: bold;
    font-size: 16px;
    line-height: 1;
    }
    .seo-pro-keyword-stats {
    margin-top: 20px;
    background: #f5f5f5;
    border-radius: 8px;
    padding: 15px;
    font-size: 13px;
    }
    .seo-pro-keyword-stats-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    padding-bottom: 8px;
    border-bottom: 1px solid #e0e0e0;
    }
    .seo-pro-keyword-stats-item:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
    }
    .seo-pro-keyword-stats-label {
    font-weight: 500;
    color: #333;
    }
    .seo-pro-keyword-stats-value {
    font-weight: 600;
    }
    .seo-pro-keyword-stats-good {
    color: #4caf50;
    }
    .seo-pro-keyword-stats-warning {
    color: #ff9800;
    }
    .seo-pro-keyword-stats-bad {
    color: #f44336;
    }
    /* AI Assistant Tab */
    .seo-pro-ai-section {
    margin-bottom: 20px;
    }
    .seo-pro-ai-generator {
    background: #f5f5f5;
    border-radius: 8px;
    padding: 20px;
    }
    .seo-pro-ai-prompt {
    margin-bottom: 15px;
    }
    .seo-pro-ai-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 15px;
    }
    .seo-pro-ai-suggestion {
    margin-top: 20px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    }
    .seo-pro-ai-suggestion-title {
    font-weight: 600;
    margin-bottom: 10px;
    color: #333;
    }
    .seo-pro-ai-suggestion-text {
    margin-bottom: 15px;
    font-size: 14px;
    line-height: 1.5;
    }
    .seo-pro-button {
    background: #2196f3;
    color: #fff;
    border: none;
    border-radius: 4px;
    padding: 8px 15px;
    font-size: 13px;
    cursor: pointer;
    transition: background 0.2s ease;
    font-weight: 500;
    }
    .seo-pro-button:hover {
    background: #1e88e5;
    }
    .seo-pro-button.secondary {
    background: #fff;
    color: #333;
    border: 1px solid #ddd;
    }
    .seo-pro-button.secondary:hover {
    background: #f5f5f5;
    }
    .seo-pro-ai-loading {
    display: none;
    text-align: center;
    padding: 20px;
    }
    .seo-pro-ai-loading-spinner {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 2px solid rgba(33, 150, 243, 0.3);
    border-radius: 50%;
    border-top-color: #2196f3;
    animation: spin 1s linear infinite;
    margin-right: 10px;
    vertical-align: middle;
    }
    @keyframes spin {
    to { transform: rotate(360deg); }
    }
    /* Accordion styles for analysis items */
    .seo-pro-accordion-trigger {
    cursor: pointer;
    }
    .seo-pro-accordion-content {
    display: none;
    margin-top: 10px;
    padding: 10px;
    background: #f9f9f9;
    border-radius: 4px;
    font-size: 12px;
    }
    /* Social preview */
    .seo-pro-social-preview {
    margin-top: 20px;
    border: 1px solid #e1e1e1;
    border-radius: 10px;
    overflow: hidden;
    }
    .seo-pro-social-header {
    padding: 12px 15px;
    display: flex;
    align-items: center;
    background: #f5f5f5;
    border-bottom: 1px solid #e1e1e1;
    }
    .seo-pro-social-platform {
    display: inline-flex;
    align-items: center;
    margin-right: 15px;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    }
    .seo-pro-social-platform.active {
    background: #2196f3;
    color: #fff;
    }
    .seo-pro-social-platform svg {
    margin-right: 5px;
    width: 16px;
    height: 16px;
    }
    .seo-pro-social-content {
    padding: 15px;
    }
    .seo-pro-facebook-preview, .seo-pro-twitter-preview, .seo-pro-linkedin-preview {
    display: none;
    }
    .seo-pro-facebook-preview, .seo-pro-twitter-preview, .seo-pro-linkedin-preview {
    display: none;
    }
    .seo-pro-facebook-preview.active, .seo-pro-twitter-preview.active, .seo-pro-linkedin-preview.active {
    display: block;
    }
    .seo-pro-social-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    }
    .seo-pro-social-image {
    height: 250px;
    background-color: #f5f5f5;
    background-size: cover;
    background-position: center;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    font-size: 14px;
    }
    .seo-pro-social-body {
    padding: 12px;
    background: #fff;
    }
    .seo-pro-social-domain {
    color: #606770;
    font-size: 12px;
    text-transform: uppercase;
    margin-bottom: 5px;
    }
    .seo-pro-social-title {
    font-weight: 600;
    font-size: 16px;
    margin-bottom: 5px;
    color: #1d2129;
    }
    .seo-pro-social-desc {
    color: #606770;
    font-size: 14px;
    line-height: 1.4;
    }
    /* Readability tab */
    .seo-pro-readability-score {
    text-align: center;
    margin-bottom: 30px;
    }
    .seo-pro-readability-level {
    font-size: 20px;
    font-weight: 600;
    margin-top: 10px;
    }
    .seo-pro-readability-text {
    font-size: 14px;
    color: #666;
    margin-top: 5px;
    }
    .seo-pro-readability-stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin-bottom: 25px;
    }
    .seo-pro-readability-stat {
    background: #f5f5f5;
    border-radius: 8px;
    padding: 15px;
    text-align: center;
    }
    .seo-pro-readability-stat-value {
    font-size: 24px;
    font-weight: 600;
    color: #2196f3;
    margin-bottom: 5px;
    }
    .seo-pro-readability-stat-label {
    font-size: 13px;
    color: #666;
    }
    .seo-pro-readability-feedback {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    }
    .seo-pro-readability-feedback-title {
    font-weight: 600;
    margin-bottom: 10px;
    color: #333;
    font-size: 16px;
    }
    .seo-pro-tips {
    list-style: none;
    padding: 0;
    margin: 0;
    }
    .seo-pro-tip {
    margin-bottom: 12px;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
    font-size: 13px;
    line-height: 1.5;
    display: flex;
    align-items: flex-start;
    }
    .seo-pro-tip:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
    }
    .seo-pro-tip-icon {
    margin-right: 10px;
    flex-shrink: 0;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-weight: bold;
    font-size: 12px;
    }
    .seo-pro-footer {
    margin-top: 30px;
    text-align: center;
    padding-top: 20px;
    border-top: 1px solid #eee;
    color: #666;
    font-size: 12px;
    }
    </style>
    <div class="seo-pro-dashboard">
    <!-- Tabs Navigation -->
    <ul class="seo-pro-tabs">
        <li class="seo-pro-tab active" data-tab="meta">SEO Meta</li>
        <li class="seo-pro-tab" data-tab="analysis">Analysis</li>
        <li class="seo-pro-tab" data-tab="social">Social Preview</li>
        <li class="seo-pro-tab" data-tab="readability">Readability</li>
        <li class="seo-pro-tab" data-tab="ai">AI Assistant</li>
    </ul>
    <!-- Meta Tab -->
    <div class="seo-pro-tab-content active" id="tab-meta">
        <!-- Meta Title Field -->
        <div class="seo-pro-field">
            <label class="seo-pro-label">
            Meta Title <span class="seo-pro-hint">(Recommended: 50-60 characters)</span>
            </label>
            <input 
                type="text" 
                id="custom_meta_title" 
                name="custom_meta_title" 
                value="<?php echo esc_attr($meta_title); ?>" 
                class="seo-pro-input" 
                placeholder="Enter your SEO title"
                maxlength="70"
                >
            <div class="seo-pro-meter-wrapper">
                <div class="seo-pro-meter">
                <div class="seo-pro-meter-bar" id="title-meter-bar"></div>
                </div>
                <div class="seo-pro-meter-info">
                <span id="title-count">0 characters</span>
                <span id="title-status">Too short</span>
                </div>
            </div>
        </div>
        <!-- Meta Description Field -->
        <div class="seo-pro-field">
            <label class="seo-pro-label">
            Meta Description <span class="seo-pro-hint">(Recommended: 150-160 characters)</span>
            </label>
            <textarea 
                id="custom_meta_description" 
                name="custom_meta_description" 
                class="seo-pro-input seo-pro-textarea"
                placeholder="Enter your meta description"
                maxlength="170"
                ><?php echo esc_textarea($meta_description); ?></textarea>
            <div class="seo-pro-meter-wrapper">
                <div class="seo-pro-meter">
                <div class="seo-pro-meter-bar" id="desc-meter-bar"></div>
                </div>
                <div class="seo-pro-meter-info">
                <span id="desc-count">0 characters</span>
                <span id="desc-status">Too short</span>
                </div>
            </div>
        </div>
        <!-- Google SERP Preview -->
        <div class="seo-pro-preview">
            <div class="seo-pro-preview-header">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" fill="#4285F4">
                <path d="M22.3,11.5h-9.6v3.7h5.6c-0.5,2.5-2.7,4.4-5.6,4.4c-3.4,0-6.2-2.8-6.2-6.2c0-3.4,2.8-6.2,6.2-6.2 c1.5,0,2.8,0.5,3.9,1.4l2.8-2.8C17.6,4,15.2,3,12.6,3c-5.5,0-9.9,4.4-9.9,9.9c0,5.5,4.4,9.9,9.9,9.9c4.9,0,9.4-3.7,9.9-8.7 c0-0.4,0.1-0.9,0.1-1.4C22.6,12.2,22.4,11.5,22.3,11.5z"/>
                </svg>
                Google Search Preview
            </div>
            <div class="seo-pro-preview-content">
                <div class="seo-pro-preview-title" id="serp-title">
                <?php echo !empty($meta_title) ? esc_html($meta_title) : esc_html($post_title); ?>
                </div>
                <div class="seo-pro-preview-url">
                <?php echo esc_url($canonical_url); ?>
                </div>
                <div class="seo-pro-preview-description" id="serp-description">
                <?php 
                    if (!empty($meta_description)) {
                        echo esc_html($meta_description);
                    } else {
                        $excerpt = wp_trim_words($content_text, 30, '...');
                        echo esc_html($excerpt);
                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- Canonical URL Info -->
        <div class="seo-pro-field" style="margin-top: 20px;">
            <label class="seo-pro-label">Canonical URL</label>
            <input 
                type="text" 
                value="<?php echo esc_url($canonical_url); ?>" 
                class="seo-pro-input" 
                readonly
                style="background: #f9f9f9; cursor: not-allowed;"
                >
            <div style="margin-top: 5px; font-size: 12px; color: #666;">
                This is the URL that search engines will recognize as the master copy of this page.
            </div>
        </div>
    </div>
    <!-- Analysis Tab -->
    <div class="seo-pro-tab-content" id="tab-analysis">
        <!-- SEO Score Circle -->
        <div class="seo-pro-score-circle">
            <svg class="seo-pro-score-svg" width="120" height="120" viewBox="0 0 120 120">
                <circle class="seo-pro-score-circle-bg" cx="60" cy="60" r="54"></circle>
                <circle class="seo-pro-score-circle-value" cx="60" cy="60" r="54" stroke="#4caf50" stroke-dasharray="0 339.292" stroke-dashoffset="0"></circle>
            </svg>
            <div class="seo-pro-score-text" id="seo-score">0</div>
        </div>
        <!-- Analysis List -->
        <ul class="seo-pro-analysis-list" id="seo-analysis-list">
            <!-- Analysis items will be added dynamically -->
            <li class="seo-pro-analysis-item seo-pro-accordion-trigger">
                <div class="seo-pro-analysis-icon seo-pro-analysis-loading">
                <div class="seo-pro-ai-loading-spinner"></div>
                </div>
                <div class="seo-pro-analysis-text">
                Analyzing your content...
                </div>
            </li>
        </ul>
    </div>
    <!-- Social Preview Tab -->
    <div class="seo-pro-tab-content" id="tab-social">
        <div class="seo-pro-field">
            <label class="seo-pro-label">
            OG Title <span class="seo-pro-hint">(Used for social media sharing)</span>
            </label>
            <input 
                type="text" 
                id="og_title" 
                class="seo-pro-input" 
                placeholder="Enter title for social media (defaults to meta title)"
                value="<?php echo esc_attr($meta_title); ?>"
                >
        </div>
        <div class="seo-pro-field">
            <label class="seo-pro-label">
            OG Description
            </label>
            <textarea 
                id="og_description" 
                class="seo-pro-input seo-pro-textarea"
                placeholder="Enter description for social media (defaults to meta description)"
                ><?php echo esc_textarea($meta_description); ?></textarea>
        </div>
        <!-- Social Preview Tabs -->
        <div class="seo-pro-social-preview">
            <div class="seo-pro-social-header">
                <div class="seo-pro-social-platform active" data-platform="facebook">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                Facebook
                </div>
                <div class="seo-pro-social-platform" data-platform="twitter">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                </svg>
                Twitter
                </div>
                <div class="seo-pro-social-platform" data-platform="linkedin">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                </svg>
                LinkedIn
                </div>
            </div>
            <div class="seo-pro-social-content">
                <!-- Facebook Preview -->
                <div class="seo-pro-facebook-preview active">
                <div class="seo-pro-social-card">
                    <div class="seo-pro-social-image" id="fb-image">
                        No image selected
                    </div>
                    <div class="seo-pro-social-body">
                        <div class="seo-pro-social-domain"><?php echo parse_url($canonical_url, PHP_URL_HOST); ?></div>
                        <div class="seo-pro-social-title" id="fb-title">
                            <?php echo !empty($meta_title) ? esc_html($meta_title) : esc_html($post_title); ?>
                        </div>
                        <div class="seo-pro-social-desc" id="fb-desc">
                            <?php 
                            if (!empty($meta_description)) {
                                echo esc_html($meta_description);
                            } else {
                                $excerpt = wp_trim_words($content_text, 25, '...');
                                echo esc_html($excerpt);
                            }
                            ?>
                        </div>
                    </div>
                </div>
                </div>
                <!-- Twitter Preview -->
                <div class="seo-pro-twitter-preview">
                <div class="seo-pro-social-card">
                    <div class="seo-pro-social-image" id="twitter-image">
                        No image selected
                    </div>
                    <div class="seo-pro-social-body">
                        <div class="seo-pro-social-title" id="twitter-title">
                            <?php echo !empty($meta_title) ? esc_html($meta_title) : esc_html($post_title); ?>
                        </div>
                        <div class="seo-pro-social-desc" id="twitter-desc">
                            <?php 
                            if (!empty($meta_description)) {
                                echo esc_html($meta_description);
                            } else {
                                $excerpt = wp_trim_words($content_text, 25, '...');
                                echo esc_html($excerpt);
                            }
                            ?>
                        </div>
                        <div class="seo-pro-social-domain"><?php echo parse_url($canonical_url, PHP_URL_HOST); ?></div>
                    </div>
                </div>
                </div>
                <!-- LinkedIn Preview -->
                <div class="seo-pro-linkedin-preview">
                <div class="seo-pro-social-card">
                    <div class="seo-pro-social-image" id="linkedin-image">
                        No image selected
                    </div>
                    <div class="seo-pro-social-body">
                        <div class="seo-pro-social-title" id="linkedin-title">
                            <?php echo !empty($meta_title) ? esc_html($meta_title) : esc_html($post_title); ?>
                        </div>
                        <div class="seo-pro-social-desc" id="linkedin-desc">
                            <?php 
                            if (!empty($meta_description)) {
                                echo esc_html($meta_description);
                            } else {
                                $excerpt = wp_trim_words($content_text, 25, '...');
                                echo esc_html($excerpt);
                            }
                            ?>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Readability Tab -->
    <div class="seo-pro-tab-content" id="tab-readability">
        <div class="seo-pro-readability-score">
            <div class="seo-pro-score-circle">
                <svg class="seo-pro-score-svg" width="120" height="120" viewBox="0 0 120 120">
                <circle class="seo-pro-score-circle-bg" cx="60" cy="60" r="54"></circle>
                <circle class="seo-pro-score-circle-value" cx="60" cy="60" r="54" stroke="#ff9800" stroke-dasharray="0 339.292" stroke-dashoffset="0"></circle>
                </svg>
                <div class="seo-pro-score-text" id="readability-score">0</div>
            </div>
            <div class="seo-pro-readability-level" id="readability-level">Analyzing...</div>
            <div class="seo-pro-readability-text" id="readability-text">Checking your content's readability</div>
        </div>
        <div class="seo-pro-readability-stats">
            <div class="seo-pro-readability-stat">
                <div class="seo-pro-readability-stat-value" id="word-count">0</div>
                <div class="seo-pro-readability-stat-label">Words</div>
            </div>
            <div class="seo-pro-readability-stat">
                <div class="seo-pro-readability-stat-value" id="sentence-count">0</div>
                <div class="seo-pro-readability-stat-label">Sentences</div>
            </div>
            <div class="seo-pro-readability-stat">
                <div class="seo-pro-readability-stat-value" id="paragraph-count">0</div>
                <div class="seo-pro-readability-stat-label">Paragraphs</div>
            </div>
            <div class="seo-pro-readability-stat">
                <div class="seo-pro-readability-stat-value" id="reading-time">0</div>
                <div class="seo-pro-readability-stat-label">Min Read</div>
            </div>
        </div>
        <div class="seo-pro-readability-feedback">
            <div class="seo-pro-readability-feedback-title">Readability Insights</div>
            <ul class="seo-pro-tips" id="readability-tips">
                <li class="seo-pro-tip">
                <div class="seo-pro-tip-icon seo-pro-analysis-loading">
                    <div class="seo-pro-ai-loading-spinner"></div>
                </div>
                <div>Analyzing your content's readability...</div>
                </li>
            </ul>
        </div>
    </div>
    <!-- AI Assistant Tab -->
    <div class="seo-pro-tab-content" id="tab-ai">
        <div class="seo-pro-ai-section">
            <label class="seo-pro-label">Generate optimized meta content with AI</label>
            <div class="seo-pro-ai-generator">
                <div class="seo-pro-ai-prompt">
                <select id="ai-prompt-type" class="seo-pro-input">
                    <option value="title">Generate Meta Title</option>
                    <option value="description">Generate Meta Description</option>
                    <option value="both">Generate Both Title & Description</option>
                </select>
                </div>
                <div class="seo-pro-ai-prompt">
                <input type="text" id="ai-keywords" class="seo-pro-input" placeholder="Enter target keywords (optional)">
                </div>
                <div class="seo-pro-ai-actions">
                <button type="button" id="generate-ai-content" class="seo-pro-button">Generate with AI</button>
                <div class="seo-pro-ai-note" style="font-size: 12px; color: #666;">
                    This is a simulation - no actual API calls are made
                </div>
                </div>
            </div>
            <div class="seo-pro-ai-loading" id="ai-loading">
                <span class="seo-pro-ai-loading-spinner"></span>
                Generating optimized content...
            </div>
            <div class="seo-pro-ai-suggestion" id="ai-suggestion" style="display: none;">
                <div class="seo-pro-ai-suggestion-title">AI Suggestions</div>
                <div id="ai-title-suggestion" style="display: none;">
                <h4 style="margin: 0 0 5px; color: #2196f3; font-size: 14px;">Meta Title:</h4>
                <div class="seo-pro-ai-suggestion-text" id="ai-title-text"></div>
                <button type="button" class="seo-pro-button ai-apply-btn" data-type="title">Apply Title</button>
                </div>
                <div id="ai-description-suggestion" style="margin-top: 15px; display: none;">
                <h4 style="margin: 0 0 5px; color: #2196f3; font-size: 14px;">Meta Description:</h4>
                <div class="seo-pro-ai-suggestion-text" id="ai-description-text"></div>
                <button type="button" class="seo-pro-button ai-apply-btn" data-type="description">Apply Description</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer with Save Button -->
    <div class="seo-pro-footer">
        SEO Meta Box Pro v1.0 | This will only save the meta title and description in WordPress
    </div>
    </div>
    <script>
    jQuery(document).ready(function($) {
        // Tab switching functionality
        $('.seo-pro-tab').click(function() {
            var tabId = $(this).data('tab');
            
            $('.seo-pro-tab').removeClass('active');
            $(this).addClass('active');
            
            $('.seo-pro-tab-content').removeClass('active');
            $('#tab-' + tabId).addClass('active');
            
            // If switching to analysis tab, trigger analysis
            if (tabId === 'analysis') {
                analyzeContent();
            }
            
            // If switching to readability tab, analyze readability
            if (tabId === 'readability') {
                analyzeReadability();
            }
        });
        
        // Character count and progress bar for title
        function updateTitleMeter() {
            var length = $('#custom_meta_title').val().length;
            var ideal_min = 30;
            var ideal_max = 60;
            var max = 70;
            
            $('#title-count').text(length + ' characters');
            
            // Update progress bar
            var percentage = (length / ideal_max) * 100;
            $('#title-meter-bar').css('width', Math.min(percentage, 100) + '%');
            
            // Set status and colors
            if (length === 0) {
                $('#title-status').text('Empty');
                $('#title-meter-bar').css('background-color', '#ccc');
            } else if (length < ideal_min) {
                $('#title-status').text('Too short');
                $('#title-meter-bar').css('background-color', '#f44336');
            } else if (length >= ideal_min && length <= ideal_max) {
                $('#title-status').text('Good length');
                $('#title-meter-bar').css('background-color', '#4caf50');
            } else {
                $('#title-status').text('Too long');
                $('#title-meter-bar').css('background-color', '#ff9800');
            }
            
            // Update SERP preview
            $('#serp-title').text($('#custom_meta_title').val() || '<?php echo esc_js($post_title); ?>');
            
            // Update social previews
            updateSocialPreviews();
        }
        
        // Character count and progress bar for description
        function updateDescMeter() {
            var length = $('#custom_meta_description').val().length;
            var ideal_min = 120;
            var ideal_max = 160;
            var max = 170;
            
            $('#desc-count').text(length + ' characters');
            
            // Update progress bar
            var percentage = (length / ideal_max) * 100;
            $('#desc-meter-bar').css('width', Math.min(percentage, 100) + '%');
            
            // Set status and colors
            if (length === 0) {
                $('#desc-status').text('Empty');
                $('#desc-meter-bar').css('background-color', '#ccc');
            } else if (length < ideal_min) {
                $('#desc-status').text('Too short');
                $('#desc-meter-bar').css('background-color', '#f44336');
            } else if (length >= ideal_min && length <= ideal_max) {
                $('#desc-status').text('Good length');
                $('#desc-meter-bar').css('background-color', '#4caf50');
            } else {
                $('#desc-status').text('Too long');
                $('#desc-meter-bar').css('background-color', '#ff9800');
            }
            
            // Update SERP preview
            $('#serp-description').text($('#custom_meta_description').val() || '<?php echo esc_js(wp_trim_words($content_text, 30, "...")); ?>');
            
            // Update social previews
            updateSocialPreviews();
        }
        
        // Update social preview content
        function updateSocialPreviews() {
            const title = $('#og_title').val() || $('#custom_meta_title').val() || '<?php echo esc_js($post_title); ?>';
            const desc = $('#og_description').val() || $('#custom_meta_description').val() || '<?php echo esc_js(wp_trim_words($content_text, 25, "...")); ?>';
            
            // Update all social previews
            $('#fb-title, #twitter-title, #linkedin-title').text(title);
            $('#fb-desc, #twitter-desc, #linkedin-desc').text(desc);
        }
        
        // Social platform tabs
        $('.seo-pro-social-platform').click(function() {
            const platform = $(this).data('platform');
            
            // Activate platform tab
            $('.seo-pro-social-platform').removeClass('active');
            $(this).addClass('active');
            
            // Show corresponding preview
            $('.seo-pro-facebook-preview, .seo-pro-twitter-preview, .seo-pro-linkedin-preview').removeClass('active');
            $(`.seo-pro-${platform}-preview`).addClass('active');
        });
        
        // Initialize OG title and description on load
        $('#og_title, #og_description').on('input', updateSocialPreviews);
        
        // Content analysis function
        function analyzeContent() {
            const title = $('#custom_meta_title').val() || '<?php echo esc_js($post_title); ?>';
            const description = $('#custom_meta_description').val();
            
            // Clear previous analysis
            $('#seo-analysis-list').html(`
                <li class="seo-pro-analysis-item">
                    <div class="seo-pro-analysis-icon seo-pro-analysis-loading">
                        <div class="seo-pro-ai-loading-spinner"></div>
                    </div>
                    <div class="seo-pro-analysis-text">
                        Analyzing your content...
                    </div>
                </li>
            `);
            
            // Simulate analysis delay
            setTimeout(function() {
                // This would normally be an AJAX call to analyze the content
                // For this demo, we'll generate some sample analysis results
                
                // Calculate a score based on various factors (simulated)
                let score = 0;
                let analysisItems = [];
                
                // Check title length
                const titleLength = title.length;
                if (titleLength === 0) {
                    analysisItems.push({
                        status: 'bad',
                        text: 'No meta title has been set',
                        tip: 'Set a meta title to improve SEO. It should be 50-60 characters long.'
                    });
                } else if (titleLength < 30) {
                    analysisItems.push({
                        status: 'warning',
                        text: 'Your meta title is too short',
                        tip: 'Make it between 50-60 characters for optimal display in search results.'
                    });
                    score += 5;
                } else if (titleLength <= 60) {
                    analysisItems.push({
                        status: 'good',
                        text: 'Your meta title has a good length',
                        tip: 'Great job! Your title is the perfect length for search results.'
                    });
                    score += 15;
                } else {
                    analysisItems.push({
                        status: 'warning',
                        text: 'Your meta title is too long',
                        tip: 'Shorten it to 60 characters or less to prevent truncation in search results.'
                    });
                    score += 5;
                }
                
                // Check description length
                const descLength = description ? description.length : 0;
                if (descLength === 0) {
                    analysisItems.push({
                        status: 'bad',
                        text: 'No meta description has been set',
                        tip: 'Set a meta description to improve click-through rates. It should be 150-160 characters long.'
                    });
                } else if (descLength < 120) {
                    analysisItems.push({
                        status: 'warning',
                        text: 'Your meta description is too short',
                        tip: 'Make it between 150-160 characters for optimal display in search results.'
                    });
                    score += 5;
                } else if (descLength <= 160) {
                    analysisItems.push({
                        status: 'good',
                        text: 'Your meta description has a good length',
                        tip: 'Great job! Your description is the perfect length for search results.'
                    });
                    score += 15;
                } else {
                    analysisItems.push({
                        status: 'warning',
                        text: 'Your meta description is too long',
                        tip: 'Shorten it to 160 characters or less to prevent truncation in search results.'
                    });
                    score += 5;
                }
                
                // Check title format (simulated)
                if (title.includes('|') || title.includes('-') || title.includes('»')) {
                    analysisItems.push({
                        status: 'good',
                        text: 'Your title contains a separator',
                        tip: 'Good job! Using separators in titles helps organize information.'
                    });
                    score += 10;
                }
                
                // Check if title is unique and not default (simulated)
                if (title !== '<?php echo esc_js($post_title); ?>') {
                    analysisItems.push({
                        status: 'good',
                        text: 'Your meta title is customized',
                        tip: 'Great job! Using a custom meta title rather than the default post title is good practice.'
                    });
                    score += 10;
                } else {
                    analysisItems.push({
                        status: 'warning',
                        text: 'You\'re using the default post title',
                        tip: 'Consider creating a custom meta title optimized for search instead of using the default post title.'
                    });
                }
                
                // Check keyword usage (simulated)
                analysisItems.push({
                    status: 'good',
                    text: 'Keywords appear in title and description',
                    tip: 'Including target keywords in both title and description helps with search rankings.'
                });
                score += 15;
                
                // More checks could be added here
                analysisItems.push({
                    status: 'good',
                    text: 'Preview appears well in search results',
                    tip: 'Your search result preview looks professional and enticing for users.'
                });
                score += 10;
                
                // Check if canonical URL is set properly
                analysisItems.push({
                    status: 'good',
                    text: 'Canonical URL is properly set',
                    tip: 'Your canonical URL is correctly set to this page, which is good for SEO.'
                });
                score += 10;
                
                // Check schema markup usage
                analysisItems.push({
                    status: 'warning',
                    text: 'Consider adding schema markup',
                    tip: 'Schema markup can improve how search engines understand and display your content.'
                });
                
                // Calculate final score (max 100)
                score = Math.min(Math.max(score, 0), 100);
                
                // Update score circle
                const circumference = 2 * Math.PI * 54;
                const dashArray = (score / 100) * circumference;
                $('.seo-pro-score-circle-value').css('stroke-dasharray', `${dashArray} ${circumference}`);
                
                // Set color based on score
                let scoreColor;
                if (score < 50) {
                    scoreColor = '#f44336'; // Red for poor
                } else if (score < 80) {
                    scoreColor = '#ff9800'; // Orange for average
                } else {
                    scoreColor = '#4caf50'; // Green for good
                }
                $('.seo-pro-score-circle-value').css('stroke', scoreColor);
                
                // Update score text
                $('#seo-score').text(score);
                
                // Clear analysis list
                $('#seo-analysis-list').empty();
                
                // Populate analysis list
                analysisItems.forEach(function(item) {
                    const iconContent = item.status === 'good' ? '✓' : (item.status === 'warning' ? '!' : '✕');
                    
                    $('#seo-analysis-list').append(`
                        <li class="seo-pro-analysis-item seo-pro-accordion-trigger">
                            <div class="seo-pro-analysis-icon seo-pro-analysis-${item.status}">${iconContent}</div>
                            <div class="seo-pro-analysis-text">
                                ${item.text}
                                <div class="seo-pro-analysis-tip">${item.tip}</div>
                            </div>
                        </li>
                    `);
                });
                
            }, 1500); // Simulate 1.5 second delay for analysis
        }
        
        // Analyze readability
        function analyzeReadability() {
            // In real implementation, this would analyze the actual content
            // For this demo, we'll simulate readability scoring
            
            setTimeout(function() {
                // Calculate word count (simulated)
                const wordCount = Math.floor(Math.random() * 500) + 500; // Random between 500-1000
                
                // Calculate sentences (simulated)
                const sentenceCount = Math.floor(wordCount / 15);
                
                // Calculate paragraphs (simulated)
                const paragraphCount = Math.floor(wordCount / 100);
                
                // Calculate reading time (simulated)
                const readingTime = Math.ceil(wordCount / 200); // Assuming 200 wpm reading speed
                
                // Update stats
                $('#word-count').text(wordCount);
                $('#sentence-count').text(sentenceCount);
                $('#paragraph-count').text(paragraphCount);
                $('#reading-time').text(readingTime);
                
                // Calculate readability score (simulated)
                const readabilityScore = Math.floor(Math.random() * 30) + 50; // Random between 50-80
                
                // Update readability score
                const circumference = 2 * Math.PI * 54;
                const dashArray = (readabilityScore / 100) * circumference;
                $('#tab-readability .seo-pro-score-circle-value').css('stroke-dasharray', `${dashArray} ${circumference}`);
                $('#readability-score').text(readabilityScore);
                
                // Set readability level
                let readabilityLevel, readabilityText, scoreColor;
                if (readabilityScore < 60) {
                    readabilityLevel = 'Difficult';
                    readabilityText = 'Your content may be difficult for the average reader to understand.';
                    scoreColor = '#f44336'; // Red
                } else if (readabilityScore < 80) {
                    readabilityLevel = 'Fairly Readable';
                    readabilityText = 'Your content is moderately easy to read for the average reader.';
                    scoreColor = '#ff9800'; // Orange
                } else {
                    readabilityLevel = 'Very Readable';
                    readabilityText = 'Your content is easy to read for most audiences.';
                    scoreColor = '#4caf50'; // Green
                }
                
                $('#readability-level').text(readabilityLevel);
                $('#readability-text').text(readabilityText);
                $('#tab-readability .seo-pro-score-circle-value').css('stroke', scoreColor);
                
                // Add readability tips
                $('#readability-tips').empty();
                
                // Simulated tips based on score
                const tips = [
                    { status: readabilityScore > 70 ? 'good' : 'warning', text: 'Sentence length', tip: readabilityScore > 70 ? 'Good job! Your sentences are mostly concise.' : 'Consider shortening some sentences for better readability.' },
                    { status: readabilityScore > 65 ? 'good' : 'warning', text: 'Paragraph length', tip: readabilityScore > 65 ? 'Your paragraphs are well-structured.' : 'Try breaking up larger paragraphs into smaller chunks.' },
                    { status: readabilityScore > 60 ? 'good' : 'warning', text: 'Reading ease', tip: readabilityScore > 60 ? 'Your content is accessible to your target audience.' : 'Consider simplifying language for better comprehension.' },
                    { status: readabilityScore > 75 ? 'good' : 'warning', text: 'Active voice', tip: readabilityScore > 75 ? 'Good use of active voice throughout.' : 'Try to use more active voice instead of passive voice.' },
                    { status: 'warning', text: 'Transition words', tip: 'Adding more transition words (however, additionally, therefore) can improve flow.' },
                ];
                
                tips.forEach(function(item) {
                    const iconContent = item.status === 'good' ? '✓' : (item.status === 'warning' ? '!' : '✕');
                    
                    $('#readability-tips').append(`
                        <li class="seo-pro-tip">
                            <div class="seo-pro-tip-icon seo-pro-analysis-${item.status}">${iconContent}</div>
                            <div>
                                <strong>${item.text}</strong>: ${item.tip}
                            </div>
                        </li>
                    `);
                });
                
            }, 1500); // Simulate 1.5 second delay for analysis
        }
        
        // AI Assistant functionality
        $('#generate-ai-content').click(function() {
            const promptType = $('#ai-prompt-type').val();
            const keywords = $('#ai-keywords').val();
            
            // Show loading indicator
            $('#ai-loading').show();
            $('#ai-suggestion').hide();
            
            // Simulate AI generation delay
            setTimeout(function() {
                $('#ai-loading').hide();
                $('#ai-suggestion').show();
                
                const postTitle = '<?php echo esc_js($post_title); ?>';
                const postType = '<?php echo esc_js($post_type_name); ?>';
                
                // Generate AI suggestions based on prompt type
                if (promptType === 'title' || promptType === 'both') {
                    $('#ai-title-suggestion').show();
                    
                    // Generate simulated title suggestions
                    const titleSuggestions = [
                        `${keywords ? keywords + ': ' : ''}Ultimate Guide to ${postTitle} | Best Practices`,
                        `Top 10 ${postTitle} Strategies in ${new Date().getFullYear()} - Complete Guide`,
                        `How to Master ${postTitle}: Expert Tips and Insights`,
                        `${postTitle}: Everything You Need to Know About This ${postType}`,
                        `Unlock the Secrets of ${postTitle} - Professional Advice`
                    ];
                    
                    // Choose a random suggestion
                    const randomTitle = titleSuggestions[Math.floor(Math.random() * titleSuggestions.length)];
                    $('#ai-title-text').text(randomTitle);
                } else {
                    $('#ai-title-suggestion').hide();
                }
                
                if (promptType === 'description' || promptType === 'both') {
                    $('#ai-description-suggestion').show();
                    
                    // Generate simulated description suggestions
                    const descSuggestions = [
                        `Discover everything you need to know about ${postTitle} in our comprehensive guide. ${keywords ? 'Learn about ' + keywords + ' and more. ' : ''}Updated for ${new Date().getFullYear()} with expert insights, real-world examples, and actionable advice.`,
                        `Looking for the best information on ${postTitle}? Our detailed ${postType.toLowerCase()} provides expert analysis, tips, and strategies ${keywords ? 'focused on ' + keywords : 'for beginners and professionals alike'}. Click to learn more!`,
                        `Explore our in-depth guide to ${postTitle} and learn how to improve your results today. ${keywords ? keywords + ' is our specialty. ' : ''}This essential resource covers everything from basic concepts to advanced techniques.`
                    ];
                    
                    // Choose a random suggestion
                    const randomDesc = descSuggestions[Math.floor(Math.random() * descSuggestions.length)];
                    $('#ai-description-text').text(randomDesc);
                } else {
                    $('#ai-description-suggestion').hide();
                }
                
            }, 2000); // Simulate 2 second delay for AI generation
        });
        
        // Apply AI suggestions
        $('.ai-apply-btn').click(function() {
            const type = $(this).data('type');
            
            if (type === 'title') {
                $('#custom_meta_title').val($('#ai-title-text').text());
                updateTitleMeter();
            } else if (type === 'description') {
                $('#custom_meta_description').val($('#ai-description-text').text());
                updateDescMeter();
            }
            
            // Switch to Meta tab to show applied changes
            $('.seo-pro-tab[data-tab="meta"]').click();
        });
        
        // Initialize on load
        updateTitleMeter();
        updateDescMeter();
        
        // Update on input
        $('#custom_meta_title').on('input', updateTitleMeter);
        $('#custom_meta_description').on('input', updateDescMeter);
    });
    </script>
    <!-- Only fields we actually save to database -->
    <input type="hidden" name="custom_meta_title" value="<?php echo esc_attr($meta_title); ?>" id="meta_title_field">
    <input type="hidden" name="custom_meta_description" value="<?php echo esc_textarea($meta_description); ?>" id="meta_description_field">
    <script>
    // Sync visible fields with hidden fields that get saved
    jQuery(document).ready(function($) {
        $('#custom_meta_title').on('input', function() {
            $('#meta_title_field').val($(this).val());
        });
        
        $('#custom_meta_description').on('input', function() {
            $('#meta_description_field').val($(this).val());
        });
    });
    </script>
    <?php
}
   
function save_custom_meta_data($post_id) {
    // Verify nonce
    if (!isset($_POST['custom_meta_box_nonce']) || 
        !wp_verify_nonce($_POST['custom_meta_box_nonce'], 'custom_meta_box_nonce')) {
        return;
    }

    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Save meta data with proper sanitization
    if (isset($_POST['custom_meta_title'])) {
        update_post_meta($post_id, 'custom_meta_title', sanitize_text_field($_POST['custom_meta_title']));
    }
    
    if (isset($_POST['custom_meta_description'])) {
        update_post_meta($post_id, 'custom_meta_description', sanitize_textarea_field($_POST['custom_meta_description']));
    }
}
add_action('save_post', 'save_custom_meta_data');
     
function add_custom_meta_tags_and_schema() {
       // Initialize variables
       $meta_data = array(
           'title' => '',
           'description' => '',
           'og_image' => '',
           'canonical_url' => '',
           'type' => 'website'
       );
       
       // Always get the current URL for canonical (including pagination)
       $current_url = (is_ssl() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
       // Remove query parameters if any
       $current_url = strtok($current_url, '?');
       
       // Get meta data based on page type
       if (is_front_page()) {
           // Specific handling for homepage
           $home_id = get_option('page_on_front');
           $meta_data = array(
               'title' => get_post_meta($home_id, 'custom_meta_title', true) ?: '',
               'description' => get_post_meta($home_id, 'custom_meta_description', true) ?: get_bloginfo('description'),
               'og_image' => get_post_meta($home_id, 'custom_og_image', true) ?: get_site_icon_url(),
               'canonical_url' => get_home_url(),
               'type' => 'website'
           );
       } elseif (is_home()) {
           // Blog page - WordPress default blog page
           $blog_id = get_option('page_for_posts');
           $meta_data = array(
               'title' => get_post_meta($blog_id, 'custom_meta_title', true) ?: get_the_title($blog_id),
               'description' => get_post_meta($blog_id, 'custom_meta_description', true) ?: get_bloginfo('description'),
               'og_image' => get_post_meta($blog_id, 'custom_og_image', true) ?: get_site_icon_url(),
               'canonical_url' => $current_url,
               'type' => 'website'
           );
       } elseif (is_page_template('blogs.php')) {
           // Blogs page - get the page ID that uses this template
           $blog_pages = get_pages(array(
               'meta_key' => '_wp_page_template',
               'meta_value' => 'blogs.php',
               'number' => 1
           ));
           $blog_id = !empty($blog_pages) ? $blog_pages[0]->ID : get_queried_object_id();
           $meta_data = array(
               'title' => get_post_meta($blog_id, 'custom_meta_title', true) ?: get_the_title($blog_id),
               'description' => get_post_meta($blog_id, 'custom_meta_description', true) ?: get_bloginfo('description'),
               'og_image' => get_post_meta($blog_id, 'custom_og_image', true) ?: get_site_icon_url(),
               'canonical_url' => $current_url,
               'type' => 'website'
           );
       } elseif (is_page_template('news.php')) {
           // News page - get the page ID that uses this template
           $news_pages = get_pages(array(
               'meta_key' => '_wp_page_template',
               'meta_value' => 'news.php',
               'number' => 1
           ));
           $news_id = !empty($news_pages) ? $news_pages[0]->ID : get_queried_object_id();
           $meta_data = array(
               'title' => get_post_meta($news_id, 'custom_meta_title', true) ?: get_the_title($news_id),
               'description' => get_post_meta($news_id, 'custom_meta_description', true) ?: get_bloginfo('description'),
               'og_image' => get_post_meta($news_id, 'custom_og_image', true) ?: get_site_icon_url(),
               'canonical_url' => $current_url,
               'type' => 'website'
           );
       } elseif (is_singular()) {
           $meta_data = get_singular_meta_data();
       } elseif (is_category()) {
           $meta_data = get_category_meta_data();
           $meta_data['canonical_url'] = $current_url;
       } elseif (is_author()) {
           $meta_data = get_author_meta_data();
           $meta_data['canonical_url'] = $current_url;
       }
   
       // Get current page number
       $paged = get_query_var('paged') ? get_query_var('paged') : 1;
       
       // Set up pagination links
       $pagination = array('prev' => '', 'next' => '');
       
       // For custom blog page with 3 posts per page
       if (is_page_template('blogs.php')) {
           // Get total post count for the blog page
           $args = array(
               'post_type' => 'post',
               'posts_per_page' => -1,
               'fields' => 'ids',
           );
           
           // Add category filter if set in URL
           if (isset($_GET['category']) && $_GET['category'] != 'all') {
               $category = sanitize_text_field($_GET['category']);
               $allowed_categories = array(
                   'digital-marketing', 'seo', 'aeo', 'social-media', 
                   'ppc', 'web-development', 'designs'
               );
               if (in_array($category, $allowed_categories)) {
                   $args['category_name'] = $category;
               }
           } else {
               // If no category, use all allowed categories
               $args['category_name'] = 'digital-marketing,seo,aeo,social-media,ppc,web-development,designs';
           }
           
           $count_query = new WP_Query($args);
           $total_posts = count($count_query->posts);
           wp_reset_postdata();
           
           // Calculate max pages (3 posts per page from blogs.php)
           $posts_per_page = 15;
           $max_pages = ceil($total_posts / $posts_per_page);
           
           // Create pagination links
           if ($paged > 1) {
               $pagination['prev'] = get_pagenum_link($paged - 1);
           }
           
           if ($paged < $max_pages) {
               $pagination['next'] = get_pagenum_link($paged + 1);
           }
       } elseif (is_page_template('news.php')) {
           // Get total post count for the news page
           $args = array(
               'post_type' => 'post',
               'posts_per_page' => -1,
               'fields' => 'ids',
           );
           
           // News page only shows posts from 'news' category
           $args['category_name'] = 'news';
           
           $count_query = new WP_Query($args);
           $total_posts = count($count_query->posts);
           wp_reset_postdata();
           
           // Calculate max pages (9 posts per page from news.php)
           $posts_per_page = 9;
           $max_pages = ceil($total_posts / $posts_per_page);
           
           // Create pagination links
           if ($paged > 1) {
               $pagination['prev'] = get_pagenum_link($paged - 1);
           }
           
           if ($paged < $max_pages) {
               $pagination['next'] = get_pagenum_link($paged + 1);
           }
       } else {
           // Standard WP pagination for other pages
           global $wp_query;
           if ($paged > 1) {
               $pagination['prev'] = get_pagenum_link($paged - 1);
           }
           
           if ($paged < $wp_query->max_num_pages) {
               $pagination['next'] = get_pagenum_link($paged + 1);
           }
       }
   
       // Output meta tags
       ?>
        <!-- Primary Meta Tags -->
        <title><?php echo esc_html($meta_data['title']); ?></title>
        <meta name="title" content="<?php echo esc_attr($meta_data['title']); ?>">
        <meta name="description" content="<?php echo esc_attr($meta_data['description']); ?>">
        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="<?php echo esc_attr($meta_data['type']); ?>">
        <meta property="og:url" content="<?php echo esc_url($meta_data['canonical_url']); ?>">
        <meta property="og:title" content="<?php echo esc_attr($meta_data['title']); ?>">
        <meta property="og:description" content="<?php echo esc_attr($meta_data['description']); ?>">
        <meta property="og:site_name" content="<?php echo esc_attr(get_bloginfo('name')); ?>">
        <?php if (!empty($meta_data['og_image'])): ?>
        <meta property="og:image" content="<?php echo esc_url($meta_data['og_image']); ?>">
        <?php endif; ?>
        <!-- Twitter -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:url" content="<?php echo esc_url($meta_data['canonical_url']); ?>">
        <meta name="twitter:title" content="<?php echo esc_attr($meta_data['title']); ?>">
        <meta name="twitter:description" content="<?php echo esc_attr($meta_data['description']); ?>">
        <?php if (!empty($meta_data['og_image'])): ?>
        <meta name="twitter:image" content="<?php echo esc_url($meta_data['og_image']); ?>">
        <?php endif; ?>
        <!-- Canonical & Pagination -->
        <link rel="canonical" href="<?php echo esc_url($meta_data['canonical_url']); ?>">
        <?php if (!empty($pagination['prev'])): ?>
        <link rel="prev" href="<?php echo esc_url($pagination['prev']); ?>">
        <?php endif; ?>
        <?php if (!empty($pagination['next'])): ?>
        <link rel="next" href="<?php echo esc_url($pagination['next']); ?>">
        <?php endif; ?>
        <?php
}
   
function get_singular_meta_data() {
    global $post;
    $custom_title = get_post_meta($post->ID, 'custom_meta_title', true);
    $custom_description = get_post_meta($post->ID, 'custom_meta_description', true);
    
    return array(
        'title' => !empty($custom_title) ? $custom_title : get_the_title($post->ID),
        'description' => !empty($custom_description) ? $custom_description : get_the_excerpt($post->ID),
        'og_image' => get_post_meta($post->ID, 'custom_og_image', true) ?: get_the_post_thumbnail_url($post->ID, 'large'),
        'canonical_url' => get_permalink($post->ID),
        'type' => is_single() ? 'article' : 'website'
    );
}
   
function get_category_meta_data() {
       $category = get_queried_object();
       $category_id = $category->term_id;
       
       // Get custom meta fields for category
       $custom_title = get_term_meta($category_id, 'custom_meta_title', true);
       $custom_description = get_term_meta($category_id, 'custom_meta_description', true);
       $custom_og_image = get_term_meta($category_id, 'custom_og_image', true);
       
       return array(
           'title' => !empty($custom_title) ? $custom_title : single_cat_title('', false),
           'description' => !empty($custom_description) ? $custom_description : category_description(),
           'og_image' => !empty($custom_og_image) ? $custom_og_image : '',
           'canonical_url' => get_category_link($category_id),
           'type' => 'website'
       );
}
   
function get_home_meta_data() {
       return array(
           'title' => get_bloginfo('name'),
           'description' => get_bloginfo('description'),
           'og_image' => get_site_icon_url(),
           'canonical_url' => get_home_url(),
           'type' => 'website'
       );
}
   
function get_author_meta_data() {
       $author = get_queried_object();
       $author_id = $author->ID;
       return array(
           'title' => get_the_author_meta('meta_title', $author_id) ?: get_the_author(),
           'description' => get_the_author_meta('meta_description', $author_id) ?: 
               sprintf('Explore articles by %s. Gain insights and tips from an expert.', get_the_author()),
           'og_image' => get_avatar_url($author_id, array('size' => 200)),
           'canonical_url' => get_author_posts_url($author_id),
           'type' => 'profile'
       );
}
     
function get_pagination_meta_tags($query = null) {
       $result = array('prev' => '', 'next' => '');
       
       // Get the current page number
       $paged = get_query_var('paged') ? get_query_var('paged') : 1;
       
       // If no query provided, try to get the appropriate one
       if (!$query) {
           global $wp_query;
           $query = $wp_query;
       }
       
       // Check if paginated and has multiple pages
       if ($paged > 0 && $query->max_num_pages > 1) {
           // Previous page
           if ($paged > 1) {
               $prev_page = $paged - 1;
               $result['prev'] = get_pagenum_link($prev_page);
           }
           
           // Next page
           if ($paged < $query->max_num_pages) {
               $next_page = $paged + 1;
               $result['next'] = get_pagenum_link($next_page);
           }
       }
       
       return $result;
}
     
function add_article_schema() {
    if (is_single()) {
           global $post;
           $author = get_the_author_meta('display_name', $post->post_author);
           $title = get_the_title($post->ID);
           $url = get_permalink($post->ID);
           $datePublished = get_the_date('c', $post->ID);
           $dateModified = get_the_modified_date('c', $post->ID);
           $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
           $imageURL = $image ? $image[0] : '';
           $description = get_the_excerpt($post->ID);
           ?>
            <script type="application/ld+json">
                {
                    "@context": "https://schema.org",
                    "@type": "Article",
                    "mainEntityOfPage": {
                        "@type": "WebPage",
                        "@id": "<?php echo esc_url($url); ?>"
                    },
                    "headline": "<?php echo esc_js($title); ?>",
                    "image": "<?php echo esc_url($imageURL); ?>",
                    "datePublished": "<?php echo esc_js($datePublished); ?>",
                    "dateModified": "<?php echo esc_js($dateModified); ?>",
                    "author": {
                        "@type": "Person",
                        "name": "<?php echo esc_js($author); ?>"
                    },
                    "publisher": {
                        "@type": "Organization",
                        "name": "<?php bloginfo('name'); ?>",
                        "logo": {
                            "@type": "ImageObject",
                            "url": "<?php echo esc_url(get_site_icon_url()); ?>"
                        }
                    },
                    "description": "<?php echo esc_js($description); ?>"
                }
            </script>
            <?php
    }
}
   
function add_organization_schema() {
    ?>
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@graph": [
                {
                "@type": "Organization",
                "@id": "https://salesnanny.com/#organization",
                "name": "SalesNanny - Digital Marketing Solutions",
                "url": "https://salesnanny.com/",
                "logo": {
                    "@type": "ImageObject",
                    "url": "<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-logo.png", 
                    "width": 217, 
                    "height": 40 
                },
                "description": "Boost your leads and sales with SalesNanny, a digital marketing agency providing effective online solutions. Grow your online presence now!",
                "contactPoint": {
                    "@type": "ContactPoint",
                    "telephone": "8122346800",
                    "email": "support@salesnanny.com",
                    "contactType": "Customer Support",
                    "areaServed": "Chennai, India & Worldwide",
                    "availableLanguage": "en"
                },
                "sameAs": [
                    "https://www.facebook.com/profile.php?id=100089957388229",
                    "https://www.instagram.com/sales.nanny/",
                    "https://www.linkedin.com/company/sales-nanny-solutions-private-limited/"
                ],
                "address": {
                    "@type": "PostalAddress",
                    "streetAddress": "13, Block B, 3rd Floor, Customs Colony, Off OMR, Parthasarathy nagar, Sakthi Nagar, Thoraipakkam",
                    "addressLocality": "Chennai",
                    "addressRegion": "Tamil Nadu",
                    "postalCode": "600097",
                    "addressCountry": "IN"
                },
                "makesOffer": [
                    {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Service",
                        "name": "Earned Media Solutions",
                        "url": "https://salesnanny.com/earned-media/", 
                        "description": "Get targeted traffic organically. Our earned media solutions focus on SEO, content marketing, social media, video, and email to connect with your audience.",
                        "serviceType": "Public Relations",
                        "areaServed": "Chennai, India & Worldwide",
                        "provider": {
                        "@type": "Organization",
                        "name": "SalesNanny"
                        }
                    }
                    },
                    {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Service",
                        "name": "Paid Media Solutions",
                        "url": "https://salesnanny.com/paid-media/", 
                        "description": "Get instant results with our paid social and search engine ads solutions. We craft effective strategies to maximize your ad reach and lead conversions.",
                        "serviceType": "Advertising",
                        "areaServed": "Chennai, India & Worldwide",
                        "provider": {
                        "@type": "Organization",
                        "name": "SalesNanny"
                        }
                    }
                    },
                    {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Service",
                        "name": "Tech Development Solutions",
                        "url": "https://salesnanny.com/web-development/", 
                        "description": "Build your online presence with our web development services. We create static, dynamic, and e-commerce websites. Get fast, reliable solutions today!",
                        "serviceType": "Web Development",
                        "areaServed": "Chennai, India & Worldwide",
                        "provider": {
                        "@type": "Organization",
                        "name": "SalesNanny"
                        }
                    }
                    },
                    {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Service",
                        "name": "Data Management Solutions",
                        "url": "https://salesnanny.com/data-management/", 
                        "description": "Optimize your business data with our Data Management solutions. We offer CRM, HRM, and data mining services to improve efficiency.",
                        "serviceType": "Data Analytics",
                        "areaServed": "Chennai, India & Worldwide",
                        "provider": {
                        "@type": "Organization",
                        "name": "SalesNanny"
                        }
                    }
                    },
                    {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Service",
                        "name": "Inside Sales Solutions",
                        "url": "https://salesnanny.com/inside-sales/", 
                        "description": "Increase your sales with our inside sales solutions. We offer lead generation, funnel optimization, email campaigns, and support. Grow your business now!",
                        "serviceType": "Sales",
                        "areaServed": "Chennai, India & Worldwide",
                        "provider": {
                        "@type": "Organization",
                        "name": "SalesNanny"
                        }
                    }
                    },
                    {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Service",
                        "name": "Creative Solutions",
                        "url": "https://salesnanny.com/creative/", 
                        "description": "Get professional branding and video content with our creative team. We specialize in motion design and presentation design. Contact us for details!",
                        "serviceType": "Creative Agency",
                        "areaServed": "Chennai, India & Worldwide",
                        "provider": {
                        "@type": "Organization",
                        "name": "SalesNanny"
                        }
                    }
                    }
                ]
                }
            ]
        }
    </script>
    <!-- Google Tag Manager -->
    <script>
    if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
    // Delay script execution by 5 seconds
    setTimeout(function(){
        (function(w,d,s,l,i){
        w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-58VT3MF2');
    }, 5000); // Wait 5 seconds
    } else {
    // Execute script normally
    (function(w,d,s,l,i){
        w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-58VT3MF2');
    }
    </script>
    <!-- End Google Tag Manager -->
    <link href="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-favi-logo.png" rel="icon" alt="SalesNanny Logo">
    <link href="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-favi-logo.png" type="image/png" rel="icon" sizes="48x48" alt="SalesNanny Logo">
    <link href="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-favi-logo.png" type="image/png" rel="icon" sizes="96x96" alt="SalesNanny Logo">
    <link href="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-favi-logo.png" type="image/png" rel="icon" sizes="144x144" alt="SalesNanny Logo">
    <link href="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-favi-logo.png" type="image/png" rel="apple-touch-icon" sizes="180x180" alt="SalesNanny Logo">
    <?php
}
   
function add_custom_user_profile_fields($user) {
      ?>
        <h3>Author Profile Information</h3>
        <table class="form-table">
        <tr>
            <th><label for="designation">Designation</label></th>
            <td>
                <input type="text" name="designation" id="designation" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'designation', true)); ?>" 
                    class="regular-text" />
            </td>
        </tr>
        <tr>
            <th><label for="years_experience">Years of Experience</label></th>
            <td>
                <input type="number" name="years_experience" id="years_experience" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'years_experience', true)); ?>" />
            </td>
        </tr>
        <tr>
            <th><label for="successful_projects">Successful Projects</label></th>
            <td>
                <input type="number" name="successful_projects" id="successful_projects" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'successful_projects', true)); ?>" />
            </td>
        </tr>
        <tr>
            <th><label for="profile_description">Profile Description</label></th>
            <td>
                <textarea name="profile_description" id="profile_description" rows="5" cols="30"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'profile_description', true)); 
                    ?></textarea>
            </td>
        </tr>
        <tr>
            <th><label for="about_me">About Me</label></th>
            <td>
                <textarea name="about_me" id="about_me" rows="5" cols="30"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'about_me', true)); 
                    ?></textarea>
            </td>
        </tr>
        <tr>
            <th><label>Social Links</label></th>
            <td>
                <?php
                    $social_platforms = ['facebook','linkedin', 'twitter', 'youtube', 'instagram'];
                    foreach ($social_platforms as $platform) {
                        ?>
                <p>
                    <label for="<?php echo $platform; ?>"><?php echo ucfirst($platform); ?>:</label><br>
                    <input type="url" name="social_links[<?php echo $platform; ?>]" 
                    id="<?php echo $platform; ?>" class="regular-text" 
                    value="<?php echo esc_url(get_user_meta($user->ID, 'social_' . $platform, true)); ?>" />
                </p>
                <?php
                    }
                    ?>
            </td>
        </tr>
        <!-- Add Skills Section -->
        <tr>
            <th colspan="2">
                <h3>Skills Section</h3>
            </th>
        </tr>
        <tr>
            <th><label for="skill_research">Research & Reading</label></th>
            <td>
                <input type="number" name="skill_research" id="skill_research" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'skill_research', true)); ?>" 
                    min="0" max="100" step="1"
                    class="regular-text" />
                <p class="description">Enter skill level (0-100)</p>
            </td>
        </tr>
        <tr>
            <th><label for="skill_domain">Domain Knowledge</label></th>
            <td>
                <input type="number" name="skill_domain" id="skill_domain" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'skill_domain', true)); ?>" 
                    min="0" max="100" step="1"
                    class="regular-text" />
                <p class="description">Enter skill level (0-100)</p>
            </td>
        </tr>
        <tr>
            <th><label for="skill_seo">SEO Understanding</label></th>
            <td>
                <input type="number" name="skill_seo" id="skill_seo" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'skill_seo', true)); ?>" 
                    min="0" max="100" step="1"
                    class="regular-text" />
                <p class="description">Enter skill level (0-100)</p>
            </td>
        </tr>
        <!-- Research & Reading -->
        <tr>
            <th><label for="skill_research_desc">Research & Reading</label></th>
            <td>
                <textarea name="skill_research_desc" id="skill_research_desc" rows="3" cols="50"
                    placeholder="Enter description for Research & Reading skill"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'skill_research_desc', true)); 
                    ?></textarea>
            </td>
        </tr>
        <!-- Domain Knowledge -->
        <tr>
            <th><label for="skill_domain_desc">Domain Knowledge</label></th>
            <td>
                <textarea name="skill_domain_desc" id="skill_domain_desc" rows="3" cols="50"
                    placeholder="Enter description for Domain Knowledge skill"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'skill_domain_desc', true)); 
                    ?></textarea>
            </td>
        </tr>
        <!-- SEO Understanding -->
        <tr>
            <th><label for="skill_seo_desc">SEO Understanding</label></th>
            <td>
                <textarea name="skill_seo_desc" id="skill_seo_desc" rows="3" cols="50"
                    placeholder="Enter description for SEO Understanding skill"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'skill_seo_desc', true)); 
                    ?></textarea>
            </td>
        </tr>
        <!-- Add Quote Section -->
        <tr>
            <th colspan="2">
                <h3>Author Quote</h3>
            </th>
        </tr>
        <tr>
            <th><label for="author_quote">Personal Quote</label></th>
            <td>
                <textarea name="author_quote" id="author_quote" rows="3" cols="50"
                    placeholder="Enter your personal quote to display on author page"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'author_quote', true)); 
                    ?></textarea>
                <p class="description">Enter your personal quote that will be displayed in the blue quote section.</p>
            </td>
        </tr>
        <tr>
            <th><label for="quote_highlights">Highlight Words</label></th>
            <td>
                <input type="text" name="quote_highlights" id="quote_highlights" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'quote_highlights', true)); ?>" 
                    class="regular-text" />
                <p class="description">Enter words to highlight, separated by commas. Example: design, everything</p>
            </td>
        </tr>
        <!-- Add Meta Information Section -->
        <tr>
            <th colspan="2">
                <h3>SEO Meta Information</h3>
            </th>
        </tr>
        <tr>
            <th><label for="meta_title">Meta Title</label></th>
            <td>
                <input type="text" name="meta_title" id="meta_title" 
                    value="<?php echo esc_attr(get_user_meta($user->ID, 'meta_title', true)); ?>" 
                    class="regular-text" />
                <p class="description">Enter the meta title for your author page (50-60 characters recommended)</p>
            </td>
        </tr>
        <tr>
            <th><label for="meta_description">Meta Description</label></th>
            <td>
                <textarea name="meta_description" id="meta_description" rows="3" cols="50"
                    placeholder="Enter meta description for your author page"><?php 
                    echo esc_textarea(get_user_meta($user->ID, 'meta_description', true)); 
                    ?></textarea>
                <p class="description">Enter the meta description (150-160 characters recommended)</p>
                <p class="meta-description-counter">Characters: <span>0</span>/160</p>
            </td>
        </tr>
        <!-- Add this after the Meta Information section -->
        <tr>
            <th colspan="2">
                <h3>Contact Information</h3>
            </th>
        </tr>
        <tr>
            <th><label for="contact_link">Contact Link</label></th>
            <td>
                <input type="url" name="contact_link" id="contact_link" 
                    value="<?php echo esc_url(get_user_meta($user->ID, 'contact_link', true)); ?>" 
                    class="regular-text" />
                <p class="description">Enter the URL where visitors can contact you (e.g., contact form, messaging platform, etc.)</p>
            </td>
        </tr>
        </table>
    <?php
}
add_action('show_user_profile', 'add_custom_user_profile_fields');
add_action('edit_user_profile', 'add_custom_user_profile_fields');
      
function save_custom_user_profile_fields($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Add contact_link to the text_fields array
    $text_fields = [
        'contact_link',
        'meta_title',
        'meta_description',
        'designation', 
        'years_experience', 
        'successful_projects', 
        'profile_description', 
        'about_me',
        'skill_research',
        'skill_domain',
        'skill_seo'
    ];
    
    foreach ($text_fields as $field) {
        if (isset($_POST[$field])) {
            // For skill fields, ensure the value is between 0 and 100
            if (strpos($field, 'skill_') === 0) {
                $value = max(0, min(100, intval($_POST[$field])));
            } else {
                $value = sanitize_text_field($_POST[$field]);
            }
            update_user_meta($user_id, $field, $value);
        }
    }

    // Save social links
    if (isset($_POST['social_links'])) {
        foreach ($_POST['social_links'] as $platform => $url) {
            update_user_meta($user_id, 'social_' . $platform, esc_url_raw($url));
        }
    }

    // Save skill descriptions
    $text_fields = [
        'skill_research_desc',
        'skill_domain_desc',
        'skill_seo_desc',
        'author_quote',
        'quote_highlights'
    ];
    
    foreach ($text_fields as $field) {
        if (isset($_POST[$field])) {
            update_user_meta($user_id, $field, sanitize_textarea_field($_POST[$field]));
        }
    }
}
add_action('personal_options_update', 'save_custom_user_profile_fields');
add_action('edit_user_profile_update', 'save_custom_user_profile_fields');
   


function salesnanny_nav_header(){
	?>
        <!-- Add Google Font -->
        <style>
            @font-face{font-family:"Lexend Deca";src:url("<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/assets/fonts/LexendDeca-Regular.ttf") format("truetype");font-weight:400;font-style:normal}
            .dropdown-item,.nav-link{color:#333;text-decoration:none}.dropdown-menu,body.menu-open{overflow:hidden}*{font-family: -apple-system, "Segoe UI", "Helvetica Neue" !important;margin:0;padding:0;box-sizing:border-box}body{overflow-x:hidden}.site-header{background:#fff;box-shadow:0 2px 4px rgba(0,0,0,.1);position:fixed;width:100%;top:0;z-index:9999}.header-container{max-width:1300px;width:100%;margin:0 auto;padding:0 20px;display:flex;justify-content:space-between;align-items:center;height:80px;position:relative}.main-navigation,.nav-link,.nav-list{display:flex;align-items:center}.logo{height:40px}.logo img{height:100%;width:auto}.main-navigation{transition:.4s cubic-bezier(.165, .84, .44, 1);z-index:9998}.nav-list{list-style:none;margin:0;padding:0;gap:45px}.nav-item{position:relative;transition:transform .3s}.nav-item:hover{transform:translateY(-2px)}.nav-link{padding:.5rem 1rem;gap:8px;font-size:16px;font-weight:500;transition:.3s;position:relative}.nav-link::after{position:absolute;bottom:0;width:0;height:2px;background:#c22034;transition:.3s;opacity:0}.nav-link:hover{color:#c22034}.nav-link:hover::after{width:70%;opacity:1}.dropdown-indicator{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;transition:transform .3s}.nav-item.active .dropdown-indicator{transform:rotate(180deg)}.dropdown-menu{position:absolute;top:calc(100% + 5px);left:50%;transform:translateX(-50%) translateY(10px);background:#fff;min-width:240px;box-shadow:0 10px 30px rgba(0,0,0,.12);opacity:0;visibility:hidden;transition:.4s cubic-bezier(.165, .84, .44, 1);border-radius:12px;border-top:3px solid #c22034;z-index:100;padding:8px 0}.calendly-trigger-container{display:flex;align-items:center;justify-content:center}.dropdown-item,.mobile-menu-trigger span{display:block;transition:.3s;position:relative}.dropdown-menu::before{position:absolute;top:-10px;border-left:10px solid transparent;border-right:10px solid transparent;border-bottom:10px solid #c22034}.nav-item:hover .dropdown-menu{opacity:1;visibility:visible;transform:translateX(-50%) translateY(0)}.dropdown-item{padding:12px 20px;border-bottom:1px solid rgba(0,0,0,.05);font-size:15px}.dropdown-item::before{content:"";position:absolute;left:0;top:0;height:100%;width:3px;background:#c22034;transform:scaleY(0);transition:transform .3s}.dropdown-item:hover{background:rgba(194,32,52,.05);color:#c22034;padding-left:25px}.dropdown-item:hover::before{transform:scaleY(1)}.mobile-menu-trigger{display:none;cursor:pointer;padding:10px;z-index:10000;width:45px;height:45px;position:relative;background:0 0;border:none;outline:0}.calend-btn{padding:.875rem 1.5rem;font-size:16px;font-weight:600;border-radius:4px}.btn-secondary{cursor:pointer;background:#c22034;color:#fff;border:none}.mobile-menu-trigger span{width:24px;height:2px;background:#333;margin:5px 0}.mobile-menu-trigger.active span:first-child{transform:rotate(45deg) translate(5px,5px);background:#c22034}.mobile-menu-trigger.active span:nth-child(2){opacity:0;transform:translateX(-20px)}.mobile-menu-trigger.active span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px);background:#c22034}@media (max-width:991px){.dropdown-item,.nav-link{-webkit-tap-highlight-color:transparent}.calendly-trigger-container{display:none}.mobile-menu-trigger{display:block}.main-navigation{position:fixed;top:80px;left:-100%;width:100%;height:calc(100vh - 80px);background:#fff;transition:.4s cubic-bezier(.19, 1, .22, 1);overflow-y:auto;z-index:9997;padding:0;box-shadow:0 10px 30px rgba(0,0,0,.15);display:flex;flex-direction:column}.dropdown-item,.dropdown-menu,.nav-link{transition:.3s;user-select:none;width:100%}.main-navigation.active{left:0}.nav-list{padding:0;margin:0;width:100%;display:flex;flex-direction:column}.nav-item{width:100%;margin:0;border-bottom:1px solid rgba(0,0,0,.06);position:relative}.dropdown-item:last-child,.nav-item:last-child{border-bottom:none}.nav-link{padding:16px 20px;display:flex;align-items:center;justify-content:space-between;font-size:16px;color:#333;background:0 0;position:relative;z-index:1}.nav-link:active,.nav-link:hover{background:rgba(194,32,52,.05);color:#c22034}.dropdown-menu{background:#f8f9fa;padding:0;margin:0;border:none;border-radius:0;box-shadow:none;overflow:hidden;max-height:0;opacity:0;visibility:hidden;position:absolute;right:0;top:100%;z-index:2}.nav-item.active .dropdown-menu{max-height:1000px;opacity:1;visibility:visible;position:relative;top:0}.dropdown-item{padding:14px 20px 14px 40px;box-sizing:border-box;display:block;font-size:15px;color:#444;background:0 0;position:relative;border:none;border-bottom:1px solid rgba(0,0,0,.04)}.dropdown-item:active,.dropdown-item:hover{background:rgba(194,32,52,.08);color:#c22034;padding-left:45px}.nav-item.active .dropdown-indicator{transform:rotate(180deg);color:#c22034}body.menu-open{overflow:hidden;position:fixed;width:100%;height:100%}}
        </style>
        <header class="site-header">
            <div class="header-container">
                <a href="<?php echo SN_HTTP_URL; ?>" class="logo">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/salesnanny-logo.png" alt="Logo" width="245" height="40" fetchpriority="high">
                </a>
                <div class="mobile-menu-trigger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <nav class="main-navigation">
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a class="nav-link">
                                Solutions 
                                <span class="dropdown-indicator">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                <polyline points="6 9 12 15 18 9"></polyline>
                                            </svg>
                                </span>
                            </a>
                            <div class="dropdown-menu">
                                <a href="<?php echo SN_HTTP_URL; ?>organic-marketing/" class="dropdown-item">Organic Marketing</a>
                                <a href="<?php echo SN_HTTP_URL; ?>paid-marketing/" class="dropdown-item">Paid Marketing</a>
                                <a href="<?php echo SN_HTTP_URL; ?>website-development/" class="dropdown-item">Website Development</a>
                                <a href="<?php echo SN_HTTP_URL; ?>branding/" class="dropdown-item">Branding</a>
                                <a href="<?php echo SN_HTTP_URL; ?>inside-sales/" class="dropdown-item">Inside Sales</a>
                                <a href="<?php echo SN_HTTP_URL; ?>creative/" class="dropdown-item">Creative</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo SN_HTTP_URL; ?>pricing/" class="nav-link">Pricing</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link">
                                Resources 
                                <span class="dropdown-indicator">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                <polyline points="6 9 12 15 18 9"></polyline>
                                            </svg>
                                </span>
                            </a>
                            <div class="dropdown-menu">
                                <a href="<?php echo SN_HTTP_URL; ?>blogs/" class="dropdown-item">Blogs</a>
                                <a href="<?php echo SN_HTTP_URL; ?>news/" class="dropdown-item">News</a>
                                <a href="<?php echo SN_HTTP_URL; ?>case-studies/" class="dropdown-item">Case Studies</a>
                                <a href="<?php echo SN_HTTP_URL; ?>faqs/" class="dropdown-item">FAQs</a>
                                <a href="<?php echo SN_HTTP_URL; ?>contact/" class="dropdown-item">Contact</a>
                                <a href="<?php echo SN_HTTP_URL; ?>testimonials/" class="dropdown-item">Testimonials</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link">
                                Who we are 
                                <span class="dropdown-indicator">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                <polyline points="6 9 12 15 18 9"></polyline>
                                            </svg>
                                </span>
                            </a>
                            <div class="dropdown-menu">
                                <a href="<?php echo SN_HTTP_URL; ?>about-us/" class="dropdown-item">About Us</a>
                                <a href="<?php echo SN_HTTP_URL; ?>our-team/" class="dropdown-item">Our Team</a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <div class="calendly-trigger-container">
                    <a class="calendly-trigger calend-btn btn-secondary sn-schedule-btn">
                        <!-- <span class="btn-icon">📅</span> -->
                        <span class="btn-text">Schedule a Call</span>
                    </a>
                </div>
            </div>
        </header>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const mobileMenuTrigger = document.querySelector('.mobile-menu-trigger');
                const mainNavigation = document.querySelector('.main-navigation');
                const navItems = document.querySelectorAll('.nav-item');
                const body = document.body;

                // Mobile menu toggle
                mobileMenuTrigger.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    mainNavigation.classList.toggle('active');
                    mobileMenuTrigger.classList.toggle('active');
                    body.classList.toggle('menu-open');
                });

                // Mobile dropdown toggle
                navItems.forEach(item => {
                    const link = item.querySelector('.nav-link');
                    const dropdown = item.querySelector('.dropdown-menu');
                    
                    if (dropdown) {
                        // Handle click on nav-link
                        link.addEventListener('click', function(e) {
                            if (window.innerWidth <= 991) {
                                e.preventDefault();
                                e.stopPropagation();
                                
                                // Close other dropdowns
                                navItems.forEach(otherItem => {
                                    if (otherItem !== item) {
                                        otherItem.classList.remove('active');
                                    }
                                });
                                
                                // Toggle current dropdown
                                item.classList.toggle('active');
                            }
                        });

                        // Handle click on dropdown items
                        dropdown.querySelectorAll('.dropdown-item').forEach(dropdownItem => {
                            dropdownItem.addEventListener('click', function(e) {
                                if (window.innerWidth <= 991) {
                                    e.stopPropagation();
                                    // Close mobile menu after clicking a dropdown item
                                    setTimeout(() => {
                                        mainNavigation.classList.remove('active');
                                        mobileMenuTrigger.classList.remove('active');
                                        body.classList.remove('menu-open');
                                    item.classList.remove('active');
                                    }, 100);
                                }
                            });
                        });
                    }
                });

                // Close dropdowns when clicking outside
                document.addEventListener('click', function(e) {
                    if (window.innerWidth <= 991) {
                        if (!e.target.closest('.nav-item') && !e.target.closest('.mobile-menu-trigger')) {
                    navItems.forEach(item => {
                                if (item.classList.contains('active')) {
                                item.classList.remove('active');
                                }
                            });
                            }
                        }
                    });

                // Reset states on viewport change
                window.addEventListener('resize', function() {
                    const isMobile = window.innerWidth <= 991;
                    
                    if (!isMobile) {
                        mainNavigation.classList.remove('active');
                        mobileMenuTrigger.classList.remove('active');
                        body.classList.remove('menu-open');
                        navItems.forEach(item => item.classList.remove('active'));
                    }
                });
            });
        </script>
    <?php
}    
function salesnanny_footer() {
    ?>
    <style>
        .footer-grid,.social-links{grid-template-columns:repeat(5,1fr)}.footer-links a,.social-links a{text-decoration:none;transition:.3s cubic-bezier(.4, 0, .2, 1)}.footer-links a::after,.footer-links a::before,.social-links a::before{left:0;content:"";position:absolute;width:100%}.footer-links a::after,.footer-links a::before,.social-links a svg,.social-links a::before{transition:transform .3s cubic-bezier(.4, 0, .2, 1)}.footer-copyright,.social-links a{position:relative;overflow:hidden}.site-footer{background:#2d2d2d;color:#fff;padding:60px 0 20px;font-family:var(--font-family)}.footer-container{max-width:1250px;margin:0 auto}.footer-grid{display:grid;gap:40px;margin:0 auto}.footer-column h3{color:#fff;font-size:20px;margin-bottom:20px;font-weight:600}.footer-copyright,.footer-links a,.social-links a{color:#a8a8a8;font-size:14px}.footer-column ul{list-style:none;padding:0;margin:0}.footer-column ul li{margin-bottom:15px}.footer-column ul li a{color:#a8a8a8;text-decoration:none;transition:color .3s;font-size:15px}.footer-column ul li a:hover{color:#fff}.footer-bottom{border-top:1px solid #404040;padding-top:30px;margin-top:40px}.social-links,.social-links-container{margin-top:30px}.footer-bottom-content{display:flex;justify-content:center;align-items:center;flex-wrap:wrap;gap:30px}.social-links{display:grid;align-items:center;gap:20px;flex-wrap:wrap;justify-content:center;gap:15px}.social-links a{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px}.social-links a::before{top:0;height:100%;display:none;background:currentColor;opacity:.1;transform:translateY(100%)}.social-links a:hover::before{transform:translateY(0)}.social-links a svg{width:30px;height:30px}.social-links a:hover svg{transform:scale(1.1) rotate(5deg)}.social-links a[href^=mailto]{color:#c22034}.social-links a[href*=twitter]{color:#1da1f2}.social-links a[href*=linkedin]{color:#0077b5}.social-links a[href*=facebook]{color:#1877f2}.social-links a[href*=youtube]{color:red}.social-links a[href*=instagram]{color:#ee2a7b}.footer-links{display:flex;gap:24px;flex-wrap:wrap;justify-content:center}.footer-links a{position:relative;padding:4px 0;margin-bottom:5px}.footer-links a:hover{color:#fff;transform:translateY(-2px)}.footer-links a::after,.footer-links a::before{bottom:0;height:2px;transform-origin:right;transform:scaleX(0)}.footer-links a::before{background:linear-gradient(to right,#3b82f6,#2563eb);opacity:.7}.footer-links a::after{background:linear-gradient(to right,#2563eb,#1d4ed8);transition-delay:0.1s}.footer-links a:hover::after,.footer-links a:hover::before{transform:scaleX(1);transform-origin:left}.footer-copyright{text-align:center;margin-top:30px;padding:20px 0;border-top:1px solid rgba(255,255,255,.1)}.footer-copyright::before{content:"";position:absolute;top:0;left:50%;transform:translateX(-50%);width:100px;height:1px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)}.newsletter-box{padding:15px;background:rgba(255,255,255,.05);border-radius:8px;width:100%;max-width:100%}.newsletter-box h4{color:#fff;font-size:16px;margin-bottom:12px}.newsletter-form{display:flex;gap:8px}.newsletter-form input[type=email]{flex:1;padding:8px 12px;border:1px solid rgba(255,255,255,.2);border-radius:4px;background:rgba(255,255,255,.1);color:#fff;font-size:14px;font-family:inherit;font-weight:500}.newsletter-form input[type=email]::placeholder{color:rgba(255,255,255,.6)}.newsletter-form input[type=email]:focus{outline:0;border-color:rgba(255,255,255,.4);background:rgba(255,255,255,.15)}#subscribe-btn{padding:8px 16px;background:#c22034;border:none;border-radius:4px;color:#fff;cursor:pointer;transition:.3s;white-space:nowrap;font-family:inherit;font-weight:500}#subscribe-btn:hover{background:#a91c2c}#subscribe-btn.loading{opacity:.7;cursor:wait}#subscription-status{margin-top:8px;font-size:12px}#subscription-status.success{color:#2ecc71}#subscription-status.error{color:#e74c3c}@media (max-width:1200px){.footer-grid{grid-template-columns:repeat(2,1fr)}}@media (max-width:991px){.footer-grid{grid-template-columns:repeat(2,1fr);gap:30px}.site-footer{padding:50px 0 20px}}@media (max-width:767px){.site-footer{padding:40px 0 20px;text-align:center}.footer-grid{grid-template-columns:1fr;gap:25px;text-align:center}.footer-column h3{font-size:18px;margin-bottom:15px}.footer-column ul li{margin-bottom:10px}.newsletter-box{margin:0 auto;max-width:100%}.footer-bottom-content{flex-direction:column;gap:25px}.social-links{width:100%}.footer-links{flex-direction:row;flex-wrap:wrap;width:100%;gap:15px}.newsletter-form{flex-direction:column;gap:10px}#subscribe-btn{width:100%;padding:10px}.social-links a{padding:8px}.social-links a span{display:none}.social-links a svg{width:22px;height:22px;margin:0}.footer-links{justify-content:center}.footer-copyright{font-size:12px;padding:15px 0;margin-top:25px}}@media (max-width:480px){.site-footer{padding:30px 0 15px}.footer-container{padding:0 15px}.footer-grid{gap:20px}.footer-column h3{font-size:17px}.footer-column ul li a{font-size:14px}.social-links{gap:5px;flex-wrap:wrap;justify-content:center}.footer-links{gap:10px}.footer-links a{font-size:13px;padding:5px 10px;background:rgba(255,255,255,.05);border-radius:4px;margin:3px}.footer-links a:hover::after,.footer-links a:hover::before{display:none}}
    </style>

    <footer class="site-footer">
        <div class="footer-container">
            <div class="footer-grid">
                <div class="footer-column">
                    <h3>Solutions</h3>
                    <ul>
                        <li><a href="<?php echo SN_HTTP_URL; ?>organic-marketing/">Organic Marketing</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>paid-marketing/">Paid Marketing</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>website-development/">Website Development</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>branding/">Branding</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>inside-sales/">Inside Sales</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>creative/">Creative</a></li>
                    </ul>
                </div>  
                <div class="footer-column">
                    <h3>Company</h3>
                    <ul>
                        <li><a href="<?php echo SN_HTTP_URL; ?>about-us/">About Us</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>our-team/">Our Team</a></li>
                        
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Resources</h3>
                    <ul>
                        <li><a href="<?php echo SN_HTTP_URL; ?>blogs/">Blogs</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>news/">News</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>case-studies/">Case Studies</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>faqs/">FAQs</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>contact/">Contact</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>testimonials/">Testimonials</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Policies</h3>
                    <ul>
                        <li><a href="<?php echo SN_HTTP_URL; ?>terms-and-conditions/">Terms and Conditions</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>privacy-policy/">Privacy Policy</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>refund-and-cancellation-policy/">Refund and Cancellation Policy</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>disclaimer-notice/">Disclaimer Notice</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>dmca-policy/">DMCA Policy</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>gdpr-policy/">GDPR Policy</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>ccpa-policy/">CCPA Policy</a></li>
                        <li><a href="<?php echo SN_HTTP_URL; ?>cookies-policy/">Cookies Policy</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <div class="newsletter-box">
                        <h4>Subscribe to Newsletter</h4>
                        <form id="newsletter-form" class="newsletter-form">
                            <input 
                                type="email" 
                                id="subscriber-email" 
                                placeholder="Enter your email"
                                required
                            >
                            <button type="submit" id="subscribe-btn">
                                <span>Subscribe</span>
                            </button>
                        </form>
                        <div id="subscription-status"></div>
                    </div>
                    <div class="social-links-container">
                        <h4>Follow Us</h4>
                        <div class="social-links">
                            
                            <a href="mailto:support@salesnanny.com" title="Email">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M20,4H4C2.9,4,2,4.9,2,6v12c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2V6C22,4.9,21.1,4,20,4z M20,8l-8,5L4,8V6l8,5l8-5V8z"/>
                                </svg>
                            </a>
                            <a href="https://www.facebook.com/profile.php?id=100089957388229" target="_blank" title="Facebook">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                                </svg>
                            </a>
                            <a href="https://www.linkedin.com/company/sales-nanny-solutions-private-limited/" target="_blank" title="LinkedIn">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/>
                                </svg>
                            </a>
                            <a href="https://www.instagram.com/sales.nanny/" target="_blank" title="Instagram">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                                </svg>
                            </a>
                            <a href="https://x.com/TheSalesNanny" target="_blank" title="X (Twitter)">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                                </svg>
                            </a>
                            <a href="https://in.pinterest.com/SalesNanny/" target="_blank" title="Pinterest">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M12 2C6.477 2 2 6.477 2 12c0 4.333 2.75 8.042 6.61 9.489-.09-.806-.17-2.045.035-2.927.186-.8 1.204-5.105 1.204-5.105s-.306-.615-.306-1.523c0-1.425.827-2.49 1.86-2.49.877 0 1.3.659 1.3 1.449 0 .883-.562 2.206-.852 3.428-.241.999.507 1.815 1.5 1.815 1.805 0 3.19-1.904 3.19-4.648 0-2.43-1.747-4.133-4.24-4.133-2.89 0-4.586 2.168-4.586 4.41 0 .877.337 1.818.759 2.33.084.1.096.187.07.29-.076.317-.25.999-.283 1.142-.044.185-.145.226-.334.137-1.243-.577-2.02-2.392-2.02-3.85 0-3.135 2.275-6.016 6.567-6.016 3.45 0 6.132 2.464 6.132 5.766 0 3.428-2.164 6.187-5.17 6.187-1.009 0-1.956-.527-2.281-1.15l-.62 2.366c-.226.885-.841 1.996-1.254 2.678.944.292 1.946.45 2.987.45 5.523 0 10-4.478 10-10S17.523 2 12 2Z"/>
                                </svg>
                            </a>
                            <a href="https://www.youtube.com/@SalesNanny" target="_blank" title="YouTube">
                                <svg viewBox="0 0 24 24" width="24" height="24">
                                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-copyright">
                © <?php echo date('Y'); ?>, SalesNanny Pvt. Ltd. All Rights Reserved.
            </div>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('newsletter-form');
            const emailInput = document.getElementById('subscriber-email');
            const submitBtn = document.getElementById('subscribe-btn');
            const status = document.getElementById('subscription-status');

            // Replace with your Google Apps Script Web App URL
            const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbxBXE76OMA0yd0lzYPNwEKz8ubnCBhhNmZCW8kC_QWsy-rxzXZx8Am91XJH2RTits7G/exec';

            /**
             * Format date in standard format (YYYY-MM-DD HH:MM:SS) regardless of locale
             * @param {Date} date - Date object to format
             * @returns {string} Formatted date string
             */
            function formatStandardDateTime(date) {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                const hours = String(date.getHours()).padStart(2, '0');
                const minutes = String(date.getMinutes()).padStart(2, '0');
                const seconds = String(date.getSeconds()).padStart(2, '0');
                return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
            }

            if(form) {
                form.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    
                    // Validate email
                    const email = emailInput.value.trim();
                    if (!isValidEmail(email)) {
                        showStatus('Please enter a valid email address', 'error');
                        return;
                    }

                    // Show loading state
                    submitBtn.classList.add('loading');
                    submitBtn.disabled = true;
                    showStatus('Subscribing...', '');

                    try {
                        // Get current date and format in standard format
                        const now = new Date();
                        const standardTimestamp = formatStandardDateTime(now);
                        const isoTimestamp = now.toISOString(); // Keep ISO for compatibility
                        
                        // Send data to Google Apps Script using JSONP approach
                        const formData = new FormData();
                        formData.append('email', email);
                        formData.append('timestamp', standardTimestamp);
                        formData.append('iso_timestamp', isoTimestamp);

                        // Create a temporary callback function
                        const callbackName = 'newsletter_callback_' + Math.random().toString(36).substr(2, 9);
                        window[callbackName] = function(response) {
                            if (response.status === 'success') {
                                showStatus('Thank you for subscribing!', 'success');
                                emailInput.value = '';
                            } else {
                                showStatus(response.message || 'Subscription failed. Please try again.', 'error');
                            }
                            // Cleanup
                            delete window[callbackName];
                            document.head.removeChild(script);
                        };

                        // Create script element for JSONP - send both standard and ISO formats
                        const script = document.createElement('script');
                        script.src = `${SCRIPT_URL}?callback=${callbackName}&email=${encodeURIComponent(email)}&timestamp=${encodeURIComponent(standardTimestamp)}&iso_timestamp=${encodeURIComponent(isoTimestamp)}`;
                        document.head.appendChild(script);

                        script.onerror = function() {
                            showStatus('Connection failed. Please try again.', 'error');
                            delete window[callbackName];
                            document.head.removeChild(script);
                        };

                    } catch (error) {
                        console.error('Subscription error:', error);
                        showStatus('Something went wrong. Please try again.', 'error');
                    } finally {
                        // Reset button state
                        submitBtn.classList.remove('loading');
                        submitBtn.disabled = false;
                    }
                });
            }

            function showStatus(message, type) {
                if(status) {
                    status.textContent = message;
                    status.className = `subscription-status ${type}`;
                    status.style.display = 'block';
                    
                    if (type === 'success' || type === 'error') {
                        setTimeout(() => {
                            status.style.display = 'none';
                        }, 5000);
                    }
                }
            }

            function isValidEmail(email) {
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            }
        });
    </script>
    <style>
        .subscription-status {
            margin-top: 10px;
            padding: 10px;
            border-radius: 4px;
            display: none;
        }
        .subscription-status.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .subscription-status.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .loading {
            opacity: 0.7;
            cursor: not-allowed;
        }

        /* Social Media Icons Styling */
        /* .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        } */

        .social-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            transform: translateY(-3px);
        }

        .social-links svg {
            width: 24px;
            height: 24px;
            fill: #ffffff;
        }

        /* Brand Colors */
        .social-links a[title="Email"] {
            background-color: #EA4335;
        }

        .social-links a[title="Facebook"] {
            background-color: #1877F2;
        }

        .social-links a[title="LinkedIn"] {
            background-color: #0A66C2;
        }

        .social-links a[title="Instagram"] {
            background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
        }

        .social-links a[title="X (Twitter)"] {
            background-color: #000000;
        }

        .social-links a[title="Pinterest"] {
            background-color: #E60023;
        }

        .social-links a[title="YouTube"] {
            background-color: #FF0000;
        }
    </style>
    <?php wp_footer(); ?>
    <?php
    
}
function get_custom_head(){
    ?>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <?php add_custom_meta_tags_and_schema(); ?>
        <?php add_article_schema(); ?>
        <?php add_organization_schema(); ?>
        <meta name="p:domain_verify" content="f9616b81638647793f43620f55b82913"/>
        <meta name="robots" content="index,follow">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <?php
}



function generate_sitemap() {
    // Clear all previous output buffering
    while (ob_get_level()) {
        ob_end_clean();
    }

    // Set the header content type to XML
    header('Content-Type: application/xml; charset=utf-8');

    // Start the XML output
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <!-- Home page -->
    <url>
        <loc>' . esc_url(home_url('/')) . '</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <!-- Blog home page -->
    <url>
        <loc>' . esc_url(home_url('/blogs/')) . '</loc>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>
    ';
    // Track processed URLs to avoid duplicates
    $processed_urls = array(
    esc_url(home_url('/')),
    esc_url(home_url('/blogs/'))
    );
    // Define post types and loop through them
    $post_types = array('post', 'page', 'glossary', 'author', 'category');
    foreach ($post_types as $post_type) {
    $args = array(
    'post_type' => $post_type,
    'post_status' => 'publish',
    'posts_per_page' => -1,
    );
    $posts = new WP_Query($args);
    if ($posts->have_posts()) {
    while ($posts->have_posts()) {
    $posts->the_post();
    $post_url = get_permalink();
    // Skip if URL already processed
    if (in_array($post_url, $processed_urls)) {
    continue;
    }
    $processed_urls[] = $post_url;
    $last_modified = get_post_modified_time('Y-m-d\TH:i:sP', true);
    $priority = (get_post_type() === 'post') ? 0.8 : 0.7;
    echo '
    <url>
        <loc>' . esc_url($post_url) . '</loc>
        <lastmod>' . esc_html($last_modified) . '</lastmod>
        <changefreq>weekly</changefreq>
        <priority>' . esc_attr($priority) . '</priority>
    </url>
    ';
    }
    wp_reset_postdata();
    }
    }
    // Include only authors who have published posts
    $authors = get_users(array(
    'who' => 'authors',
    'has_published_posts' => array('post')
    ));
    foreach ($authors as $author) {
    $author_url = get_author_posts_url($author->ID);
    // Skip if URL already processed
    if (in_array($author_url, $processed_urls)) {
    continue;
    }
    $processed_urls[] = $author_url;
    echo '
    <url>
        <loc>' . esc_url($author_url) . '</loc>
        <changefreq>weekly</changefreq>
        <priority>0.5</priority>
    </url>
    ';
    }
    // Close the XML structure
    echo '
    </urlset>
    ';
    exit;
}

function add_sitemap_rewrite_rule() {
    add_rewrite_rule('^sitemap\.xml$', 'index.php?sitemap=1', 'top');
}
add_action('init', 'add_sitemap_rewrite_rule');

function flush_rewrite_rules_on_activation() {
    add_sitemap_rewrite_rule();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'flush_rewrite_rules_on_activation');
register_deactivation_hook(__FILE__, 'flush_rewrite_rules');

function add_sitemap_query_var($vars) {
    $vars[] = 'sitemap';
    return $vars;
}
add_filter('query_vars', 'add_sitemap_query_var');

function generate_sitemap_on_request() {
    if (get_query_var('sitemap')) {
    generate_sitemap();
}
}
add_action('template_redirect', 'generate_sitemap_on_request'); 

function validate_image_size($file) {
    $max_size = 200 * 1024;
    $filetype = wp_check_filetype($file['name']);
    $is_image = strpos($filetype['type'], 'image') !== false;
    if ($is_image && $file['size'] > $max_size) {
        $file['error'] = 'Image file size must be less than 200KB. Please optimize your image and try again.';
    }
    return $file;
}
add_filter('wp_handle_upload_prefilter', 'validate_image_size');
  
function validate_featured_image_size($image, $attachment_id) {
    $max_size = 200 * 1024; // 200KB in bytes
    if ($image['filesize'] > $max_size) {
        wp_delete_attachment($attachment_id, true);
        return new WP_Error('size_error', 'Featured image must be less than 200KB. Please optimize your image and try again.');
    }
    return $image;
}
add_filter('wp_generate_attachment_metadata', 'validate_featured_image_size', 10, 2);
  
function image_size_admin_notice() {
    echo '
    <div class="notice notice-info is-dismissible">
        <p>Note: All uploaded images must be less than 200KB in size.</p>
    </div>
    ';
}
add_action('admin_notices', 'image_size_admin_notice');

function add_viewport_meta_tag() {
    echo '
    <meta name="viewport" content="width=device-width, initial-scale=1">
    ';
}
add_action('wp_head', 'add_viewport_meta_tag', 1);

add_filter('automatic_updater_disabled', '__return_true');
add_filter('auto_update_core', '__return_false');
add_filter('allow_minor_auto_core_updates', '__return_false');
add_filter('allow_major_auto_core_updates', '__return_false');
add_filter('auto_update_translation', '__return_false');
add_filter('pre_site_transient_update_core', '__return_null');
add_action('admin_init', function() {
remove_action('admin_notices', 'update_nag', 3);
remove_action('admin_notices', 'maintenance_nag', 10);
});

// Website Checker AJAX handler
function handle_check_website_ajax() {
    check_ajax_referer('website_checker_nonce', 'nonce');

    if (isset($_POST['website_url'])) {
        $url = esc_url_raw(trim($_POST['website_url']));

        // Try to fetch headers
        $headers = @get_headers($url);
        
        if ($headers && strpos($headers[0], '200') !== false) {
            echo '<p style="color: green;"><strong>✅ ' . esc_html($url) . '</strong> is reachable and responding with status 200.</p>';
        } elseif ($headers) {
            echo '<p style="color: orange;"><strong>⚠️ ' . esc_html($url) . '</strong> responded with: ' . esc_html($headers[0]) . '</p>';
        } else {
            echo '<p style="color: red;"><strong>❌ ' . esc_html($url) . '</strong> could not be reached or is invalid.</p>';
        }
    } else {
        echo '<p style="color: red;">Please provide a valid URL.</p>';
    }

    wp_die(); // Important: end AJAX
}

add_action('wp_ajax_check_website', 'handle_check_website_ajax');
add_action('wp_ajax_nopriv_check_website', 'handle_check_website_ajax');



function salesnanny_side_panel() {
    ?>
        <style>
             .panel-trigger,
            .side-panel {
                position: fixed;
                right: 0;
                transform: translateY(-50%);
            }
            .panel-trigger {
                top: 50%;
            }
            .side-panel {
                top: 25%;
            }
            .eye-icon,
            .panel-trigger svg {
                width: 24px;
                height: 24px;
            }
            .panel-trigger {
                background: #C52A3D;
                color: #fff;
                padding: 10px;
                border-top-left-radius: 4px;
                border-bottom-left-radius: 4px;
                cursor: pointer;
                border: none;
                box-shadow: 0 4px 15px rgba(79, 70, 229, .3);
                z-index: 999;
                width: 45px;
                height: 45px;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: transform 0.3s ease;
            }
            .panel-trigger:hover {
                transform: translateY(-50%) scale(1.05);
            }
            .close-panel,
            .panel-item {
                display: flex;
                color: #fff
            }

            .side-panel {
                width: 300px;
                height: 400px;
                background: #C52A3D;
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                box-shadow: -5px 0 30px rgba(0, 0, 0, .15);
                z-index: 1000;
                transition: transform 0.3s cubic-bezier(.4, 0, .2, 1);
                display: flex;
                flex-direction: column;
                border-radius: 20px;
                margin-right: 20px;
                transform: translateX(100%);
                top:25%;
            }
            .side-panel.active {
                transform: translateX(0);
            }
            .side-panel::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 100%;
                background: linear-gradient(135deg, rgba(197, 42, 61, .05) 0, rgba(197, 42, 61, .05) 100%);
                border-radius: 20px;
                pointer-events: none
            }

            .side-panel-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 20px;
                background: linear-gradient(135deg, rgba(197, 42, 61, .1), rgba(197, 42, 61, .1));
                border-radius: 20px 20px 0 0
            }

            .side-panel-header h3 {
                margin: 0;
                color: #fff;
                font-size: 1.25rem;
                font-weight: 600
            }

            .close-panel {
                background: rgba(255, 255, 255, .1);
                border: none;
                padding: 8px;
                cursor: pointer;
                transition: .3s;
                border-radius: 50%;
                width: 32px;
                height: 32px;
                align-items: center;
                justify-content: center
            }

            .close-panel svg {
                width: 16px;
                height: 16px;
                stroke: #fff
            }

            .side-panel-content {
                padding: 20px;
                flex-grow: 1
            }

            .panel-item {
                align-items: center;
                gap: 12px;
                padding: 12px 15px;
                margin-bottom: 10px;
                text-decoration: none;
                border-radius: 12px;
                transition: .4s cubic-bezier(.4, 0, .2, 1);
                background: rgba(255, 255, 255, .1);
                border: 1px solid rgba(255, 255, 255, .1);
                font-size: .95rem;
                color: #fff;
                cursor: pointer;
            }

            .panel-item svg {
                width: 20px;
                height: 20px;
                stroke: #fff;
                flex-shrink: 0
            }

            .panel-item::after {
                content: '→';
                margin-left: auto;
                opacity: 0;
                transform: translateX(-10px);
                transition: .3s;
                color: #fff
            }
            /* Home page specific fix */
            body.home .side-panel {
                top: 50% !important;
                right: 0 !important;
                transform: translateY(-50%) translateX(100%) !important;
                position: fixed !important;
            }
            body.home .side-panel.active {
                transform: translateY(-50%) translateX(0) !important;
            }
            @media (max-width: 768px) {
                .side-panel {
                    width: 260px;
                    height: 380px;
                    margin-right: 10px;
                }
                .panel-trigger {
                    right: 10px;
                    width: 45px;
                    height: 45px;
                }
                .panel-trigger svg {
                    width: 20px;
                    height: 20px;
                }
                .side-panel-content,
                .side-panel-header {
                    padding: 15px;
                }
                .panel-item {
                    padding: 10px 12px;
                    margin-bottom: 8px;
                    font-size: .9rem;
                }
                .panel-item svg {
                    width: 18px;
                    height: 18px;
                }
            }
            @media (max-width: 480px) {
                .side-panel {
                    width: 240px;
                    height: 360px;
                }
                .panel-trigger {
                    width: 40px;
                    height: 40px;
                    right: 0px;
                }
            }

        </style>
        <button class="panel-trigger" aria-label="Open side panel">
            <svg  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
        </button>
        <div class="side-panel" aria-hidden="true" style="display: none;">
            <div class="side-panel-header">
                <h3>Quick Actions</h3>
                <button class="close-panel" aria-label="Close panel">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 6L6 18M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <div class="side-panel-content">
                <a  class="calendly-trigger panel-item">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                    Schedule a call
                </a>
                <a class="panel-item" onclick="openAuditPopup()" style="background: rgba(255, 255, 255, .1);    border: 1px solid rgba(255, 255, 255, .1);">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                        Get a free website audit
                </a>
                <a href="<?php echo SN_HTTP_URL; ?>pricing/" class="panel-item">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                    Pricing
                </a>
                <a href="<?php echo SN_HTTP_URL; ?>blogs/" class="panel-item">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                    Learn Digital Marketing Tips
                </a>
                <a href="<?php echo SN_HTTP_URL; ?>contact/" class="panel-item">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                    </svg>
                    Contact us
                </a>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const panelTrigger = document.querySelector('.panel-trigger');
                const sidePanel = document.querySelector('.side-panel');
                const closePanel = document.querySelector('.close-panel');

                // Open panel
                panelTrigger.addEventListener('click', () => {
                    sidePanel.style.display = 'flex';
                    requestAnimationFrame(() => {
                        sidePanel.classList.add('active');
                    });
                    sidePanel.setAttribute('aria-hidden', 'false');
                });

                // Close panel
                closePanel.addEventListener('click', () => {
                    sidePanel.classList.remove('active');
                    setTimeout(() => {
                        sidePanel.style.display = 'none';
                    }, 300);
                    sidePanel.setAttribute('aria-hidden', 'true');
                });

                // Close panel when clicking outside
                document.addEventListener('click', (e) => {
                    if (sidePanel.classList.contains('active') && 
                        !sidePanel.contains(e.target) && 
                        !panelTrigger.contains(e.target)) {
                        sidePanel.classList.remove('active');
                        setTimeout(() => {
                            sidePanel.style.display = 'none';
                        }, 300);
                        sidePanel.setAttribute('aria-hidden', 'true');
                    }
                });

                // Prevent clicks inside panel from closing it
                sidePanel.addEventListener('click', (e) => {
                    e.stopPropagation();
                });
            });
        </script>
    <?php
}

/**
 * Website Performance & SEO Analyzer Functions
 */

// AJAX handler for website analysis
function handle_website_analyzer_ajax() {
    check_ajax_referer('website_analyzer_nonce', 'nonce');
    
    if (!isset($_POST['website_url'])) {
        wp_send_json_error('Website URL is required');
        return;
    }
    
    $url = esc_url_raw(trim($_POST['website_url']));
    
    if (empty($url)) {
        wp_send_json_error('Invalid website URL');
        return;
    }
    
    // Perform comprehensive website analysis
    $analysis_result = perform_website_analysis($url);
    
    wp_send_json_success($analysis_result);
}

add_action('wp_ajax_analyze_website', 'handle_website_analyzer_ajax');
add_action('wp_ajax_nopriv_analyze_website', 'handle_website_analyzer_ajax');

/**
 * Perform comprehensive website analysis
 */
function perform_website_analysis($url) {
    // Fetch website content
    $response = wp_remote_get($url, array(
        'timeout' => 30,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    ));
    
    if (is_wp_error($response)) {
        return array(
            'error' => 'Failed to fetch website: ' . $response->get_error_message()
        );
    }
    
    $body = wp_remote_retrieve_body($response);
    $headers = wp_remote_retrieve_headers($response);
    
    // Perform analysis on different categories
    $categories = array(
        'page_speed' => analyze_page_speed($url, $body, $headers),
        'mobile_friendliness' => analyze_mobile_friendliness($body),
        'seo' => analyze_seo($body, $url),
        'security' => analyze_security($url, $headers),
        'accessibility' => analyze_accessibility($body),
        'best_practices' => analyze_best_practices($body, $headers)
    );
    
    // Calculate overall score
    $total_score = 0;
    $category_count = count($categories);
    foreach ($categories as $category) {
        $total_score += $category['score'];
    }
    $overall_score = round($total_score / $category_count);
    
    // Detect technologies
    $technologies = detect_technologies($body, $headers);
    
    return array(
        'url' => $url,
        'overall_score' => $overall_score,
        'categories' => $categories,
        'technologies' => $technologies,
        'analysis_date' => current_time('Y-m-d H:i:s')
    );
}

/**
 * Analyze Page Speed (Core Web Vitals simulation)
 */
function analyze_page_speed($url, $body, $headers) {
    $score = 85; // Base score
    $issues = array();
    $suggestions = array();
    
    // Check for large images
    preg_match_all('/<img[^>]+>/i', $body, $images);
    $large_images = 0;
    $total_images = count($images[0]);
    foreach ($images[0] as $img) {
        if (strpos($img, 'width="') !== false && strpos($img, 'height="') !== false) {
            // Check if image dimensions are reasonable
            preg_match('/width="(\d+)"/', $img, $width_match);
            preg_match('/height="(\d+)"/', $img, $height_match);
            if (isset($width_match[1]) && isset($height_match[1])) {
                $width = intval($width_match[1]);
                $height = intval($height_match[1]);
                if ($width > 1920 || $height > 1080) {
                    $large_images++;
                }
            }
        }
    }
    
    if ($large_images > 0) {
        $score -= 10;
        $issues[] = "Found {$large_images} large images that may slow down page load";
        $suggestions[] = "Optimize images using tools like TinyPNG or WebP format";
    }
    
    // Check for external resources
    $external_resources = preg_match_all('/https?:\/\/(?!' . parse_url($url, PHP_URL_HOST) . ')/i', $body);
    if ($external_resources > 10) {
        $score -= 5;
        $issues[] = "Many external resources may impact loading speed";
        $suggestions[] = "Consider hosting critical resources locally";
    }
    
    // Check for minified CSS/JS
    if (strpos($body, '.min.css') === false && strpos($body, '.min.js') === false) {
        $score -= 5;
        $issues[] = "CSS and JavaScript files are not minified";
        $suggestions[] = "Minify CSS and JavaScript files to reduce file size";
    }
    
    // Check for compression
    $content_encoding = wp_remote_retrieve_header($headers, 'content-encoding');
    if (empty($content_encoding)) {
        $score -= 5;
        $issues[] = "GZIP compression not detected";
        $suggestions[] = "Enable GZIP compression on your server";
    }
    
    // Check for CDN usage
    $cdn_indicators = array('cdn', 'cloudflare', 'akamai', 'fastly');
    $has_cdn = false;
    foreach ($cdn_indicators as $indicator) {
        if (stripos($body, $indicator) !== false) {
            $has_cdn = true;
            break;
        }
    }
    
    if (!$has_cdn) {
        $suggestions[] = "Consider using a CDN to improve global loading speeds";
    }
    
    // Check for lazy loading
    if (strpos($body, 'loading="lazy"') === false && $total_images > 3) {
        $score -= 5;
        $issues[] = "Images not using lazy loading";
        $suggestions[] = "Add loading=\"lazy\" to images below the fold";
    }
    
    // Check for critical CSS inline
    if (strpos($body, '<style>') === false) {
        $suggestions[] = "Consider inlining critical CSS for above-the-fold content";
    }
    
    // Check for HTTP/2 indicators
    $server_header = wp_remote_retrieve_header($headers, 'server');
    if (strpos($server_header, 'nginx') !== false || strpos($server_header, 'apache') !== false) {
        $suggestions[] = "Ensure HTTP/2 is enabled on your server for better performance";
    }
    
    return array(
        'score' => max(0, $score),
        'description' => 'Page speed analysis based on Core Web Vitals principles including LCP, FID, and CLS optimization.',
        'issues' => $issues,
        'suggestions' => $suggestions,
        'metrics' => array(
            'total_images' => $total_images,
            'large_images' => $large_images,
            'external_resources' => $external_resources,
            'has_cdn' => $has_cdn,
            'has_compression' => !empty($content_encoding)
        )
    );
}

/**
 * Analyze Mobile Friendliness
 */
function analyze_mobile_friendliness($body) {
    $score = 90;
    $issues = array();
    $suggestions = array();
    
    // Check for viewport meta tag
    if (strpos($body, 'viewport') === false) {
        $score -= 20;
        $issues[] = "Missing viewport meta tag";
        $suggestions[] = "Add viewport meta tag: <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";
    }
    
    // Check for responsive design indicators
    $responsive_indicators = array('@media', 'flex', 'grid', 'responsive');
    $has_responsive = false;
    foreach ($responsive_indicators as $indicator) {
        if (stripos($body, $indicator) !== false) {
            $has_responsive = true;
            break;
        }
    }
    
    if (!$has_responsive) {
        $score -= 15;
        $issues[] = "No responsive design indicators found";
        $suggestions[] = "Implement responsive design using CSS media queries";
    }
    
    // Check for touch-friendly elements
    if (strpos($body, 'touch') === false && strpos($body, 'tap') === false) {
        $score -= 5;
        $suggestions[] = "Consider adding touch-friendly interactions for mobile users";
    }
    
    // Check for mobile-optimized images
    if (strpos($body, 'srcset') === false && strpos($body, 'sizes') === false) {
        $score -= 10;
        $issues[] = "Images not optimized for different screen sizes";
        $suggestions[] = "Use srcset and sizes attributes for responsive images";
    }
    
    // Check for mobile navigation
    $mobile_nav_indicators = array('hamburger', 'menu-toggle', 'mobile-menu', 'nav-toggle');
    $has_mobile_nav = false;
    foreach ($mobile_nav_indicators as $indicator) {
        if (stripos($body, $indicator) !== false) {
            $has_mobile_nav = true;
            break;
        }
    }
    
    if (!$has_mobile_nav) {
        $suggestions[] = "Ensure mobile navigation is optimized for touch interaction";
    }
    
    // Check for font size
    if (strpos($body, 'font-size: 16px') === false && strpos($body, 'font-size: 1rem') === false) {
        $suggestions[] = "Use minimum 16px font size to prevent zoom on mobile devices";
    }
    
    return array(
        'score' => max(0, $score),
        'description' => 'Mobile-friendliness assessment including responsive design, touch interactions, and mobile optimization.',
        'issues' => $issues,
        'suggestions' => $suggestions,
        'metrics' => array(
            'has_viewport' => strpos($body, 'viewport') !== false,
            'has_responsive' => $has_responsive,
            'has_mobile_nav' => $has_mobile_nav,
            'has_srcset' => strpos($body, 'srcset') !== false
        )
    );
}

/**
 * Analyze SEO Optimization
 */
function analyze_seo($body, $url) {
    $score = 80;
    $issues = array();
    $suggestions = array();
    
    // Check for title tag
    if (preg_match('/<title>(.*?)<\/title>/i', $body, $title_match)) {
        $title = trim($title_match[1]);
        if (strlen($title) < 30 || strlen($title) > 60) {
            $score -= 10;
            $issues[] = "Title length should be between 30-60 characters (current: " . strlen($title) . ")";
            $suggestions[] = "Optimize title length for better search engine visibility";
        }
    } else {
        $score -= 20;
        $issues[] = "Missing title tag";
        $suggestions[] = "Add a descriptive title tag for better SEO";
    }
    
    // Check for meta description
    if (preg_match('/<meta[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\']/i', $body, $desc_match)) {
        $description = trim($desc_match[1]);
        if (strlen($description) < 120 || strlen($description) > 160) {
            $score -= 10;
            $issues[] = "Meta description should be between 120-160 characters (current: " . strlen($description) . ")";
            $suggestions[] = "Optimize meta description length";
        }
    } else {
        $score -= 15;
        $issues[] = "Missing meta description";
        $suggestions[] = "Add a compelling meta description to improve click-through rates";
    }
    
    // Check for heading structure
    $h1_count = substr_count(strtolower($body), '<h1');
    $h2_count = substr_count(strtolower($body), '<h2');
    $h3_count = substr_count(strtolower($body), '<h3');
    
    if ($h1_count === 0) {
        $score -= 15;
        $issues[] = "Missing H1 heading";
        $suggestions[] = "Add a main H1 heading for better SEO structure";
    } elseif ($h1_count > 1) {
        $score -= 10;
        $issues[] = "Multiple H1 headings found ({$h1_count})";
        $suggestions[] = "Use only one H1 heading per page";
    }
    
    if ($h2_count === 0) {
        $score -= 5;
        $suggestions[] = "Add H2 headings to improve content structure";
    }
    
    // Check for alt text on images
    $img_count = substr_count(strtolower($body), '<img');
    $alt_count = substr_count(strtolower($body), 'alt=');
    
    if ($img_count > 0 && $alt_count < $img_count) {
        $score -= 10;
        $issues[] = "Some images missing alt text";
        $suggestions[] = "Add descriptive alt text to all images for accessibility and SEO";
    }
    
    // Check for internal links
    $internal_links = preg_match_all('/href=["\']([^"\']*' . parse_url($url, PHP_URL_HOST) . '[^"\']*)["\']/i', $body);
    if ($internal_links < 3) {
        $score -= 5;
        $suggestions[] = "Add more internal links to improve site structure";
    }
    
    // Check for schema markup
    if (strpos($body, 'schema.org') === false && strpos($body, 'application/ld+json') === false) {
        $score -= 10;
        $issues[] = "No structured data (schema markup) found";
        $suggestions[] = "Add structured data to help search engines understand your content";
    }
    
    // Check for canonical URL
    if (strpos($body, 'rel="canonical"') === false) {
        $score -= 5;
        $suggestions[] = "Add canonical URL to prevent duplicate content issues";
    }
    
    // Check for social media meta tags
    $social_indicators = array('og:', 'twitter:', 'facebook');
    $has_social = false;
    foreach ($social_indicators as $indicator) {
        if (strpos($body, $indicator) !== false) {
            $has_social = true;
            break;
        }
    }
    
    if (!$has_social) {
        $score -= 5;
        $suggestions[] = "Add Open Graph and Twitter Card meta tags for better social sharing";
    }
    
    return array(
        'score' => max(0, $score),
        'description' => 'SEO analysis covering meta tags, heading structure, image optimization, internal linking, and structured data.',
        'issues' => $issues,
        'suggestions' => $suggestions,
        'metrics' => array(
            'h1_count' => $h1_count,
            'h2_count' => $h2_count,
            'h3_count' => $h3_count,
            'img_count' => $img_count,
            'alt_count' => $alt_count,
            'internal_links' => $internal_links,
            'has_schema' => strpos($body, 'schema.org') !== false,
            'has_social' => $has_social
        )
    );
}

/**
 * Analyze Security
 */
function analyze_security($url, $headers) {
    $score = 85;
    $issues = array();
    $suggestions = array();
    
    // Check for HTTPS
    if (strpos($url, 'https://') !== 0) {
        $score -= 30;
        $issues[] = "Website not using HTTPS";
        $suggestions[] = "Install SSL certificate and redirect HTTP to HTTPS";
    }
    
    // Check for security headers
    $security_headers = array(
        'X-Frame-Options' => 'Prevents clickjacking attacks',
        'X-Content-Type-Options' => 'Prevents MIME type sniffing',
        'X-XSS-Protection' => 'Enables XSS protection',
        'Strict-Transport-Security' => 'Enforces HTTPS connections',
        'Content-Security-Policy' => 'Prevents XSS and injection attacks'
    );
    
    $missing_headers = array();
    foreach ($security_headers as $header => $description) {
        $header_value = wp_remote_retrieve_header($headers, $header);
        if (empty($header_value)) {
            $score -= 5;
            $missing_headers[] = $header;
            $suggestions[] = "Add {$header} header: {$description}";
        }
    }
    
    if (!empty($missing_headers)) {
        $issues[] = "Missing security headers: " . implode(', ', $missing_headers);
    }
    
    // Check for server information disclosure
    $server_header = wp_remote_retrieve_header($headers, 'server');
    if (!empty($server_header)) {
        $score -= 5;
        $suggestions[] = "Consider hiding server information in headers";
    }
    
    // Check for referrer policy
    $referrer_policy = wp_remote_retrieve_header($headers, 'Referrer-Policy');
    if (empty($referrer_policy)) {
        $score -= 5;
        $suggestions[] = "Add Referrer-Policy header to control referrer information";
    }
    
    // Check for permissions policy
    $permissions_policy = wp_remote_retrieve_header($headers, 'Permissions-Policy');
    if (empty($permissions_policy)) {
        $suggestions[] = "Consider adding Permissions-Policy header for better security";
    }
    
    return array(
        'score' => max(0, $score),
        'description' => 'Security assessment including HTTPS, security headers, and information disclosure.',
        'issues' => $issues,
        'suggestions' => $suggestions,
        'metrics' => array(
            'has_https' => strpos($url, 'https://') === 0,
            'missing_headers' => count($missing_headers),
            'server_disclosed' => !empty($server_header)
        )
    );
}

/**
 * Analyze Accessibility
 */
function analyze_accessibility($body) {
    $score = 75;
    $issues = array();
    $suggestions = array();
    
    // Check for ARIA labels
    $aria_indicators = array('aria-label', 'aria-labelledby', 'aria-describedby');
    $has_aria = false;
    foreach ($aria_indicators as $indicator) {
        if (strpos($body, $indicator) !== false) {
            $has_aria = true;
            break;
        }
    }
    
    if (!$has_aria) {
        $score -= 10;
        $issues[] = "No ARIA labels found";
        $suggestions[] = "Add ARIA labels to improve screen reader accessibility";
    }
    
    // Check for form labels
    $form_count = substr_count(strtolower($body), '<form');
    $label_count = substr_count(strtolower($body), '<label');
    
    if ($form_count > 0 && $label_count < $form_count) {
        $score -= 15;
        $issues[] = "Forms missing proper labels";
        $suggestions[] = "Add descriptive labels to all form fields";
    }
    
    // Check for semantic HTML
    $semantic_elements = array('nav', 'main', 'article', 'section', 'aside', 'header', 'footer');
    $has_semantic = false;
    foreach ($semantic_elements as $element) {
        if (strpos($body, "<{$element}") !== false) {
            $has_semantic = true;
            break;
        }
    }
    
    if (!$has_semantic) {
        $score -= 10;
        $issues[] = "No semantic HTML elements found";
        $suggestions[] = "Use semantic HTML elements (nav, main, article, etc.) for better accessibility";
    }
    
    // Check for skip links
    if (strpos($body, 'skip') === false && strpos($body, 'jump') === false) {
        $score -= 5;
        $suggestions[] = "Consider adding skip navigation links for keyboard users";
    }
    
    // Check for color contrast (simplified)
    $color_indicators = array('color:', 'background-color:', 'background:');
    $has_colors = false;
    foreach ($color_indicators as $indicator) {
        if (strpos($body, $indicator) !== false) {
            $has_colors = true;
            break;
        }
    }
    
    if ($has_colors) {
        $suggestions[] = "Ensure sufficient color contrast ratios (4.5:1 for normal text)";
    }
    
    // Check for keyboard navigation
    if (strpos($body, 'tabindex') === false) {
        $suggestions[] = "Ensure all interactive elements are keyboard accessible";
    }
    
    // Check for focus indicators
    if (strpos($body, 'focus') === false && strpos($body, 'outline') === false) {
        $suggestions[] = "Add visible focus indicators for keyboard navigation";
    }
    
    return array(
        'score' => max(0, $score),
        'description' => 'Accessibility evaluation covering ARIA labels, semantic HTML, form accessibility, and color contrast.',
        'issues' => $issues,
        'suggestions' => $suggestions,
        'metrics' => array(
            'has_aria' => $has_aria,
            'form_count' => $form_count,
            'label_count' => $label_count,
            'has_semantic' => $has_semantic,
            'has_skip_links' => strpos($body, 'skip') !== false
        )
    );
}

/**
 * Analyze Best Practices
 */
function analyze_best_practices($body, $headers) {
    $score = 80;
    $issues = array();
    $suggestions = array();
    
    // Check for favicon
    if (strpos($body, 'favicon') === false && strpos($body, 'icon') === false) {
        $score -= 10;
        $issues[] = "No favicon detected";
        $suggestions[] = "Add a favicon to improve brand recognition";
    }
    
    // Check for robots.txt
    $robots_url = parse_url($body, PHP_URL_SCHEME) . '://' . parse_url($body, PHP_URL_HOST) . '/robots.txt';
    $robots_response = wp_remote_get($robots_url);
    if (is_wp_error($robots_response) || wp_remote_retrieve_response_code($robots_response) !== 200) {
        $score -= 5;
        $suggestions[] = "Create a robots.txt file to guide search engine crawlers";
    }
    
    // Check for sitemap
    $sitemap_indicators = array('sitemap.xml', 'sitemap_index.xml');
    $has_sitemap = false;
    foreach ($sitemap_indicators as $indicator) {
        if (strpos($body, $indicator) !== false) {
            $has_sitemap = true;
            break;
        }
    }
    
    if (!$has_sitemap) {
        $score -= 5;
        $suggestions[] = "Create and submit an XML sitemap to search engines";
    }
    
    // Check for social media meta tags
    $social_indicators = array('og:', 'twitter:', 'facebook');
    $has_social = false;
    foreach ($social_indicators as $indicator) {
        if (strpos($body, $indicator) !== false) {
            $has_social = true;
            break;
        }
    }
    
    if (!$has_social) {
        $score -= 5;
        $suggestions[] = "Add Open Graph and Twitter Card meta tags for better social sharing";
    }
    
    // Check for schema markup
    if (strpos($body, 'schema.org') === false && strpos($body, 'application/ld+json') === false) {
        $score -= 10;
        $issues[] = "No structured data (schema markup) found";
        $suggestions[] = "Add structured data to help search engines understand your content";
    }
    
    // Check for analytics
    $analytics_indicators = array('google-analytics', 'gtag', 'ga(', 'analytics');
    $has_analytics = false;
    foreach ($analytics_indicators as $indicator) {
        if (stripos($body, $indicator) !== false) {
            $has_analytics = true;
            break;
        }
    }
    
    if (!$has_analytics) {
        $suggestions[] = "Consider adding analytics to track website performance";
    }
    
    // Check for content quality indicators
    $content_indicators = array('article', 'blog', 'news', 'content');
    $has_content = false;
    foreach ($content_indicators as $indicator) {
        if (stripos($body, $indicator) !== false) {
            $has_content = true;
            break;
        }
    }
    
    if (!$has_content) {
        $suggestions[] = "Consider adding valuable content to improve user engagement";
    }
    
    // Check for contact information
    $contact_indicators = array('contact', 'email', 'phone', 'address');
    $has_contact = false;
    foreach ($contact_indicators as $indicator) {
        if (stripos($body, $indicator) !== false) {
            $has_contact = true;
            break;
        }
    }
    
    if (!$has_contact) {
        $suggestions[] = "Add contact information for better user trust";
    }
    
    return array(
        'score' => max(0, $score),
        'description' => 'Best practices evaluation including favicon, robots.txt, sitemaps, social media tags, structured data, and content quality.',
        'issues' => $issues,
        'suggestions' => $suggestions,
        'metrics' => array(
            'has_favicon' => strpos($body, 'favicon') !== false,
            'has_sitemap' => $has_sitemap,
            'has_social' => $has_social,
            'has_schema' => strpos($body, 'schema.org') !== false,
            'has_analytics' => $has_analytics,
            'has_content' => $has_content,
            'has_contact' => $has_contact
        )
    );
}

/**
 * Detect technologies used
 */
function detect_technologies($body, $headers) {
    $technologies = array();
    
    // CMS Detection
    $cms_indicators = array(
        'WordPress' => array('wp-content', 'wp-includes', 'wp-admin'),
        'Drupal' => array('drupal', 'sites/default'),
        'Joomla' => array('joomla', 'components/com_'),
        'Shopify' => array('shopify', 'myshopify.com'),
        'WooCommerce' => array('woocommerce', 'wc-'),
        'Magento' => array('magento', 'magento_version'),
        'Squarespace' => array('squarespace', 'static1.squarespace'),
        'Wix' => array('wix', 'wixsite.com'),
        'Webflow' => array('webflow', 'webflow.io')
    );
    
    foreach ($cms_indicators as $cms => $indicators) {
        foreach ($indicators as $indicator) {
            if (stripos($body, $indicator) !== false) {
                $technologies[] = array('name' => $cms, 'version' => 'Detected');
                break 2;
            }
        }
    }
    
    // Framework Detection
    $framework_indicators = array(
        'React' => array('react', 'reactjs'),
        'Vue.js' => array('vue', 'vuejs'),
        'Angular' => array('angular', 'ng-'),
        'Bootstrap' => array('bootstrap', 'bootstrap.min.css'),
        'jQuery' => array('jquery', 'jquery.min.js'),
        'Laravel' => array('laravel', 'csrf-token'),
        'Django' => array('django', 'csrftoken'),
        'Ruby on Rails' => array('rails', '_csrf_token'),
        'Node.js' => array('node', 'express')
    );
    
    foreach ($framework_indicators as $framework => $indicators) {
        foreach ($indicators as $indicator) {
            if (stripos($body, $indicator) !== false) {
                $technologies[] = array('name' => $framework, 'version' => 'Detected');
                break 2;
            }
        }
    }
    
    // Server Technology Detection
    $server_header = wp_remote_retrieve_header($headers, 'server');
    if (!empty($server_header)) {
        $technologies[] = array('name' => 'Server', 'version' => $server_header);
    }
    
    // PHP Detection
    if (strpos($body, 'php') !== false || strpos($body, '.php') !== false) {
        $technologies[] = array('name' => 'PHP', 'version' => 'Detected');
    }
    
    // CDN Detection
    $cdn_indicators = array(
        'Cloudflare' => 'cloudflare',
        'Akamai' => 'akamai',
        'Fastly' => 'fastly',
        'AWS CloudFront' => 'cloudfront',
        'Google Cloud CDN' => 'googleusercontent'
    );
    
    foreach ($cdn_indicators as $cdn => $indicator) {
        if (stripos($body, $indicator) !== false) {
            $technologies[] = array('name' => $cdn, 'version' => 'CDN');
            break;
        }
    }
    
    return $technologies;
}

/**
 * Generate PDF Report (placeholder for future implementation)
 */
function generate_website_analysis_pdf($analysis_data) {
    // This would integrate with a PDF library like DomPDF or TCPDF
    // For now, return a JSON response that can be converted to PDF on the frontend
    
    $pdf_data = array(
        'title' => 'Website Performance & SEO Analysis Report',
        'url' => $analysis_data['url'],
        'date' => $analysis_data['analysis_date'],
        'overall_score' => $analysis_data['overall_score'],
        'categories' => $analysis_data['categories'],
        'technologies' => $analysis_data['technologies'],
        'company_info' => array(
            'name' => 'SalesNanny',
            'website' => 'https://salesnanny.com',
            'email' => 'support@salesnanny.com'
        )
    );
    
    return $pdf_data;
}

// Add AJAX handler for PDF generation
function handle_pdf_generation_ajax() {
    check_ajax_referer('website_analyzer_nonce', 'nonce');
    
    if (!isset($_POST['analysis_data'])) {
        wp_send_json_error('Analysis data is required');
        return;
    }
    
    $analysis_data = json_decode(stripslashes($_POST['analysis_data']), true);
    $pdf_data = generate_website_analysis_pdf($analysis_data);
    
    wp_send_json_success($pdf_data);
}

add_action('wp_ajax_generate_pdf_report', 'handle_pdf_generation_ajax');
add_action('wp_ajax_nopriv_generate_pdf_report', 'handle_pdf_generation_ajax');



// Enhanced Website Analyzer Functions are now in analyzer-functions.php
// This keeps analyzer functionality separate and prevents conflicts

function perform_enhanced_website_analysis($url) {
    // Fetch website content
    $response = wp_remote_get($url, array(
        'timeout' => 30,
        'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    ));
    
    if (is_wp_error($response)) {
        return new WP_Error('fetch_error', 'Failed to fetch website content');
    }
    
    $body = wp_remote_retrieve_body($response);
    $headers = wp_remote_retrieve_headers($response);
    
    // Perform comprehensive analysis
    $mobile_metrics = analyze_mobile_performance($url);
    $desktop_metrics = analyze_desktop_performance($url);
    $seo_analysis = analyze_enhanced_seo($body, $url);
    $mobile_friendliness = analyze_mobile_friendliness_enhanced($body);
    $security_analysis = analyze_security_enhanced($url, $headers);
    $accessibility_analysis = analyze_accessibility_enhanced($body);
    $best_practices_analysis = analyze_best_practices_enhanced($body, $headers);
    $technologies = detect_technologies_enhanced($body, $headers);
    
    // Calculate scores
    $mobile_score = calculate_mobile_score($mobile_metrics, $mobile_friendliness);
    $desktop_score = calculate_desktop_score($desktop_metrics);
    $seo_score = calculate_seo_score($seo_analysis);
    $security_score = calculate_security_score($security_analysis);
    $accessibility_score = calculate_accessibility_score($accessibility_analysis);
    $best_practices_score = calculate_best_practices_score($best_practices_analysis);
    
    // Overall score
    $overall_score = round(($mobile_score + $desktop_score + $seo_score + $security_score + $accessibility_score + $best_practices_score) / 6);
    
    return array(
        'url' => $url,
        'analysis_date' => current_time('Y-m-d H:i:s'),
        'overall_score' => $overall_score,
        'mobile_score' => $mobile_score,
        'desktop_score' => $desktop_score,
        'mobile_metrics' => $mobile_metrics,
        'desktop_metrics' => $desktop_metrics,
        'seo_score' => $seo_score,
        'seo_issues' => $seo_analysis['issues'],
        'seo_suggestions' => $seo_analysis['suggestions'],
        'mobile_friendliness_score' => $mobile_friendliness['score'],
        'mobile_issues' => $mobile_friendliness['issues'],
        'mobile_suggestions' => $mobile_friendliness['suggestions'],
        'security_score' => $security_score,
        'security_issues' => $security_analysis['issues'],
        'security_suggestions' => $security_analysis['suggestions'],
        'accessibility_score' => $accessibility_score,
        'accessibility_issues' => $accessibility_analysis['issues'],
        'accessibility_suggestions' => $accessibility_analysis['suggestions'],
        'best_practices_score' => $best_practices_score,
        'best_practices_issues' => $best_practices_analysis['issues'],
        'best_practices_suggestions' => $best_practices_analysis['suggestions'],
        'technologies' => $technologies
    );
}

function analyze_mobile_performance($url) {
    // Simulate mobile performance metrics
    // In a real implementation, you would use Google PageSpeed Insights API or similar
    $fcp = rand(800, 3000) / 1000; // 0.8 to 3.0 seconds
    $lcp = rand(1500, 5000) / 1000; // 1.5 to 5.0 seconds
    $cls = rand(0, 25) / 100; // 0 to 0.25
    $fid = rand(10, 300); // 10 to 300ms
    
    return array(
        'fcp' => round($fcp, 2),
        'lcp' => round($lcp, 2),
        'cls' => round($cls, 3),
        'fid' => $fid
    );
}

function analyze_desktop_performance($url) {
    // Simulate desktop performance metrics
    $fcp = rand(500, 2000) / 1000; // 0.5 to 2.0 seconds
    $lcp = rand(1000, 3500) / 1000; // 1.0 to 3.5 seconds
    $cls = rand(0, 15) / 100; // 0 to 0.15
    $fid = rand(5, 150); // 5 to 150ms
    
    return array(
        'fcp' => round($fcp, 2),
        'lcp' => round($lcp, 2),
        'cls' => round($cls, 3),
        'fid' => $fid
    );
}

function analyze_enhanced_seo($body, $url) {
    $issues = array();
    $suggestions = array();
    
    // Check for title tag
    if (!preg_match('/<title>(.*?)<\/title>/i', $body)) {
        $issues[] = 'Missing title tag';
        $suggestions[] = 'Add a unique, descriptive title tag for each page';
    }
    
    // Check for meta description
    if (!preg_match('/<meta[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\']/i', $body)) {
        $issues[] = 'Missing meta description';
        $suggestions[] = 'Add a compelling meta description (150-160 characters)';
    }
    
    // Check for heading structure
    if (!preg_match('/<h1[^>]*>(.*?)<\/h1>/i', $body)) {
        $issues[] = 'Missing H1 heading';
        $suggestions[] = 'Include one main H1 heading per page';
    }
    
    // Check for alt attributes on images
    $img_count = preg_match_all('/<img[^>]*>/i', $body);
    $img_with_alt = preg_match_all('/<img[^>]*alt=["\'][^"\']*["\'][^>]*>/i', $body);
    
    if ($img_count > 0 && $img_with_alt < $img_count) {
        $issues[] = 'Some images missing alt attributes';
        $suggestions[] = 'Add descriptive alt text to all images';
    }
    
    // Check for internal links
    $internal_links = preg_match_all('/<a[^>]*href=["\']' . preg_quote(parse_url($url, PHP_URL_HOST), '/') . '[^"\']*["\'][^>]*>/i', $body);
    if ($internal_links < 3) {
        $suggestions[] = 'Add more internal links to improve site structure';
    }
    
    return array(
        'issues' => $issues,
        'suggestions' => $suggestions
    );
}

function analyze_mobile_friendliness_enhanced($body) {
    $issues = array();
    $suggestions = array();
    $score = 100;
    
    // Check for viewport meta tag
    if (!preg_match('/<meta[^>]*name=["\']viewport["\'][^>]*>/i', $body)) {
        $issues[] = 'Missing viewport meta tag';
        $suggestions[] = 'Add viewport meta tag for mobile responsiveness';
        $score -= 20;
    }
    
    // Check for responsive design indicators
    if (!preg_match('/@media[^}]*max-width[^}]*{/i', $body) && !preg_match('/responsive|mobile|tablet/i', $body)) {
        $issues[] = 'No responsive design detected';
        $suggestions[] = 'Implement responsive design with CSS media queries';
        $score -= 30;
    }
    
    // Check for touch-friendly elements
    if (!preg_match('/min-height[^:]*:[^;]*4[0-9]px/i', $body) && !preg_match('/padding[^:]*:[^;]*1[0-9]px/i', $body)) {
        $suggestions[] = 'Ensure touch targets are at least 44px in size';
    }
    
    return array(
        'score' => max(0, $score),
        'issues' => $issues,
        'suggestions' => $suggestions
    );
}

function analyze_security_enhanced($url, $headers) {
    $issues = array();
    $suggestions = array();
    $score = 100;
    
    // Check for HTTPS
    if (strpos($url, 'https://') !== 0) {
        $issues[] = 'Website not using HTTPS';
        $suggestions[] = 'Implement SSL certificate for secure connections';
        $score -= 25;
    }
    
    // Check for security headers
    $security_headers = array(
        'X-Frame-Options' => 'Missing X-Frame-Options header',
        'X-Content-Type-Options' => 'Missing X-Content-Type-Options header',
        'X-XSS-Protection' => 'Missing X-XSS-Protection header',
        'Strict-Transport-Security' => 'Missing HSTS header'
    );
    
    foreach ($security_headers as $header => $message) {
        if (!wp_remote_retrieve_header($headers, $header)) {
            $issues[] = $message;
            $suggestions[] = 'Add ' . $header . ' security header';
            $score -= 10;
        }
    }
    
    return array(
        'score' => max(0, $score),
        'issues' => $issues,
        'suggestions' => $suggestions
    );
}

function analyze_accessibility_enhanced($body) {
    $issues = array();
    $suggestions = array();
    $score = 100;
    
    // Check for ARIA labels
    if (!preg_match('/aria-label|aria-labelledby|aria-describedby/i', $body)) {
        $suggestions[] = 'Consider adding ARIA labels for better accessibility';
    }
    
    // Check for semantic HTML
    if (!preg_match('/<nav[^>]*>|<main[^>]*>|<article[^>]*>|<section[^>]*>/i', $body)) {
        $issues[] = 'Limited use of semantic HTML elements';
        $suggestions[] = 'Use semantic HTML elements (nav, main, article, section)';
        $score -= 15;
    }
    
    // Check for color contrast (basic check)
    if (preg_match('/color[^:]*:[^;]*#[0-9a-f]{3,6}/i', $body)) {
        $suggestions[] = 'Ensure sufficient color contrast for text readability';
    }
    
    return array(
        'score' => max(0, $score),
        'issues' => $issues,
        'suggestions' => $suggestions
    );
}

function analyze_best_practices_enhanced($body, $headers) {
    $issues = array();
    $suggestions = array();
    $score = 100;
    
    // Check for compression
    $content_encoding = wp_remote_retrieve_header($headers, 'content-encoding');
    if (!$content_encoding) {
        $issues[] = 'Content not compressed';
        $suggestions[] = 'Enable GZIP compression for faster loading';
        $score -= 15;
    }
    
    // Check for caching headers
    $cache_control = wp_remote_retrieve_header($headers, 'cache-control');
    if (!$cache_control) {
        $issues[] = 'No caching headers found';
        $suggestions[] = 'Implement proper caching headers';
        $score -= 10;
    }
    
    // Check for minification indicators
    if (strlen($body) > 50000 && !preg_match('/\.min\.(css|js)/i', $body)) {
        $suggestions[] = 'Consider minifying CSS and JavaScript files';
    }
    
    return array(
        'score' => max(0, $score),
        'issues' => $issues,
        'suggestions' => $suggestions
    );
}

function detect_technologies_enhanced($body, $headers) {
    $technologies = array();
    
    // WordPress
    if (strpos($body, 'wp-content') !== false || strpos($body, 'wp-includes') !== false) {
        $technologies[] = 'WordPress';
    }
    
    // PHP
    if (strpos($body, 'php') !== false) {
        $technologies[] = 'PHP';
    }
    
    // JavaScript frameworks
    if (strpos($body, 'react') !== false) $technologies[] = 'React';
    if (strpos($body, 'vue') !== false) $technologies[] = 'Vue.js';
    if (strpos($body, 'angular') !== false) $technologies[] = 'Angular';
    
    // CSS frameworks
    if (strpos($body, 'bootstrap') !== false) $technologies[] = 'Bootstrap';
    if (strpos($body, 'tailwind') !== false) $technologies[] = 'Tailwind CSS';
    
    // Server technologies
    $server = wp_remote_retrieve_header($headers, 'server');
    if ($server) {
        $technologies[] = $server;
    }
    
    return $technologies;
}

// Score calculation functions
function calculate_mobile_score($metrics, $friendliness) {
    $score = 100;
    
    // FCP scoring
    if ($metrics['fcp'] > 2.5) $score -= 20;
    elseif ($metrics['fcp'] > 1.8) $score -= 10;
    
    // LCP scoring
    if ($metrics['lcp'] > 4.0) $score -= 20;
    elseif ($metrics['lcp'] > 2.5) $score -= 10;
    
    // CLS scoring
    if ($metrics['cls'] > 0.25) $score -= 20;
    elseif ($metrics['cls'] > 0.1) $score -= 10;
    
    // FID scoring
    if ($metrics['fid'] > 300) $score -= 20;
    elseif ($metrics['fid'] > 100) $score -= 10;
    
    // Mobile friendliness
    $score = ($score + $friendliness['score']) / 2;
    
    return max(0, round($score));
}

function calculate_desktop_score($metrics) {
    $score = 100;
    
    // FCP scoring
    if ($metrics['fcp'] > 2.0) $score -= 20;
    elseif ($metrics['fcp'] > 1.5) $score -= 10;
    
    // LCP scoring
    if ($metrics['lcp'] > 3.0) $score -= 20;
    elseif ($metrics['lcp'] > 2.0) $score -= 10;
    
    // CLS scoring
    if ($metrics['cls'] > 0.15) $score -= 20;
    elseif ($metrics['cls'] > 0.1) $score -= 10;
    
    // FID scoring
    if ($metrics['fid'] > 150) $score -= 20;
    elseif ($metrics['fid'] > 100) $score -= 10;
    
    return max(0, round($score));
}

function calculate_seo_score($analysis) {
    $score = 100;
    $score -= count($analysis['issues']) * 15;
    return max(0, $score);
}

function calculate_security_score($analysis) {
    return $analysis['score'];
}

function calculate_accessibility_score($analysis) {
    return $analysis['score'];
}

function calculate_best_practices_score($analysis) {
    return $analysis['score'];
}

// PDF Generation Functions
function handle_enhanced_pdf_generation_ajax() {
    error_log('=== PDF Generation AJAX Request Started ===');
    error_log('POST data: ' . print_r($_POST, true));
    
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'pdf_generation_nonce')) {
        error_log('Nonce verification failed');
        wp_send_json_error('Invalid nonce');
        return;
    }
    
    error_log('Nonce verification passed');
    
    // Get URL and email
    $url = sanitize_url($_POST['url']);
    $email = sanitize_email($_POST['email']);
    
    error_log('Sanitized URL: ' . $url);
    error_log('Sanitized email: ' . $email);
    
    if (empty($url) || empty($email)) {
        error_log('URL or email is empty');
        wp_send_json_error('URL and email are required');
        return;
    }
    
    error_log('PDF generation request received for URL: ' . $url . ', Email: ' . $email);
    
    // Test PDF generation capability first
    error_log('Testing PDF generation capability...');
    if (!test_pdf_generation_debug()) {
        error_log('PDF generation test failed');
        wp_send_json_error('PDF generation system is not working properly. Please contact support.');
        return;
    }
    
    error_log('PDF generation test passed, proceeding with analysis...');
    
    // Generate PDF report
    $pdf_result = generate_enhanced_pdf_report($url, $email);
    
    error_log('PDF generation result: ' . print_r($pdf_result, true));
    
    if (is_wp_error($pdf_result)) {
        error_log('PDF generation failed: ' . $pdf_result->get_error_message());
        wp_send_json_error('PDF generation failed: ' . $pdf_result->get_error_message());
        return;
    }
    
    if (is_array($pdf_result) && isset($pdf_result['download_url'])) {
        error_log('PDF generation successful: ' . $pdf_result['download_url']);
        wp_send_json_success($pdf_result);
    } else {
        error_log('PDF generation returned unexpected result: ' . print_r($pdf_result, true));
        wp_send_json_error('PDF generation failed - unexpected result');
    }
}

add_action('wp_ajax_generate_enhanced_pdf_report', 'handle_enhanced_pdf_generation_ajax');
add_action('wp_ajax_nopriv_generate_enhanced_pdf_report', 'handle_enhanced_pdf_generation_ajax');

function generate_enhanced_pdf_report($url, $email) {
    error_log('generate_enhanced_pdf_report called with URL: ' . $url . ', Email: ' . $email);
    
    // Get analysis data
    $analysis_data = perform_enhanced_website_analysis($url);
    
    if (is_wp_error($analysis_data)) {
        error_log('Analysis failed: ' . $analysis_data->get_error_message());
        return $analysis_data;
    }
    
    error_log('Analysis completed successfully');
    
    // Generate PDF file directly
    $pdf_file = create_simple_pdf_report($url, $analysis_data);
    
    if (is_wp_error($pdf_file)) {
        error_log('PDF file creation failed: ' . $pdf_file->get_error_message());
        return $pdf_file;
    }
    
    error_log('PDF file created successfully');
    
    // Store email in admin database
    $store_result = store_analyzer_email($url, $email, $analysis_data);
    if (is_wp_error($store_result)) {
        error_log('Email storage failed: ' . $store_result->get_error_message());
    } else {
        error_log('Email stored successfully with ID: ' . $store_result);
    }
    
    return $pdf_file;
}

function create_simple_pdf_report($url, $analysis_data) {
    error_log('create_simple_pdf_report called with URL: ' . $url);
    
    // Create uploads directory if it doesn't exist
    $upload_dir = wp_upload_dir();
    $pdf_dir = $upload_dir['basedir'] . '/website-analyzer-pdfs/';
    
    error_log('PDF directory: ' . $pdf_dir);
    
    if (!file_exists($pdf_dir)) {
        error_log('Creating PDF directory');
        wp_mkdir_p($pdf_dir);
    }
    
    // Create .htaccess to protect the directory
    $htaccess_file = $pdf_dir . '.htaccess';
    if (!file_exists($htaccess_file)) {
        error_log('Creating .htaccess file');
        $htaccess_content = "Order deny,allow\nDeny from all\n";
        file_put_contents($htaccess_file, $htaccess_content);
    }
    
    // Generate unique filename
    $domain = parse_url($url, PHP_URL_HOST);
    $domain = preg_replace('/[^a-zA-Z0-9]/', '_', $domain);
    $timestamp = current_time('Y-m-d_H-i-s');
    $filename = 'website-analysis-' . $domain . '-' . $timestamp . '.pdf';
    $filepath = $pdf_dir . $filename;
    
    error_log('Generated filename: ' . $filename);
    error_log('Full filepath: ' . $filepath);
    
    // Create HTML content for PDF
    $html_content = create_simple_pdf_html($url, $analysis_data);
    
    // Try to generate PDF using DomPDF
    if (class_exists('\Dompdf\Dompdf') || check_and_install_dompdf()) {
        error_log('Attempting PDF generation with Dompdf');
        $result = create_pdf_with_dompdf_simple($html_content, $filepath);
        if (!is_wp_error($result)) {
            error_log('PDF created successfully with Dompdf');
            return $result;
        }
        error_log('Dompdf failed: ' . $result->get_error_message());
    }
    
    // Fallback: Create HTML file for manual printing
    error_log('Creating HTML file as fallback');
    $html_filename = 'website-analysis-' . $domain . '-' . $timestamp . '.html';
    $html_filepath = $pdf_dir . $html_filename;
    
    $write_result = file_put_contents($html_filepath, $html_content);
    if ($write_result === false) {
        error_log('Failed to write HTML file');
        return new WP_Error('file_write_error', 'Failed to create file');
    }
    
    error_log('HTML file created successfully as fallback');
    
    // Create download URL
    $download_url = wp_nonce_url(
        admin_url('admin-ajax.php?action=download_website_analysis_pdf&file=' . urlencode($html_filename)),
        'download_pdf_' . $html_filename
    );
    
    return array(
        'download_url' => $download_url,
        'filename' => $html_filename,
        'filepath' => $html_filepath
    );
}

function create_simple_pdf_html($url, $analysis_data) {
    error_log('Creating simple HTML content for PDF...');
    
    // Basic data with fallbacks
    $overall_score = isset($analysis_data['overall_score']) ? intval($analysis_data['overall_score']) : 0;
    $mobile_score = isset($analysis_data['mobile_score']) ? intval($analysis_data['mobile_score']) : 0;
    $desktop_score = isset($analysis_data['desktop_score']) ? intval($analysis_data['desktop_score']) : 0;
    $seo_score = isset($analysis_data['seo_score']) ? intval($analysis_data['seo_score']) : 0;
    $security_score = isset($analysis_data['security_score']) ? intval($analysis_data['security_score']) : 0;
    $accessibility_score = isset($analysis_data['accessibility_score']) ? intval($analysis_data['accessibility_score']) : 0;
    $best_practices_score = isset($analysis_data['best_practices_score']) ? intval($analysis_data['best_practices_score']) : 0;
    
    $analysis_date = current_time('F j, Y \a\t g:i A');
    $escaped_url = esc_html($url);
    
    $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Website Analysis Report - ' . $escaped_url . '</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; color: #333; }
        .header { text-align: center; background: #1F2253; color: white; padding: 20px; margin-bottom: 20px; }
        .score { text-align: center; margin: 20px 0; }
        .score-circle { width: 100px; height: 100px; border-radius: 50%; background: #c22034; color: white; display: flex; flex-direction: column; justify-content: center; align-items: center; margin: 0 auto 20px; }
        .category { margin: 20px 0; padding: 15px; border: 1px solid #ddd; background: #f9f9f9; }
        .category h3 { color: #1F2253; margin-top: 0; }
        ul { margin: 10px 0; padding-left: 20px; }
        li { margin: 5px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>SalesNanny Website Analysis Report</h1>
        <p>Generated on ' . $analysis_date . '</p>
        <p><strong>Website:</strong> ' . $escaped_url . '</p>
    </div>
    
    <div class="score">
        <h2>Overall Performance Score</h2>
        <div class="score-circle">
            <div style="font-size: 2em; font-weight: bold;">' . $overall_score . '</div>
            <div>/100</div>
        </div>
        <p><strong>Mobile:</strong> ' . $mobile_score . '/100 | <strong>Desktop:</strong> ' . $desktop_score . '/100</p>
    </div>
    
    <div class="category">
        <h3>SEO Analysis (Score: ' . $seo_score . '/100)</h3>
        <h4>Issues Found:</h4>
        <ul>';
    
    if (isset($analysis_data['seo_issues']) && is_array($analysis_data['seo_issues'])) {
        foreach ($analysis_data['seo_issues'] as $issue) {
            $html .= '<li>' . esc_html($issue) . '</li>';
        }
    } else {
        $html .= '<li>No issues found</li>';
    }
    
    $html .= '</ul>
        <h4>Suggestions:</h4>
        <ul>';
    
    if (isset($analysis_data['seo_suggestions']) && is_array($analysis_data['seo_suggestions'])) {
        foreach ($analysis_data['seo_suggestions'] as $suggestion) {
            $html .= '<li>' . esc_html($suggestion) . '</li>';
        }
    } else {
        $html .= '<li>No suggestions available</li>';
    }
    
    $html .= '</ul>
    </div>
    
    <div class="category">
        <h3>Security Assessment (Score: ' . $security_score . '/100)</h3>
        <h4>Security Issues:</h4>
        <ul>';
    
    if (isset($analysis_data['security_issues']) && is_array($analysis_data['security_issues'])) {
        foreach ($analysis_data['security_issues'] as $issue) {
            $html .= '<li>' . esc_html($issue) . '</li>';
        }
    } else {
        $html .= '<li>No security issues found</li>';
    }
    
    $html .= '</ul>
    </div>
    
    <div class="category">
        <h3>Accessibility (Score: ' . $accessibility_score . '/100)</h3>
        <h4>Accessibility Issues:</h4>
        <ul>';
    
    if (isset($analysis_data['accessibility_issues']) && is_array($analysis_data['accessibility_issues'])) {
        foreach ($analysis_data['accessibility_issues'] as $issue) {
            $html .= '<li>' . esc_html($issue) . '</li>';
        }
    } else {
        $html .= '<li>No accessibility issues found</li>';
    }
    
    $html .= '</ul>
    </div>
    
    <div class="category">
        <h3>Best Practices (Score: ' . $best_practices_score . '/100)</h3>
        <h4>Best Practice Issues:</h4>
        <ul>';
    
    if (isset($analysis_data['best_practices_issues']) && is_array($analysis_data['best_practices_issues'])) {
        foreach ($analysis_data['best_practices_issues'] as $issue) {
            $html .= '<li>' . esc_html($issue) . '</li>';
        }
    } else {
        $html .= '<li>No best practice issues found</li>';
    }
    
    $html .= '</ul>
    </div>
    
    <div style="text-align: center; margin-top: 40px; padding: 20px; background: #f8f9fa; color: #666;">
        <p><strong>Report generated by SalesNanny Website Analyzer</strong></p>
        <p>This report provides a comprehensive analysis of your website\'s performance, SEO, security, and accessibility.</p>
    </div>
</body>
</html>';
    
    error_log('Simple HTML content created successfully');
    return $html;
}

function create_pdf_with_dompdf_simple($html_content, $filepath) {
    try {
        // Ensure autoloader is included
        if (!class_exists('\Dompdf\Dompdf')) {
            $autoload_path = ABSPATH . 'vendor/autoload.php';
            if (file_exists($autoload_path)) {
                require_once $autoload_path;
            }
        }
        
        if (!class_exists('\Dompdf\Dompdf')) {
            error_log('Dompdf class not available');
            return new WP_Error('dompdf_not_available', 'Dompdf library not available');
        }
        
        // Create Dompdf instance
        $dompdf = new \Dompdf\Dompdf();
        $dompdf->setPaper('A4', 'portrait');
        
        // Load HTML into Dompdf
        $dompdf->loadHtml($html_content);
        
        // Render PDF
        $dompdf->render();
        
        // Save PDF to file
        $pdf_content = $dompdf->output();
        $write_result = file_put_contents($filepath, $pdf_content);
        
        if ($write_result === false) {
            error_log('Failed to write PDF file');
            return new WP_Error('pdf_write_error', 'Failed to create PDF file');
        }
        
        error_log('PDF created successfully with Dompdf');
        
        // Create download URL
        $filename = basename($filepath);
        $download_url = wp_nonce_url(
            admin_url('admin-ajax.php?action=download_website_analysis_pdf&file=' . urlencode($filename)),
            'download_pdf_' . $filename
        );
        
        return array(
            'download_url' => $download_url,
            'filename' => $filename,
            'filepath' => $filepath
        );
        
    } catch (Exception $e) {
        error_log('Dompdf error: ' . $e->getMessage());
        return new WP_Error('dompdf_error', 'PDF generation failed: ' . $e->getMessage());
    }
}

// Test function to verify PDF generation
function test_pdf_generation() {
    // Include autoloader if not already included
    if (!class_exists('\Dompdf\Dompdf')) {
        $autoload_path = ABSPATH . 'vendor/autoload.php';
        if (file_exists($autoload_path)) {
            require_once $autoload_path;
        }
    }
    
    if (!class_exists('\Dompdf\Dompdf')) {
        error_log('Dompdf class not found');
        return false;
    }
    
    try {
        $dompdf = new \Dompdf\Dompdf();
        $dompdf->setPaper('A4', 'portrait');
        
        $html = '<html><body><h1>Test PDF</h1><p>This is a test PDF generated by DomPDF.</p></body></html>';
        $dompdf->loadHtml($html);
        $dompdf->render();
        
        $pdf_content = $dompdf->output();
        if (!empty($pdf_content)) {
            error_log('PDF generation test successful');
            return true;
        } else {
            error_log('PDF generation test failed - empty output');
            return false;
        }
    } catch (Exception $e) {
        error_log('PDF generation test failed: ' . $e->getMessage());
        return false;
    }
}

// Add this to the existing check_and_install_dompdf function
function check_and_install_dompdf() {
    // First try to include the autoloader
    $autoload_path = ABSPATH . 'vendor/autoload.php';
    if (file_exists($autoload_path)) {
        require_once $autoload_path;
        if (class_exists('\Dompdf\Dompdf')) {
            error_log('Dompdf loaded successfully from vendor directory');
            return true;
        }
    }
    
    // Test if PDF generation works
    if (test_pdf_generation()) {
        return true;
    }
    
    error_log('Dompdf not available or not working');
    return false;
}

// Test function to debug PDF generation
function test_pdf_generation_debug() {
    error_log('=== PDF Generation Debug Test ===');
    
    // Test 1: Check if autoloader exists
    $autoload_path = ABSPATH . 'vendor/autoload.php';
    error_log('Autoloader path: ' . $autoload_path);
    error_log('Autoloader exists: ' . (file_exists($autoload_path) ? 'YES' : 'NO'));
    
    // Test 2: Try to include autoloader
    if (file_exists($autoload_path)) {
        require_once $autoload_path;
        error_log('Autoloader included successfully');
    } else {
        error_log('Autoloader not found');
        return false;
    }
    
    // Test 3: Check if DomPDF class exists
    error_log('Dompdf class exists: ' . (class_exists('\Dompdf\Dompdf') ? 'YES' : 'NO'));
    
    if (!class_exists('\Dompdf\Dompdf')) {
        error_log('Dompdf class not found after including autoloader');
        return false;
    }
    
    // Test 4: Try to create a simple PDF
    try {
        $dompdf = new \Dompdf\Dompdf();
        $dompdf->setPaper('A4', 'portrait');
        
        $html = '<html><body><h1>Test PDF</h1><p>This is a test PDF generated by DomPDF.</p></body></html>';
        $dompdf->loadHtml($html);
        $dompdf->render();
        
        $pdf_content = $dompdf->output();
        error_log('PDF content length: ' . strlen($pdf_content));
        
        if (!empty($pdf_content)) {
            error_log('PDF generation test successful');
            
            // Test 5: Try to save to file
            $upload_dir = wp_upload_dir();
            $test_file = $upload_dir['basedir'] . '/test-pdf-' . time() . '.pdf';
            $write_result = file_put_contents($test_file, $pdf_content);
            
            if ($write_result !== false) {
                error_log('PDF file saved successfully: ' . $test_file);
                return true;
            } else {
                error_log('Failed to save PDF file');
                return false;
            }
        } else {
            error_log('PDF generation test failed - empty output');
            return false;
        }
    } catch (Exception $e) {
        error_log('PDF generation test failed with exception: ' . $e->getMessage());
        return false;
    }
}

// Add this to WordPress admin to test PDF generation
add_action('admin_menu', function() {
    add_submenu_page(
        'tools.php',
        'Test PDF Generation',
        'Test PDF',
        'manage_options',
        'test-pdf-generation',
        function() {
            echo '<div class="wrap">';
            echo '<h1>Test PDF Generation</h1>';
            
            if (isset($_POST['test_pdf'])) {
                echo '<h2>Test Results:</h2>';
                $result = test_pdf_generation_debug();
                if ($result) {
                    echo '<div style="color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px;">';
                    echo '<strong>SUCCESS:</strong> PDF generation is working correctly!';
                    echo '</div>';
                } else {
                    echo '<div style="color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px;">';
                    echo '<strong>FAILED:</strong> PDF generation is not working. Check error logs for details.';
                    echo '</div>';
                }
            }
            
            echo '<form method="post">';
            echo '<p>Click the button below to test PDF generation:</p>';
            echo '<input type="submit" name="test_pdf" class="button button-primary" value="Test PDF Generation">';
            echo '</form>';
            echo '</div>';
        }
    );
});

// Simple test function for PDF generation
function test_simple_pdf_generation() {
    error_log('=== Simple PDF Generation Test ===');
    
    // Create test data
    $test_url = 'https://example.com';
    $test_email = 'test@example.com';
    $test_analysis_data = array(
        'overall_score' => 85,
        'mobile_score' => 80,
        'desktop_score' => 90,
        'seo_score' => 88,
        'security_score' => 92,
        'accessibility_score' => 75,
        'best_practices_score' => 82,
        'mobile_metrics' => array(
            'fcp' => 1.8,
            'lcp' => 2.5,
            'cls' => 0.08,
            'fid' => 85
        ),
        'desktop_metrics' => array(
            'fcp' => 1.5,
            'lcp' => 2.0,
            'cls' => 0.05,
            'fid' => 65
        ),
        'seo_issues' => array('Test SEO issue 1', 'Test SEO issue 2'),
        'seo_suggestions' => array('Test SEO suggestion 1', 'Test SEO suggestion 2'),
        'mobile_issues' => array('Test mobile issue 1'),
        'mobile_suggestions' => array('Test mobile suggestion 1'),
        'security_issues' => array('Test security issue 1'),
        'security_suggestions' => array('Test security suggestion 1'),
        'accessibility_issues' => array('Test accessibility issue 1'),
        'accessibility_suggestions' => array('Test accessibility suggestion 1'),
        'best_practices_issues' => array('Test best practice issue 1'),
        'best_practices_suggestions' => array('Test best practice suggestion 1'),
        'technologies' => array('WordPress', 'PHP', 'MySQL')
    );
    
    error_log('Test data created, attempting PDF generation...');
    
    // Try to generate PDF
    $pdf_result = create_simple_pdf_report($test_url, $test_analysis_data);
    
    error_log('PDF generation result: ' . print_r($pdf_result, true));
    
    if (is_wp_error($pdf_result)) {
        error_log('PDF generation failed: ' . $pdf_result->get_error_message());
        return false;
    }
    
    if (is_array($pdf_result) && isset($pdf_result['download_url'])) {
        error_log('PDF generation successful: ' . $pdf_result['download_url']);
        return $pdf_result;
    }
    
    error_log('PDF generation returned unexpected result');
    return false;
}

// Add test endpoint to admin
add_action('admin_menu', function() {
    add_submenu_page(
        'tools.php',
        'Test Simple PDF',
        'Test Simple PDF',
        'manage_options',
        'test-simple-pdf',
        function() {
            echo '<div class="wrap">';
            echo '<h1>Test Simple PDF Generation</h1>';
            
            if (isset($_POST['test_simple_pdf'])) {
                echo '<h2>Test Results:</h2>';
                $result = test_simple_pdf_generation();
                if ($result) {
                    echo '<div style="color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px;">';
                    echo '<strong>SUCCESS:</strong> Simple PDF generation is working!<br>';
                    echo 'Download URL: <a href="' . esc_url($result['download_url']) . '" target="_blank">Download PDF</a>';
                    echo '</div>';
                } else {
                    echo '<div style="color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px;">';
                    echo '<strong>FAILED:</strong> Simple PDF generation is not working. Check error logs for details.';
                    echo '</div>';
                }
            }
            
            echo '<form method="post">';
            echo '<p>Click the button below to test simple PDF generation:</p>';
            echo '<input type="submit" name="test_simple_pdf" class="button button-primary" value="Test Simple PDF Generation">';
            echo '</form>';
            echo '</div>';
        }
    );
});

// Add missing function for storing analyzer emails
function store_analyzer_email($url, $email, $analysis_data) {
    global $wpdb;
    
    // Create table if it doesn't exist
    $table_name = $wpdb->prefix . 'website_analyzer_emails';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        url varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        analysis_data longtext,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    
    // Insert the data
    $result = $wpdb->insert(
        $table_name,
        array(
            'url' => $url,
            'email' => $email,
            'analysis_data' => json_encode($analysis_data),
            'created_at' => current_time('mysql')
        ),
        array('%s', '%s', '%s', '%s')
    );
    
    if ($result === false) {
        return new WP_Error('db_error', 'Failed to store email in database');
    }
    
    return $wpdb->insert_id;
}

// Add proper admin menu function
function add_website_analyzer_admin_menu() {
    add_submenu_page(
        'tools.php',
        'Test PDF Generation',
        'Test PDF',
        'manage_options',
        'test-pdf-generation',
        'test_pdf_generation_page'
    );
    
    add_submenu_page(
        'tools.php',
        'Test Simple PDF',
        'Test Simple PDF',
        'manage_options',
        'test-simple-pdf',
        'test_simple_pdf_page'
    );
}

// Admin page callback functions
function test_pdf_generation_page() {
    echo '<div class="wrap">';
    echo '<h1>Test PDF Generation</h1>';
    
    if (isset($_POST['test_pdf'])) {
        echo '<h2>Test Results:</h2>';
        $result = test_pdf_generation_debug();
        if ($result) {
            echo '<div style="color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px;">';
            echo '<strong>SUCCESS:</strong> PDF generation is working correctly!';
            echo '</div>';
        } else {
            echo '<div style="color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px;">';
            echo '<strong>FAILED:</strong> PDF generation is not working. Check error logs for details.';
            echo '</div>';
        }
    }
    
    echo '<form method="post">';
    echo '<p>Click the button below to test PDF generation:</p>';
    echo '<input type="submit" name="test_pdf" class="button button-primary" value="Test PDF Generation">';
    echo '</form>';
    echo '</div>';
}

function test_simple_pdf_page() {
    echo '<div class="wrap">';
    echo '<h1>Test Simple PDF Generation</h1>';
    
    if (isset($_POST['test_simple_pdf'])) {
        echo '<h2>Test Results:</h2>';
        $result = test_simple_pdf_generation();
        if ($result) {
            echo '<div style="color: green; padding: 10px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px;">';
            echo '<strong>SUCCESS:</strong> Simple PDF generation is working!<br>';
            echo 'Download URL: <a href="' . esc_url($result['download_url']) . '" target="_blank">Download PDF</a>';
            echo '</div>';
        } else {
            echo '<div style="color: red; padding: 10px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px;">';
            echo '<strong>FAILED:</strong> Simple PDF generation is not working. Check error logs for details.';
            echo '</div>';
        }
    }
    
    echo '<form method="post">';
    echo '<p>Click the button below to test simple PDF generation:</p>';
    echo '<input type="submit" name="test_simple_pdf" class="button button-primary" value="Test Simple PDF Generation">';
    echo '</form>';
    echo '</div>';
}

// Hook the admin menu function
add_action('admin_menu', 'add_website_analyzer_admin_menu');

// ============================================================================
// XML-RPC SECURITY MEASURES
// ============================================================================


// function disable_xmlrpc() {
//     // Disable XML-RPC at WordPress level
//     add_filter('xmlrpc_enabled', '__return_false');
    
//     // Block XML-RPC requests at the application level
//     if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
//         wp_die('XML-RPC is disabled for security reasons.', 'XML-RPC Disabled', array('response' => 403));
//     }
// }
// add_action('init', 'disable_xmlrpc');
// function block_xmlrpc_direct_access() {
//     if (strpos($_SERVER['REQUEST_URI'], 'xmlrpc.php') !== false) {
//         // Log the attempt
//         error_log('XML-RPC access attempt blocked: ' . $_SERVER['REMOTE_ADDR'] . ' - ' . $_SERVER['REQUEST_URI']);
        
//         // Return 403 Forbidden
//         header('HTTP/1.1 403 Forbidden');
//         header('Content-Type: text/plain');
//         echo 'XML-RPC is disabled for security reasons.';
//         exit;
//     }
// }
// add_action('init', 'block_xmlrpc_direct_access', 1);

// function remove_xmlrpc_headers() {
//     // Remove XML-RPC from WordPress headers
//     remove_action('wp_head', 'rsd_link');
//     remove_action('wp_head', 'wlwmanifest_link');
    
//     // Remove XML-RPC from REST API discovery
//     remove_action('wp_head', 'rest_output_link_wp_head');
//     remove_action('wp_head', 'wp_oembed_add_discovery_links');
// }
// add_action('init', 'remove_xmlrpc_headers');

// function block_xmlrpc_pingback() {
//     if (isset($_POST['pingback'])) {
//         error_log('XML-RPC pingback attempt blocked: ' . $_SERVER['REMOTE_ADDR']);
//         wp_die('Pingbacks are disabled for security reasons.', 'Pingback Disabled', array('response' => 403));
//     }
// }
// add_action('init', 'block_xmlrpc_pingback');

// function disable_xmlrpc_methods($methods) {
//     // Remove dangerous methods
//     unset($methods['pingback.ping']);
//     unset($methods['pingback.extensions.getPingbacks']);
//     unset($methods['wp.getUsersBlogs']);
//     unset($methods['wp.getOptions']);
//     unset($methods['wp.setOptions']);
//     unset($methods['wp.getPosts']);
//     unset($methods['wp.getPost']);
//     unset($methods['wp.newPost']);
//     unset($methods['wp.editPost']);
//     unset($methods['wp.deletePost']);
//     unset($methods['wp.getTerms']);
//     unset($methods['wp.getTerm']);
//     unset($methods['wp.newTerm']);
//     unset($methods['wp.editTerm']);
//     unset($methods['wp.deleteTerm']);
//     unset($methods['wp.getUsers']);
//     unset($methods['wp.getUser']);
//     unset($methods['wp.editUser']);
//     unset($methods['wp.deleteUser']);
//     unset($methods['wp.getMediaLibrary']);
//     unset($methods['wp.getMediaItem']);
//     unset($methods['wp.uploadFile']);
//     unset($methods['wp.getCommentCount']);
//     unset($methods['wp.getComments']);
//     unset($methods['wp.getComment']);
//     unset($methods['wp.newComment']);
//     unset($methods['wp.editComment']);
//     unset($methods['wp.deleteComment']);
//     unset($methods['wp.getCommentStatusList']);
    
//     return $methods;
// }
// add_filter('xmlrpc_methods', 'disable_xmlrpc_methods');

// function add_xmlrpc_security_headers() {
//     if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
//         // Add security headers
//         header('X-Content-Type-Options: nosniff');
//         header('X-Frame-Options: DENY');
//         header('X-XSS-Protection: 1; mode=block');
//         header('Referrer-Policy: strict-origin-when-cross-origin');
//     }
// }
// add_action('init', 'add_xmlrpc_security_headers');

// function log_xmlrpc_attempts() {
//     if (strpos($_SERVER['REQUEST_URI'], 'xmlrpc.php') !== false || 
//         (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST)) {
        
//         $log_data = array(
//             'timestamp' => current_time('mysql'),
//             'ip' => $_SERVER['REMOTE_ADDR'],
//             'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown',
//             'request_uri' => $_SERVER['REQUEST_URI'],
//             'method' => $_SERVER['REQUEST_METHOD'],
//             'referer' => isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'Direct Access'
//         );
        
//         error_log('XML-RPC Access Attempt: ' . json_encode($log_data));
//     }
// }
// add_action('init', 'log_xmlrpc_attempts');
// function xmlrpc_rate_limiting() {
//     if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
//         $ip = $_SERVER['REMOTE_ADDR'];
//         $transient_key = 'xmlrpc_attempts_' . md5($ip);
//         $attempts = get_transient($transient_key);
        
//         if ($attempts === false) {
//             set_transient($transient_key, 1, 300); 
//         } else {
//             if ($attempts >= 5) { 
//                 error_log('XML-RPC rate limit exceeded for IP: ' . $ip);
//                 wp_die('Too many requests. Please try again later.', 'Rate Limited', array('response' => 429));
//             }
//             set_transient($transient_key, $attempts + 1, 300);
//         }
//     }
// }
// add_action('init', 'xmlrpc_rate_limiting');
// function xmlrpc_security_admin_notice() {
//     if (current_user_can('manage_options')) {
//         echo '<div class="notice notice-info is-dismissible">';
//         echo '<p><strong>🔒 XML-RPC Security:</strong> XML-RPC has been disabled for enhanced security. ';
//         echo 'This prevents brute force attacks, DDoS amplification, and pingback exploits. ';
//         echo 'If you need XML-RPC for specific integrations, contact your administrator.</p>';
//         echo '</div>';
//     }
// }
// add_action('admin_notices', 'xmlrpc_security_admin_notice');
// function add_xmlrpc_security_status() {
//     if (current_user_can('manage_options')) {
//         echo '<div class="postbox">';
//         echo '<h3 class="hndle"><span>🔒 XML-RPC Security Status</span></h3>';
//         echo '<div class="inside">';
//         echo '<p><strong>Status:</strong> <span style="color: green;">✓ DISABLED</span></p>';
//         echo '<p><strong>Protection:</strong> Brute force attacks, DDoS amplification, pingback exploits</p>';
//         echo '<p><strong>Methods Blocked:</strong> All XML-RPC methods including pingback.ping</p>';
//         echo '<p><strong>Rate Limiting:</strong> 5 attempts per 5 minutes (if somehow accessed)</p>';
//         echo '<p><strong>Logging:</strong> All access attempts are logged for monitoring</p>';
//         echo '</div>';
//         echo '</div>';
//     }
// }
// add_action('dashboard_glance_items', 'add_xmlrpc_security_status');

// function add_xmlrpc_test_link($wp_admin_bar) {
//     if (current_user_can('manage_options')) {
//         $wp_admin_bar->add_node(array(
//             'id' => 'xmlrpc-security-test',
//             'title' => 'Test XML-RPC Security',
//             'href' => add_query_arg('test_xmlrpc_security', '1', admin_url()),
//             'meta' => array('target' => '_blank')
//         ));
//     }
// }
// add_action('admin_bar_menu', 'add_xmlrpc_test_link', 999);
// function block_xmlrpc_attack_patterns() {
//     $request_uri = $_SERVER['REQUEST_URI'];
//     $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    
//     // Block common attack patterns
//     $attack_patterns = array(
//         'xmlrpc.php',
//         'wp-xmlrpc.php',
//         'xmlrpc',
//         'pingback',
//         'system.listMethods',
//         'system.multicall'
//     );
    
//     foreach ($attack_patterns as $pattern) {
//         if (stripos($request_uri, $pattern) !== false || stripos($user_agent, $pattern) !== false) {
//             error_log('XML-RPC attack pattern detected: ' . $pattern . ' from IP: ' . $_SERVER['REMOTE_ADDR']);
//             header('HTTP/1.1 403 Forbidden');
//             header('Content-Type: text/plain');
//             echo 'Access denied for security reasons.';
//             exit;
//         }
//     }
// }
// add_action('init', 'block_xmlrpc_attack_patterns', 1);
// function add_security_headers() {
//     // Security headers to prevent various attacks
//     header('X-Content-Type-Options: nosniff');
//     header('X-Frame-Options: SAMEORIGIN');
//     header('X-XSS-Protection: 1; mode=block');
//     header('Referrer-Policy: strict-origin-when-cross-origin');
//     header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
// }
// add_action('init', 'add_security_headers');

// ============================================================================
// END XML-RPC SECURITY MEASURES
// ============================================================================

// ============================================================================
// USER ACTIVITY MONITORING & SECURITY LOGGING
// ============================================================================

/**
 * Comprehensive user activity monitoring system
 * Logs all critical user actions for security monitoring
 */

// Create log file if it doesn't exist
function create_activity_log_file() {
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    if (!file_exists($log_file)) {
        file_put_contents($log_file, "=== WORDPRESS ACTIVITY LOG ===\n");
        file_put_contents($log_file, "Started: " . current_time('mysql') . "\n\n", FILE_APPEND);
    }
}

/**
 * Log user login events
 */
function log_user_login_event($user_login, $user) {
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
    $user_roles = implode(', ', $user->roles);
    
    $message = "[LOGIN] User: {$user_login} | IP: {$ip} | Roles: {$user_roles} | Time: {$time} | User-Agent: {$user_agent}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
    
    // Alert for admin logins
    if (in_array('administrator', $user->roles)) {
        $admin_message = "[ADMIN LOGIN] User: {$user_login} | IP: {$ip} | Time: {$time}\n";
        file_put_contents($log_file, $admin_message, FILE_APPEND);
    }
}
add_action('wp_login', 'log_user_login_event', 10, 2);

/**
 * Log user logout events
 */
function log_user_logout_event($user_id) {
    $user = get_userdata($user_id);
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    
    $message = "[LOGOUT] User: {$user->user_login} | IP: {$ip} | Time: {$time}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('wp_logout', 'log_user_logout_event');

/**
 * Log failed login attempts
 */
function log_failed_login_attempt($username) {
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
    
    $message = "[FAILED LOGIN] Username: {$username} | IP: {$ip} | Time: {$time} | User-Agent: {$user_agent}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('wp_login_failed', 'log_failed_login_attempt');

/**
 * Log new user registration
 */
function log_new_user_register($user_id) {
    $user = get_userdata($user_id);
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    $user_roles = implode(', ', $user->roles);
    
    $message = "[NEW USER] Username: {$user->user_login} | Email: {$user->user_email} | Roles: {$user_roles} | IP: {$ip} | Time: {$time}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('user_register', 'log_new_user_register');

/**
 * Alert when new admin is created
 */
function alert_new_admin_role($user_id, $new_role, $old_roles) {
    if ($new_role === 'administrator') {
        $user = get_userdata($user_id);
        $log_file = WP_CONTENT_DIR . '/activity-log.txt';
        $ip = $_SERVER['REMOTE_ADDR'];
        $time = current_time('mysql');
        
        $message = "[ALERT: NEW ADMIN] User: {$user->user_login} | Email: {$user->user_email} | IP: {$ip} | Time: {$time}\n";
        file_put_contents($log_file, $message, FILE_APPEND);
        
        // Send email alert to site admin
        $admin_email = get_option('admin_email');
        $subject = 'Security Alert: New Administrator Created';
        $body = "A new administrator account has been created:\n\n";
        $body .= "Username: {$user->user_login}\n";
        $body .= "Email: {$user->user_email}\n";
        $body .= "IP Address: {$ip}\n";
        $body .= "Time: {$time}\n\n";
        $body .= "Please verify this is legitimate.\n";
        
        wp_mail($admin_email, $subject, $body);
    }
}
add_action('set_user_role', 'alert_new_admin_role', 10, 3);

/**
 * Log user deletion
 */
function log_user_deletion($user_id) {
    $user = get_userdata($user_id);
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    
    $message = "[USER DELETED] User ID: {$user_id} | Username: {$user->user_login} | IP: {$ip} | Time: {$time}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('delete_user', 'log_user_deletion');

/**
 * Log post status changes
 */
function log_post_status_change($new_status, $old_status, $post) {
    if ($new_status !== $old_status) {
        $log_file = WP_CONTENT_DIR . '/activity-log.txt';
        $current_user = wp_get_current_user();
        $ip = $_SERVER['REMOTE_ADDR'];
        $time = current_time('mysql');
        
        $message = "[POST STATUS] Post: {$post->post_title} | Old: {$old_status} | New: {$new_status} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
        file_put_contents($log_file, $message, FILE_APPEND);
    }
}
add_action('transition_post_status', 'log_post_status_change', 10, 3);

/**
 * Log post deletion
 */
function log_post_deletion($post_id) {
    $post = get_post($post_id);
    $current_user = wp_get_current_user();
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    
    $message = "[POST DELETED] Post ID: {$post_id} | Title: {$post->post_title} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('before_delete_post', 'log_post_deletion');

/**
 * Log plugin and theme updates
 */
function log_upgrader_process_complete($upgrader, $options) {
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $current_user = wp_get_current_user();
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    
    if ($options['type'] === 'plugin') {
        $message = "[PLUGIN UPDATE] Action: {$options['action']} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
        file_put_contents($log_file, $message, FILE_APPEND);
    } elseif ($options['type'] === 'theme') {
        $message = "[THEME UPDATE] Action: {$options['action']} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
        file_put_contents($log_file, $message, FILE_APPEND);
    }
}
add_action('upgrader_process_complete', 'log_upgrader_process_complete', 10, 2);

/**
 * Log file uploads
 */
function log_file_upload($attachment_id) {
    $attachment = get_post($attachment_id);
    $current_user = wp_get_current_user();
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    
    $message = "[FILE UPLOAD] File: {$attachment->post_title} | Type: {$attachment->post_mime_type} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('add_attachment', 'log_file_upload');

/**
 * Log comment actions
 */
function log_comment_actions($comment_id, $comment_status) {
    $comment = get_comment($comment_id);
    $current_user = wp_get_current_user();
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = current_time('mysql');
    
    $message = "[COMMENT] ID: {$comment_id} | Status: {$comment_status} | Author: {$comment->comment_author} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
    file_put_contents($log_file, $message, FILE_APPEND);
}
add_action('wp_insert_comment', 'log_comment_actions', 10, 2);

/**
 * Log option changes (settings)
 */
function log_option_changes($option, $old_value, $new_value) {
    // Only log important options
    $important_options = array(
        'siteurl', 'home', 'blogname', 'blogdescription',
        'users_can_register', 'default_role', 'admin_email',
        'permalink_structure', 'rewrite_rules'
    );
    
    if (in_array($option, $important_options)) {
        $log_file = WP_CONTENT_DIR . '/activity-log.txt';
        $current_user = wp_get_current_user();
        $ip = $_SERVER['REMOTE_ADDR'];
        $time = current_time('mysql');
        
        $message = "[SETTING CHANGE] Option: {$option} | User: {$current_user->user_login} | IP: {$ip} | Time: {$time}\n";
        file_put_contents($log_file, $message, FILE_APPEND);
    }
}
add_action('updated_option', 'log_option_changes', 10, 3);

/**
 * Log database queries (for debugging)
 */
function log_database_queries($query) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        $log_file = WP_CONTENT_DIR . '/db-queries.log';
        $time = current_time('mysql');
        $message = "[DB QUERY] Time: {$time} | Query: {$query}\n";
        file_put_contents($log_file, $message, FILE_APPEND);
    }
}
// Uncomment the line below to log all database queries (use with caution)
// add_action('query', 'log_database_queries');

/**
 * Admin dashboard widget for activity monitoring
 */
function add_activity_monitoring_widget() {
    if (current_user_can('manage_options')) {
        wp_add_dashboard_widget(
            'activity_monitoring_widget',
            '🔍 Activity Monitoring',
            'display_activity_monitoring_widget'
        );
    }
}
add_action('wp_dashboard_setup', 'add_activity_monitoring_widget');

/**
 * Display activity monitoring widget content
 */
function display_activity_monitoring_widget() {
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    
    if (file_exists($log_file)) {
        $log_content = file_get_contents($log_file);
        $lines = explode("\n", $log_content);
        $recent_lines = array_slice($lines, -20); // Last 20 lines
        
        echo '<div style="max-height: 300px; overflow-y: auto; font-family: monospace; font-size: 11px;">';
        echo '<h4>Recent Activity (Last 20 entries):</h4>';
        echo '<div style="background: #f9f9f9; padding: 10px; border: 1px solid #ddd;">';
        
        foreach ($recent_lines as $line) {
            if (!empty(trim($line))) {
                $color = 'black';
                if (strpos($line, '[ALERT') !== false) {
                    $color = 'red';
                } elseif (strpos($line, '[ADMIN') !== false) {
                    $color = 'orange';
                } elseif (strpos($line, '[FAILED') !== false) {
                    $color = 'red';
                }
                
                echo '<div style="color: ' . $color . '; margin-bottom: 2px;">' . esc_html($line) . '</div>';
            }
        }
        
        echo '</div>';
        echo '<p><a href="' . admin_url('admin.php?page=activity-log-viewer') . '" class="button button-small">View Full Log</a></p>';
    } else {
        echo '<p>No activity log found.</p>';
    }
}

/**
 * Add admin menu for activity log viewer
 */
function add_activity_log_menu() {
    add_submenu_page(
        'tools.php',
        'Activity Log Viewer',
        'Activity Log',
        'manage_options',
        'activity-log-viewer',
        'display_activity_log_viewer'
    );
}
add_action('admin_menu', 'add_activity_log_menu');

/**
 * Display activity log viewer page
 */
function display_activity_log_viewer() {
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    
    echo '<div class="wrap">';
    echo '<h1>🔍 Activity Log Viewer</h1>';
    
    if (file_exists($log_file)) {
        $log_content = file_get_contents($log_file);
        $lines = explode("\n", $log_content);
        
        echo '<div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; max-height: 600px; overflow-y: auto; font-family: monospace; font-size: 12px;">';
        
        foreach ($lines as $line) {
            if (!empty(trim($line))) {
                $color = 'black';
                if (strpos($line, '[ALERT') !== false) {
                    $color = 'red';
                } elseif (strpos($line, '[ADMIN') !== false) {
                    $color = 'orange';
                } elseif (strpos($line, '[FAILED') !== false) {
                    $color = 'red';
                } elseif (strpos($line, '[LOGIN') !== false) {
                    $color = 'green';
                }
                
                echo '<div style="color: ' . $color . '; margin-bottom: 2px;">' . esc_html($line) . '</div>';
            }
        }
        
        echo '</div>';
        
        echo '<p><strong>Log file location:</strong> ' . esc_html($log_file) . '</p>';
        echo '<p><strong>Total entries:</strong> ' . count(array_filter($lines)) . '</p>';
    } else {
        echo '<p>No activity log found.</p>';
    }
    
    echo '</div>';
}

/**
 * Initialize activity logging system
 */
function init_activity_logging() {
    create_activity_log_file();
}
add_action('init', 'init_activity_logging');

// ============================================================================
// END USER ACTIVITY MONITORING
// ============================================================================

// ============================================================================
// EMAIL SECURITY NOTIFICATIONS
// ============================================================================

/**
 * Format date/time in standard format regardless of locale
 * This ensures dates are always displayed in standard format (YYYY-MM-DD HH:MM:SS)
 * 
 * @param string $format Optional. Date format string. Default 'Y-m-d H:i:s'
 * @param int $timestamp Optional. Unix timestamp. Default current time
 * @return string Formatted date string
 */
function sn_format_standard_datetime($format = 'Y-m-d H:i:s', $timestamp = null) {
    if ($timestamp === null) {
        $timestamp = current_time('timestamp');
    }
    
    // Temporarily set locale to en_US to ensure standard format
    $original_locale = setlocale(LC_TIME, '0');
    setlocale(LC_TIME, 'en_US.UTF-8', 'en_US', 'C');
    
    // Format the date
    $formatted = date($format, $timestamp);
    
    // Restore original locale
    if ($original_locale !== false) {
        setlocale(LC_TIME, $original_locale);
    }
    
    return $formatted;
}

/**
 * TEST FUNCTION - Remove after testing
 * Add this shortcode to any page to test timestamp formatting: [test_timestamp_format]
 */
function test_timestamp_format_shortcode() {
    if (!current_user_can('manage_options')) {
        return ''; // Only show to admins
    }
    
    $output = '<div style="padding: 20px; background: #f0f0f0; margin: 20px 0; border: 2px solid #333;">';
    $output .= '<h3>Timestamp Formatting Test</h3>';
    
    // Test PHP function
    $standard_format = sn_format_standard_datetime();
    $output .= '<p><strong>PHP Standard Format:</strong> ' . esc_html($standard_format) . '</p>';
    
    // Test with different formats
    $output .= '<p><strong>Date Only:</strong> ' . esc_html(sn_format_standard_datetime('Y-m-d')) . '</p>';
    $output .= '<p><strong>Time Only:</strong> ' . esc_html(sn_format_standard_datetime('H:i:s')) . '</p>';
    $output .= '<p><strong>Full Format:</strong> ' . esc_html(sn_format_standard_datetime('Y-m-d H:i:s')) . '</p>';
    
    // Compare with WordPress default
    $wp_default = current_time('mysql');
    $output .= '<p><strong>WordPress Default (may show Persian):</strong> ' . esc_html($wp_default) . '</p>';
    
    $output .= '<hr>';
    $output .= '<p><em>If you see Persian numerals in "WordPress Default" but standard format in others, the fix is working!</em></p>';
    $output .= '</div>';
    
    return $output;
}
add_shortcode('test_timestamp_format', 'test_timestamp_format_shortcode');

/**
 * Get security notification settings
 */
function get_security_notification_settings() {
    return array(
        'admin_email' => get_option('admin_email'),
        'security_admin_email' => 'thilakar@salesnanny.com', // Specific email for security alerts
        'notify_on_successful_login' => true,
        'notify_on_failed_login' => true,
        'notify_on_admin_login' => true,
        'notify_on_suspicious_activity' => true,
        'suspicious_ip_threshold' => 5, // Failed attempts from same IP
        'notification_cooldown' => 300, // 5 minutes between notifications
    );
}

/**
 * Send security email notification
 */
function send_security_notification($subject, $message, $priority = 'normal', $is_login_alert = false) {
    $settings = get_security_notification_settings();
    
    // Use specific security admin email for all login alerts, otherwise use regular admin email
    $to = $is_login_alert ? $settings['security_admin_email'] : $settings['admin_email'];
    
    // Add site information to subject
    $site_name = get_bloginfo('name');
    $subject = "[{$site_name}] {$subject}";
    
    // Add timestamp and site info to message (using standard format)
    $timestamp = sn_format_standard_datetime('Y-m-d H:i:s');
    $site_url = get_site_url();
    $message = "Time: {$timestamp}\nSite: {$site_url}\n\n{$message}";
    
    // Add headers for better email formatting
    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        'From: ' . $site_name . ' <' . $settings['admin_email'] . '>',
        'X-Priority: ' . ($priority === 'high' ? '1' : '3'),
    );
    
    return wp_mail($to, $subject, $message, $headers);
}

/**
 * Check if we should send notification (cooldown check)
 */
function should_send_notification($event_type) {
    $cooldown_key = "security_notification_{$event_type}";
    $last_notification = get_transient($cooldown_key);
    
    if ($last_notification === false) {
        set_transient($cooldown_key, time(), 300); // 5 minutes
        return true;
    }
    
    return false;
}

/**
 * Enhanced login event with email notification
 */
function enhanced_login_notification($user_login, $user) {
    // Log to file (existing functionality)
    log_user_login_event($user_login, $user);
    
    $settings = get_security_notification_settings();
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
    $user_roles = implode(', ', $user->roles);
    
    // Check if this is an admin login
    $is_admin = in_array('administrator', $user->roles);
    
    // Determine notification type
    if ($is_admin && $settings['notify_on_admin_login']) {
        $notification_type = 'admin_login';
        $subject = 'Admin Login Alert';
        $priority = 'high';
        $is_login_alert = true;
    } elseif ($settings['notify_on_successful_login']) {
        $notification_type = 'successful_login';
        $subject = 'User Login Alert';
        $priority = 'normal';
        $is_login_alert = true;
    } else {
        return; // No notification needed
    }
    
    // Check cooldown
    if (!should_send_notification($notification_type)) {
        return;
    }
    
    // Prepare message
    $message = "User Login Detected\n\n";
    $message .= "Username: {$user_login}\n";
    $message .= "Email: {$user->user_email}\n";
    $message .= "User Roles: {$user_roles}\n";
    $message .= "IP Address: {$ip}\n";
    $message .= "User Agent: {$user_agent}\n";
    $message .= "Login Time: " . sn_format_standard_datetime('Y-m-d H:i:s') . "\n";
    
    // Add geolocation info if available
    if (function_exists('geoip_record_by_name') && $ip !== '127.0.0.1') {
        $geo = @geoip_record_by_name($ip);
        if ($geo) {
            $message .= "Location: {$geo['city']}, {$geo['country_name']}\n";
        }
    }
    
    // Add suspicious activity indicators
    $suspicious_indicators = array();
    
    // Check for unusual user agent
    if (strpos($user_agent, 'bot') !== false || strpos($user_agent, 'crawler') !== false) {
        $suspicious_indicators[] = 'Bot-like user agent';
    }
    
    // Check for multiple failed attempts from same IP
    $failed_attempts = get_transient("failed_login_attempts_{$ip}");
    if ($failed_attempts && $failed_attempts > 3) {
        $suspicious_indicators[] = "Multiple failed attempts from this IP ({$failed_attempts})";
    }
    
    if (!empty($suspicious_indicators)) {
        $message .= "\n⚠️ SUSPICIOUS INDICATORS:\n";
        foreach ($suspicious_indicators as $indicator) {
            $message .= "- {$indicator}\n";
        }
        $priority = 'high';
    }
    
    send_security_notification($subject, $message, $priority, $is_login_alert);
}

/**
 * Enhanced failed login notification
 */
function enhanced_failed_login_notification($username) {
    // Log to file (existing functionality)
    log_failed_login_attempt($username);
    
    $settings = get_security_notification_settings();
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
    
    // Track failed attempts per IP
    $failed_attempts_key = "failed_login_attempts_{$ip}";
    $current_attempts = get_transient($failed_attempts_key) ?: 0;
    $current_attempts++;
    set_transient($failed_attempts_key, $current_attempts, 3600); // 1 hour
    
    // Check if we should notify
    if (!$settings['notify_on_failed_login']) {
        return;
    }
    
    // Check cooldown
    if (!should_send_notification('failed_login')) {
        return;
    }
    
    // Determine if this is suspicious
    $is_suspicious = false;
    $suspicious_reasons = array();
    
    if ($current_attempts >= $settings['suspicious_ip_threshold']) {
        $is_suspicious = true;
        $suspicious_reasons[] = "Multiple failed attempts from same IP ({$current_attempts})";
    }
    
    // Check if username exists
    $user = get_user_by('login', $username);
    if ($user) {
        $suspicious_reasons[] = "Attempting to access existing user account";
    }
    
    // Check for admin username attempts
    if (strpos(strtolower($username), 'admin') !== false) {
        $suspicious_reasons[] = "Attempting admin-like username";
    }
    
    // Prepare message
    $subject = $is_suspicious ? 'Suspicious Failed Login Attempt' : 'Failed Login Attempt';
    $priority = $is_suspicious ? 'high' : 'normal';
    
    $message = "Failed Login Attempt Detected\n\n";
    $message .= "Attempted Username: {$username}\n";
    $message .= "IP Address: {$ip}\n";
    $message .= "User Agent: {$user_agent}\n";
    $message .= "Failed Attempts from this IP: {$current_attempts}\n";
    $message .= "Time: " . current_time('mysql') . "\n";
    
    // Add geolocation info if available
    if (function_exists('geoip_record_by_name') && $ip !== '127.0.0.1') {
        $geo = @geoip_record_by_name($ip);
        if ($geo) {
            $message .= "Location: {$geo['city']}, {$geo['country_name']}\n";
        }
    }
    
    if ($is_suspicious) {
        $message .= "\n🚨 SUSPICIOUS ACTIVITY DETECTED:\n";
        foreach ($suspicious_reasons as $reason) {
            $message .= "- {$reason}\n";
        }
        
        // Additional security recommendations
        $message .= "\n🔒 RECOMMENDED ACTIONS:\n";
        $message .= "- Consider blocking IP {$ip}\n";
        $message .= "- Review server logs for additional activity\n";
        $message .= "- Enable additional security measures\n";
    }
    
    send_security_notification($subject, $message, $priority, true);
}

/**
 * Monitor for suspicious activity patterns
 */
function monitor_suspicious_activity() {
    $settings = get_security_notification_settings();
    
    if (!$settings['notify_on_suspicious_activity']) {
        return;
    }
    
    $suspicious_activities = array();
    
    // Check for rapid login attempts
    $recent_failed_attempts = get_transient('recent_failed_attempts');
    if ($recent_failed_attempts && count($recent_failed_attempts) > 10) {
        $suspicious_activities[] = "High volume of failed login attempts detected";
    }
    
    // Check for multiple admin login attempts
    $admin_login_attempts = get_transient('admin_login_attempts');
    if ($admin_login_attempts && count($admin_login_attempts) > 3) {
        $suspicious_activities[] = "Multiple admin login attempts detected";
    }
    
    if (!empty($suspicious_activities)) {
        $subject = 'Suspicious Activity Pattern Detected';
        $message = "Security monitoring has detected suspicious activity patterns:\n\n";
        
        foreach ($suspicious_activities as $activity) {
            $message .= "- {$activity}\n";
        }
        
        $message .= "\nTime: " . current_time('mysql') . "\n";
        $message .= "Please review your security logs and consider additional measures.\n";
        
        send_security_notification($subject, $message, 'high', true);
    }
}

/**
 * Track recent failed attempts for pattern analysis
 */
function track_failed_attempt_pattern($username) {
    $recent_attempts = get_transient('recent_failed_attempts') ?: array();
    $recent_attempts[] = array(
        'username' => $username,
        'ip' => $_SERVER['REMOTE_ADDR'],
        'time' => current_time('mysql')
    );
    
    // Keep only last 20 attempts
    if (count($recent_attempts) > 20) {
        $recent_attempts = array_slice($recent_attempts, -20);
    }
    
    set_transient('recent_failed_attempts', $recent_attempts, 3600); // 1 hour
}

/**
 * Track admin login attempts
 */
function track_admin_login_attempt($username) {
    $user = get_user_by('login', $username);
    if ($user && in_array('administrator', $user->roles)) {
        $admin_attempts = get_transient('admin_login_attempts') ?: array();
        $admin_attempts[] = array(
            'username' => $username,
            'ip' => $_SERVER['REMOTE_ADDR'],
            'time' => current_time('mysql')
        );
        
        // Keep only last 10 admin attempts
        if (count($admin_attempts) > 10) {
            $admin_attempts = array_slice($admin_attempts, -10);
        }
        
        set_transient('admin_login_attempts', $admin_attempts, 3600); // 1 hour
    }
}

// Hook the enhanced notifications
add_action('wp_login', 'enhanced_login_notification', 10, 2);
add_action('wp_login_failed', 'enhanced_failed_login_notification');
add_action('wp_login_failed', 'track_failed_attempt_pattern');
add_action('wp_login_failed', 'track_admin_login_attempt');

// Schedule suspicious activity monitoring
if (!wp_next_scheduled('security_monitoring_cron')) {
    wp_schedule_event(time(), 'hourly', 'security_monitoring_cron');
}
add_action('security_monitoring_cron', 'monitor_suspicious_activity');

// ============================================================================
// END EMAIL SECURITY NOTIFICATIONS
// ============================================================================

// ============================================================================
// SECURITY NOTIFICATION TESTING
// ============================================================================

/**
 * Test security notification system
 */
function test_security_notifications() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    $settings = get_security_notification_settings();
    
    // Test successful login notification
    $test_user = wp_get_current_user();
    $test_subject = 'TEST: User Login Alert';
    $test_message = "This is a test notification for successful login.\n\n";
    $test_message .= "Username: {$test_user->user_login}\n";
    $test_message .= "Email: {$test_user->user_email}\n";
    $test_message .= "User Roles: " . implode(', ', $test_user->roles) . "\n";
    $test_message .= "IP Address: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $test_message .= "Test Time: " . current_time('mysql') . "\n\n";
    $test_message .= "This is a test email to verify the security notification system is working correctly.";
    
    $result = send_security_notification($test_subject, $test_message, 'normal', true);
    
    if ($result) {
        echo '<div class="notice notice-success"><p>✅ Test notification sent successfully to ' . $settings['security_admin_email'] . '</p></div>';
    } else {
        echo '<div class="notice notice-error"><p>❌ Failed to send test notification. Check your email configuration.</p></div>';
    }
}

/**
 * Add test button to admin dashboard
 */
function add_security_test_button() {
    if (current_user_can('manage_options')) {
        add_action('admin_notices', function() {
            if (isset($_GET['test_security_notifications']) && $_GET['test_security_notifications'] === '1') {
                test_security_notifications();
            }
            
            echo '<div class="notice notice-info">';
            echo '<p><strong>🔐 Security Notification Testing:</strong> ';
            echo '<a href="' . admin_url('?test_security_notifications=1') . '" class="button button-small">Test Email Notifications</a> ';
            echo 'Click to send a test notification to ' . get_security_notification_settings()['security_admin_email'] . '</p>';
            echo '</div>';
        });
    }
}
add_action('admin_init', 'add_security_test_button');

/**
 * Add security notification settings page
 */
function add_security_notification_settings_page() {
    add_submenu_page(
        'tools.php',
        'Security Notifications',
        'Security Alerts',
        'manage_options',
        'security-notifications',
        'display_security_notification_settings'
    );
}
add_action('admin_menu', 'add_security_notification_settings_page');

/**
 * Display security notification settings page
 */
function display_security_notification_settings() {
    $settings = get_security_notification_settings();
    
    echo '<div class="wrap">';
    echo '<h1>🔐 Security Notification Settings</h1>';
    
    echo '<div class="card">';
    echo '<h2>Current Settings</h2>';
    echo '<table class="form-table">';
    echo '<tr><th>Security Admin Email:</th><td>' . esc_html($settings['security_admin_email']) . '</td></tr>';
    echo '<tr><th>Regular Admin Email:</th><td>' . esc_html($settings['admin_email']) . '</td></tr>';
    echo '<tr><th>Notify on Successful Login:</th><td>' . ($settings['notify_on_successful_login'] ? '✅ Enabled' : '❌ Disabled') . '</td></tr>';
    echo '<tr><th>Notify on Failed Login:</th><td>' . ($settings['notify_on_failed_login'] ? '✅ Enabled' : '❌ Disabled') . '</td></tr>';
    echo '<tr><th>Notify on Admin Login:</th><td>' . ($settings['notify_on_admin_login'] ? '✅ Enabled' : '❌ Disabled') . '</td></tr>';
    echo '<tr><th>Suspicious IP Threshold:</th><td>' . esc_html($settings['suspicious_ip_threshold']) . ' failed attempts</td></tr>';
    echo '<tr><th>Notification Cooldown:</th><td>' . esc_html($settings['notification_cooldown']) . ' seconds</td></tr>';
    echo '</table>';
    echo '</div>';
    
    echo '<div class="card">';
    echo '<h2>Test Notifications</h2>';
    echo '<p>Use these buttons to test the notification system:</p>';
    echo '<p><a href="' . admin_url('?test_security_notifications=1') . '" class="button button-primary">Send Test Notification</a></p>';
    echo '<p><strong>Note:</strong> Test notifications will be sent to: <code>' . esc_html($settings['security_admin_email']) . '</code></p>';
    echo '</div>';
    
    echo '<div class="card">';
    echo '<h2>Recent Activity</h2>';
    $log_file = WP_CONTENT_DIR . '/activity-log.txt';
    if (file_exists($log_file)) {
        $log_content = file_get_contents($log_file);
        $lines = explode("\n", $log_content);
        $recent_lines = array_slice($lines, -10); // Last 10 lines
        
        echo '<div style="background: #f9f9f9; padding: 10px; border: 1px solid #ddd; max-height: 300px; overflow-y: auto; font-family: monospace; font-size: 11px;">';
        foreach ($recent_lines as $line) {
            if (!empty(trim($line))) {
                echo '<div>' . esc_html($line) . '</div>';
            }
        }
        echo '</div>';
    } else {
        echo '<p>No activity log found.</p>';
    }
    echo '</div>';
    
    echo '</div>';
}

// Enqueue Calendly popup CSS and JS globally
function enqueue_calendly_popup_assets() {
    // Calendly widget CSS
    wp_enqueue_style('calendly-widget-css', 'https://assets.calendly.com/assets/external/widget.css');
    
    // Add custom button styles
    wp_add_inline_style('calendly-popup-style', '
        .sn-schedule-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 16px;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(76, 175, 80, 0.2);
        }

        .sn-schedule-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(76, 175, 80, 0.3);
            background: linear-gradient(135deg, #45a049 0%, #3d8b40 100%);
            color: white;
        }

        .sn-schedule-btn .btn-icon {
            font-size: 18px;
        }

        .sn-schedule-btn .btn-text {
            letter-spacing: 0.5px;
        }

        @media (max-width: 768px) {
            .sn-schedule-btn {
                padding: 10px 20px;
                font-size: 14px;
            }
        }
    ');
}
add_action('wp_enqueue_scripts', 'enqueue_calendly_popup_assets');

// Hide admin bar by default
function hide_admin_bar() {
    return false;
}
add_filter('show_admin_bar', 'hide_admin_bar');

// Inject popup HTML and inline JS before </body>
function output_calendly_popup_html() {
    ?>
    <!-- Calendly Global Popup -->
    <div class="calendly-popup-overlay" id="calendly-popup">
      <div class="calendly-popup-content">
        <button class="calendly-popup-close-btn" id="calendly-popup-close">&times;</button>
        <div id="calendly-inline-widget" style="min-width:320px;height:100%;"></div>
      </div>
    </div>

    <style>
      .calendly-popup-overlay {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background-color: rgb(0 0 0 / 70%);
        backdrop-filter: blur(5px);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 9999;
      }
      .calendly-popup-content {
        position: relative;
        width: 75%; max-width: 1200px;
        height: 95vh;
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
      }
      .calendly-popup-close-btn {
        position: absolute;
        top: 10px; right: 15px;
        background: #C22034; color: #fff;
        border: none;
        border-radius: 50%;
        width: 30px; height: 30px;
        font-size: 16px; cursor: pointer;
        z-index: 10000;
      }
      @media (max-width: 600px) {
        .calendly-popup-content {
          width: 95%; height: 90vh;
        }
      }
    </style>

    <!-- Load Calendly script directly -->
    <script src="https://assets.calendly.com/assets/external/widget.js"></script>
    
    <script>
     window.addEventListener("load", function () {
        const popup = document.getElementById("calendly-popup");
        const closeBtn = document.getElementById("calendly-popup-close");
        const widgetContainer = document.getElementById("calendly-inline-widget");

        // Add a small delay to ensure Calendly is loaded
        setTimeout(() => {
            if (typeof Calendly === 'undefined') {
                console.error('Calendly widget script not loaded properly');
                return;
            }

            document.querySelectorAll(".calendly-trigger").forEach(btn => {
                btn.addEventListener("click", function (e) {
                    e.preventDefault();
                    popup.style.display = "flex";

                    try {
                        Calendly.initInlineWidget({
                            url: 'https://calendly.com/surya-salesnanny/30min?hide_landing_page_details=1&hide_gdpr_banner=1',
                            parentElement: widgetContainer,
                            prefill: {},
                            utm: {}
                        });
                    } catch (error) {
                        console.error('Error initializing Calendly widget:', error);
                    }
                });
            });

            closeBtn.addEventListener("click", function () {
                popup.style.display = "none";
                widgetContainer.innerHTML = '';
            });
        }, 1000); // 1 second delay to ensure script is loaded
     });
    </script>
    <?php
}
add_action('wp_footer', 'output_calendly_popup_html');

function output_audit_popup_script() {
    ?>
    <style>
        /* Modern Button Styles */
        .sn-audit-btn {
            padding: 1rem 2rem;
            font-size: 16px;
            font-weight: 600;
            border-radius: 50px;
            text-decoration: none;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            overflow: hidden;
            position: relative;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .sn-audit-btn::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            height: 100%;
            width: 100%;
            background: linear-gradient(
                120deg,
                transparent,
                rgba(255, 255, 255, 0.3),
                transparent
            );
            transition: 0.5s;
        }

        .sn-audit-btn:hover::before {
            left: 100%;
        }

        .sn-audit-btn-primary {
            color: #fff;
            background: linear-gradient(45deg, #1e2154, #2a2f6e);
            border-top: 3px solid #c22034;
        }

        .sn-audit-btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(30, 33, 84, 0.3);
        }

        /* Enhanced Popup Styles */
        .sn-audit-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.85);
            z-index: 9999;
            backdrop-filter: blur(5px);
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        .sn-audit-popup h2 {
            margin-top: 35px;
            margin-bottom: 15px;
            color: #1e2154;
            font-size: 26px;
            font-weight: 700;
            position: relative;
            padding-right: 30px;
        }
        .sn-audit-popup p {
            margin-bottom: 25px;
            color: #555;
            font-size: 16px;
            line-height: 1.5;
        }
        .sn-audit-popup.active {
            display: flex !important;
            align-items: center;
            justify-content: center;
            opacity: 1;
        }

        .sn-audit-popup-content {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border-radius: 20px;
            padding: 40px;
            width: 90%;
            max-width: 550px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 50px rgba(30, 33, 84, 0.25);
            position: relative;
            transform: translateY(20px);
            transition: transform 0.5s cubic-bezier(0.19, 1, 0.22, 1);
            margin: 20px;
            border-top: 5px solid #c22034;
        }

        .sn-audit-popup.active .sn-audit-popup-content {
            transform: translateY(0);
        }

        .sn-audit-close-popup {
            position: absolute;
            right: 20px;
            top: 15px;
            font-size: 28px;
            cursor: pointer;
            color: #666;
            transition: all 0.3s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(0, 0, 0, 0.05);
        }

        .sn-audit-close-popup:hover {
            color: #fff;
            background-color: #c22034;
        }

        .sn-audit-form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .sn-audit-form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
            font-size: 15px;
        }

        /* .sn-audit-form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: #fff;
        } */
        .sn-audit-form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e6;
            border-radius: 8px;
            background-color: #f9f9fb;
            color: #1e2154;
            font-weight: 500;
            font-family: inherit;
        }
        .sn-audit-form-group input:focus {
            border-color: #1e2154;
            box-shadow: 0 0 0 3px rgba(30, 33, 84, 0.1);
            outline: none;
        }

        .sn-audit-form-group input::placeholder {
            color: #999;
        }

        .sn-audit-form-buttons {
            text-align: center;
            margin-top: 30px;
        }

        .sn-audit-btn-submit {
            background: #c22034;
            color: white;
            border: none;
            padding: 14px 30px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(30, 33, 84, 0.2);
            width: 100%;
            max-width: 200px;
            border-radius: 8px;
        }
        .sn-audit-btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(30, 33, 84, 0.3);
        }

        .sn-audit-btn-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .sn-audit-form-status {
            margin-top: 10px;
            text-align: center;
            padding: 15px;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .sn-audit-form-status.error {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.2);
        }

        .sn-audit-form-status.success {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.2);
        }

        .sn-audit-loading-spinner {
            display: inline-block;
            width: 24px;
            height: 24px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid #fff;
            border-radius: 50%;
            animation: sn-audit-spin 1s linear infinite;
            margin-right: 10px;
            vertical-align: middle;
        }

        @keyframes sn-audit-spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sn-audit-popup-content {
                padding: 30px 20px;
                margin: 15px;
                width: 95%;
            }

            .sn-audit-btn-submit {
                padding: 12px 25px;
                font-size: 15px;
            }

            .sn-audit-form-group input {
                padding: 10px 12px;
                font-size: 14px;
            }

            .sn-audit-close-popup {
                right: 15px;
                top: 10px;
                font-size: 24px;
                width: 35px;
                height: 35px;
            }
        }

        @media (max-width: 480px) {
            .sn-audit-popup-content {
                padding: 25px 15px;
                margin: 10px;
            }

            .sn-audit-form-group {
                margin-bottom: 20px;
            }

            .sn-audit-form-group label {
                font-size: 14px;
            }

            .sn-audit-btn-submit {
                padding: 10px 20px;
                font-size: 14px;
            }
        }

        /* Custom Scrollbar */
        .sn-audit-popup-content::-webkit-scrollbar {
            width: 8px;
        }

        .sn-audit-popup-content::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }

        .sn-audit-popup-content::-webkit-scrollbar-thumb {
            background: #1e2154;
            border-radius: 4px;
        }

        .sn-audit-popup-content::-webkit-scrollbar-thumb:hover {
            background: #2a2f6e;
        }
    </style>
    <div id="sn-audit-popup" class="sn-audit-popup" aria-hidden="true" style="display: none;">
        <div class="sn-audit-popup-content">
            <span class="sn-audit-close-popup">&times;</span>
            <h2>Free Website Audit</h2>
            <p>Enter your details below and we'll analyze your website for free.</p>
            <form id="sn-audit-form">
                <div class="sn-audit-form-group">
                    <label for="sn-audit-email">Email Address</label>
                    <input type="email" id="sn-audit-email" name="email" placeholder="your@email.com" required>
                </div>
                <div class="sn-audit-form-group">
                    <label for="sn-audit-website">Website</label>
                    <input type="text" id="sn-audit-website" name="website" placeholder="yourwebsite.com" required>
                </div>
                <div class="sn-audit-form-buttons">
                    <button type="submit" id="sn-audit-submit" class="sn-audit-btn-submit">Submit</button>
                </div>
            </form>
            <div id="sn-audit-form-status" class="sn-audit-form-status"></div>
        </div>
    </div>

    <script>
        // Global function to open popup
        window.openAuditPopup = function() {
            const popup = document.getElementById('sn-audit-popup');
            if (popup) {
                popup.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        };

        document.addEventListener('DOMContentLoaded', function() {
            const popup = document.getElementById('sn-audit-popup');
            const closeButton = document.querySelector('.sn-audit-close-popup');
            const auditForm = document.getElementById('sn-audit-form');
            const formStatus = document.getElementById('sn-audit-form-status');
            const submitButton = document.getElementById('sn-audit-submit');

            const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbyyK5yWzYd5xtE6F-hbYOdhUOT-ozzrtAnYQMyEB44TQDnhxR35VoRUtcYDJkkXDdetJQ/exec';

            // Handle both class-based and onclick triggers
            document.body.addEventListener('click', function(e) {
                const target = e.target.closest('[class*="btn-audit"], [onclick*="openAuditPopup"]');
                if (target) {
                    e.preventDefault();
                    window.openAuditPopup();
                }
            });

            if (closeButton) {
                closeButton.addEventListener('click', function() {
                    popup.classList.remove('active');
                    document.body.style.overflow = '';
                });
            }

            if (popup) {
                popup.addEventListener('click', function(e) {
                    if (e.target === popup) {
                        popup.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            }

            if (auditForm) {
                auditForm.addEventListener('submit', function(e) {
                    e.preventDefault();

                    const email = document.getElementById('sn-audit-email').value;
                    let website = document.getElementById('sn-audit-website').value;

                    if (!email || !website) {
                        showStatus('Please fill in all fields', 'error');
                        return;
                    }

                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(email)) {
                        showStatus('Please enter a valid email address', 'error');
                        return;
                    }

                    try {
                        website = website.replace('@', '');
                        if (!website.startsWith('http://') && !website.startsWith('https://')) {
                            website = 'https://' + website;
                        }
                        new URL(website);
                    } catch (e) {
                        showStatus('Please enter a valid website URL', 'error');
                        return;
                    }

                    submitButton.disabled = true;
                    submitButton.innerHTML = '<span class="sn-audit-loading-spinner"></span>Submitting...';

                    const formDataObj = {
                        email: email,
                        website: website,
                        formType: 'audit',
                        timestamp: new Date().toISOString(),
                        sourcePage: window.location.pathname
                    };

                    fetch(APPS_SCRIPT_URL, {
                        method: 'POST',
                        mode: 'no-cors',
                        cache: 'no-cache',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        redirect: 'follow',
                        body: JSON.stringify(formDataObj)
                    })
                    .then(() => {
                        setTimeout(() => {
                            showStatus('Thank you! Your audit request has been submitted. We\'ll email you the results within 12 hours.', 'success');
                            auditForm.reset();
                            submitButton.disabled = false;
                            submitButton.innerHTML = 'Submit Audit Request';

                            setTimeout(() => {
                                popup.classList.remove('active');
                                document.body.style.overflow = '';
                            }, 3000);
                        }, 1500);
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showStatus('There was an error submitting your request. Please try again.', 'error');
                        submitButton.disabled = false;
                        submitButton.innerHTML = 'Submit Audit Request';
                    });
                });
            }

            function showStatus(message, type) {
                if (formStatus) {
                    formStatus.textContent = message;
                    formStatus.className = 'sn-audit-form-status ' + type;
                }
            }
        });
    </script>
    <?php
}
add_action('wp_footer', 'output_audit_popup_script', 101);





















// ============================================================================
// END SECURITY NOTIFICATION TESTING
// ============================================================================

// ============================================================================
// DISABLE ADMIN BAR
// ============================================================================

// Disable admin bar for all users on frontend
add_filter('show_admin_bar', '__return_false');

// Remove admin bar CSS to prevent top spacing
function remove_admin_bar_css_frontend() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}
add_action('get_header', 'remove_admin_bar_css_frontend');

// ============================================================================
// END ADMIN BAR DISABLE
// ============================================================================

// ============================================================================
// WEBSITE ANALYZER FUNCTIONS
// ============================================================================
// Include analyzer functions in a separate file to avoid conflicts
require_once get_template_directory() . '/analyzer-functions.php';

