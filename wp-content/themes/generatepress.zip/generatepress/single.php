<?php
// Get the current post object
global $post;

if (in_category('blogs')) {
    get_template_part('single', 'blogs');
} elseif (in_category('digital-marketing')) {
    get_template_part('single', 'digital-marketing');
} elseif (in_category('seo')) {
    get_template_part('single', 'seo');
} elseif (in_category('aeo')) {
    get_template_part('single', 'aeo');
} elseif (in_category('social-media')) {
    get_template_part('single', 'social-media');
} elseif (in_category('ppc')) {
    get_template_part('single', 'ppc');
} elseif (in_category('web-development')) {
    get_template_part('single', 'web-development');
} elseif (in_category('designs')) {
    get_template_part('single', 'designs');
} elseif (in_category('case-studies')) {
    get_template_part('single', 'case-studies');
} elseif (in_category('news')) {
    get_template_part('single', 'news');
}
    
?>

