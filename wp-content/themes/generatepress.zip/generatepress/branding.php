<?php
   /*
   Template Name: Branding
   */
?>
<html>
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
<body>    
      <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/earned-media.non-critical.css" as="style" onload="this.onload=null;this.rel='stylesheet'" />
      <noscript>
            <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/earned-media.non-critical.css" />
      </noscript>
    <div>
        <style>
            .channel-card img,.illustration-column img,.process-diagram img{max-width:100%;height:auto}.hero-wrapper{background-color:#fdf3f3;width:100%}.hero-section{padding:80px 20px;min-height:600px;display:flex;align-items:center;margin-top:80px;width:100%;box-sizing:border-box}.hero-container{display:flex;align-items:center;justify-content:space-between;gap:12rem;width:100%;max-width:1250px;margin:0 auto}.hero-content{max-width:600px;flex:1}.hero-title{font-size:54px;line-height:1.2;margin-bottom:24px;color:#1a1a1a}.hero-title span{background:linear-gradient(120deg,gold 0,gold 100%);background-repeat:no-repeat;background-size:100% .4em;background-position:0 88%}.hero-description{font-size:1.25rem;line-height:1.6;color:#4a4a4a;margin-bottom:32px}.hero-cta{display:inline-block;cursor:pointer;background-color:#c82333;color:#fff;padding:.875rem 1.5rem;text-decoration:none;border-radius:4px;font-weight:600;transition:background-color .3s;box-shadow:rgba(0,0,0,.02) 0 1px 3px 0,rgba(27,31,35,.15) 0 0 0 1px}.channel-card,.process-diagram{border-radius:8px;padding:40px}.hero-image{flex:1;max-width:500px;aspect-ratio:1;position:relative;display:flex;align-items:center;justify-content:center}.hero-image img{width:100%;height:100%;object-fit:contain;position:relative}.channels-section,.features-section,.quotes-section,.sales-process-section{padding:80px 20px;width:100%;box-sizing:border-box}.channels-header,.feature-item{margin-bottom:60px}.channels-title{font-size:48px;font-weight:700;margin-bottom:20px;color:#1a1a1a}.channels-description{font-size:19px;line-height:1.6;color:#000;max-width:600px}.channels-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:30px;width:100%;max-width:1250px;margin:0 auto}.quotes-content,.sales-process-content{gap:60px;box-sizing:border-box;display:flex;width:100%}.channel-card{background:#f8f9fa;display:flex;flex-direction:column;align-items:center;text-align:center;padding:20px;box-sizing:border-box}.channel-card h3{font-size:28px;font-weight:600;margin:20px 0 10px;color:#1a1a1a}.channel-card p{font-size:17px;line-height:1.5;color:#4a4a4a;margin-bottom:20px}.channel-card img{border-radius:4px;max-height:95px;width:auto;object-fit:contain}.channels-header,.quotes-header,.sales-process-header{width:100%;max-width:1250px;margin:0 auto 60px;box-sizing:border-box}.sales-process-title{font-size:48px;line-height:1.2;font-weight:600;color:#1a1a1a;margin-bottom:24px}.quotes-description,.sales-process-description{font-size:1.125rem;line-height:1.6;color:#4a4a4a}.sales-process-content{background-color:#fdf3f3;align-items:center;padding:40px;max-width:1250px;margin:0 auto}.features-column,.features-list{flex:1;max-width:400px}.feature-item:last-child,.quote-feature:last-child{margin-bottom:0}.feature-title{font-size:1.75rem;font-weight:600;color:#1a1a1a;margin-bottom:16px}.feature-description{font-size:1.125rem;line-height:1.5;color:#4a4a4a;margin-bottom:16px}.process-diagram{flex:1.5;min-height:600px;display:flex;align-items:center;justify-content:center}.quotes-title{font-size:3rem;line-height:1.2;font-weight:600;color:#1a1a1a;margin-bottom:24px}.quotes-content{align-items:center;background-color:#e8f5f0;border-radius:12px;padding:60px;position:relative;overflow:hidden;max-width:1250px;margin:0 auto}.features-column{position:relative;z-index:2}.quote-feature{margin-bottom:40px}.quote-feature-title{font-size:1.75rem;font-weight:600;color:#1a1a1a;margin-bottom:12px}.quote-feature-description{font-size:1rem;line-height:1.5;color:#4a4a4a;margin-bottom:16px}.feature-name,.features-title{font-weight:600;color:#1a1a1a}.illustration-column{flex:1;display:flex;justify-content:center;align-items:center;position:relative;z-index:1}.features-title{font-size:28px;line-height:1.2;text-align:center;margin-bottom:60px}.features-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:24px;width:100%;max-width:1200px;margin:0 auto}.feature-card{background:0 0;padding:32px 24px;border-radius:8px;text-align:center;transition:transform .3s;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;aspect-ratio:1}.feature-card:first-child{background-color:#ffe4e1}.feature-icon{width:48px;height:48px;margin-bottom:16px}.feature-name{font-size:1.25rem;margin:0}@media (max-width:968px){.hero-container{flex-direction:column;text-align:center;gap:2rem}.hero-content{order:1}.hero-section{min-height:400px;padding:60px 10px 40px}.hero-image{order:2;aspect-ratio:1/1;min-height:220px;max-width:320px;width:100%;margin:0 auto;height:auto;display:flex;align-items:center;justify-content:center}.hero-image img{width:100%;height:auto;max-height:320px;object-fit:contain;display:block}.hero-title{font-size:2rem}.hero-content{max-width:100%}}@media (max-width:1024px){.channels-header,.quotes-header,.sales-process-header{padding:0 20px}.quotes-content,.sales-process-content{padding:40px 20px;flex-direction:column}.features-column,.features-list{max-width:100%}.process-diagram{width:100%}.quotes-content{flex-direction:column}.illustration-column{margin-top:40px}.features-grid{grid-template-columns:repeat(3,1fr);gap:20px}}@media (max-width:768px){.channels-grid{grid-template-columns:1fr}.channels-title{font-size:2rem}.channel-card{height:auto;min-height:350px}.channel-card h3{font-size:24px}.channel-card p{font-size:16px}.channel-card img{max-height:150px}.quotes-title,.sales-process-title{font-size:2.5rem}.feature-title,.quote-feature-title{font-size:1.5rem}.process-diagram{padding:20px;min-height:400px}.features-grid{grid-template-columns:repeat(2,1fr);gap:16px}.features-title{font-size:2rem;margin-bottom:40px}}@media (max-width:480px){.channels-section,.features-section,.hero-section,.quotes-section,.sales-process-section{padding:50px 20px!important}.channels-title,.features-title,.hero-title,.quotes-title,.sales-process-title{font-size:24px}.hero-description,.quotes-description,.sales-process-description{font-size:18px}.hero-container{flex-direction:column;text-align:center;gap:2rem}.channel-card{height:auto;min-height:400px}.channel-card img{width:100%;height:auto}.features-grid{grid-template-columns:1fr;max-width:280px;margin:0 auto}.feature-card{padding:24px}.hero-section{min-height:320px;padding:40px 5px 30px}.hero-image{min-height:160px;max-width:200px}.hero-title{font-size:1.5rem}}
        </style>
        <?php salesnanny_nav_header(); ?>
        <div class="hero-wrapper">
            <section class="hero-section">
                <div class="hero-container">
                    <div class="hero-content">
                        <h1 class="hero-title">
                        <span>Design Engaging Brand Connections</span> with Our Branding Solutions
                        </h1>
                        <p class="hero-description">
                            We build brands that people remember and like. We ensure your brand stays consistent, so it looks the same no matter where people see your brand.
                        </p>
                        <a  class="calendly-trigger hero-cta">Schedule a Call</a>
                    </div>
                    <div class="hero-image">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/branding/branding-header.png" alt="Branding services illustration showing brand development process" fetchpriority="high" width="458" height="458">
                    </div>
                </div>
            </section>
        </div>
        <section class="channels-section">
            <div class="channels-header">
                <h2 class="channels-title">Your Creative Partner for<br>Successful Business Branding</h2>
                <p class="channels-description">Branding can feel stuck, but we make it move. Our Branding Solutions help you solidify your core, build your visuals, and broadcast your message, so you can focus on connecting and growing.</p>
            </div>
            
            <div class="channels-grid">
                <!-- CRM Mobile Card -->
                <div class="channel-card">
                    <h3>Logo Design</h3>
                    <p>We create a special picture or symbol for your brand. This helps people remember you and makes your business look unique.</p>
                    <!-- <a href="#" class="watch-video-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                            <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                        </svg>
                        Watch a video
                    </a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/branding/logo-design.png" alt="Logo design icon representing brand identity creation" loading="lazy" width="95" height="95">
                </div>

                <!-- Email Card -->
                <div class="channel-card">
                    <h3>Brand Guidelines</h3>
                    <p>We make rules about how your brand looks and sounds. This helps keep everything consistent, so people always recognize you.</p>
                    <!-- <a href="#" class="watch-video-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                            <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                        </svg>
                        Watch a video
                    </a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/branding/brand-guide.png" alt="Brand guidelines icon showing style guide elements" loading="lazy" width="95" height="95">
                </div>

                <!-- Telephony Card -->
                <div class="channel-card">
                    <h3>Brand Messaging</h3>
                    <p>We help you find the best words to talk about your brand. This makes sure everyone understands what you do and why you are special.</p>
                    <!-- <a href="#" class="learn-more-link">Learn more</a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/branding/brand-message.png" alt="Brand messaging icon representing communication strategy" loading="lazy" width="95" height="95">
                </div>

                <!-- Social Media Card -->
                <div class="channel-card">
                    <h3>Visual Identity</h3>
                    <p>We create the look and feel of your brand. This includes colors, fonts, and images that make your brand stand out and feel consistent.</p>
                    <!-- <a href="#" class="watch-video-link">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                            <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                        </svg>
                        Watch a video
                    </a> -->
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/branding/visual-identity.png" alt="Visual identity icon showing brand design elements" loading="lazy" width="95" height="95">
                </div>

            </div>
        </section>
        <section class="sales-process-section">
            <div class="sales-process-header">
                <h2 class="sales-process-title">Shape and Empower Your Brand</h2>
                <p class="sales-process-description">Your brand is a critical asset. Our branding services provide the tools to define, express, and activate your brand, enabling strong connections and driving business recognition.</p>
            </div>
            <div class="sales-process-content">
                <div class="features-list">
                    <div class="feature-item">
                        <h3 class="feature-title">Logo & Visual Identity</h3>
                        <p class="feature-description">Create a memorable and distinctive look.</p>
                        <!-- <a href="#" class="feature-link">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                                <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                            </svg>
                            Watch a video
                        </a> -->
                    </div>

                    <div class="feature-item">
                        <h3 class="feature-title">Brand Messaging & Voice</h3>
                        <p class="feature-description">Develop clear and consistent communication.</p>
                        <!-- <a href="#" class="learn-more">Learn more</a> -->
                    </div>

                    <div class="feature-item">
                        <h3 class="feature-title">Brand Strategy & Guidelines</h3>
                        <p class="feature-description">Establish a strong foundation and rules.</p>
                        <!-- <a href="#" class="feature-link">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="12" cy="12" r="12" fill="#1a1a1a"/>
                                <path d="M16 12L10 15.464V8.536L16 12Z" fill="white"/>
                            </svg>
                            Watch a video
                        </a> -->
                    </div>
                </div>
                <div class="process-diagram">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/branding/branding-opt.png" alt="Brand development process diagram showing key stages" loading="lazy" width="670" height="670">
                </div>
            </div>
        </section>
        <section class="features-section">
            <h2 class="features-title">See What Else You Can Do with Salesnanny</h2>
            <div class="features-grid">
                <a href="<?php echo SN_HTTP_URL; ?>paid-marketing/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/paid-marketing-tab.png" alt="Paid marketing services icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Paid Marketing</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>website-development/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/web-development-tab.png" alt="Website development services icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Website Development</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>organic-marketing/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/organic-marketing-tab.png" alt="Organic marketing services icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Organic Marketing</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>inside-sales/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/inside-sales-tab.png" alt="Inside sales services icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Inside Sales</h3>
                    </div>
                </a>

                <a href="<?php echo SN_HTTP_URL; ?>creative/" style="text-decoration: none;">
                    <div class="feature-card">
                        <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/footer-logos/creative-tab.png" alt="Creative services icon" class="feature-icon" loading="lazy">
                        <h3 class="feature-name">Creative</h3>
                    </div>
                </a>
            </div>
        </section>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>
