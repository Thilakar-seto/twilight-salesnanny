<?php
   /*
   Template Name: Teams New
   */
   ?>
<!DOCTYPE html>
<html>
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
   <body>
      <div>
        <?php salesnanny_nav_header(); ?>
<!DOCTYPE html>
<html lang="en">
        <style>
            .sn-person,.sn-team-hero,.sn-values-bridge{position:relative;box-sizing:border-box!important}.sn-container,.sn-info-bar,.sn-person,.sn-team-hero,.sn-team-wrapper,.sn-values-bridge{box-sizing:border-box!important}:root{--sn-navy:#0F172A;--sn-text:#334155;--sn-bg:#F1F5F9;--card-bg:#FFFFFF;--overlay-navy:#0F172A;--overlay-red:#D9232D}html{scroll-behavior:smooth}.sn-team-wrapper{color:var(--sn-text);line-height:1.4;background-color:var(--sn-bg);background-image:radial-gradient(#cbd5e1 1px,transparent 1px);background-size:30px 30px;width:100%;text-align:left}.sn-container{max-width:1400px;margin:0 auto;padding:0 40px}h1,h2,h3,h4{color:var(--sn-navy);font-weight:800;margin:0}.sn-team-hero{text-align:center;padding:125px 20px 50px;background:linear-gradient(156deg,#0f172a 34%,#1e293be6 49%,#d9232d 100%);color:#fff;z-index:10}.sn-team-hero h1{font-size:46px;margin-bottom:25px;letter-spacing:-.03em;color:#fff;line-height:1.1;font-weight:700}.sn-team-hero p{font-size:1.5rem;color:#e2e8f0;max-width:750px;margin:0 auto;font-weight:400;line-height:1.6}.sn-values-bridge{padding:80px 0;background:#fff;border-bottom:1px solid #e2e8f0;z-index:5;box-shadow:0 10px 30px -10px rgba(0,0,0,.05)}.sn-values-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:40px;text-align:center}.sn-value-item h3{font-size:1.25rem;color:var(--sn-navy);margin-bottom:10px;font-weight:800}.sn-value-item p{font-size:1rem;color:#64748b;line-height:1.5;max-width:300px;margin:0 auto}.sn-value-icon{font-size:2.5rem;display:block;margin-bottom:15px}.sn-grid-section{padding:80px 0 100px}.sn-gallery{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;align-items:start}.sn-person{border-radius:16px;overflow:hidden;aspect-ratio:5/5;cursor:pointer;transform:translateZ(0);background:var(--card-bg);box-shadow:0 4px 6px -1px rgba(0,0,0,.1),0 2px 4px -1px rgba(0,0,0,.06);border:1px solid rgba(255,255,255,.5);transition:transform .4s ease-out,box-shadow .4s ease-out}.sn-info-bar,.sn-overlay{position:absolute;left:0;bottom:0}.sn-person:hover{transform:translateY(-8px);box-shadow:0 20px 40px -10px rgba(0,0,0,.15)}.sn-person img{width:100%;height:auto;object-fit:cover;transition:transform .7s cubic-bezier(.25, .46, .45, .94)}.sn-person:hover img{transform:scale(1.15)}.sn-info-bar{width:100%;padding:20px;background:linear-gradient(to top,rgba(15,23,42,.9) 0,transparent 100%);color:#fff;z-index:2;transition:opacity .2s}.sn-info-bar h3{color:#fff;font-size:1.25rem;margin-bottom:4px}.sn-info-bar span{font-size:.8rem;font-weight:600;opacity:.9;text-transform:uppercase;letter-spacing:.5px;color:#e2e8f0}.sn-person:hover .sn-info-bar{opacity:0}.sn-overlay{top:0;right:0;width:100%!important;height:100%!important;background:#0f172a;display:flex!important;flex-direction:column!important;justify-content:center!important;align-items:center!important;text-align:center!important;padding:20px!important;opacity:0;z-index:3;transition:opacity .4s;box-sizing:border-box!important}.sn-footer,.sn-manifesto-section{padding:100px 0;box-sizing:border-box!important}.dept-tech .sn-overlay{background:linear-gradient(135deg,#0284c7,#2563eb)}.dept-strategy .sn-overlay{background:linear-gradient(135deg,#059669,#10b981)}.dept-creative .sn-overlay{background:linear-gradient(135deg,#7c3aed,#db2777)}.dept-success .sn-overlay{background:linear-gradient(135deg,#ea580c,#d9232d)}.sn-person:hover .sn-overlay{opacity:1}.sn-overlay-content{width:100%!important;transform:translateY(20px);transition:transform .5s cubic-bezier(.25, .46, .45, .94);display:flex;flex-direction:column;align-items:center;justify-content:center}.sn-fun-fact,.sn-fun-title{width:100%;text-align:center!important}.sn-person:hover .sn-overlay-content{transform:translateY(0)}.sn-emoji{font-size:2.5rem;margin-bottom:10px;display:block;margin-left:auto;margin-right:auto}.sn-list-items,.sn-manifesto-grid{display:grid;grid-template-columns:1fr 1fr}.sn-fun-title{color:#fff;font-size:1.3rem;font-weight:800;margin-bottom:10px;line-height:1.2}.sn-fun-fact{color:#f1f5f9;font-size:.95rem;line-height:1.4;font-style:italic}.sn-manifesto-section{background:#fff;border-top:1px solid #e2e8f0}.sn-manifesto-header h2{font-size:46px;max-width:900px;font-weight:700;text-align:center;margin:0 auto;margin-bottom:60px;line-height:1.2;color:var(--sn-navy)}.sn-manifesto-grid{gap:80px}.sn-list-col h3{font-size:1.5rem;margin-bottom:30px;border-bottom:2px solid #e2e8f0;padding-bottom:15px;display:inline-block}.sn-do-list h3{border-color:#059669;color:#059669}.sn-dont-list h3{border-color:#d9232d;color:#d9232d;text-decoration:line-through}.sn-list-items{gap:20px}.sn-list-item{font-size:1.1rem;color:var(--sn-text);font-weight:500}.sn-btn,.sn-footer h2{color:#fff;font-weight:700}.sn-footer{text-align:center;background:#0f172a;color:#fff}.sn-footer h2{font-size:46px;margin-bottom:30px;letter-spacing:-.02em}.sn-btn{display:inline-block;background:#d9232d;padding:20px 50px;border-radius:5px;font-size:16px;text-decoration:none;transition:.3s}.sn-btn:hover{background:#fff;color:#d9232d;transform:translateY(-3px)}@media (max-width:1024px){.sn-gallery{grid-template-columns:repeat(3,1fr)}.sn-container{padding:0 30px}}@media (max-width:768px){.sn-team-hero{padding:100px 20px 40px}.sn-team-hero h1{font-size:32px;margin-bottom:20px}.sn-team-hero p{font-size:1.2rem}.sn-values-bridge{padding:60px 0}.sn-manifesto-grid,.sn-values-grid{grid-template-columns:1fr;gap:40px}.sn-gallery{grid-template-columns:repeat(2,1fr);gap:15px}.sn-grid-section{padding:60px 0 80px}.sn-emoji,.sn-manifesto-header h2{font-size:2rem}.sn-container{padding:0 20px}.sn-info-bar{padding:15px}.sn-fun-title,.sn-info-bar h3{font-size:1.1rem}.sn-info-bar span{font-size:.75rem}.sn-fun-fact{font-size:.85rem}.sn-footer{padding:80px 0}.sn-footer h2{font-size:36px}.sn-btn{padding:16px 40px;font-size:15px}}@media (max-width:480px){.sn-team-hero{padding:100px 15px 30px}.sn-team-hero h1{font-size:28px;margin-bottom:15px;line-height:1.2}.sn-team-hero p{font-size:1rem;line-height:1.5}.sn-values-bridge{padding:50px 0}.sn-value-item h3{font-size:1.1rem}.sn-value-item p{font-size:.9rem}.sn-value-icon{font-size:2rem;margin-bottom:12px}.sn-values-grid{gap:30px}.sn-grid-section{padding:50px 0 60px}.sn-gallery{grid-template-columns:1fr;gap:15px}.sn-person{border-radius:12px}.sn-container{padding:20px 15px}.sn-info-bar{padding:12px}.sn-info-bar h3{font-size:1rem;margin-bottom:3px}.sn-info-bar span{font-size:.7rem;letter-spacing:.3px}.sn-overlay{padding:15px!important}.sn-emoji{font-size:1.8rem;margin-bottom:8px}.sn-fun-title{font-size:1rem;margin-bottom:8px}.sn-fun-fact{font-size:.8rem;line-height:1.3}.sn-footer{padding:60px 0}.sn-footer h2{font-size:24px;margin-bottom:25px}.sn-btn{padding:14px 35px;font-size:14px;width:auto}}
            @media screen and (max-width:480px){.sn-manifesto-section{padding:40px 20px!important}.sn-manifesto-header h2{font-size:22px!important}.sn-list-item{font-size:14px!important}}.sn-linkedin-link{position:absolute;bottom:15px;right:15px;width:25px;height:25px;padding:3px;background:rgba(255,255,255,.9);border-radius:50%;display:flex;align-items:center;justify-content:center;z-index:4;transition:.3s;text-decoration:none;box-shadow:0 2px 8px rgba(0,0,0,.15)}.sn-linkedin-link:hover{background:#0077b5;transform:scale(1.1);box-shadow:0 4px 12px rgba(0,119,181,.4)}.sn-linkedin-link svg{width:18px;height:18px;fill:#0077b5;transition:fill .3s}.sn-linkedin-link:hover svg{fill:#ffffff}@media (max-width:768px){.sn-linkedin-link{width:32px;height:32px;top:12px;right:12px}.sn-linkedin-link svg{width:16px;height:16px}}@media (max-width:480px){.sn-linkedin-link{width:28px;height:28px;top:10px;right:10px}.sn-linkedin-link svg{width:14px;height:14px}}
        </style>
        <div class="sn-team-wrapper">
            <section class="sn-team-hero">
                <div class="sn-container">
                <h1>The Engine Behind Your Growth.</h1>
                <p>Meet the full-time specialists dedicated to scaling your business.<br>No freelancers. Just a unified team under one roof.</p>
                </div>
            </section>
            <section class="sn-values-bridge">
                <div class="sn-container">
                <div class="sn-values-grid">
                    <div class="sn-value-item">
                    <span class="sn-value-icon">🏢</span>
                    <h3>100% In-House</h3>
                    <p>No freelancers. No outsourcing. Every person listed below works full-time from our Chennai HQ.</p>
                    </div>
                    <div class="sn-value-item">
                    <span class="sn-value-icon">🎯</span>
                    <h3>Deep Specialization</h3>
                    <p>We don't hire "generalists." We hire dedicated experts for SEO, Design, and Development.</p>
                    </div>
                    <div class="sn-value-item">
                    <span class="sn-value-icon">❤️</span>
                    <h3>Low Attrition</h3>
                    <p>Our team stays. You won't have to explain your brand to a new account manager every month.</p>
                    </div>
                </div>
                </div>
            </section>
            <section class="sn-grid-section">
                <div class="sn-container">
                <div class="sn-gallery">
                    
                    <div class="sn-person dept-tech">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/surya-salesnanny.webp" alt="Surya">
                    <a href="https://www.linkedin.com/in/surya-prakash-s-g/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Surya LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Surya</h3><span>Tech Lead</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🤖</span><div class="sn-fun-title">The Architect</div><div class="sn-fun-fact">"If it's broken, he fixes it. If it works, he breaks it to make it faster."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/muthukumar-salesnanny.webp" alt="Muthu">
                    <a href="https://www.linkedin.com/in/s-muthu-kumar/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Muthu LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Muthu</h3><span>Strategy Lead</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🧠</span><div class="sn-fun-title">Growth Mind</div><div class="sn-fun-fact">"Can explain complex SEO strategy using only food analogies."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-success">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/jelshiya-salesnanny.webp" alt="Jelshiya">
                    <a href="https://www.linkedin.com/in/jelshiyajose/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Jelshiya LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Jelshiya</h3><span>Business Dev</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🤝</span><div class="sn-fun-title">Client Welcome</div><div class="sn-fun-fact">"Makes onboarding feel like a welcome party, not homework."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/karthik-salesnanny.webp" alt="Karthick">
                    <a href="https://www.linkedin.com/in/karthickdigitalmarketing/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Karthick LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Karthick</h3><span>Ads Specialist</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">💸</span><div class="sn-fun-title">Google Whisperer</div><div class="sn-fun-fact">"Knows the CPC of keywords before Google does."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-creative">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/hari-salesnanny.webp" alt="Hari">
                    <a href="https://www.linkedin.com/in/harivenkadesh/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Hari LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Hari</h3><span>Creative Lead</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🎨</span><div class="sn-fun-title">Pixel Perfect</div><div class="sn-fun-fact">"Will judge a restaurant solely by its menu font choice."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-creative">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/prabince-salesnanny.webp" alt="Prabince">
                    <a href="https://www.linkedin.com/in/prabince-walter-t-28b359169/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Prabince LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Prabince</h3><span>Designer</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">✨</span><div class="sn-fun-title">Visual Wizard</div><div class="sn-fun-fact">"Turns vague client ideas into stunning visuals instantly."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-success">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/radha-salesnanny.webp" alt="Radha">
                    <a href="https://www.linkedin.com/in/p-radha/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Radha LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Radha</h3><span>Business Dev</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">⭐</span><div class="sn-fun-title">Client Champion</div><div class="sn-fun-fact">"Will fight for your ROI like it's her own money."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-success">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/mala-salesnanny.webp" alt="Manimala">
                    <a href="https://www.linkedin.com/in/manimalaoffl/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Manimala LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Manimala</h3><span>Head of Ops</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🎯</span><div class="sn-fun-title">The Organizer</div><div class="sn-fun-fact">"Keeps 17 creative people organized. Deserves a medal daily."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-tech">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/thilakar-salesnanny.webp" alt="Thilakar">
                    <a href="https://www.linkedin.com/in/thilakar-j-b21504255/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Thilakar LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Thilakar</h3><span>Frontend Dev</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">💻</span><div class="sn-fun-title">Code Ninja</div><div class="sn-fun-fact">"Makes websites look good on devices that don't even exist yet."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-tech">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/sahith-salesnanny.webp" alt="Sahith">
                    <a href="https://www.linkedin.com/in/mohamed-sahith-s-7bb66836a/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Sahith LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Sahith</h3><span>Backend Dev</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">⚙️</span><div class="sn-fun-title">Backend Boss</div><div class="sn-fun-fact">"Lives in the server room. Doesn't fear the dark mode."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/sagana-salesnanny.webp" alt="Sagana">
                    <a href="https://www.linkedin.com/in/christy-sagana/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Sagana LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Sagana</h3><span>Email Specialist</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">💌</span><div class="sn-fun-title">Inbox Hero</div><div class="sn-fun-fact">"Writes subject lines that even CEOs can't resist clicking."</div>
                        </div>
                    </div>
                    </div>
                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/fahad-salesnanny.webp" alt="Fahad">
                    <a href="http://linkedin.com/in/fahad-hussain-baig-1b366a26b/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Fahad LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Fahad</h3><span>Digital Exec</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🚀</span><div class="sn-fun-title">The Hustler</div><div class="sn-fun-fact">"Execution machine. Never met a deadline he didn't beat."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/swati-salesnanny.webp" alt="Swathi">
                    <a href="https://www.linkedin.com/in/swathi-g-852044260/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Swathi LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Swathi</h3><span>Social Media</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">📱</span><div class="sn-fun-title">Trend Spotter</div><div class="sn-fun-fact">"Already knows next week's viral TikTok trend."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-creative">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/prasanth-salesnanny.webp" alt="Prasanth">
                    <a href="https://www.linkedin.com/in/prasanth-m-a5324030a/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Prasanth LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Prasanth</h3><span>Content Writer</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">✍️</span><div class="sn-fun-title">Word Smith</div><div class="sn-fun-fact">"Can write 2,000 words on B2B topics and make it fun."</div>
                        </div>
                    </div>
                    </div> 

                    <div class="sn-person dept-creative">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/karthika-salesnanny.webp" alt="Karthika">
                    <a href="https://www.linkedin.com/in/karthika003/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Karthika LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Karthika</h3><span>Content Writer</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">📚</span><div class="sn-fun-title">Storyteller</div><div class="sn-fun-fact">"Crafts brand narratives that actually make people care."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-creative">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/dinesh-salesnanny.webp" alt="Dinesh">
                    <a href="https://www.linkedin.com/in/dinesh-s-6083ba270/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Dinesh LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Dinesh</h3><span>Designer</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🎭</span><div class="sn-fun-title">Motion Master</div><div class="sn-fun-fact">"Brings static images to life. Probably dreams in animation."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-success">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/louis-salesnanny.webp" alt="Louis">
                    <a href="https://www.linkedin.com/in/louis-fernandas-v-37292b280/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Louis LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Louis</h3><span>SEO Specialist</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🛡️</span><div class="sn-fun-title">The Silent Strategist</div><div class="sn-fun-fact">"Working behind the scenes so visibility never slips."</div>
                        </div>
                    </div>
                    </div>

                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/raja-salesnanny.webp" alt="Raja Lingam">
                    <a href="https://www.linkedin.com/in/raja-lingam-a2b090352/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Raja Lingam LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Raja Lingam</h3><span>Graphic Designer</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">⭐</span><div class="sn-fun-title">Design Thinker</div><div class="sn-fun-fact">"Designing with purpose, precision, and passion."</div>
                        </div>
                    </div>
                    </div>
                    <div class="sn-person dept-strategy">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/veera-salesnanny.webp" alt="veera">
                    <a href="https://www.linkedin.com/in/maduraiveeran-g-287a5a27b" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Veera LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Veera</h3><span>SEO analyst</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">⭐</span><div class="sn-fun-title">Search Specialist</div><div class="sn-fun-fact">"Driving sustainable growth through search."</div>
                        </div>
                    </div>
                    </div>
                    <div class="sn-person dept-success">
                    <img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/our-team/paulos-salesnanny.webp" alt="Paulos">
                    <a href="https://www.linkedin.com/in/paulosraja/" class="sn-linkedin-link" target="_blank" rel="noopener noreferrer" aria-label="Paulos LinkedIn Profile">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                            <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                        </svg>
                    </a>
                    <div class="sn-info-bar"><h3>Paulos</h3><span>Sales Head</span></div>
                    <div class="sn-overlay">
                        <div class="sn-overlay-content">
                        <span class="sn-emoji">🦁</span><div class="sn-fun-title">The Rainmaker</div><div class="sn-fun-fact">"Founder. Leader. Still gets too excited when a new lead comes in."</div>
                        </div>
                    </div>
                    </div>

                </div>
                </div>
            </section>
            <section class="sn-manifesto-section">
                <div class="sn-container">
                <div class="sn-manifesto-header">
                    <h2>Above all, we believe in driving growth, building trust, and having fun along the way.</h2>
                </div>
                
                <div class="sn-manifesto-grid">
                    <div class="sn-list-col sn-do-list">
                    <h3>What we do</h3>
                    <div class="sn-list-items">
                        <div class="sn-list-item">World-class digital</div>
                        <div class="sn-list-item">Drive Revenue</div>
                        <div class="sn-list-item">Celebrate Success</div>
                        <div class="sn-list-item">Obsess Over ROI</div>
                        <div class="sn-list-item">Proactive Comms</div>
                        <div class="sn-list-item">Total Transparency</div>
                        <div class="sn-list-item">In-House Experts</div>
                        <div class="sn-list-item">Exceed Expectations</div>
                    </div>
                    </div>

                    <div class="sn-list-col sn-dont-list">
                    <h3>What we don't</h3>
                    <div class="sn-list-items">
                        <div class="sn-list-item">Work Weekends</div>
                        <div class="sn-list-item">Outsource</div>
                        <div class="sn-list-item">Miss Deadlines</div>
                        <div class="sn-list-item">Use Templates</div>
                        <div class="sn-list-item">Hide Fees</div>
                        <div class="sn-list-item">Egos</div>
                        <div class="sn-list-item">Overpromise</div>
                        <div class="sn-list-item">Accept Mediocrity</div>
                    </div>
                    </div>
                </div>
                </div>
            </section>
            <section class="sn-footer">
                <div class="sn-container">
                <h2>Let's build something epic.</h2>
                <a class="sn-btn calendly-trigger">Schedule a Call</a>
                </div>
            </section>
        </div>
        <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>