<html lang="en-US">
   <?php get_custom_head(); ?>
   <body>
      <div class="page-wrapper">
         <?php salesnanny_nav_header(); ?>
		<div class="error-404-container">
		<div id="particles-js"></div>
		<div class="error-404-content">
			<div class="error-404-illustration">
				<img src="<?php echo SN_HTTP_URL; ?>wp-content/themes/assets/logos/logo-404.png" alt="404 illustration" class="floating">
			</div>
			<h1 class="error-404-title">404</h1>
			<h2 class="error-404-subtitle">
				<?php _e('Oops! Page not found', 'generatepress'); ?>
			</h2>
			<div class="error-404-text">
				<p><?php _e('Let us guide you back to where the magic happens.', 'generatepress'); ?></p>
			</div>
		</div>
		</div>
		<div class="error-404-actions">
		<a href="<?php echo SN_HTTP_URL; ?>" class="button button-primary">
		<?php _e('Back to home', 'generatepress'); ?>
		</a>
		</div>
		<style>
			.page-wrapper {
			position: relative;
			min-height: 100vh;
			background: #f8f9fa;
			}
			#particles-js {
			position: absolute;
			width: 100%;
			height: 100%;
			top: 0;
			left: 0;
			z-index: 1;
			}
			.error-404-container {
			position: relative;
			text-align: center;
			max-width: 1200px;
			margin: 80px auto 0px auto;
			min-height: 100vh;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 0px 20px;
			z-index: 2;
			}
			.error-404-content {
			width: 100%;
			padding: 40px;
			border-radius: 20px;
			backdrop-filter: blur(10px);
			}
			/* .error-404-illustration {
			margin-bottom: 30px;
			} */
			.error-404-illustration img {
			max-width: 400px;
			width: 100%;
			height: auto;
			}
			.error-404-title {
			font-size: 120px;
			font-weight: 800;
			color: #c22034;
			margin: 0;
			line-height: 1;
			text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
			}
			.error-404-subtitle {
			font-size: 32px;
			margin: 20px 0;
			color: #1F2937;
			}
			.error-404-text {
			font-size: 18px;
			color: #6B7280;
			}
			.error-404-search {
			max-width: 500px;
			margin: 0 auto 30px;
			}
			.error-404-search .search-form {
			display: flex;
			gap: 10px;
			}
			.error-404-search input[type="search"] {
			flex: 1;
			padding: 12px 20px;
			border: 2px solid #e5e7eb;
			border-radius: 8px;
			font-size: 16px;
			transition: all 0.3s ease;
			}
			.error-404-search input[type="search"]:focus {
			border-color: #c22034;
			outline: none;
			box-shadow: 0 0 0 3px rgba(194, 32, 52, 0.1);
			}
			.error-404-actions {
			display: flex;
			gap: 15px;
			justify-content: center;
			flex-wrap: wrap;
			margin-bottom: 40px;
			}
			.button {
			display: inline-block;
			padding: 12px 24px;
			border-radius: 4px;
			font-size: 16px;
			font-weight: 600;
			text-decoration: none;
			transition: all 0.3s ease;
			cursor: pointer;
			border: none;
			outline: none;
			}
			.button-primary {
			background: #c22034;
			color: #fff !important;
			text-decoration: none !important;
			}
			.button-primary:hover {
			background: #a61b2c;
			transform: translateY(-2px);
			box-shadow: 0 4px 12px rgba(194, 32, 52, 0.2);
			}
			.button-primary:active {
			transform: translateY(0);
			}
			.button-secondary {
			background: #e5e7eb;
			color: #1F2937;
			}
			.button:hover {
			transform: translateY(-2px);
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
			}
			.floating {
			animation: floating 3s ease-in-out infinite;
			}
			@keyframes floating {
			0% { transform: translateY(0px); }
			50% { transform: translateY(-20px); }
			100% { transform: translateY(0px); }
			}
			@media (max-width: 768px) {
			.error-404-content {
			padding: 30px 20px;
			}
			.error-404-title {
			font-size: 80px;
			}
			.error-404-subtitle {
			font-size: 24px;
			}
			.error-404-text {
			font-size: 16px;
			}
			.error-404-illustration img {
			max-width: 300px;
			}
			.error-404-actions {
			flex-direction: column;
			}
			.button {
			width: 100%;
			text-align: center;
			}
			}
			@media (max-width: 480px) {
			.error-404-title {
			font-size: 60px;
			}
			.error-404-subtitle {
			font-size: 20px;
			}
			.error-404-illustration img {
			max-width: 250px;
			}
			.error-404-search .search-form {
			flex-direction: column;
			}
			}
		</style>
		<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				particlesJS('particles-js', {
					particles: {
						number: { value: 80, density: { enable: true, value_area: 800 } },
						color: { value: '#c22034' },
						shape: { type: 'circle' },
						opacity: { value: 0.5, random: false },
						size: { value: 3, random: true },
						line_linked: {
							enable: true,
							distance: 150,
							color: '#c22034',
							opacity: 0.4,
							width: 1
						},
						move: {
							enable: true,
							speed: 2,
							direction: 'none',
							random: false,
							straight: false,
							out_mode: 'out',
							bounce: false
						}
					},
					interactivity: {
						detect_on: 'canvas',
						events: {
							onhover: { enable: true, mode: 'repulse' },
							onclick: { enable: true, mode: 'push' },
							resize: true
						}
					},
					retina_detect: true
				});
			});
		</script>
         <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>