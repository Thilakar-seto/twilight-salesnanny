<?php
   /*
   Template Name: Pricing Plans
   */
   ?>
<html lang="en-US">
   <?php get_custom_head(); ?>
   <?php salesnanny_side_panel(); ?>
   <body>
        <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/pricing.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
        <noscript>
            <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/pricing.noncritical.css"/>
        </noscript>
      <div>
         <style>
                .pricing-container::after,.pricing-container::before{content:"";position:absolute;border-radius:50%;z-index:-1}.pricing-container,.pricing-title{position:relative;text-align:center}.pricing-toggle,body{background-color:var(--neutral-light)}:root{--brand-primary:#c22034;--brand-primary-rgb:194,32,52;--brand-primary-light:rgba(194, 32, 52, 0.1);--brand-primary-medium:rgba(194, 32, 52, 0.2);--brand-navy:#1e2154;--brand-navy-light:rgba(30, 33, 84, 0.08);--brand-navy-medium:rgba(30, 33, 84, 0.15);--accent-gold:#ffd700;--accent-gold-light:rgba(255, 215, 0, 0.15);--accent-teal:#008080;--accent-teal-light:rgba(0, 128, 128, 0.1);--neutral-dark:#333333;--neutral-medium:#666666;--neutral-light:#f8f8f8}body{color:var(--neutral-dark)}.pricing-container{max-width:1400px;width:100%;margin:80px auto;padding:40px 20px;overflow:hidden;background:#fdf3f3}.pricing-container::before{top:-50px;right:-50px;width:200px;display:none;height:200px;background-color:var(--brand-primary-light)}.pricing-container::after{bottom:-50px;left:-50px;display:none;width:180px;height:180px;background-color:var(--brand-navy-light)}.pricing-title{margin-bottom:50px;font-size:2.5rem;font-weight:800;display:inline-block;background:padding-box text #1e2154;-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-fill-color:transparent;width:100%}.pricing-title::after{content:"";position:absolute;bottom:-15px;left:50%;display:none;transform:translateX(-50%);width:100px;height:4px;background:linear-gradient(to right,#1e2154,#c22034);border-radius:2px}.pricing-toggle{display:flex;align-items:center;justify-content:center;gap:15px;margin:50px auto;padding:10px;border-radius:50px;box-shadow:0 4px 15px rgba(0,0,0,.05);width:fit-content}.toggle-text{color:var(--neutral-medium);transition:.3s;padding:8px 15px;border-radius:20px;font-weight:500}.slider,.slider:before{transition:.4s;position:absolute}.toggle-text.active{color:#fff;background-color:var(--brand-primary);font-weight:700}.switch{position:relative;display:inline-block;width:60px;height:30px}.switch input{opacity:0;width:0;height:0}.slider{cursor:pointer;top:0;left:0;right:0;bottom:0;background:linear-gradient(to right,var(--brand-primary-light),var(--brand-navy-light));border-radius:30px}.slider:before{content:"";height:24px;width:24px;left:3px;bottom:3px;background-color:#fff;border-radius:50%;box-shadow:0 2px 5px rgba(0,0,0,.2)}.pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:30px;max-width:1000px;margin:0 auto;perspective:1000px}.original-price,.pricing-card h3{display:inline-block;position:relative}.pricing-card{background:#fff;padding:40px 30px;border-radius:15px;text-align:center;box-shadow:0 10px 30px rgba(0,0,0,.05);transition:.4s;position:relative;overflow:hidden;transform-style:preserve-3d;transform:translateZ(0);border-top:5px solid transparent}.pricing-card:first-child{border-top-color:var(--brand-primary)}.pricing-card:nth-child(2){border-top-color:var(--brand-navy)}.pricing-card::before{content:"";position:absolute;top:0;right:0;height:100%;width:15px;background:linear-gradient(to bottom,var(--brand-primary),transparent);opacity:0;transition:opacity .3s}.cta-button::before,.original-price::after,.pricing-card h3::after{width:100%;content:"";position:absolute}.pricing-card h3{color:var(--brand-navy);font-weight:600;margin-bottom:25px;padding-bottom:10px}.pricing-card h3::after{bottom:0;left:0;height:2px;background:linear-gradient(to right,transparent,var(--brand-primary),transparent)}.price-wrapper,.price-wrapper-sme{margin:36px 0;position:relative}.original-price{text-decoration:line-through;color:var(--neutral-medium);margin-right:10px;font-size:20px}.original-price::after{left:0;top:50%;height:2px;background-color:var(--brand-primary);transform:rotate(-10deg)}.price{font-size:52px;font-weight:600;color:#c22034;display:block;height:100px}.billing-period,.price-period{color:var(--neutral-medium);font-size:15px}.billing-period{background-color:var(--brand-primary-light);display:inline-block;padding:5px 15px;border-radius:20px;margin-top:5px}.requirement{background-color:var(--brand-navy-light);padding:12px 15px;border-radius:8px;margin:25px 0;font-weight:500;border-left:3px solid var(--brand-navy)}.cta-button,.support-button{padding:15px 30px;transition:.3s;text-decoration:none;display:inline-block}.benefits-title,.cta-button,.highlight,.support-button{font-weight:600}.cta-button{color:#fff;margin-top:20px;position:relative;overflow:hidden;background-color:#c22034;border-radius:4px}.cta-button::before{top:0;left:-100%;height:100%;background:linear-gradient(to right,rgba(255,255,255,.1),rgba(255,255,255,.2),rgba(255,255,255,.1));transition:.6s}.support-plans{margin-top:50px}.support-button{background-color:var(--brand-navy-light);color:var(--brand-navy);border-radius:50px;border:2px solid var(--brand-navy)}.disclaimer,.footnote{color:var(--neutral-medium);margin-top:20px;font-size:14px}.faq-link{color:var(--brand-primary);text-decoration:none;border-bottom:1px dotted var(--brand-primary);transition:.2s}.benefits-section{max-width:1000px;margin:0 auto;padding:60px 30px;text-align:center;position:relative;border-radius:20px}.benefits-section::before{content:"";position:absolute;width:150px;height:150px;display:none;background-color:var(--brand-primary-light);top:-75px;right:10%;border-radius:50%;z-index:-1}.benefits-title{font-size:42px;margin-bottom:20px;color:var(--brand-navy);position:relative;display:inline-block;padding-bottom:15px}.benefits-title::after{content:"";position:absolute;bottom:0;left:50%;transform:translateX(-50%);width:100%;height:3px;background:linear-gradient(to right,var(--brand-primary),var(--brand-navy))}.benefits-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:30px;margin-bottom:40px}.benefit-item{display:flex;align-items:flex-start;gap:15px;margin-bottom:25px;text-align:left;transition:.3s;background-color:#fff;padding:20px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,.03);position:relative;overflow:hidden}.benefit-item::before{content:"";position:absolute;top:0;left:0;width:5px;height:100%;background:linear-gradient(to bottom,var(--brand-primary),var(--brand-navy));border-top-left-radius:8px;border-bottom-left-radius:8px}.checkmark{color:var(--brand-primary);font-size:24px;flex-shrink:0;display:flex;align-items:center;justify-content:center;width:40px;height:40px;background-color:var(--brand-primary-light);border-radius:50%}.concierge-link,.faq-button,.plan-details-link{display:inline-block;text-decoration:none;transition:.3s}.benefit-item p{font-size:16px;line-height:1.5;margin:0;color:var(--neutral-dark)}.plan-details{margin:50px 0}.plan-details-link{color:var(--brand-navy);font-size:18px;padding:12px 30px;border-radius:50px;border:2px solid var(--brand-navy);background-color:transparent}.concierge-link,.highlight{color:var(--brand-primary)}.benefits-description,.concierge-section{max-width:900px;border-radius:15px;position:relative}.benefits-description{margin:60px auto;font-size:18px;line-height:1.6;padding:30px;background-color:#fff;box-shadow:0 5px 25px rgba(0,0,0,.03)}.benefits-description::before{content:"";position:absolute;top:10px;left:20px;font-size:100px;color:var(--brand-primary-light);font-family:Georgia,serif;line-height:1}.concierge-section{background:linear-gradient(135deg,var(--brand-navy-light),var(--brand-primary-light));padding:50px 30px;overflow:hidden}.concierge-section::after,.concierge-section::before{content:"";position:absolute;width:200px;height:200px;border-radius:50%}.concierge-section::before{top:-100px;right:-100px;background-color:rgba(var(--brand-primary-rgb),.1)}.concierge-section::after{bottom:-100px;left:-100px;background-color:rgba(30,33,84,.1)}.concierge-section h2{font-size:32px;line-height:1.4;margin:0;color:var(--neutral-dark);position:relative;z-index:2}.concierge-link{font-weight:700;border-bottom:2px solid transparent}.faq-section{margin:50px 0 70px}.faq-button{color:var(--brand-navy);font-size:18px;background-color:#fff;padding:15px 40px;border-radius:50px;box-shadow:0 5px 20px rgba(0,0,0,.05);border:2px solid var(--brand-navy)}@media (max-width:992px){.benefits-grid{gap:20px}.benefits-section::before,.pricing-container::after,.pricing-container::before{display:none}}@media (max-width:768px){.benefits-grid,.pricing-grid{grid-template-columns:1fr}.pricing-grid{max-width:500px;margin-left:auto;margin-right:auto}.pricing-title{font-size:2rem}.pricing-title::after{width:80px}.price{font-size:42px}.benefits-title{font-size:32px}.benefit-item p{font-size:16px}.benefits-description{font-size:16px;padding:25px 20px 20px}.benefits-description::before{font-size:70px;top:5px;left:10px}.concierge-section h2{font-size:24px}.concierge-section{padding:30px 20px}}@media (max-width:480px){.pricing-container{padding:30px 15px}.pricing-title{font-size:28px}.pricing-toggle{flex-direction:column;gap:10px;padding:10px}.toggle-text{width:100%}.benefit-item{padding:15px}.checkmark{width:30px;height:30px;font-size:18px}.price{height:150px}.cta-button,.faq-button,.plan-details-link,.support-button{padding:12px 20px;font-size:15px;width:100%;box-sizing:border-box}}.back-to-top{position:fixed;bottom:100px;right:30px;width:50px;height:50px;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;z-index:99;box-shadow:0 4px 10px rgb(0 0 0 / .15);background:#c22034;text-decoration:none;transition:.3s}.back-to-top.visible{opacity:1;pointer-events:auto}.yearly-plan-btn{background:linear-gradient(135deg,#1e2154,#c22034);color:#fff;border:none;padding:12px 30px;border-radius:8px;font-size:18px;font-weight:600;cursor:pointer;transition:.3s;box-shadow:0 4px 15px rgba(0,0,0,.1);margin-bottom:20px}.yearly-plan-btn:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,.15);background:linear-gradient(135deg,#c22034,#1e2154)}
         </style>
         <?php salesnanny_nav_header(); ?>
         <div class="pricing-container">
            <h1 class="pricing-title"> Simplify Your Business: One Team, One Price</h1>
            <div class="pricing-grid">
               <!-- All Employee Pricing -->
               <div class="pricing-card">
                  <h3>SME Plan</h3>
                  <div class="price-wrapper-sme">
                     <!-- <span class="original-price">₹1800</span> -->
                     <span class="price">$2500<span class="price-period" style="color:rgb(57, 57, 57)">/month</span></span>
                  </div>
                  <!-- <p class="billing-period">billed annually</p> -->
                  <p class="requirement">Your Complete Marketing Team to Fuel Business Growth.</p>
                  <a  class="calendly-trigger cta-button">Get Your Team</a>
               </div>
               <!-- Flexible User Pricing -->
               <div class="pricing-card">
                  <h3>Enterprise Plan</h3>
                  <div class="price-wrapper">
                     <span class="price" style="font-size: 14px; line-height: 1.4; color: #000; text-align: justify;">The Enterprise plan is designed for larger organizations with more complex marketing needs. It offers a fully customized approach and provides access to a dedicated team of experts tailored to your specific requirements. Contact sales to discuss pricing and create a plan that aligns with your business goals.</span>
                  </div>
                  <p class="requirement">Accelerate Your Growth with a Fully Customized Marketing Solution.</p>
                  <a class="calendly-trigger cta-button">Contact Sales</a>
               </div>
            </div>

            <!-- Calendly Popup -->
            <div class="calendly-popup-overlay" id="calendly-popup">
               <div class="calendly-popup-content">
                  <button class="calendly-popup-close-btn" id="calendly-popup-close">&times;</button>
                  <div id="calendly-inline-widget" style="min-width:320px;height:100%;"></div>
               </div>
            </div>


            <style>
               .cta-button {
                  display: inline-block;
                  padding: 12px 24px;
                  background-color: #c22034;
                  color: #fff;
                  text-decoration: none;
                  border-radius: 4px;
                  cursor: pointer;
               }

               .calendly-popup-overlay {
                  position: fixed;
                  top: 0;
                  left: 0;
                  width: 100%;
                  height: 100%;
                  background-color: rgba(0, 0, 0, 0.6);
                  display: none;
                  justify-content: center;
                  align-items: center;
                  z-index: 9999;
               }

               .calendly-popup-content {
                  position: relative;
                  width: 90%;
                  max-width: 600px;
                  height: 80vh;
                  background-color: #fff;
                  border-radius: 10px;
                  overflow: hidden;
               }

               .calendly-popup-close-btn {
                  position: absolute;
                  top: 10px;
                  right: 15px;
                  background: #c22034;
                  color: white;
                  border: none;
                  border-radius: 50%;
                  width: 30px;
                  height: 30px;
                  font-size: 16px;
                  cursor: pointer;
                  z-index: 10000;
               }

               @media (max-width: 600px) {
                  .calendly-popup-content {
                  width: 95%;
                  height: 90vh;
                  }
               }
            </style>
            <!-- Calendly script -->
            <script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" async></script>
            <script>
                document.addEventListener("DOMContentLoaded", function () {
                const trigger = document.getElementById("calendly-trigger");
                const popup = document.getElementById("calendly-popup");
                const closeBtn = document.getElementById("calendly-popup-close");
                const widgetContainer = document.getElementById("calendly-inline-widget");

                trigger.addEventListener("click", function (e) {
                e.preventDefault();
                popup.style.display = "flex";

                Calendly.initInlineWidget({
                    url: 'https://calendly.com/surya-salesnanny/30min?hide_landing_page_details=1&hide_gdpr_banner=1',
                    parentElement: widgetContainer,
                    prefill: {},
                    utm: {}
                });
                });

                closeBtn.addEventListener("click", function () {
                popup.style.display = "none";
                widgetContainer.innerHTML = '';
                });
                });
            </script>

         </div>
         <div class="benefits-section">
            <h2 class="benefits-title">Your All-In-One Business Solution</h2>
            <div class="benefits-grid">
               <div class="benefits-column">
                  <div class="benefit-item">
                     <span class="checkmark">✓</span>
                     <p>Complete Team Integration</p>
                  </div>
                  <div class="benefit-item">
                     <span class="checkmark">✓</span>
                     <p> Customizable Service Packages</p>
                  </div>
                  <div class="benefit-item">
                     <span class="checkmark">✓</span>
                     <p>On-the-Go Project Management</p>
                  </div>
               </div>
               <div class="benefits-column">
                  <div class="benefit-item">
                     <span class="checkmark">✓</span>
                     <p>Unified, Simplified Billing</p>
                  </div>
                  <div class="benefit-item">
                     <span class="checkmark">✓</span>
                     <p>Platform for Scalable Operations</p>
                  </div>
                  <div class="benefit-item">
                     <span class="checkmark">✓</span>
                     <p>Efficient Project Management Tools</p>
                  </div>
               </div>
            </div>
            <div class="benefits-description">
               <p>Optimize your business workflow with our integrated team offering. One comprehensive team, one straightforward price, one simple invoice. This efficient approach to team staffing providing a broad range of expertise for a single affordable fee is fundamental to our service design.</p>
            </div>
            <div class="concierge-section">
               <h2>Considering outsourcing but worried about managing multiple vendors? Our all-in-one team simplifies everything.</h2>
            </div>
         </div>
         <a class="back-to-top">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M18 15l-6-6-6 6"/>
               </svg>
         </a>
         <script>
               // Back to top button functionality
               document.addEventListener('DOMContentLoaded', function() {
                  const backToTopButton = document.querySelector('.back-to-top');
                  
                  // Show button when user scrolls down 300px
                  window.addEventListener('scroll', function() {
                     if (window.pageYOffset > 300) {
                           backToTopButton.classList.add('visible');
                     } else {
                           backToTopButton.classList.remove('visible');
                     }
                  });
                  
                  // Smooth scroll to top when button is clicked
                  backToTopButton.addEventListener('click', function(e) {
                     e.preventDefault();
                     window.scrollTo({
                           top: 0,
                           behavior: 'smooth'
                     });
                  });
               });
         </script>
         <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>