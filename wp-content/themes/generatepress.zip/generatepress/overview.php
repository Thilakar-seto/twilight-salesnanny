<?php
/*
Template Name: Overview
*/
?>

<html>
<body>
    <div>
        <?php salesnanny_nav_header(); ?>
        <section class="sn-hero-section">
            <div class="sn-container">
                <div class="sn-hero-content">
                    <h1 class="sn-hero-title">
                        Meet the Operating System<br>
                        for <span class="sn-highlight">Business</span>
                    </h1>
                    <p class="sn-hero-description">
                        Our sophisticated approach to business software gives you one integrated and customizable system to work smarter and grow faster.
                    </p>
                    <a href="#" class="sn-cta-button">ACCESS YOUR APPS</a>
                </div>
                <div class="sn-hero-image">
                    <div class="sn-rocket-animation"></div>
                </div>
            </div>
        </section>

        <style>
            .sn-hero-section {
                padding: 80px 0;
                background-color: #fbe7b7;
                overflow: hidden;
            }
            
            .sn-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 20px;
                display: flex;
                align-items: center;
                gap: 40px;
            }
            
            .sn-hero-content {
                flex: 1;
            }
            
            .sn-hero-title {
                font-size: 3.5rem;
                line-height: 1.2;
                margin-bottom: 24px;
            }
            
            .sn-highlight {
                color: #000;
                position: relative;
                display: inline-block;
                z-index: 1;
            }
            
            .sn-highlight:before {
                content: '';
                position: absolute;
                top: -5px;
                left: -6%;
                width: 0;
                height: 110%;
                background-image: url('https://www.zohowebstatic.com/sites/zweb/images/one/zhead-bg.svg');
                background-repeat: no-repeat;
                background-position: left;
                z-index: -1;
                animation: sn-zdraw 2.4s cubic-bezier(0.23, 1, 0.32, 1) forwards;
                animation-delay: 1.2s;
            }
            
            @keyframes sn-zdraw {
                from { width: 0; }
                to { width: 112%; }
            }
            
            .sn-hero-description {
                font-size: 1.25rem;
                line-height: 1.6;
                margin-bottom: 32px;
                max-width: 600px;
            }
            
            .sn-cta-button {
                display: inline-block;
                background-color: #e42527;
                color: white;
                padding: 16px 32px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: bold;
                transition: background-color 0.3s;
            }
            
            .sn-cta-button:hover {
                background-color: #C82333;
            }
            
            .sn-hero-image {
                flex: 1;
                max-width: 445px;
                margin-top: 100px;
                height: 550px;
                background: #ffd200;
            }
            
            .sn-rocket-animation {
                width: 100%;
                height: 500px;
                background: url('https://www.zohowebstatic.com/sites/zweb/images/one/zoho-one-platform-sprint-ani.png') no-repeat;
                animation: sn-tilegrow 1s steps(9) 1.2s forwards;
            }
            
            @keyframes sn-tilegrow {
                from { background-position: 0 0; }
                to { background-position: 100% 0; }
            }
            
            @media (max-width: 968px) {
                .sn-container {
                    flex-direction: column;
                    text-align: center;
                }
                
                .sn-hero-title {
                    font-size: 2.5rem;
                }
                
                .sn-hero-image {
                    max-width: 100%;
                }
            }
        </style>

        <section class="sn-what-is-it">
            <div class="sn-container-main">
                <h2 class="sn-section-title">Sounds cool. But what is it?</h2>
                <h3 class="sn-section-subtitle">Integrated apps to improve<br>business processes</h3>
                <p class="sn-section-description">
                    Our integrated, online applications help you manage and automate business processes across your organization. Choose apps that address your pain points, then deploy them to your employees. Every app comes with a mobile version, so you can work wherever you go.
                </p>
                <div class="sn-action-buttons">
                    <a href="#" class="sn-link-button">Explore web apps</a>
                    <a href="#" class="sn-link-button">Explore mobile apps</a>
                </div>
                <div class="sn-devices-showcase">
                    <div class="sn-laptop">
                        <img src="https://www.zohowebstatic.com/sites/zweb/images/one/zoho-platform-improve-business-processes.jpg" alt="Web apps interface">
                    </div>
                    <!-- <div class="sn-mobile">
                        <img src="path-to-your-mobile-image.png" alt="Mobile apps interface">
                    </div> -->
                </div>
            </div>
        </section>

        <style>
            .sn-what-is-it {
                padding: 100px 0;
                background-color: #fff;
                text-align: center;
            }
            .sn-container-main {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 20px;
            }
            .sn-section-title {
                font-size: 2.5rem;
                margin-bottom: 24px;
            }

            .sn-section-subtitle {
                font-size: 3rem;
                margin-bottom: 32px;
            }

            .sn-section-description {
                max-width: 800px;
                font-size: 1.25rem;
                line-height: 1.6;
                color: #555;
            }

            .sn-action-buttons {
                margin-bottom: 60px;
            }

            .sn-link-button {
                display: inline-block;
                color: #0066cc;
                text-decoration: none;
                font-weight: 500;
                margin: 0 16px;
                font-size: 1.1rem;
            }

            .sn-link-button:hover {
                text-decoration: underline;
            }

            .sn-devices-showcase {
                position: relative;
                max-width: 1200px;
                margin: 0 auto;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .sn-laptop {
                width: 100%;
                max-width: 800px;
                z-index: 1;
            }

            .sn-mobile {
                position: absolute;
                right: 0;
                width: 300px;
                transform: translateX(20%);
                z-index: 2;
            }

            .sn-laptop img,
            .sn-mobile img {
                width: 100%;
                height: auto;
                display: block;
            }

            @media (max-width: 1024px) {
                .sn-devices-showcase {
                    flex-direction: column;
                    padding: 0 20px;
                }

                .sn-mobile {
                    position: relative;
                    transform: translateX(0) translateY(-60px);
                    width: 250px;
                }

                .sn-section-subtitle {
                    font-size: 2.5rem;
                }
            }

            @media (max-width: 768px) {
                .sn-what-is-it {
                    padding: 60px 0;
                }

                .sn-section-title {
                    font-size: 2rem;
                }

                .sn-section-subtitle {
                    font-size: 2rem;
                }

                .sn-section-description {
                    font-size: 1.1rem;
                    padding: 0 20px;
                }

                .sn-action-buttons {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                    align-items: center;
                }

                .sn-mobile {
                    width: 200px;
                    transform: translateY(-40px);
                }
            }
        </style>

<section class="sn-smart-services">
    <div class="sn-container-main">
        <h2 class="sn-section-title">Smart services for ultimate productivity</h2>
        <p class="sn-section-description">
            Our broad set of integrated apps serve as the basis for additional services that bring even more value to your organization.
        </p>
        
        <div class="sn-services-grid">
            <div class="sn-service-item">
                <div class="sn-service-icon">
                    <svg viewBox="0 0 24 24" width="48" height="48">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                        <path d="M13 7h-2v5.414l3.293 3.293 1.414-1.414L13 11.586z"/>
                    </svg>
                </div>
                <h3>Work smarter with Zia,<br>the Zoho Intelligent Assistant.</h3>
                <a href="#" class="sn-service-link">Explore AI</a>
            </div>
            
            <div class="sn-service-item">
                <div class="sn-service-icon">
                    <svg viewBox="0 0 24 24" width="48" height="48">
                        <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/>
                    </svg>
                </div>
                <h3>Get insights across your organization with out-of-the-box dashboards.</h3>
                <a href="#" class="sn-service-link">Explore Business Intelligence</a>
            </div>
            
            <div class="sn-service-item">
                <div class="sn-service-icon">
                    <svg viewBox="0 0 24 24" width="48" height="48">
                        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                    </svg>
                </div>
                <h3>Find everything faster with one search for all your business data.</h3>
                <a href="#" class="sn-service-link">Explore Zia Search</a>
            </div>
            
            <div class="sn-service-item">
                <div class="sn-service-icon">
                    <svg viewBox="0 0 24 24" width="48" height="48">
                        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm-5 14H4v-4h11v4zm0-5H4V9h11v4zm5 5h-4V9h4v9z"/>
                    </svg>
                </div>
                <h3>Simplify user provisioning, app deployment, and org-wide security policies.</h3>
                <a href="#" class="sn-service-link">Learn More</a>
            </div>
        </div>
    </div>
</section>

<style>
    .sn-smart-services {
        padding: 100px 0;
        background-color: #D6EDFF;
    }

    .sn-services-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 40px;
        margin-top: 60px;
    }

    .sn-service-item {
        padding: 32px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease;
    }

    .sn-service-item:hover {
        transform: translateY(-5px);
    }

    .sn-service-icon {
        margin-bottom: 24px;
    }

    .sn-service-icon svg {
        fill: #0066cc;
    }

    .sn-service-item h3 {
        font-size: 1.5rem;
        margin-bottom: 20px;
        line-height: 1.3;
    }

    .sn-service-link {
        color: #0066cc;
        text-decoration: none;
        font-weight: 500;
        display: inline-block;
        margin-top: 16px;
    }

    .sn-service-link:hover {
        text-decoration: underline;
    }

    @media (max-width: 1024px) {
        .sn-services-grid {
            gap: 24px;
        }

        .sn-service-item h3 {
            font-size: 1.3rem;
        }
    }

    @media (max-width: 768px) {
        .sn-smart-services {
            padding: 60px 0;
        }

        .sn-services-grid {
            grid-template-columns: 1fr;
            gap: 24px;
        }

        .sn-service-item {
            padding: 24px;
        }
    }
</style>

<section class="sn-tools-section">
    <div class="sn-container-main">
        <div class="sn-tools-content">
            <h2 class="sn-section-title">Tools to align our software with your business</h2>
            <p class="sn-section-description">
                Zoho One includes a powerful toolkit to customize, extend, and integrate our software to fit your organization.
            </p>

            <div class="sn-tools-list">
                <div class="sn-tool-item">
                    <h3>Integrate Apps</h3>
                    <p>Create custom integrations between Zoho and third party-apps.</p>
                    <a href="#" class="sn-tool-link">Explore Zoho Flow</a>
                </div>

                <div class="sn-tool-item">
                    <h3>Extend Apps</h3>
                    <p>Extend Zoho apps with custom functions.</p>
                    <a href="#" class="sn-tool-link">Learn more</a>
                </div>

                <div class="sn-tool-item">
                    <h3>Create Apps</h3>
                    <p>Create custom, low-code apps for unique processes.</p>
                    <a href="#" class="sn-tool-link">Explore Zoho Creator</a>
                </div>
            </div>
        </div>

        <div class="sn-tools-visual">
            <img src="https://www.zohowebstatic.com/sites/zweb/images/one/powerful-customization-tools.webp" 
                 alt="Customization Tools" 
                 class="sn-tools-image">
            <div class="sn-orbit-container">
                <div class="sn-orbit-circle"></div>
                <div class="sn-orbit-icons">
                    <span class="orbit-icon icon-1">⚙️</span>
                    <span class="orbit-icon icon-2">&lt;/&gt;</span>
                    <span class="orbit-icon icon-3">📱</span>
                    <span class="orbit-icon icon-4">🔍</span>
                    <span class="orbit-icon icon-5">📊</span>
                    <span class="orbit-icon icon-6">💬</span>
                    <span class="orbit-icon icon-7">📧</span>
                    <span class="orbit-icon icon-8">🔄</span>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .sn-tools-section {
        padding: 100px 0;
        background-color: #fff;
        overflow: hidden;
    }

    .sn-tools-section .sn-container-main {
        display: flex;
        align-items: center;
        gap: 60px;
    }

    .sn-tools-content {
        flex: 1;
        max-width: 600px;
    }

    .sn-tools-list {
        margin-top: 48px;
    }

    .sn-tool-item {
        margin-bottom: 40px;
    }

    .sn-tool-item h3 {
        font-size: 1.75rem;
        margin-bottom: 16px;
    }

    .sn-tool-item p {
        font-size: 1.1rem;
        color: #555;
        margin-bottom: 12px;
        line-height: 1.5;
    }

    .sn-tool-link {
        color: #0066cc;
        text-decoration: none;
        font-weight: 500;
    }

    .sn-tool-link:hover {
        text-decoration: underline;
    }

    .sn-tools-visual {
        flex: 1;
        max-width: 500px;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .sn-tools-image {
        position: absolute;
        width: 100%;
        height: auto;
        max-width: 500px;
        z-index: 0;
    }

    @media (max-width: 1024px) {
        .sn-tools-image {
            max-width: 400px;
        }
    }

    @media (max-width: 768px) {
        .sn-tools-image {
            max-width: 300px;
        }
    }

    .sn-orbit-container {
        position: relative;
        width: 300px;
        height: 300px;
        margin: 0 auto;
        z-index: 1;
    }

    .sn-orbit-circle {
        position: absolute;
        width: 100%;
        height: 100%;
        border: 2px solid rgba(255, 255, 255, 0.2);
        border-radius: 50%;
    }

    .sn-orbit-icons {
        position: absolute;
        width: 100%;
        height: 100%;
        animation: orbit 20s linear infinite;
    }

    .orbit-icon {
        position: absolute;
        width: 40px;
        height: 40px;
        background: white;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        font-size: 20px;
        transform-origin: center;
    }

    .icon-1 { transform: translate(150px, 0) rotate(0deg); }
    .icon-2 { transform: translate(251px, 345px) rotate(-45deg); }
    .icon-3 { transform: translate(0, 150px) rotate(-90deg); }
    .icon-4 { transform: translate(298px, 171px) rotate(-135deg); }
    .icon-5 { transform: translate(-43px, 255px) rotate(-180deg); }
    .icon-6 { transform: translate(180px, 259px) rotate(-225deg); }
    .icon-7 { transform: translate(0, -36px) rotate(-270deg); }
    .icon-8 { transform: translate(106px, -117px) rotate(-315deg); }

    @keyframes orbit {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(360deg);
        }
    }

    @keyframes counter-orbit {
        from {
            transform: rotate(0deg);
        }
        to {
            transform: rotate(-360deg);
        }
    }

    @media (max-width: 1024px) {
        .sn-tools-section .sn-container-main {
            flex-direction: column;
            align-items: center;
        }

        .sn-tools-content {
            max-width: 100%;
            text-align: center;
        }

        .sn-tools-visual {
            max-width: 100%;
            margin-top: 40px;
        }

        .sn-orbit-container {
            width: 300px;
            height: 300px;
        }
    }

    @media (max-width: 768px) {
        .sn-tools-section {
            padding: 60px 0;
        }

        .sn-tool-item h3 {
            font-size: 1.5rem;
        }

        .sn-orbit-container {
            width: 250px;
            height: 250px;
        }

        .icon-1 { transform: translate(108px, 0); }
        .icon-2 { transform: translate(76px, 76px); }
        .icon-3 { transform: translate(0, 108px); }
        .icon-4 { transform: translate(-76px, 76px); }
        .icon-5 { transform: translate(-108px, 0); }
        .icon-6 { transform: translate(-76px, -76px); }
        .icon-7 { transform: translate(0, -108px); }
        .icon-8 { transform: translate(76px, -76px); }
    }
</style>

<section class="sn-categories">
    <div class="sn-container-main">
        <h2 class="sn-section-title">See What Else You Can Do with Zoho One</h2>
        <div class="sn-categories-grid">
            <div class="sn-category-item">
                <div class="sn-category-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40">
                        <path d="M13.13 22.19l-1.63-3.83c-.24-.56-.15-1.21.24-1.68l3.82-4.56c.39-.47.98-.74 1.58-.74h4.36c.38 0 .73.21.89.55l1.63 3.83c.24.56.15 1.21-.24 1.68l-3.82 4.56c-.39.47-.98.74-1.58.74h-4.36c-.38 0-.73-.21-.89-.55zM3 13.5h8v8H3z"/>
                    </svg>
                </div>
                <span>Sales</span>
            </div>
            <div class="sn-category-item">
                <div class="sn-category-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40">
                        <path d="M20 4v16H4V4h16m2-2H2v20h20V2zM12 6h-2v4H6v2h4v4h2v-4h4v-2h-4V6z"/>
                    </svg>
                </div>
                <span>Marketing</span>
            </div>
            <div class="sn-category-item">
                <div class="sn-category-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>
                    </svg>
                </div>
                <span>Support</span>
            </div>
            <div class="sn-category-item">
                <div class="sn-category-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40">
                        <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
                    </svg>
                </div>
                <span>HR</span>
            </div>
            <div class="sn-category-item">
                <div class="sn-category-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40">
                        <path d="M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/>
                    </svg>
                </div>
                <span>Accounting</span>
            </div>
            <div class="sn-category-item">
                <div class="sn-category-icon">
                    <svg viewBox="0 0 24 24" width="40" height="40">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/>
                    </svg>
                </div>
                <span>Operations</span>
            </div>
        </div>
    </div>
</section>

<style>
    .sn-categories {
        padding: 80px 0;
        background-color: #fff;
    }

    .sn-categories .sn-section-title {
        text-align: center;
        margin-bottom: 60px;
    }

    .sn-categories-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 24px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .sn-category-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        padding: 24px;
        border-radius: 12px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        cursor: pointer;
    }

    .sn-category-item:nth-child(1) { background-color: #C6EAFB; }
    .sn-category-item:nth-child(2) { background-color: #FEC3B7; }
    .sn-category-item:nth-child(3) { background-color: #C6F1DF; }
    .sn-category-item:nth-child(4) { background-color: #F9CBD8; }
    .sn-category-item:nth-child(5) { background-color: #C6F0F1; }
    .sn-category-item:nth-child(6) { background-color: #FBE7B8; }

    .sn-category-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    .sn-category-icon {
        margin-bottom: 16px;
    }

    .sn-category-icon svg {
        fill: #333;
    }

    .sn-category-item span {
        font-size: 1.1rem;
        font-weight: 500;
        color: #333;
    }

    @media (max-width: 1024px) {
        .sn-categories-grid {
            grid-template-columns: repeat(3, 1fr);
            padding: 0 20px;
        }
    }

    @media (max-width: 768px) {
        .sn-categories {
            padding: 60px 0;
        }

        .sn-categories-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }

        .sn-category-item {
            padding: 16px;
        }
    }

    @media (max-width: 480px) {
        .sn-categories-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>