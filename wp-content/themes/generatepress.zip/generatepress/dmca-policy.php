<?php
/*
Template Name: DMCA Policy
*/
?>
<html>
<?php get_custom_head(); ?>
<body>
    <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
    <noscript>
        <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/policy.noncritical.css"/>
    </noscript>
    <div>
        <style>
            body{margin:0;padding:0;font-family:"Lexend Deca",-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif!important;color:#333;line-height:1.6;background-color:#f8f9fa;overflow-x:hidden}.terms-container{width:100%;margin:80px auto 0;padding:0}.terms-header{position:relative;background:linear-gradient(135deg,#c22034,#1e2154);padding:6rem 2rem;text-align:center;margin-bottom:0;box-shadow:0 10px 25px rgba(0,0,0,.15);display:flex;flex-direction:column;justify-content:center;align-items:center;min-height:350px;overflow:hidden}.terms-header::before{content:'';position:absolute;top:0;left:0;width:100%;height:100%;background-image:url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.05' fill-rule='evenodd'/%3E%3C/svg%3E");opacity:.6}.terms-header h1{color:#fff;margin-bottom:1.5rem;font-size:3.5rem;font-weight:700;text-shadow:0 2px 4px rgba(0,0,0,.2);position:relative}.terms-header p{color:#fff;font-size:1.2rem;max-width:700px;margin:0 auto;opacity:.9;position:relative;line-height:1.6}.terms-content-wrapper{position:relative;margin-top:-50px;padding:0 20px;max-width:1200px;margin-left:auto;margin-right:auto}.terms-content{background-color:#fff;padding:3rem;border-radius:12px;margin:0 auto 4rem;box-shadow:0 15px 35px rgba(0,0,0,.1);position:relative;border-top:5px solid #c22034}.terms-content h2{color:#1e2154;font-size:1.8rem;font-weight:700;margin:2.5rem 0 1.5rem;padding-bottom:.5rem;border-bottom:2px solid rgba(194,32,52,.2)}.terms-content h2:first-child{margin-top:0}.terms-content p{color:#444;font-size:1.05rem;line-height:1.8;margin:1.5rem 0}.terms-content ol,.terms-content ul{margin:1.5rem 0 1.5rem 1rem;padding-left:1.5rem}.terms-content ol{list-style-type:decimal;counter-reset:item}.terms-content ol li{margin:1rem 0;color:#444;line-height:1.7}.terms-cta{text-align:center;margin:3rem 0 2rem;padding:2rem;background:rgba(194,32,52,.05);border-radius:8px;border-left:3px solid #c22034}.back-to-top,.terms-cta-button{background:#c22034;text-decoration:none;transition:.3s}.terms-cta p{font-size:1.1rem;margin-bottom:1.5rem}.terms-cta-button{display:inline-block;padding:.8rem 2rem;color:#fff;font-weight:600;border-radius:50px}.last-updated{display:block;text-align:right;margin-top:2rem;font-size:.9rem;color:#777;font-style:italic}.back-to-top{position:fixed;bottom:100px;right:30px;width:50px;height:50px;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;z-index:99;box-shadow:0 4px 10px rgba(0,0,0,.15)}
        </style>
        <?php salesnanny_nav_header(); ?>
            <div class="terms-container">
                <div class="terms-header">
                    <h1>DMCA Policy</h1>
                    <p>Please read these terms and conditions carefully before using our services. By accessing and using our website, you agree to be bound by these terms.</p>
                </div>
                <div class="terms-content-wrapper">
                    <div class="terms-content">
                        <h2>DMCA Policy For SalesNanny</h2>
                       <p>The Digital Millennium Copyright Act (“DMCA”) is designed to protect content creators from having their work stolen and published by other people on the internet.</p>
                       <p>The law specifically targets websites where owners do not know who contributed each item of content or that the website is a platform for uploading and publishing content.</p>
                       <p>We have the policy to respond to any infringement notice and take appropriate action.</p>
                       <p>This Digital Millennium Copyright Act policy applies to the “https://SalesNanny.com/” website (“Website” or “Service”) and any of its related products and services (collectively, “Services”) and outlines how this Website operator (“Operator”, “we”, “us” or “our”) addresses copyright infringement notifications and how you (“you” or “your”) may submit a copyright infringement complaint.</p>
                       <p>Protection of intellectual property is of utmost importance to us and we ask our users and their authorized agents to do the same. It is our policy to expeditiously respond to clear notifications of alleged copyright infringement that comply with the United States Digital Millennium Copyright Act (“DMCA”) of 1998, the text of which can be found on the U.S. Copyright Office website.</p>

                       <h2>What to consider before submitting a copyright complaint?</h2>
                       <p>Please note that if you are unsure whether the material you are reporting is in fact infringing, you may wish to contact an attorney before filing a notification with us.</p>
                       <p>The DMCA requires you to provide your personal information in the copyright infringement notification. If you are concerned about the privacy of your personal information.</p>

                       <h2>Notifications of Infringement</h2>
                       <p>If you are a copyright owner or an agent thereof, and you believe that any material available on our Services infringes your copyrights, then you may submit a written copyright infringement notification (“Notification”) using the contact details below pursuant to the DMCA. All such Notifications must comply with the DMCA requirements.</p>
                       <p>Filing a DMCA complaint is the start of a pre-defined legal process. Your complaint will be reviewed for accuracy, validity, and completeness. If your complaint has satisfied these requirements, our response may include the removal or restriction of access to allegedly infringing material.</p>
                       <p>If we remove or restrict access to materials or terminate an account in response to a Notification of alleged infringement, we will make a good-faith effort to contact the affected user with information concerning the removal or restriction of access.</p>

                       <p>Notwithstanding anything to the contrary contained in any portion of this Policy, the Operator reserves the right to take no action upon receipt of a DMCA copyright infringement notification if it fails to comply with all the requirements of the DMCA for such notifications.</p>

                       <p>The process described in this Policy does not limit our ability to pursue any other remedies we may have to address suspected infringement.</p>

                       <h2>Changes and amendments</h2>
                       <p>We reserve the right to modify this Policy, or its terms related to the Website and Services at any time at our discretion. When we do, we will post a notification on the main page of the Website, and send you an email to notify you. We may also provide notice to you in other ways at our discretion, such as through the contact information you have provided.</p>
                       <p>An updated version of this Policy will be effective immediately upon the posting of the revised Policy unless otherwise specified. Your continued use of the Website and Services after the effective date of the revised Policy (or such other act specified at that time) will constitute your consent to those changes.</p>
                       
                       <h2>Reporting copyright infringement</h2>
                       <p>If you would like to notify us of the infringing material or activity, we encourage you to contact us via the email address given below.</p>
                       <p>Email: support@SalesNanny.com</p>
                       <p>Note: Please allow 1-2 business days for an email response.</p>
                
                        <div class="terms-cta">
                            <p>Have questions about our DMCA Policy? We're here to help.</p>
                            <a href="<?php echo SN_HTTP_URL; ?>contact/" class="terms-cta-button">Contact Us</a>
                        </div>
                        <span class="last-updated">Last updated: <?php echo date('F d, Y'); ?></span>
                    </div>
                </div>
                <a href="#" class="back-to-top">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 15l-6-6-6 6"/>
                    </svg>
                </a>
            </div>
            <script>
                // Back to top button functionality
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTopButton = document.querySelector('.back-to-top');
                    
                    // Show button when user scrolls down 300px
                    window.addEventListener('scroll', function() {
                        if (window.pageYOffset > 300) {
                            backToTopButton.classList.add('visible');
                        } else {
                            backToTopButton.classList.remove('visible');
                        }
                    });
                    
                    // Smooth scroll to top when button is clicked
                    backToTopButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
            </script>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>