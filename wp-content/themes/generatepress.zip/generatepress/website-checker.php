<?php
   /*
   Template Name: Website Checker
   */
   ?>
<html lang="en-US">
   <?php get_custom_head(); ?>
   <body>
        <div>
            <?php salesnanny_nav_header(); ?>
            <div class="container" style="padding: 40px;">
                <h2>Website Speed & Health Checker</h2>
                <?php include(get_template_directory() . '/website-checker/index.php'); ?>
            </div>
            <?php salesnanny_footer(); ?>
        </div>
   </body>
</html>