<?php
   /*
   Template Name: Contact 
   */
?>
<html>
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
   <body>
        <link rel="preload" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/contact-noncritical.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
        <noscript>
            <link rel="stylesheet" href="<?php echo SN_HTTP_URL; ?>wp-content/themes/generatepress/contact-noncritical.css"/>
        </noscript>
        <div>
            <style>
                .contact-hero{padding:clamp(70px,10vw,120px) 20px;text-align:center;position:relative;margin-top:80px}.contact-hero::before{content:"";position:absolute;top:0;left:0;right:0;bottom:0;background:#1e2154;backdrop-filter:blur(2px)}.hero-content{position:relative;z-index:1;max-width:800px;margin:0 auto}.hero-title{color:#fff;font-size:clamp(2.5rem, 5vw, 3.5rem);font-weight:700;margin-bottom:clamp(15px,2vw,25px);text-shadow:0 2px 10px rgba(0,0,0,.2);letter-spacing:-.02em}.hero-subtitle{color:#fff;font-size:clamp(1.1rem, 2.5vw, 1.5rem);line-height:1.6;max-width:90%;margin:0 auto;opacity:.95}.contact-container,.help-section{max-width:1400px;position:relative}.contact-container{display:flex;margin:0 auto;padding:clamp(30px,5vw,60px);gap:clamp(30px,5vw,60px);background:#fff5f5;box-shadow:0 20px 40px rgba(0,0,0,.05)}.contact-container::before{left:0;height:5px}.left-section,.right-section{flex:1}.contact-title{font-size:clamp(2rem, 4vw, 2.625rem);font-weight:700;margin-bottom:clamp(15px,2vw,20px);color:#1e2154;line-height:1.2}.description,.subtitle{margin-bottom:clamp(20px,3vw,30px)}.subtitle{font-size:clamp(1.5rem, 3vw, 2rem);color:#333;font-weight:600}.description{color:#555;line-height:1.7;font-size:clamp(1rem, 1.2vw, 1.125rem)}.form-group{margin-bottom:clamp(15px,2vw,20px)}input,textarea{width:100%;padding:clamp(10px,1.5vw,15px);border:1px solid #ddd;border-radius:8px;margin-top:5px;font-size:clamp(.95rem, 1.1vw, 1rem);transition:.3s;background-color:#fff;color:#333}textarea{min-height:clamp(100px,15vw,150px);resize:vertical}.submit-btn{background:linear-gradient(135deg,#c22034,#a61c2e);color:#fff;padding:clamp(12px,1.5vw,16px) clamp(20px,2vw,30px);border:none;border-radius:8px;cursor:pointer;font-size:clamp(.95rem, 1.1vw, 1.1rem);width:100%;font-weight:600;letter-spacing:.5px;transition:.3s;text-transform:uppercase;box-shadow:0 4px 15px rgba(194,32,52,.25)}.privacy-notice{font-size:clamp(.8rem, .9vw, .9rem);color:#666;margin:clamp(15px,2vw,20px) 0;line-height:1.6}.privacy-notice a{color:#c22034;text-decoration:underline;transition:color .3s}#form-status{margin-top:clamp(15px,2vw,25px);min-height:60px;overflow:hidden;max-height:0;transition:max-height .5s ease-in-out,opacity .5s ease-in-out;opacity:0}.help-section{text-align:center;padding:clamp(40px,6vw,80px) clamp(15px,2vw,30px);margin:0 auto}.help-section::before{content:"";position:absolute;top:0;width:100%;background:linear-gradient(90deg,#c22034,#1e2154);left:50%;transform:translateX(-50%);height:4px;border-radius:2px}.help-title{font-size:clamp(2rem, 3.5vw, 2.625rem);color:#1e2154;margin-bottom:clamp(15px,2vw,20px);font-weight:700}.help-description{font-size:clamp(1rem, 1.2vw, 1.125rem);color:#555;margin-bottom:clamp(30px,4vw,50px);max-width:800px;margin-left:auto;margin-right:auto;line-height:1.7}.support-options{display:flex;gap:clamp(15px,3vw,30px);justify-content:center;max-width:1000px;margin:0 auto}.support-card{flex:1;background:#fff5f5;padding:clamp(25px,3vw,40px);border-radius:12px;transition:.3s;box-shadow:0 8px 30px rgba(0,0,0,.05);border:1px solid rgba(0,0,0,.05)}.support-card h3{font-size:clamp(1.2rem, 1.8vw, 1.5rem);color:#1e2154;margin-bottom:clamp(8px,1vw,15px);font-weight:600}.support-card p{color:#555;font-size:clamp(.9rem, 1vw, 1rem);line-height:1.6}
                .back-to-top{position:fixed;bottom:100px;right:30px;width:50px;height:50px;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;z-index:99;box-shadow:0 4px 10px rgb(0 0 0 / .15);background:#c22034;text-decoration:none;transition:opacity .3s;transform:translateY(0)}.back-to-top.visible{opacity:1;pointer-events:auto}
                .error-message,.success-message{display:flex;align-items:center;gap:10px;padding:15px;border-radius:8px;margin-bottom:20px}.success-message{background-color:#e6f4ea;color:#1e4620}.error-message{background-color:#fce8e6;color:#c5221f}@font-face{font-family:YourFont;font-display:swap;src:url('path-to-your-font.woff2') format('woff2')}

                @media screen and (max-width:768px){.contact-hero{margin-top:60px;min-height:180px}.contact-container{flex-direction:column;padding:20px;gap:20px}.left-section,.right-section,.support-card{width:100%}.support-options{flex-direction:column;gap:15px}#form-status{position:relative;height:auto;min-height:60px;margin-bottom:20px}.form-group{margin-bottom:15px}input,textarea{height:45px;min-height:45px}textarea{height:120px;min-height:120px}.submit-btn{height:45px}}
            </style>
            <?php salesnanny_nav_header(); ?>
            <div class="contact-hero">
                <div class="hero-content">
                    <h1 class="hero-title">Contact SalesNanny</h1>
                    <p class="hero-subtitle">Let us help you transform your business with SalesNanny</p>
                </div>
            </div>
            <div class="contact-container">
                <div class="left-section">
                    <h1 class="contact-title">Not sure where to start with SalesNanny?</h1>
                    <h2 class="subtitle">We're here to help!</h2>
                    <p class="description">We have a team of experts available to answer your questions. We'll assign a concierge to learn about your business, and explain how SalesNanny can fit into your workday. Think of us as your own personal business consultants.</p>
                </div>

                <div class="right-section">
                    <h3 class="subtitle">Get in touch to get the ball rolling.</h3>
                    <form id="contact-form">
                        <div class="form-group">
                            <input type="text" name="name" placeholder="Name*" required>
                        </div>
                        <div class="form-group">
                            <input type="url" name="website" placeholder="Website URL*" pattern="https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)" title="Please enter a valid website URL (e.g., https://example.com)" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" placeholder="Email*" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Please enter a valid email address" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" name="phone" placeholder="Phone Number*" pattern="[0-9]*" title="Please enter numbers only" required>
                        </div>
                        <div class="form-group">
                            <textarea name="message" placeholder="Your Message*" required></textarea>
                        </div>
                        <div class="privacy-notice">
                            By submitting this form, you agree to the processing of personal data according to our <a href="<?php echo SN_HTTP_URL; ?>privacy-policy/">Privacy Policy</a>.
                        </div>
                        <button type="submit" class="submit-btn">SUBMIT</button>
                    </form>
                    
                    <!-- Form status message container -->
                    <div id="form-status"></div>
                </div>
            </div>
            <div class="help-section">
                <h2 class="help-title">Still need help?</h2>
                <p class="help-description">Our support team is available 24/7 to assist you with any questions.</p>
                
                <div class="support-options">
                    <div class="support-card">
                        <a href="mailto:support@salesnanny.com" style="text-decoration: none; color: inherit;">
                            <h3>Email Support</h3>
                            <p>Get a response within 24 hours</p>
                        </a>
                    </div>
                    <div class="support-card">
                        <a href="https://tawk.to/chat/670e1b904304e3196ad1b27c/1ia7hnb8n" onclick="window.tidioChatApi.open()" style="text-decoration: none; color: inherit;">
                            <h3>Live Chat</h3>
                            <p>Chat with us now</p>
                        </a>
                    </div>
                </div>
            </div>
            <script>
                // Google Apps Script integration for contact form
                document.addEventListener('DOMContentLoaded', function() {
                    const contactForm = document.getElementById('contact-form');
                    const formStatus = document.getElementById('form-status');
                    
                    // Pre-reserve space for form status
                    formStatus.style.maxHeight = '60px';
                    
                    contactForm.addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        const submitButton = document.querySelector('.submit-btn');
                        const originalButtonText = submitButton.textContent;
                        submitButton.textContent = 'Sending...';
                        submitButton.disabled = true;
                        submitButton.classList.add('loading');
                        
                        const formData = new FormData(contactForm);
                        const formDataObj = {};
                        
                        formData.forEach((value, key) => {
                            formDataObj[key] = value;
                        });
                        
                        formDataObj.timestamp = new Date().toISOString();
                        
                        fetch('https://script.google.com/macros/s/AKfycby6L_9h5lo7wqJwuOfvfq-VpofABKmvnrXHHdF2iA6UT9Dshm3ybptxf7qhQK8QVWImsQ/exec', {
                            method: 'POST',
                            mode: 'no-cors',
                            cache: 'no-cache',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            redirect: 'follow',
                            body: JSON.stringify(formDataObj)
                        })
                        .then(response => {
                            formStatus.innerHTML = '<div class="success-message"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg><p>Thank you! Your message has been received. We\'ll be in touch shortly.</p></div>';
                            contactForm.reset();
                            
                            formStatus.style.maxHeight = '60px';
                            formStatus.style.opacity = '1';
                            
                            formStatus.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                            
                            setTimeout(() => {
                                submitButton.textContent = originalButtonText;
                                submitButton.disabled = false;
                                submitButton.classList.remove('loading');
                            }, 3000);
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            formStatus.innerHTML = '<div class="error-message"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg><p>Something went wrong. Please try again or contact us directly.</p></div>';
                            formStatus.style.maxHeight = '60px';
                            formStatus.style.opacity = '1';
                            
                            submitButton.textContent = originalButtonText;
                            submitButton.disabled = false;
                            submitButton.classList.remove('loading');
                        });
                    });
                });

                // Back to top button functionality
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTopButton = document.querySelector('.back-to-top');
                    
                    // Show button when user scrolls down 300px
                    window.addEventListener('scroll', function() {
                        if (window.pageYOffset > 300) {
                            backToTopButton.classList.add('visible');
                        } else {
                            backToTopButton.classList.remove('visible');
                        }
                    });
                    
                    // Smooth scroll to top when button is clicked
                    backToTopButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
            </script>
            <a class="back-to-top">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M18 15l-6-6-6 6"/>
                </svg>
            </a>
            <?php salesnanny_footer(); ?>
      </div>
   </body>
</html>