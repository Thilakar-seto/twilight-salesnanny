<?php
/**
 * Template Name: Enhanced Real API Website Analyzer
 * 
 * Comprehensive website analysis with multiple real APIs:
 * - Google PageSpeed Insights API (Performance & Core Web Vitals)
 * - Custom SEO Analysis
 * - Security Headers Check
 * - Technology Detection
 * - Accessibility Testing
 * - Social Media Meta Tags Analysis
 * 
 * @package GeneratePress
 */

require_once get_template_directory() . '/analyzer-config.php';

// Enqueue dependencies
function enqueue_enhanced_real_api_analyzer_scripts() {
    wp_enqueue_script('jquery');
    // FontAwesome removed - using clean SVG icons instead
}
add_action('wp_enqueue_scripts', 'enqueue_enhanced_real_api_analyzer_scripts');

// Ensure jQuery is loaded in header for this page
add_action('wp_head', function() {
    if (is_page_template('enhanced-real-api-analyzer.php')) {
        wp_print_scripts('jquery');
    }
});


?>
<html lang="en-US">
<?php get_custom_head(); ?>
<?php salesnanny_side_panel(); ?>
<body>

    <div>
        <style>
        .enhanced-analyzer-container {
            background: #fef4f4;
            min-height: 100vh;
            padding: 20px 0;
            margin: 80px auto 0px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
        }
        
        .container { 
            max-width: 1300px; 
            margin: 0 auto; 
            padding: 0 20px; 
        }
        
        .analyzer-hero {
            text-align: center;
            margin-bottom: 60px;
            padding: 60px 40px;
            background: linear-gradient(135deg, #1e2154 0%, #c22034 100%);
            border-radius: 24px;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(30, 33, 84, 0.15);
        }
            
        .analyzer-hero::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(194, 32, 52, 0.1);
            border-radius: 50%;
            z-index: 0;
            animation: floatBubble 15s ease-in-out infinite;
        }
        
        .analyzer-hero::after {
            content: '';
            position: absolute;
            bottom: -50px;
            left: -50px;
            width: 180px;
            height: 180px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            z-index: 0;
            animation: floatBubble 18s ease-in-out infinite reverse;
        }
        
        @keyframes floatBubble {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            33% { transform: translate(30px, -30px) rotate(120deg); }
            66% { transform: translate(-20px, 20px) rotate(240deg); }
        }
            
            .analyzer-hero h1 {
                font-size: 2.8rem;
                font-weight: 700;
                margin-bottom: 16px;
                position: relative;
                z-index: 1;
            }
            
            .analyzer-hero .subtitle {
                font-size: 1.2rem;
                opacity: 0.9;
                max-width: 600px;
                margin: 0 auto 32px;
                line-height: 1.6;
                position: relative;
                z-index: 1;
            }
            
            .feature-tags {
                display: flex;
                justify-content: center;
                flex-wrap: wrap;
                gap: 12px;
                position: relative;
                z-index: 1;
            }
            
            .feature-tag {
                background: rgba(255,255,255,0.2);
                backdrop-filter: blur(10px);
                padding: 8px 16px;
                border-radius: 20px;
                font-size: 0.9rem;
                font-weight: 500;
                border: 1px solid rgba(255,255,255,0.3);
                transition: all 0.3s ease;
            }
            
            .feature-tag:hover {
                background: rgba(255,255,255,0.3);
                transform: translateY(-2px);
            }
            
            .main-form-card {
                background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%);
                border-radius: 24px;
                padding: 48px;
                box-shadow: 
                    0 20px 40px rgba(0,0,0,0.08),
                    0 8px 16px rgba(0,0,0,0.04),
                    inset 0 1px 0 rgba(255,255,255,0.6);
                margin-bottom: 48px;
                border: 1px solid rgba(255,255,255,0.2);
                position: relative;
                overflow: hidden;
            }
            
            .main-form-card::before {
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: conic-gradient(from 0deg, transparent, rgba(102, 126, 234, 0.03), transparent, rgba(118, 75, 162, 0.03), transparent);
                animation: rotate 20s linear infinite;
                z-index: 0;
            }
            
            .main-form-card > * {
                position: relative;
                z-index: 1;
            }
            
            @keyframes rotate {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            .form-header {
                text-align: center;
                margin-bottom: 48px;
                position: relative;
            }
            
        .form-header::after {
            content: '';
            position: absolute;
            bottom: -16px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, #1e2154, #c22034);
            border-radius: 2px;
        }
            
        .form-header h2 {
            color: #1e2154;
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 12px;
            background: linear-gradient(135deg, #1e2154 0%, #c22034 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .form-header p {
            color: #787878;
            font-size: 1.1rem;
            margin-bottom: 0;
            font-weight: 400;
        }
            
            .step-indicator {
                display: flex;
                justify-content: center;
                align-items: center;
                margin-bottom: 40px;
                gap: 16px;
            }
            
            .step {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 8px 16px;
                border-radius: 12px;
                background: #f1f5f9;
                color: #64748b;
                font-size: 0.9rem;
                font-weight: 500;
            }
            
        .step.active {
            background: #c22034;
            color: white;
        }
        
        .step-number {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #94a3b8;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .step.active .step-number {
            background: white;
            color: #c22034;
        }
            
            .url-input-section {
                margin-bottom: 48px;
                position: relative;
            }
            
        .url-input-container {
            background: linear-gradient(145deg, #ffffff, #fef4f4);
            border-radius: 20px;
            padding: 36px;
            border: 1px solid rgba(30, 33, 84, 0.1);
            box-shadow: 
                0 8px 32px rgba(30, 33, 84, 0.08),
                inset 0 1px 0 rgba(255, 255, 255, 0.9);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
            
        .url-input-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(30, 33, 84, 0.03), transparent);
            transition: left 0.6s ease;
        }
        
        .url-input-container:hover::before {
            left: 100%;
        }
        
        .url-input-container:hover {
            transform: translateY(-2px);
            box-shadow: 
                0 12px 48px rgba(30, 33, 84, 0.12),
                inset 0 1px 0 rgba(255, 255, 255, 0.9);
            border-color: rgba(30, 33, 84, 0.2);
        }
        
        .url-input-container.focused {
            transform: translateY(-4px);
            box-shadow: 
                0 20px 64px rgba(30, 33, 84, 0.15),
                0 0 0 4px rgba(194, 32, 52, 0.1),
                inset 0 1px 0 rgba(255, 255, 255, 0.9);
            border-color: #c22034;
        }
            
            .url-input-group {
                position: relative;
                z-index: 2;
            }
            
        .url-input-group label {
            display: block;
            margin-bottom: 16px;
            font-weight: 700;
            color: #1e2154;
            font-size: 1.2rem;
            text-align: center;
        }
            
            .url-input-wrapper {
                position: relative;
                overflow: hidden;
                border-radius: 16px;
            }
            
        .url-input {
            width: 100%;
            padding: 20px 24px 20px 56px;
            border: 2px solid rgba(30, 33, 84, 0.2);
            border-radius: 16px;
            font-size: 18px;
            font-weight: 500;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            background: linear-gradient(145deg, #ffffff, #fafbfc);
            color: #1e2154;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.02);
        }
        
        .url-input:focus {
            outline: none;
            border-color: #c22034;
            background: #ffffff;
            box-shadow: 
                inset 0 2px 4px rgba(0, 0, 0, 0.02),
                0 0 0 3px rgba(194, 32, 52, 0.1);
            transform: scale(1.01);
        }
            
            .url-input::placeholder {
                color: #9ca3af;
                font-weight: 400;
            }
            
        .url-icon {
            position: absolute;
            left: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: #c22034;
            z-index: 3;
            transition: all 0.3s ease;
        }
        
        .url-input:focus + .url-icon {
            color: #1e2154;
            transform: translateY(-50%) scale(1.1);
        }
            
        .url-help-text {
            margin-top: 12px;
            font-size: 0.95rem;
            color: #787878;
            text-align: center;
            font-weight: 500;
        }
            
            .analysis-info {
                margin: 40px 0;
                position: relative;
            }
            
        .analysis-info-card {
            background: linear-gradient(145deg, #ffffff 0%, #fef4f4 100%);
            border-radius: 20px;
            padding: 32px;
            border: 1px solid rgba(30, 33, 84, 0.08);
            box-shadow: 
                0 8px 32px rgba(30, 33, 84, 0.06),
                inset 0 1px 0 rgba(255, 255, 255, 0.8);
            position: relative;
            overflow: hidden;
        }
        
        .analysis-info-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #1e2154, #c22034, #1e2154);
            border-radius: 20px 20px 0 0;
        }
            
        .analysis-info h3 {
            color: #1e2154;
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-align: center;
            position: relative;
        }
        
        .analysis-info h3::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 40px;
            height: 2px;
            background: linear-gradient(90deg, #1e2154, #c22034);
            border-radius: 1px;
        }
            
            .analysis-features {
                display: grid;
                gap: 16px;
                margin-top: 24px;
            }
            
        .feature-item {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1rem;
            color: #787878;
            line-height: 1.6;
            padding: 16px;
            background: linear-gradient(145deg, #ffffff, #fef4f4);
            border-radius: 12px;
            border: 1px solid rgba(30, 33, 84, 0.05);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
            transition: all 0.3s ease;
        }
        
        .feature-item:hover {
            transform: translateX(4px);
            box-shadow: 0 4px 16px rgba(30, 33, 84, 0.08);
            border-color: rgba(194, 32, 52, 0.1);
        }
        
        .feature-item::before {
            content: '';
            width: 8px;
            height: 8px;
            background: linear-gradient(135deg, #1e2154, #c22034);
            border-radius: 50%;
            flex-shrink: 0;
            box-shadow: 0 0 0 3px rgba(194, 32, 52, 0.1);
        }
        
        .feature-item strong {
            color: #1e2154;
            font-weight: 600;
        }
            
            .options-title {
                text-align: center;
                margin-bottom: 25px;
                color: #2c3e50;
                font-size: 1.3rem;
                font-weight: 600;
            }
            
            .options-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
                gap: 20px;
            }
            
            .option-toggle {
                background: #f8f9fa;
                border-radius: 16px;
                padding: 25px 20px;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s ease;
                border: 2px solid transparent;
                position: relative;
                overflow: hidden;
            }
            
            .option-toggle:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }
            
            .option-toggle.active {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-color: #667eea;
            }
            
            .option-toggle input[type="checkbox"] {
                display: none;
            }
            
            .option-icon {
                width: 2rem;
                height: 2rem;
                margin-bottom: 15px;
                display: block;
                color: #667eea;
                fill: currentColor;
            }
            

            
            .option-toggle.active .option-icon {
                color: white;
            }
            
            .option-title {
                font-weight: 700;
                margin-bottom: 8px;
                font-size: 1rem;
            }
            
            .option-description {
                font-size: 0.85rem;
                opacity: 0.8;
                line-height: 1.4;
            }
            
            .analyze-button-container {
                margin-top: 40px;
                text-align: center;
            }
            
        .analyze-button {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 20px 48px;
            background: linear-gradient(145deg, #c22034 0%, #1e2154 50%, #c22034 100%);
            background-size: 300% 100%;
            color: white;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
            box-shadow: 
                0 8px 32px rgba(194, 32, 52, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            min-width: 280px;
        }
            
            .analyze-button::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
                transform: translateX(-100%);
                transition: transform 0.6s ease;
            }
            
            .analyze-button::after {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
                transform: translate(-50%, -50%);
                transition: all 0.4s ease;
                border-radius: 50%;
            }
            
        .analyze-button:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 
                0 16px 48px rgba(194, 32, 52, 0.4),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
            background-position: 100% 0;
        }
        
        .analyze-button:hover::before {
            transform: translateX(100%);
        }
        
        .analyze-button:hover::after {
            width: 300px;
            height: 300px;
        }
        
        .analyze-button:active {
            transform: translateY(-1px) scale(0.98);
            transition: all 0.1s ease;
        }
        
        .analyze-button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
            box-shadow: 0 4px 16px rgba(194, 32, 52, 0.2);
        }
            
            .analyze-button:disabled:hover {
                transform: none;
                background-position: 0% 0;
            }
            
            .btn-content {
                position: relative;
                z-index: 2;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            
            .btn-icon {
                transition: transform 0.3s ease;
            }
            
            .analyze-button:hover .btn-icon {
                transform: rotate(15deg) scale(1.1);
            }
            
            .loading-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.8);
                display: none;
                z-index: 9999;
                align-items: center;
                justify-content: center;
            }
            
            .loading-content {
                background: white;
                padding: 40px;
                border-radius: 20px;
                text-align: center;
                max-width: 500px;
                margin: 20px;
            }
            
        .loading-spinner {
            width: 60px;
            height: 60px;
            border: 4px solid #e1e5e9;
            border-top: 4px solid #c22034;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
            
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            
            .progress-steps {
                margin: 30px 0;
            }
            
            .progress-step {
                display: flex;
                align-items: center;
                gap: 15px;
                padding: 10px 0;
                color: #666;
            }
            
        .progress-step.active {
            color: #c22034;
            font-weight: 600;
        }
            
            .progress-step.completed {
                color: #28a745;
            }
            
            .step-icon {
                width: 24px;
                text-align: center;
            }
            
            .results-container {
                display: none;
                margin-top: 40px;
            }
            
        .section-main-title {
            font-size: 1.8rem;
            font-weight: 700;
            color: #1e2154;
            margin-bottom: 8px;
            text-align: center;
        }
        
        .section-subtitle {
            font-size: 1rem;
            color: #787878;
            text-align: center;
            margin-bottom: 32px;
        }
            
            .pagespeed-section {
                background: white;
                border-radius: 20px;
                padding: 40px;
                margin-bottom: 32px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.06);
                border: 1px solid #e2e8f0;
            }
            
            .seo-section {
                background: white;
                border-radius: 20px;
                padding: 40px;
                margin-bottom: 32px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.06);
                border: 1px solid #e2e8f0;
            }
            
            .accessibility-section {
                background: white;
                border-radius: 20px;
                padding: 40px;
                margin-bottom: 32px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.06);
                border: 1px solid #e2e8f0;
            }
            
            .accessibility-overview {
                margin-bottom: 32px;
            }
            
            .accessibility-score-display {
                display: flex;
                align-items: center;
                gap: 24px;
                padding: 24px;
                background: #f9fafb;
                border-radius: 12px;
                border: 1px solid #e5e7eb;
            }
            
            .accessibility-score-details h4 {
                color: #111827;
                font-size: 1.2rem;
                font-weight: 600;
                margin-bottom: 8px;
            }
            
            .accessibility-score-details p {
                color: #6b7280;
                font-size: 0.95rem;
                line-height: 1.5;
                margin: 0 0 8px 0;
            }
            
            .wcag-info {
                background: rgba(16, 185, 129, 0.1);
                padding: 4px 8px;
                border-radius: 6px;
                display: inline-block;
            }
            
            .wcag-info small {
                color: #065f46;
                font-weight: 500;
                font-size: 0.8rem;
            }
            
            .accessibility-audits h4 {
                color: #111827;
                font-size: 1.3rem;
                font-weight: 600;
                margin-bottom: 20px;
            }
            
            .accessibility-audit-grid {
                display: grid;
                gap: 16px;
                margin-bottom: 32px;
            }
            
            .accessibility-audit-item {
                background: white;
                border-radius: 8px;
                padding: 20px;
                border-left: 4px solid;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }
            
            .accessibility-audit-item.pass {
                border-left-color: #10b981;
                background: linear-gradient(145deg, #ffffff, #f0fdf4);
            }
            
            .accessibility-audit-item.warning {
                border-left-color: #f59e0b;
                background: linear-gradient(145deg, #ffffff, #fffbeb);
            }
            
            .accessibility-audit-item.fail {
                border-left-color: #ef4444;
                background: linear-gradient(145deg, #ffffff, #fef2f2);
            }
            
            .audit-icon.accessibility-pass {
                background: #10b981;
            }
            
            .audit-icon.accessibility-warning {
                background: #f59e0b;
            }
            
            .audit-icon.accessibility-fail {
                background: #ef4444;
            }
            
            .accessibility-recommendations {
                background: #f8fafc;
                border-radius: 12px;
                padding: 24px;
                border: 1px solid #e2e8f0;
            }
            
            .accessibility-recommendations h4 {
                color: #1a202c;
                font-size: 1.2rem;
                font-weight: 600;
                margin-bottom: 20px;
                text-align: center;
            }
            
            .recommendations-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 16px;
            }
            
            .recommendation-card {
                background: white;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
                border: 1px solid #e5e7eb;
            }
            
            .recommendation-card h5 {
                color: #1f2937;
                font-size: 1rem;
                font-weight: 600;
                margin-bottom: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .recommendation-card ul {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            
            .recommendation-card li {
                color: #4b5563;
                font-size: 0.9rem;
                line-height: 1.5;
                margin-bottom: 8px;
                padding-left: 20px;
                position: relative;
            }
            
            .recommendation-card li::before {
                content: '✓';
                position: absolute;
                left: 0;
                color: #10b981;
                font-weight: bold;
            }
            
            .suggestions-container {
                display: flex;
                flex-direction: column;
                gap: 20px;
            }
            
            .suggestion-category {
                background: white;
                border-radius: 8px;
                padding: 20px;
                border-left: 4px solid;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            }
            
            .suggestion-category.critical {
                border-left-color: #ef4444;
                background: linear-gradient(145deg, #ffffff, #fef2f2);
            }
            
            .suggestion-category.important {
                border-left-color: #f59e0b;
                background: linear-gradient(145deg, #ffffff, #fffbeb);
            }
            
            .suggestion-category.recommended {
                border-left-color: #10b981;
                background: linear-gradient(145deg, #ffffff, #f0fdf4);
            }
            
            .suggestion-category h5 {
                color: #1f2937;
                font-size: 1.1rem;
                font-weight: 600;
                margin-bottom: 12px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .suggestion-category ul {
                list-style: none;
                padding: 0;
                margin: 0;
            }
            
            .suggestion-category li {
                color: #374151;
                font-size: 0.95rem;
                line-height: 1.6;
                margin-bottom: 8px;
                padding-left: 20px;
                position: relative;
            }
            
            .suggestion-category.critical li::before {
                content: '🚨';
                position: absolute;
                left: 0;
                font-size: 1rem;
            }
            
            .suggestion-category.important li::before {
                content: '⚠️';
                position: absolute;
                left: 0;
                font-size: 1rem;
            }
            
            .suggestion-category.recommended li::before {
                content: '✅';
                position: absolute;
                left: 0;
                font-size: 1rem;
            }
            
            .performance-details {
                margin-top: 32px;
            }
            
            .additional-analysis {
                display: grid;
                gap: 24px;
            }
            
            .opportunities-section {
                margin-top: 32px;
            }
            
            .opportunities-section h4 {
                color: #1a202c;
                font-size: 1.3rem;
                font-weight: 600;
                margin-bottom: 20px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .opportunities-list {
                display: grid;
                gap: 16px;
            }
            
            .opportunity-item {
                background: white;
                border-radius: 12px;
                padding: 20px;
                border-left: 4px solid;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
                transition: all 0.3s ease;
            }
            
            .opportunity-item:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
            }
            
            .opportunity-high {
                border-left-color: #dc3545;
                background: linear-gradient(145deg, #ffffff, #fff5f5);
            }
            
            .opportunity-medium {
                border-left-color: #ffc107;
                background: linear-gradient(145deg, #ffffff, #fffbeb);
            }
            
            .opportunity-low {
                border-left-color: #28a745;
                background: linear-gradient(145deg, #ffffff, #f0fff4);
            }
            
            .opportunity-header {
                margin-bottom: 12px;
            }
            
            .opportunity-title-row {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                gap: 16px;
            }
            
            .opportunity-title {
                color: #1a202c;
                font-size: 1.1rem;
                font-weight: 600;
                margin: 0;
                flex: 1;
                line-height: 1.3;
            }
            
            .opportunity-impact {
                display: flex;
                flex-direction: column;
                align-items: flex-end;
                gap: 4px;
                flex-shrink: 0;
            }
            
            .impact-label {
                font-size: 0.8rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .opportunity-score {
                font-size: 0.9rem;
                font-weight: 700;
                background: rgba(0, 0, 0, 0.05);
                padding: 2px 8px;
                border-radius: 12px;
            }
            
            .opportunity-description {
                color: #4b5563;
                line-height: 1.6;
                margin-bottom: 16px;
                font-size: 0.95rem;
            }
            
            .opportunity-savings {
                background: rgba(39, 174, 96, 0.05);
                border-radius: 8px;
                padding: 12px;
                border: 1px solid rgba(39, 174, 96, 0.2);
            }
            
            .savings-label {
                display: block;
                font-size: 0.9rem;
                font-weight: 600;
                color: #27ae60;
                margin-bottom: 8px;
            }
            
            .savings-details {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
            }
            
            .saving-item {
                background: white;
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 0.85rem;
                font-weight: 500;
                border: 1px solid rgba(39, 174, 96, 0.3);
                color: #1a5027;
                display: flex;
                align-items: center;
                gap: 4px;
            }
            
            .saving-item.time {
                background: linear-gradient(145deg, #e3f2fd, #ffffff);
                border-color: #2196f3;
                color: #0d47a1;
            }
            
            .saving-item.size {
                background: linear-gradient(145deg, #f3e5f5, #ffffff);
                border-color: #9c27b0;
                color: #4a148c;
            }
            
            .saving-item.value {
                background: linear-gradient(145deg, #fff3e0, #ffffff);
                border-color: #ff9800;
                color: #e65100;
            }
            
            .seo-overview {
                margin-bottom: 32px;
            }
            
            .seo-score-display {
                display: flex;
                align-items: center;
                gap: 24px;
                padding: 24px;
                background: #f9fafb;
                border-radius: 12px;
                border: 1px solid #e5e7eb;
            }
            
            .seo-score-details h4 {
                color: #111827;
                font-size: 1.2rem;
                font-weight: 600;
                margin-bottom: 8px;
            }
            
            .seo-score-details p {
                color: #6b7280;
                font-size: 0.95rem;
                line-height: 1.5;
                margin: 0;
            }
            
            .seo-audits h4 {
                color: #111827;
                font-size: 1.3rem;
                font-weight: 600;
                margin-bottom: 20px;
            }
            
            .seo-audit-grid {
                display: grid;
                gap: 16px;
            }
            
            .seo-audit-item {
                background: white;
                border-radius: 8px;
                padding: 20px;
                border-left: 4px solid;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }
            
            .seo-audit-item.pass {
                border-left-color: #10b981;
                background: linear-gradient(145deg, #ffffff, #f0fdf4);
            }
            
            .seo-audit-item.warning {
                border-left-color: #f59e0b;
                background: linear-gradient(145deg, #ffffff, #fffbeb);
            }
            
            .seo-audit-item.fail {
                border-left-color: #ef4444;
                background: linear-gradient(145deg, #ffffff, #fef2f2);
            }
            
            .audit-header {
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 12px;
            }
            
            .audit-icon {
                width: 24px;
                height: 24px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                flex-shrink: 0;
            }
            
            .audit-icon.check-pass {
                background: #10b981;
            }
            
            .audit-icon.check-warning {
                background: #f59e0b;
            }
            
            .audit-icon.check-fail {
                background: #ef4444;
            }
            
            .audit-icon svg {
                width: 14px;
                height: 14px;
            }
            
            .audit-info {
                flex: 1;
            }
            
            .audit-info h5 {
                color: #111827;
                font-size: 1rem;
                font-weight: 600;
                margin: 0 0 4px 0;
            }
            
            .audit-score {
                color: #6b7280;
                font-size: 0.85rem;
                font-weight: 500;
            }
            
            .audit-description {
                color: #4b5563;
                font-size: 0.9rem;
                line-height: 1.5;
                margin-bottom: 8px;
            }
            
            .audit-detail {
                background: rgba(0, 0, 0, 0.02);
                padding: 8px 12px;
                border-radius: 6px;
                font-size: 0.85rem;
                color: #374151;
                font-family: 'Monaco', 'Consolas', monospace;
            }
            
            .audit-detail em {
                color: #1f2937;
                font-weight: 500;
            }
            
            .results-header {
                background: white;
                border-radius: 20px;
                padding: 30px;
                margin-bottom: 30px;
                text-align: center;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            }
            
            .analyzed-url {
                font-size: 1.2rem;
                color: #2c3e50;
                margin-bottom: 15px;
                word-break: break-all;
            }
            
            .analysis-timestamp {
                color: #666;
                font-size: 0.95rem;
            }
            
            .pagespeed-tabs {
                display: flex;
                border-bottom: 1px solid #e2e8f0;
                margin-bottom: 32px;
            }
            
            .pagespeed-tab {
                padding: 12px 24px;
                cursor: pointer;
                border-bottom: 3px solid transparent;
                font-weight: 500;
                color: #64748b;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
        .pagespeed-tab.active {
            color: #c22034;
            border-bottom-color: #c22034;
        }
        
        .pagespeed-tab:hover {
            color: #c22034;
        }
            
            .pagespeed-content {
                display: none;
            }
            
            .pagespeed-content.active {
                display: block;
            }
            
            .pagespeed-overview {
                display: flex;
                align-items: center;
                gap: 40px;
                margin-bottom: 32px;
                padding: 24px;
                background: #f8fafc;
                border-radius: 12px;
            }
            
            .score-gauge {
                position: relative;
                width: 120px;
                height: 120px;
                flex-shrink: 0;
            }
            
            .score-circle {
                width: 120px;
                height: 120px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.8rem;
                font-weight: 700;
                color: white;
                position: relative;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            
            .score-circle:hover {
                transform: scale(1.05);
            }
            
            .score-tooltip {
                position: absolute;
                top: -40px;
                left: 50%;
                transform: translateX(-50%);
                background: rgba(0,0,0,0.8);
                color: white;
                padding: 6px 12px;
                border-radius: 6px;
                font-size: 0.9rem;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.3s ease;
                white-space: nowrap;
                z-index: 10;
            }
            
            .score-circle:hover .score-tooltip {
                opacity: 1;
            }
            
            .score-details {
                flex: 1;
            }
            
        .score-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #1e2154;
            margin-bottom: 8px;
        }
        
        .score-description {
            color: #787878;
            margin-bottom: 16px;
            line-height: 1.5;
        }
            
            .score-excellent { background: linear-gradient(135deg, #28a745, #20c997); }
            .score-good { background: linear-gradient(135deg, #17a2b8, #6f42c1); }
            .score-average { background: linear-gradient(135deg, #ffc107, #fd7e14); }
            .score-poor { background: linear-gradient(135deg, #dc3545, #e83e8c); }
            
            .core-vitals {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 16px;
                margin-top: 16px;
            }
            
            .vital-metric {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 16px;
                background: white;
                border-radius: 8px;
                border: 1px solid #e2e8f0;
            }
            
            .vital-icon {
                width: 32px;
                height: 32px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 0.8rem;
                font-weight: 600;
                color: white;
                flex-shrink: 0;
            }
            
            .vital-good { background: #0cce6b; }
            .vital-needs-improvement { background: #ffa400; }
            .vital-poor { background: #ff5722; }
            
            .vital-info {
                flex: 1;
            }
            
            .vital-label {
                font-size: 0.85rem;
                color: #64748b;
                margin-bottom: 2px;
            }
            
            .vital-value {
                font-weight: 600;
                color: #1a202c;
                font-size: 1rem;
            }
            
            .detailed-results {
                display: grid;
                gap: 30px;
            }
            
            .result-section {
                background: white;
                border-radius: 20px;
                padding: 35px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            }
            
            .section-header {
                display: flex;
                align-items: center;
                gap: 15px;
                margin-bottom: 25px;
                padding-bottom: 15px;
                border-bottom: 2px solid #f1f3f4;
            }
            
        .section-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            background: linear-gradient(135deg, #1e2154, #c22034);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.3rem;
        }
        
        .section-title {
            font-size: 1.5rem;
            color: #1e2154;
            font-weight: 700;
        }
            
            .metrics-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }
            
        .metric-item {
            background: #fef4f4;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            border-left: 4px solid #c22034;
        }
        
        .metric-label {
            font-size: 0.9rem;
            color: #787878;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .metric-value {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1e2154;
        }
            
            .metric-status {
                font-size: 0.8rem;
                margin-top: 5px;
                padding: 2px 8px;
                border-radius: 12px;
                display: inline-block;
            }
            
            .status-good { background: #d4edda; color: #155724; }
            .status-needs-improvement { background: #fff3cd; color: #856404; }
            .status-poor { background: #f8d7da; color: #721c24; }
            
            .recommendations-list {
                list-style: none;
                padding: 0;
            }
            
            .recommendation-item {
                background: #fff8dc;
                margin-bottom: 15px;
                padding: 20px;
                border-radius: 12px;
                border-left: 4px solid #ffc107;
            }
            
            .recommendation-title {
                font-weight: 700;
                color: #856404;
                margin-bottom: 8px;
            }
            
            .recommendation-description {
                color: #666;
                line-height: 1.5;
                margin-bottom: 10px;
            }
            
            .recommendation-impact {
                font-size: 0.85rem;
                color: #28a745;
                font-weight: 600;
            }
            
            .seo-checklist {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 15px;
            }
            
            .seo-check-item {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 15px;
                background: #f8f9fa;
                border-radius: 10px;
            }
            
            .check-icon {
                width: 24px;
                height: 24px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 0.8rem;
            }
            
            .check-pass { background: #28a745; }
            .check-fail { background: #dc3545; }
            .check-warning { background: #ffc107; }
            
            .security-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
            }
            
            .security-item {
                padding: 15px;
                border-radius: 10px;
                text-align: center;
                font-weight: 600;
            }
            
            .security-pass {
                background: #d4edda;
                color: #155724;
                border: 1px solid #c3e6cb;
            }
            
            .security-fail {
                background: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
            }
            
            .download-button-container {
                text-align: center;
                margin: 32px 0;
                padding: 24px;
                background: linear-gradient(145deg, #f8fafc, #ffffff);
                border-radius: 16px;
                border: 1px solid #e2e8f0;
                box-shadow: 0 4px 20px rgba(0,0,0,0.06);
            }
            
            .email-collection-section h3 {
                color: #1e2154;
                font-size: 1.3rem;
                font-weight: 700;
                margin-bottom: 8px;
            }
            
            .email-collection-section p {
                color: #787878;
                font-size: 1rem;
                margin-bottom: 20px;
            }
            
            .email-input-group {
                display: flex;
                gap: 12px;
                align-items: stretch;
                margin-bottom: 16px;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .email-input {
                flex: 1;
                min-width: 250px;
                max-width: 400px;
                padding: 16px 20px;
                border: 2px solid rgba(30, 33, 84, 0.2);
                border-radius: 50px;
                font-size: 16px;
                font-weight: 500;
                transition: all 0.3s ease;
                background: linear-gradient(145deg, #ffffff, #fafbfc);
                color: #1e2154;
            }
            
            .email-input:focus {
                outline: none;
                border-color: #c22034;
                background: #ffffff;
                box-shadow: 0 0 0 3px rgba(194, 32, 52, 0.1);
                transform: scale(1.02);
            }
            
            .email-input::placeholder {
                color: #9ca3af;
                font-weight: 400;
            }
            
        .download-button {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 16px 32px;
            background: linear-gradient(145deg, #c22034 0%, #1e2154 50%, #c22034 100%);
            background-size: 300% 100%;
            color: white;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
            box-shadow: 
                0 6px 24px rgba(194, 32, 52, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            min-width: 200px;
        }
            
            .download-button::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
                transform: translateX(-100%);
                transition: transform 0.6s ease;
            }
            
        .download-button:hover {
            transform: translateY(-2px) scale(1.02);
            box-shadow: 
                0 12px 36px rgba(194, 32, 52, 0.4),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
            background-position: 100% 0;
        }
        
        .download-button:hover::before {
            transform: translateX(100%);
        }
        
        .download-button:active {
            transform: translateY(-1px) scale(0.98);
            transition: all 0.1s ease;
        }
        
        .download-button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
            box-shadow: 0 4px 16px rgba(194, 32, 52, 0.2);
        }
        
        .download-button:disabled:hover {
            transform: none;
            background-position: 0% 0;
        }
            
            .download-btn-content {
                position: relative;
                z-index: 2;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            
            .download-btn-icon {
                transition: transform 0.3s ease;
            }
            
            .download-button:hover .download-btn-icon {
                transform: translateY(-2px);
            }
            
            .download-info {
                margin-top: 16px;
                font-size: 0.9rem;
                color: #64748b;
                font-style: italic;
            }
            
            .api-config-notice {
                background: #fff3cd;
                border: 1px solid #ffeaa7;
                border-radius: 12px;
                padding: 20px;
                margin-bottom: 30px;
            }
            
            .api-config-notice h3 {
                color: #856404;
                margin-bottom: 15px;
            }
            
            .api-config-notice ol {
                margin-left: 20px;
            }
            
            .api-config-notice li {
                margin-bottom: 8px;
                color: #856404;
            }
            
            .api-config-notice code {
                background: #f8f9fa;
                padding: 2px 6px;
                border-radius: 4px;
                font-family: 'Monaco', 'Consolas', monospace;
            }
            
            /* Responsive Design */
            @media (max-width: 1024px) {
                .container { padding: 0 16px; }
                .options-grid { grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); }
            }
            
            @media (max-width: 768px) {
                .enhanced-analyzer-container { 
                    margin-top: 60px; 
                    padding: 16px 0; 
                }
                
                .analyzer-hero { 
                    padding: 40px 20px; 
                    margin-bottom: 40px; 
                }
                
                .analyzer-hero h1 { 
                    font-size: 2.2rem; 
                    margin-bottom: 12px; 
                }
                
                .analyzer-hero .subtitle { 
                    font-size: 1.1rem; 
                }
                
                .feature-tags { 
                    gap: 8px; 
                }
                
                .feature-tag { 
                    font-size: 0.8rem; 
                    padding: 6px 12px; 
                }
                
                .main-form-card { 
                    padding: 28px 20px; 
                }
                
                .url-input-section { 
                    padding: 24px; 
                }
                
                .analysis-info {
                    padding: 20px;
                    margin: 24px 0;
                }
                
                .analysis-info h3 {
                    font-size: 1rem;
                }
                
                .pagespeed-section,
                .seo-section {
                    padding: 24px 20px;
                }
                
                .section-main-title {
                    font-size: 1.5rem;
                }
                
                .pagespeed-overview {
                    flex-direction: column;
                    gap: 24px;
                    text-align: center;
                }
                
                .core-vitals {
                    grid-template-columns: 1fr;
                }
                
                .options-grid { 
                    grid-template-columns: 1fr; 
                    gap: 12px; 
                }
                
                .option-card { 
                    padding: 20px; 
                }
                
                .option-icon { 
                    width: 36px; 
                    height: 36px; 
                }
                
                .scores-overview { 
                    grid-template-columns: 1fr; 
                    gap: 16px; 
                }
                
                .score-breakdown { 
                    grid-template-columns: repeat(2, 1fr); 
                    gap: 8px; 
                }
                
                .detailed-results { 
                    gap: 20px; 
                }
                
                .result-section { 
                    padding: 24px 20px; 
                }
                
                .metrics-grid { 
                    grid-template-columns: 1fr; 
                    gap: 12px; 
                }
            }
            
            @media (max-width: 480px) {
                .analyzer-hero h1 { 
                    font-size: 1.8rem; 
                }
                
                .main-form-card { 
                    padding: 20px 16px; 
                }
                
                .url-input-section { 
                    padding: 20px; 
                }
                
                .option-card { 
                    padding: 16px; 
                }
                
                .option-header { 
                    gap: 10px; 
                }
                
                .option-icon { 
                    width: 32px; 
                    height: 32px; 
                }
                
                .analyze-button { 
                    padding: 16px 24px; 
                    font-size: 15px; 
                }
                
                .pagespeed-tabs {
                    flex-wrap: wrap;
                }
                
                .pagespeed-tab {
                    flex: 1;
                    text-align: center;
                }
                
                .score-circle {
                    width: 100px;
                    height: 100px;
                    font-size: 1.5rem;
                }
                
                .core-vitals {
                    grid-template-columns: 1fr;
                }
                
                .email-input-group {
                    flex-direction: column;
                    align-items: center;
                    gap: 16px;
                }
                
                .email-input {
                    min-width: 100%;
                    max-width: 100%;
                }
                
                .download-button {
                    min-width: 100%;
                }
            }
        </style>
        <?php salesnanny_nav_header(); ?>

        <div class="enhanced-analyzer-container">
            <div class="container">
                
                <?php 
                // Display API configuration notice if not configured
                if (!WebsiteAnalyzerConfig::isApiKeyConfigured()): 
                ?>
                <div class="api-config-notice">
                    <h3>⚠️ API Configuration Required</h3>
                    <p>To get real-time data from Google PageSpeed Insights, please configure your API key:</p>
                    <ol>
                        <li>Get a free API key from <a href="https://developers.google.com/speed/docs/insights/v5/get-started" target="_blank">Google PageSpeed Insights API</a></li>
                        <li>Add it to your wp-config.php: <code>define('GOOGLE_PAGESPEED_API_KEY', 'your-api-key');</code></li>
                        <li>Or edit the analyzer-config.php file</li>
                    </ol>
                    <p><strong>Benefits:</strong> Real Core Web Vitals, Performance scores, SEO audits, and optimization recommendations</p>
                </div>
                <?php endif; ?>

                <div class="analyzer-hero">
                    <h1> Website Performance Analyzer</h1>
                    <div class="subtitle">Boost your website’s potential with authentic PageSpeed Insights, expert SEO audits, and tailored optimization strategies.</div>
                    
                    <div class="feature-tags">
                        <span class="feature-tag">⚡ Core Web Vitals</span>
                        <span class="feature-tag">📱 Mobile & Desktop</span>
                        <span class="feature-tag">🔍 SEO Analysis</span>
                        <span class="feature-tag">🛡️ Security Check</span>
                        <span class="feature-tag">♿ Accessibility</span>
                    </div>
                </div>

                <div class="main-form-card">
                    <div class="form-header">
                        <h2>Website Performance Analyzer</h2>
                        <p>Get comprehensive PageSpeed and SEO analysis with just one click</p>
                    </div>

                    <form id="enhanced-analyzer-form">
                        <div class="url-input-section" id="url-section">
                            <div class="url-input-container" id="url-container">
                                <div class="url-input-group">
                                    <label for="website_url">🌐 Enter Your Website URL</label>
                                    <div class="url-input-wrapper">
                                        <input type="url" id="website_url" class="url-input" placeholder="https://example.com" required>
                                    </div>
                                    <div class="url-help-text">💡 Enter your complete website URL including https://</div>
                                </div>
                            </div>
                        </div>

                        <div class="analysis-info">
                            <div class="analysis-info-card">
                                <h3>📊 Comprehensive Analysis Features</h3>
                                <div class="analysis-features">
                                    <div class="feature-item"><strong>PageSpeed Insights</strong> - Real Google performance data for mobile & desktop</div>
                                    <div class="feature-item"><strong>SEO Analysis</strong> - Complete meta tags, structured data & optimization recommendations</div>
                                    <div class="feature-item"><strong>Security Audit</strong> - HTTPS status, security headers & vulnerability assessment</div>
                                    <div class="feature-item"><strong>Accessibility Check</strong> - WCAG compliance evaluation & usability insights</div>
                                </div>
                            </div>
                        </div>

                        <div class="analyze-button-container">
                            <button type="submit" class="analyze-button">
                                <div class="btn-content">
                                    <span>Start Analysis</span>
                                </div>
                            </button>
                        </div>
                    </form>
                </div>

                <div class="results-container" id="results-container">
                    <!-- Results will be dynamically inserted here -->
                </div>
            </div>
        </div>

        <!-- Loading Overlay -->
        <div class="loading-overlay" id="loading-overlay">
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <h3>Analyzing Your Website</h3>
                <p>Please wait while we gather data from multiple sources...</p>
                
                <div class="progress-steps">
                    <div class="progress-step" id="step-fetch">
                        📥
                        <span>Fetching website data...</span>
                    </div>
                    <div class="progress-step" id="step-pagespeed">
                        ⚡
                        <span>Running PageSpeed analysis...</span>
                    </div>
                    <div class="progress-step" id="step-seo">
                        🔍
                        <span>Analyzing SEO factors...</span>
                    </div>
                    <div class="progress-step" id="step-security">
                        🛡️
                        <span>Checking security headers...</span>
                    </div>
                    <div class="progress-step" id="step-complete">
                        ✅
                        <span>Compiling results...</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- jQuery CDN Fallback -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script>
            // Ensure jQuery is available
            if (typeof jQuery === 'undefined') {
                console.error('jQuery is not loaded');
            }
            
            // Use both jQuery and $ to ensure compatibility
            (function($) {
                if (typeof $ === 'undefined') {
                    console.error('$ is not defined');
                    return;
                }
                
                $(document).ready(function() {
                
                // Handle URL input focus states with advanced animations
                $('#website_url').on('focus', function() {
                    $('#url-container').addClass('focused');
                    $(this).closest('.url-input-wrapper').addClass('focused');
                }).on('blur', function() {
                    $('#url-container').removeClass('focused');
                    $(this).closest('.url-input-wrapper').removeClass('focused');
                });
                
                // Add floating label effect
                $('#website_url').on('input', function() {
                    if ($(this).val().length > 0) {
                        $(this).addClass('has-value');
                    } else {
                        $(this).removeClass('has-value');
                    }
                });

                // Form submission
                $('#enhanced-analyzer-form').on('submit', function(e) {
                    e.preventDefault();
                    
                    const url = $('#website_url').val().trim();
                    if (!url) {
                        alert('Please enter a website URL');
                        return;
                    }

                    // Validate URL format
                    try {
                        new URL(url);
                    } catch (e) {
                        alert('Please enter a valid URL (including http:// or https://)');
                        return;
                    }

                    // Automatically analyze all options
                    const options = {
                        analyze_mobile: true,
                        analyze_desktop: true,
                        analyze_seo: true,
                        analyze_security: true,
                        analyze_accessibility: true,
                        analyze_tech: true
                    };

                    startAnalysis(url, options);
                });

                function startAnalysis(url, options) {
                    // Show loading overlay
                    $('#loading-overlay').css('display', 'flex');
                    
                    // Reset progress steps
                    $('.progress-step').removeClass('active completed');
                    
                    // Start the analysis
                    performEnhancedAnalysis(url, options);
                }

                function updateProgressStep(stepId, status = 'active') {
                    $('.progress-step').removeClass('active');
                    
                    if (status === 'completed') {
                        $('#' + stepId).addClass('completed');
                    } else {
                        $('#' + stepId).addClass('active');
                    }
                }

                function performEnhancedAnalysis(url, options) {
                    updateProgressStep('step-fetch');
                    
                    const ajaxData = {
                            action: 'enhanced_website_analysis',
                            url: url,
                            options: options,
                            nonce: '<?php echo wp_create_nonce('enhanced_analysis_nonce'); ?>'
                    };
                    
                    console.log('Sending AJAX request:', ajaxData);
                    
                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: ajaxData,
                        success: function(response) {
                            updateProgressStep('step-complete', 'completed');
                            console.log('Analysis response:', response);
                            
                            setTimeout(() => {
                                $('#loading-overlay').hide();
                                
                                if (response.success) {
                                    if (Object.keys(response.data).length > 2) { // More than just url and timestamp
                                    displayEnhancedResults(response.data);
                                } else {
                                        console.warn('API returned empty results. Check debug logs for API errors.');
                                        alert('Analysis completed but no data was returned. This may be due to API issues. Please check the debug logs.');
                                    }
                                } else {
                                    console.error('Analysis failed:', response);
                                    alert('Analysis failed: ' + (response.data || 'Unknown error'));
                                }
                            }, 1000);
                        },
                        error: function(xhr, status, error) {
                            $('#loading-overlay').hide();
                            console.error('AJAX error:', {xhr: xhr, status: status, error: error});
                            console.error('Response text:', xhr.responseText);
                            alert('An error occurred during analysis. Please try again.');
                        }
                    });

                    // Simulate progress steps
                    setTimeout(() => updateProgressStep('step-pagespeed'), 2000);
                    setTimeout(() => updateProgressStep('step-seo'), 4000);
                    setTimeout(() => updateProgressStep('step-security'), 6000);
                }

                function displayEnhancedResults(data) {
                    const resultsHtml = generateEnhancedResultsHTML(data);
                    $('#results-container').html(resultsHtml).show();
                    
                    // Smooth scroll to results
                    $('html, body').animate({
                        scrollTop: $('#results-container').offset().top - 100
                    }, 800);
                }

                function generateEnhancedResultsHTML(data) {
                    let html = `
                        <div class="results-header">
                            <h2>📊 Analysis Results</h2>
                            <div class="analyzed-url">${data.url}</div>
                            <div class="analysis-timestamp">Analyzed on ${new Date(data.timestamp * 1000).toLocaleDateString()} at ${new Date(data.timestamp * 1000).toLocaleTimeString()}</div>
                        </div>
                        
                        <div class="download-button-container">
                            <div class="email-collection-section" id="email-collection">
                                <h3>📧 Get Your PDF Report</h3>
                                <p>Enter your email to download the comprehensive analysis report and receive it via email</p>
                                <div class="email-input-group">
                                    <input type="email" id="user-email" class="email-input" placeholder="your.email@example.com" required>
                                    <button class="download-button" id="download-pdf-btn" data-analysis='${JSON.stringify(data).replace(/'/g, "&apos;")}'>
                                        <div class="download-btn-content">
                                            <svg class="download-btn-icon" style="width: 20px; height: 20px;" viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                                            </svg>
                                            <span>Download PDF Report</span>
                                        </div>
                                    </button>
                                </div>
                                <div class="download-info">
                                    📄 Generate a comprehensive PDF report with SalesNanny branding<br>
                                    🔒 Your email is secure and will only be used for notifications
                                </div>
                            </div>
                        </div>
                    `;

                    // 1. PageSpeed Performance Overview - Google-style tabs
                    if (data.mobile || data.desktop) {
                        html += `
                            <div class="pagespeed-section">
                                <h2 class="section-main-title">⚡ Google PageSpeed Insights</h2>
                                <p class="section-subtitle">Real performance data from Google's official PageSpeed API</p>
                                
                                <div class="pagespeed-tabs">`;
                        
                        if (data.mobile) {
                            html += `<div class="pagespeed-tab active" data-tab="mobile">
                                📱 Mobile
                            </div>`;
                        }
                        
                        if (data.desktop) {
                            html += `<div class="pagespeed-tab ${!data.mobile ? 'active' : ''}" data-tab="desktop">
                                🖥️ Desktop
                            </div>`;
                        }
                        
                        html += `</div>`;
                        
                        if (data.mobile) {
                            html += `
                                <div class="pagespeed-content active" id="mobile-content">
                                    ${generateGoogleStyleContent('Mobile', data.mobile)}
                                </div>`;
                        }
                        
                        if (data.desktop) {
                            html += `
                                <div class="pagespeed-content ${!data.mobile ? 'active' : ''}" id="desktop-content">
                                    ${generateGoogleStyleContent('Desktop', data.desktop)}
                                </div>`;
                        }
                        
                        html += `</div>`;
                    }

                    // 2. SEO Analysis Section
                    if (data.seo) {
                        html += `
                            <div class="seo-section">
                                <h2 class="section-main-title">🔍 SEO Analysis</h2>
                                <p class="section-subtitle">Search engine optimization insights and recommendations</p>
                                ${generateSEOSection(data.seo)}
                            </div>`;
                    }
                    
                    // 3. Accessibility Analysis Section
                    if (data.accessibility) {
                        html += `
                            <div class="accessibility-section">
                                <h2 class="section-main-title">♿ Accessibility Analysis</h2>
                                <p class="section-subtitle">WCAG compliance and usability evaluation for all users</p>
                                ${generateAccessibilitySection(data.accessibility)}
                            </div>`;
                    }
                    
                    // 3. Additional Analysis (Security, etc.)
                    html += `<div class="additional-analysis">`;
                    
                    if (data.security) {
                        html += generateSecuritySection(data.security);
                    }
                    
                    html += `</div>`;
                    
                    return html;
                }

                function generateGoogleStyleContent(device, data) {
                    const score = data.performance?.score || 0;
                    const scoreClass = getScoreClass(score);
                    
                    return `
                        <div class="pagespeed-overview">
                            <div class="score-gauge">
                                <div class="score-circle ${scoreClass}">
                                    ${score}
                                    <div class="score-tooltip">Performance Score: ${score}%</div>
                                </div>
                            </div>
                            <div class="score-details">
                                <div class="score-title">${device} Performance</div>
                                <div class="score-description">
                                    ${getScoreDescription(score)}
                                </div>
                                <div class="core-vitals">
                                    ${data.metrics ? Object.entries(data.metrics).slice(0, 6).map(([key, metric]) => {
                                        const status = getMetricStatus(metric.score);
                                        const statusClass = status.replace('status-', 'vital-');
                                        return `
                                            <div class="vital-metric">
                                                <div class="vital-icon ${statusClass}">
                                                    ${getVitalIcon(metric.score)}
                                                </div>
                                                <div class="vital-info">
                                                    <div class="vital-label">${formatMetricName(key)}</div>
                                                    <div class="vital-value">${metric.displayValue || 'N/A'}</div>
                                                </div>
                                            </div>
                                        `;
                                    }).join('') : ''}
                                </div>
                            </div>
                        </div>
                        
                        ${data.opportunities && data.opportunities.length > 0 ? `
                            <div class="opportunities-section">
                                <h4>🚀 Optimization Opportunities</h4>
                                <div class="opportunities-list">
                                    ${data.opportunities.map(opp => `
                                        <div class="opportunity-item ${getOpportunityClass(opp.impact)}">
                                            <div class="opportunity-header">
                                                <div class="opportunity-title-row">
                                                    <h5 class="opportunity-title">${opp.title}</h5>
                                                    <div class="opportunity-impact" style="color: ${opp.impactColor}">
                                                        <span class="impact-label">${opp.impact} Impact</span>
                                                        <span class="opportunity-score">${Math.round((1 - opp.score) * 100)}%</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="opportunity-description">${opp.description}</div>
                                            ${(opp.savings?.time || opp.savings?.size || opp.displayValue) ? `
                                                <div class="opportunity-savings">
                                                    <span class="savings-label">💾 Potential Savings:</span>
                                                    <div class="savings-details">
                                                        ${opp.savings.time ? `<span class="saving-item time">⏱️ ${opp.savings.time}</span>` : ''}
                                                        ${opp.savings.size ? `<span class="saving-item size">📦 ${opp.savings.size}</span>` : ''}
                                                        ${opp.displayValue && !opp.savings.time && !opp.savings.size ? `<span class="saving-item value">📊 ${opp.displayValue}</span>` : ''}
                                                    </div>
                                                </div>
                                            ` : ''}
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}
                    `;
                }

                function generatePerformanceSection(title, data, iconType) {
                    const iconSvg = iconType === 'mobile' ? 
                        `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 2C5.9 2 5 2.9 5 4V20C5 21.1 5.9 22 7 22H17C18.1 22 19 21.1 19 20V4C19 2.9 18.1 2 17 2H7M7 4H17V20H7V4Z"/></svg>` :
                        `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21,16V4H3V16H21M21,2A2,2 0 0,1 23,4V16A2,2 0 0,1 21,18H14L16,21V22H8V21L10,18H3C1.89,18 1,17.1 1,16V4C1,2.89 1.89,2 3,2H21Z"/></svg>`;
                    
                    return `
                        <div class="result-section">
                            <div class="section-header">
                                <div class="section-icon">${iconSvg}</div>
                                <h3 class="section-title">${title}</h3>
                            </div>
                            
                            ${data.metrics ? `
                                <div class="metrics-grid">
                                    ${Object.entries(data.metrics).map(([key, metric]) => `
                                        <div class="metric-item">
                                            <div class="metric-label">${formatMetricName(key)}</div>
                                            <div class="metric-value">${metric.displayValue || 'N/A'}</div>
                                            <div class="metric-status ${getMetricStatus(metric.score)}">${getMetricStatusText(metric.score)}</div>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : ''}
                            
                            ${data.opportunities && data.opportunities.length > 0 ? `
                                <h4>💡 Optimization Opportunities</h4>
                                <ul class="recommendations-list">
                                    ${data.opportunities.slice(0, 5).map(opp => `
                                        <li class="recommendation-item">
                                            <div class="recommendation-title">${opp.title}</div>
                                            <div class="recommendation-description">${opp.description || ''}</div>
                                            ${opp.details?.savings ? `<div class="recommendation-impact">Potential savings: ${opp.details.savings}</div>` : ''}
                                        </li>
                                    `).join('')}
                                </ul>
                            ` : ''}
                        </div>
                    `;
                }

                function generateSEOSection(data) {
                    return `
                        <div class="result-section">
                            <div class="section-header">
                                <div class="section-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"/></svg></div>
                                <h3 class="section-title">SEO Analysis</h3>
                            </div>
                            
                            <div class="seo-overview">
                                <div class="seo-score-display">
                                    <div class="score-circle ${getScoreClass(data.score)}" style="width: 100px; height: 100px;">
                                        ${data.score !== undefined && data.score !== null ? data.score : 'N/A'}
                                    </div>
                                    <div class="seo-score-details">
                                        <h4>Overall SEO Score</h4>
                                        <p>${getSEOScoreDescription(data.score)}</p>
                                    </div>
                                </div>
                            </div>
                            
                            ${data.audits ? `
                                <div class="seo-audits">
                                    <h4>📋 SEO Audit Results</h4>
                                    <div class="seo-audit-grid">
                                        ${Object.entries(data.audits).map(([key, audit]) => {
                                            const status = audit.score >= 0.9 ? 'pass' : (audit.score >= 0.5 ? 'warning' : 'fail');
                                            const percentage = Math.round(audit.score * 100);
                                            
                                            return `
                                                <div class="seo-audit-item ${status}">
                                                    <div class="audit-header">
                                                        <div class="audit-icon check-${status}">
                                                            ${audit.score >= 0.9 ? 
                                                                '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>' : 
                                                                audit.score >= 0.5 ? 
                                                                    '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1,21H23L12,2M13,18H11V16H13M13,14H11V10H13"/></svg>' :
                                                                    '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/></svg>'
                                                            }
                                                        </div>
                                                        <div class="audit-info">
                                                            <h5>${audit.title}</h5>
                                                            <span class="audit-score">${percentage}%</span>
                                                        </div>
                                                    </div>
                                                    <div class="audit-description">
                                                        ${audit.description}
                                                    </div>
                                                    ${audit.details ? generateAuditDetails(key, audit.details) : ''}
                                                </div>
                                            `;
                                        }).join('')}
                                    </div>
                                </div>
                            ` : ''}
                        </div>
                    `;
                }
                
                function getSEOScoreDescription(score) {
                    if (score >= 90) return 'Excellent SEO optimization! Your page follows most best practices.';
                    if (score >= 70) return 'Good SEO foundation with room for improvement.';
                    if (score >= 50) return 'Basic SEO present but needs significant optimization.';
                    return 'Poor SEO - immediate attention required for better search visibility.';
                }
                
                function generateAuditDetails(auditType, details) {
                    if (auditType === 'title' && details.content) {
                        return `<div class="audit-detail">Current title: "<em>${details.content}</em>" (${details.length} characters)</div>`;
                    }
                    
                    if (auditType === 'meta-description' && details.content) {
                        return `<div class="audit-detail">Current description: "<em>${details.content}</em>" (${details.length} characters)</div>`;
                    }
                    
                    if (auditType === 'headings' && details) {
                        const headingsList = Object.entries(details).map(([tag, count]) => `${tag.toUpperCase()}: ${count}`).join(', ');
                        return `<div class="audit-detail">Heading structure: ${headingsList}</div>`;
                    }
                    
                    if (auditType === 'images' && details) {
                        return `<div class="audit-detail">Images: ${details.total} total, ${details.without_alt} missing alt text</div>`;
                    }
                    
                    if (auditType === 'social-meta' && details) {
                        const socialInfo = [];
                        if (details.open_graph && Object.keys(details.open_graph).length > 0) {
                            socialInfo.push(`Open Graph: ${Object.keys(details.open_graph).length} tags`);
                        }
                        if (details.twitter && Object.keys(details.twitter).length > 0) {
                            socialInfo.push(`Twitter: ${Object.keys(details.twitter).length} tags`);
                        }
                        return socialInfo.length > 0 ? `<div class="audit-detail">${socialInfo.join(', ')}</div>` : '';
                    }
                    
                    return '';
                }

                function generateAccessibilitySection(data) {
                    return `
                        <div class="result-section">
                            <div class="section-header">
                                <div class="section-icon">
                                    <svg viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4M12,6A6,6 0 0,0 6,12A6,6 0 0,0 12,18A6,6 0 0,0 18,12A6,6 0 0,0 12,6M12,8A4,4 0 0,1 16,12A4,4 0 0,1 12,16A4,4 0 0,1 8,12A4,4 0 0,1 12,8Z"/>
                                    </svg>
                                </div>
                                <h3 class="section-title">Accessibility Analysis</h3>
                            </div>
                            
                            <div class="accessibility-overview">
                                <div class="accessibility-score-display">
                                    <div class="score-circle ${getScoreClass(data.score)}" style="width: 100px; height: 100px;">
                                        ${data.score !== undefined && data.score !== null ? data.score : 'N/A'}
                                    </div>
                                    <div class="accessibility-score-details">
                                        <h4>Accessibility Score</h4>
                                        <p>${getAccessibilityScoreDescription(data.score)}</p>
                                        <div class="wcag-info">
                                            <small>Based on WCAG 2.1 guidelines</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            ${data.audits ? `
                                <div class="accessibility-audits">
                                    <h4>♿ WCAG Compliance Checklist</h4>
                                    <div class="accessibility-audit-grid">
                                        ${Object.entries(data.audits).map(([key, audit]) => {
                                            const status = audit.score >= 0.9 ? 'pass' : (audit.score >= 0.5 ? 'warning' : 'fail');
                                            const percentage = Math.round(audit.score * 100);
                                            
                                            return `
                                                <div class="accessibility-audit-item ${status}">
                                                    <div class="audit-header">
                                                        <div class="audit-icon accessibility-${status}">
                                                            ${audit.score >= 0.9 ? 
                                                                '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>' : 
                                                                audit.score >= 0.5 ? 
                                                                    '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1,21H23L12,2M13,18H11V16H13M13,14H11V10H13"/></svg>' :
                                                                    '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/></svg>'
                                                            }
                                                        </div>
                                                        <div class="audit-info">
                                                            <h5>${audit.title}</h5>
                                                            <span class="audit-score">${percentage}%</span>
                                                        </div>
                                                    </div>
                                                    <div class="audit-description">
                                                        ${audit.description}
                                                    </div>
                                                    ${audit.details ? generateAccessibilityAuditDetails(key, audit.details) : ''}
                                                </div>
                                            `;
                                        }).join('')}
                                    </div>
                                    
                                    ${data.suggestions ? `
                                        <div class="accessibility-recommendations">
                                            <h4>🔧 Accessibility Action Plan</h4>
                                            <div class="suggestions-container">
                                                ${data.suggestions.critical && data.suggestions.critical.length > 0 ? `
                                                    <div class="suggestion-category critical">
                                                        <h5>🚨 Critical Issues (Fix Immediately)</h5>
                                                        <ul>
                                                            ${data.suggestions.critical.map(suggestion => `<li>${suggestion}</li>`).join('')}
                                                        </ul>
                                                    </div>
                                                ` : ''}
                                                
                                                ${data.suggestions.important && data.suggestions.important.length > 0 ? `
                                                    <div class="suggestion-category important">
                                                        <h5>⚠️ Important Improvements</h5>
                                                        <ul>
                                                            ${data.suggestions.important.map(suggestion => `<li>${suggestion}</li>`).join('')}
                                                        </ul>
                                                    </div>
                                                ` : ''}
                                                
                                                ${data.suggestions.recommended && data.suggestions.recommended.length > 0 ? `
                                                    <div class="suggestion-category recommended">
                                                        <h5>✅ Recommended Enhancements</h5>
                                                        <ul>
                                                            ${data.suggestions.recommended.map(suggestion => `<li>${suggestion}</li>`).join('')}
                                                        </ul>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        </div>
                                    ` : `
                                        <div class="accessibility-recommendations">
                                            <h4>🔧 General Accessibility Guidelines</h4>
                                            <div class="recommendations-grid">
                                                <div class="recommendation-card">
                                                    <h5>🖼️ Images & Media</h5>
                                                    <ul>
                                                        <li>Add descriptive alt text to all images</li>
                                                        <li>Provide captions for videos</li>
                                                        <li>Use proper image formats</li>
                                                    </ul>
                                                </div>
                                                <div class="recommendation-card">
                                                    <h5>📝 Forms & Navigation</h5>
                                                    <ul>
                                                        <li>Label all form inputs properly</li>
                                                        <li>Ensure keyboard navigation works</li>
                                                        <li>Use clear link text</li>
                                                    </ul>
                                                </div>
                                                <div class="recommendation-card">
                                                    <h5>🎨 Design & Layout</h5>
                                                    <ul>
                                                        <li>Maintain sufficient color contrast</li>
                                                        <li>Use proper heading hierarchy</li>
                                                        <li>Make text resizable</li>
                                                    </ul>
                                                </div>
                                                <div class="recommendation-card">
                                                    <h5>🤖 Screen Readers</h5>
                                                    <ul>
                                                        <li>Use semantic HTML elements</li>
                                                        <li>Add ARIA labels where needed</li>
                                                        <li>Provide skip navigation links</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    `}
                                </div>
                            ` : ''}
                        </div>
                    `;
                }
                
                function getAccessibilityScoreDescription(score) {
                    if (score >= 90) return 'Excellent accessibility! Your site is highly usable for people with disabilities.';
                    if (score >= 70) return 'Good accessibility foundation with some areas for improvement.';
                    if (score >= 50) return 'Basic accessibility present but significant improvements needed.';
                    return 'Poor accessibility - immediate attention required for WCAG compliance.';
                }
                
                function generateAccessibilityAuditDetails(auditType, details) {
                    if (auditType === 'images' && details) {
                        return `<div class="audit-detail">Images: ${details.total} total, ${details.missing} missing alt text</div>`;
                    }
                    
                    if (auditType === 'heading-order' && details) {
                        const headingsList = Object.entries(details).map(([level, count]) => `H${level}: ${count}`).join(', ');
                        return `<div class="audit-detail">Heading structure: ${headingsList}</div>`;
                    }
                    
                    if (auditType === 'form-labels' && details) {
                        return `<div class="audit-detail">Form inputs: ${details.total_inputs} total, ${details.labeled} properly labeled</div>`;
                    }
                    
                    if (auditType === 'link-text' && details) {
                        return `<div class="audit-detail">Links: ${details.total_links} total, ${details.poor_text} with poor text</div>`;
                    }
                    
                    if (auditType === 'aria-usage' && details) {
                        return `<div class="audit-detail">ARIA enhanced elements: ${details.elements_with_aria}</div>`;
                    }
                    
                    return '';
                }

                function generateSecuritySection(data) {
                    return `
                        <div class="result-section">
                            <div class="section-header">
                                <div class="section-icon"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.4,7 14.8,8.6 14.8,10V11.5C15.4,11.5 16,12.4 16,13V16C16,17.4 15.4,18 14.8,18H9.2C8.6,18 8,17.4 8,16V13C8,12.4 8.6,11.5 9.2,11.5V10C9.2,8.6 10.6,7 12,7M12,8.2C11.2,8.2 10.5,8.7 10.5,10V11.5H13.5V10C13.5,8.7 12.8,8.2 12,8.2Z"/></svg></div>
                                <h3 class="section-title">Security Analysis</h3>
                            </div>
                            
                            <div class="security-grid">
                                <div class="security-item ${data.https ? 'security-pass' : 'security-fail'}">
                                    ${data.https ? 
                                        '<svg viewBox="0 0 24 24" fill="currentColor" style="width: 16px; height: 16px;"><path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>' : 
                                        '<svg viewBox="0 0 24 24" fill="currentColor" style="width: 16px; height: 16px;"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/></svg>'
                                    }
                                    HTTPS ${data.https ? 'Enabled' : 'Not Enabled'}
                                </div>
                                
                                ${data.headers ? data.headers.map(header => `
                                    <div class="security-item ${header.present ? 'security-pass' : 'security-fail'}">
                                        ${header.present ? 
                                            '<svg viewBox="0 0 24 24" fill="currentColor" style="width: 16px; height: 16px;"><path d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>' : 
                                            '<svg viewBox="0 0 24 24" fill="currentColor" style="width: 16px; height: 16px;"><path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/></svg>'
                                        }
                                        ${header.name}
                                    </div>
                                `).join('') : ''}
                            </div>
                        </div>
                    `;
                }

                function getScoreClass(score) {
                    if (score === undefined || score === null) return 'score-poor';
                    if (score >= 90) return 'score-excellent';
                    if (score >= 70) return 'score-good';
                    if (score >= 50) return 'score-average';
                    return 'score-poor';
                }

                function getMetricStatus(score) {
                    if (score === undefined || score === null) return 'status-poor';
                    if (score >= 0.9) return 'status-good';
                    if (score >= 0.5) return 'status-needs-improvement';
                    return 'status-poor';
                }

                function getMetricStatusText(score) {
                    if (score === undefined || score === null) return 'Poor';
                    if (score >= 0.9) return 'Good';
                    if (score >= 0.5) return 'Needs Improvement';
                    return 'Poor';
                }

                function formatMetricName(key) {
                    return key.split('-').map(word => 
                        word.charAt(0).toUpperCase() + word.slice(1)
                    ).join(' ');
                }
                
                function getScoreDescription(score) {
                    if (score >= 90) return 'This page performs exceptionally well! Keep up the great work.';
                    if (score >= 70) return 'This page has good performance but could be improved.';
                    if (score >= 50) return 'This page has average performance and needs optimization.';
                    return 'This page has poor performance and requires immediate attention.';
                }
                
                function getVitalIcon(score) {
                    if (score === undefined || score === null) return '!';
                    if (score >= 0.9) return '✓';
                    if (score >= 0.5) return '⚠';
                    return '✗';
                }
                
                function getOpportunityClass(impact) {
                    switch(impact) {
                        case 'High': return 'opportunity-high';
                        case 'Medium': return 'opportunity-medium';
                        case 'Low': return 'opportunity-low';
                        default: return 'opportunity-medium';
                    }
                }
                
                // Tab switching functionality
                $(document).on('click', '.pagespeed-tab', function() {
                    const tab = $(this).data('tab');
                    
                    // Update active tab
                    $('.pagespeed-tab').removeClass('active');
                    $(this).addClass('active');
                    
                    // Update active content
                    $('.pagespeed-content').removeClass('active');
                    $(`#${tab}-content`).addClass('active');
                });
                
                // PDF Download functionality
                $(document).on('click', '#download-pdf-btn', function(e) {
                    e.preventDefault();
                    
                    const button = $(this);
                    const originalText = button.find('span').text();
                    
                    // Validate email first
                    const userEmail = $('#user-email').val().trim();
                    if (!userEmail) {
                        showNotification('📧 Please enter your email address', 'error');
                        $('#user-email').focus();
                        return;
                    }
                    
                    // Validate email format
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(userEmail)) {
                        showNotification('📧 Please enter a valid email address', 'error');
                        $('#user-email').focus();
                        return;
                    }
                    
                    // Disable button and show loading state
                    button.prop('disabled', true);
                    button.find('span').text('Generating PDF...');
                    button.find('.download-btn-icon').html(`
                        <svg style="width: 20px; height: 20px; animation: spin 1s linear infinite;" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12,4V2A10,10 0 0,0 2,12H4A8,8 0 0,1 12,4Z"/>
                        </svg>
                    `);
                    
                    try {
                        // Get analysis data from the button's data attribute
                        const analysisData = JSON.parse(button.attr('data-analysis'));
                        
                        // Create form data for PDF generation
                        const formData = new FormData();
                        formData.append('action', 'generate_analyzer_pdf_report');
                        formData.append('analysis_data', JSON.stringify(analysisData));
                        formData.append('user_email', userEmail);
                        formData.append('nonce', '<?php echo wp_create_nonce('pdf_generation_nonce'); ?>');
                        
                        // Send request to generate PDF
                        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            
                            // Download as PDF blob
                            return response.blob().then(blob => {
                                // Create download link
                                const url = window.URL.createObjectURL(blob);
                                const a = document.createElement('a');
                                a.style.display = 'none';
                                a.href = url;
                                
                                // Generate filename with timestamp
                                const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
                                const domain = analysisData.url.replace(/^https?:\/\//, '').replace(/[^a-zA-Z0-9]/g, '-');
                                a.download = `salesnanny-website-analysis-${domain}-${timestamp}.pdf`;
                                
                                document.body.appendChild(a);
                                a.click();
                                window.URL.revokeObjectURL(url);
                                document.body.removeChild(a);
                                
                                // Show success message
                                showNotification('✅ PDF report downloaded successfully! Check your email for the attached report.', 'success');
                                
                                // Reset the page after successful download
                                setTimeout(() => {
                                    resetAnalyzerPage();
                                }, 2000); // Wait 2 seconds to show success message
                            });
                        })
                        .catch(error => {
                            console.error('PDF generation error:', error);
                            showNotification('❌ Failed to generate PDF. Please try again.', 'error');
                        })
                        .finally(() => {
                            // Reset button state
                            button.prop('disabled', false);
                            button.find('span').text(originalText);
                            button.find('.download-btn-icon').html(`
                                <svg style="width: 20px; height: 20px;" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z"/>
                                </svg>
                            `);
                        });
                    } catch (error) {
                        console.error('Error parsing analysis data:', error);
                        showNotification('❌ Error processing analysis data', 'error');
                        
                        // Reset button state
                        button.prop('disabled', false);
                        button.find('span').text(originalText);
                    }
                });
                
                // Notification helper function
                function showNotification(message, type = 'info') {
                    // Remove existing notifications
                    $('.notification').remove();
                    
                    const notification = $(`
                        <div class="notification notification-${type}" style="
                            position: fixed;
                            top: 20px;
                            right: 20px;
                            z-index: 10000;
                            padding: 16px 24px;
                            border-radius: 8px;
                            color: white;
                            font-weight: 500;
                            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                            transform: translateX(400px);
                            transition: transform 0.3s ease;
                            ${type === 'success' ? 'background: #10b981;' : 'background: #ef4444;'}
                        ">
                            ${message}
                        </div>
                    `);
                    
                    $('body').append(notification);
                    
                    // Animate in
                    setTimeout(() => {
                        notification.css('transform', 'translateX(0)');
                    }, 100);
                    
                    // Auto remove after 4 seconds
                    setTimeout(() => {
                        notification.css('transform', 'translateX(400px)');
                        setTimeout(() => notification.remove(), 300);
                    }, 4000);
                }
                
                // Function to reset the analyzer page to initial state
                function resetAnalyzerPage() {
                    // Hide results container
                    $('#results-container').hide().empty();
                    
                    // Clear the URL input
                    $('#website_url').val('').removeClass('has-value');
                    
                    // Reset URL container focus states
                    $('#url-container').removeClass('focused');
                    $('.url-input-wrapper').removeClass('focused');
                    
                    // Smooth scroll back to the top of the form
                    $('html, body').animate({
                        scrollTop: $('#enhanced-analyzer-form').offset().top - 100
                    }, 800);
                    
                    // Show a friendly message
                    showNotification('🔄 Ready for your next website analysis!', 'success');
                }
                
                // All icons are now clean SVG - no external dependencies needed!
                });
            })(jQuery);
        </script>
        <?php salesnanny_footer(); ?>
    </div>
</body>
</html>
<?php
// AJAX handlers and all analyzer functions are now handled in analyzer-functions.php
// This keeps the template clean and ensures handlers are always available globally
